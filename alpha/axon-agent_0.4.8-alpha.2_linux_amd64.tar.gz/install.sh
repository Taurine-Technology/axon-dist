#!/usr/bin/env bash
set -Eeuo pipefail

usage() {
    cat <<'USAGE'
Usage: install.sh [operation] [options]

Operations (default: install):
  (none)                         Transactional install/upgrade of the agent.
  --update                       A/B atomic update: stage the new payload into
                                 the INACTIVE slot, validate it, flip `current`,
                                 restart, post-swap health check, and revert the
                                 symlink + restart on any failure.
  --uninstall                    Stop+disable both units, remove the unit files,
                                 remove /opt/axon-agent, and run marker-guarded
                                 OVS cleanup. Preserves /etc/axon and
                                 /var/lib/axon by default.
  --purge                        Imply --uninstall and additionally wipe
                                 /etc/axon (bootstrap.json, classifier_config.json)
                                 and /var/lib/axon state.

Options:
  --enrollment-token TOKEN       Enroll and write /etc/axon/bootstrap.json.
  --controller-url URL           Controller base URL for enrollment.
                                 Default: https://controller.axon.local
  --primary-interface IFACE      Interface hint sent with enrollment. Validated
                                 to exist on the host at preflight; a typo aborts
                                 the install (PRIMARY_IFACE_NOT_FOUND).
  --deployment-mode MODE         "switching" (default) or "mirror". "mirror"
                                 writes /etc/axon/classifier_config.json
                                 (deployment_mode=mirror) and enables + starts the
                                 axon-agent-classifier service. Promiscuous/monitor
                                 mode on the capture NIC is the operator's
                                 responsibility; the installer does not modify NIC
                                 state. Switching mode leaves the classifier to the
                                 controller (started after OVS bridge provisioning).
  --monitor-interface IFACE      SPAN/mirror capture NIC (required for mirror).
                                 Validated at preflight: must exist
                                 (MIRROR_IFACE_NOT_FOUND), and a loud WARNING is
                                 emitted if it is administratively down
                                 (MIRROR_IFACE_DOWN) or not in promiscuous mode
                                 (MIRROR_IFACE_NOT_PROMISC). NIC state stays
                                 operator-managed; the installer only inspects it.
  --site-id ID                   Mirror site_id; defaults to the enrollment
                                 response site_id from bootstrap.json.
  --device-id ID                 Mirror device_id; defaults to the
                                 primary-interface MAC (lowercase, colon-form).
  --channel CHANNEL              Release stream to record on the host: one of
                                 alpha|beta|main (default main). Persisted to
                                 /etc/axon/agent.env so the agent's self-update
                                 default resolves this channel's release index.
                                 An invalid value aborts (exit 2).
  --download-base URL            Release download base (e.g. the CDN/file server
                                 root). With --channel CH the installer records
                                 AXON_UPDATE_INDEX_URL=<base>/<CH>/index.json so
                                 a controller-omitted update resolves this
                                 channel. Defaults to $AXON_DOWNLOAD_BASE.
  --qos-tier TIER                OVERRIDE the Smart Uplink platform tier for
                                 this device (e.g. a lab/campaign tier). NOT
                                 needed on approved hardware: since v0.4.2 the
                                 agent itself self-activates Pi 4B/5B,
                                 ROCK 4SE, and Protectli V1410 from embedded
                                 evidence rows, so plain installs and updates
                                 need no QoS fields at all. Requires
                                 --qos-max-rate-kbit and
                                 --qos-max-memlimit-bytes: the tuple is
                                 all-or-none — the agent refuses to start on a
                                 partial tuple. Written to the systemd drop-in
                                 axon-agent.service.d/20-qos-tier.conf
                                 (installer-owned: uninstall removes it; place
                                 manual tuples in 50-qos-tier-operator.conf
                                 instead). Explicit flags abort if another
                                 source already assigns activation-tuple keys.
  --qos-max-rate-kbit KBIT       Maximum safe shaped rate measured for this
                                 device tier, in kbit/s (1..100000000).
  --qos-max-memlimit-bytes BYTES Maximum queue memory validated for this device
                                 tier, in bytes (1048576..1073741824).
  --migrate-python               Force legacy Python-agent migration.
  -h, --help                     Show this help.

Transactionality:
  install and update record every mutation (dirs, files, symlinks, unit installs,
  enables, legacy-unit removals, OVS flow deletes) in a rollback journal. A
  `trap` on ERR/EXIT replays the journal in reverse (install) or reverts the
  `current` symlink + restarts (update) on any failure. Update rollback verifies
  both locally-managed services after restoring the previous slot and emits a
  failed rollback state if restart or health verification is incomplete. All
  operations are idempotent and safe to re-run.

Lifecycle steps (names are stable so they can later be streamed as
LifecycleProgress events; status is one of started|ok|warn|failed|rolled_back):
  install:   preflight, migrate_python, install_payload, write_channel,
             write_bootstrap, write_classifier_config, enable_units,
             health_check
             (preflight validates the operator-supplied NIC names before any
             mutation: a missing primary/monitor NIC aborts; a down or
             non-promiscuous monitor NIC warns but proceeds.)
  update:    write_channel (only when --channel/--download-base given), download,
             verify_checksum, stage_inactive_slot, validate_slot, swap_current,
             restart, post_swap_health_check
  uninstall: stop_units, disable_units, remove_units, remove_opt, ovs_cleanup,
             purge
  rollback:  revert_journal (install), revert_symlink (update)
  error_code (failed/warn/rolled_back): DOWNLOAD_FAILED, CHECKSUM_MISMATCH,
             HEALTH_CHECK_FAILED, ENROLL_FAILED, PRIMARY_IFACE_NOT_FOUND,
             MIRROR_IFACE_NOT_FOUND, MIRROR_IFACE_DOWN, MIRROR_IFACE_NOT_PROMISC

Environment:
  AXON_ROOT                      Install root for tests/images. Default: /
  AXON_CHANNEL                   Default release stream when --channel is omitted
                                 (alpha|beta|main; default main).
  AXON_DOWNLOAD_BASE             Default release download base when
                                 --download-base is omitted.
  AXON_PACKAGE_DIR               Directory containing axon-agent, lib/, systemd/.
                                 Default: directory containing this installer.
                                 Also the default --update payload source.
  AXON_MANAGED_BRIDGES           Space-separated bridge list to flush on
                                 migration and uninstall.
  AXON_SKIP_APT=1                Do not install missing apt prerequisites.
  AXON_AGENT_URL                 --update only: tarball URL to download when no
                                 staged payload is present (file:// supported).
  AXON_UPDATE_PACKAGE_DIR        --update only: staged payload dir override.
  AXON_UPDATE_SHA256             --update only: expected sha256 of the staged
                                 axon-agent binary (verify_checksum step).
  AXON_FAIL_AT=STEP              Test-only fault injection: force a failure right
                                 after the named lifecycle step to exercise
                                 rollback.
USAGE
}

log() {
    printf 'axon-install: %s\n' "$*" >&2
}

# ── Lifecycle step emission (names only; no streaming here) ──────────────────
# Emits one structured line per step keyed by the shared LifecycleProgress
# vocabulary (operation_id, op_type, step, status, seq, ts, message, error_code)
# so the live-streaming work can later forward these as MQTT events without
# re-architecting this script.
OP_ID=""
OP_TYPE=""
LIFECYCLE_SEQ=0
LAST_ERROR_CODE=""
# CURRENT_STEP tracks the in-flight step (started but not yet ok/warn/failed) so
# on_err can report WHICH step failed when `set -e` jumps straight into the trap
# from a mid-step command failure (e.g. write_bootstrap, verify_update_checksum,
# validate_slot) before a `failed` event would otherwise be emitted.
CURRENT_STEP=""

lifecycle_init() {
    OP_TYPE="$1"
    OP_ID="op-$$-$(date -u +%s 2>/dev/null || printf '0')"
    LIFECYCLE_SEQ=0
    CURRENT_STEP=""
}

emit() {
    # emit <step> <status> [error_code] [message]
    local step="$1" status="$2" error_code="${3:-}" message="${4:-}"
    local ts line
    # Track the in-flight step: a `started` marks the step current; any terminal
    # status clears it (so a later mid-step failure is attributed correctly).
    case "$status" in
        started) CURRENT_STEP="$step" ;;
        ok|warn|failed|rolled_back) CURRENT_STEP="" ;;
    esac
    LIFECYCLE_SEQ=$((LIFECYCLE_SEQ + 1))
    ts="$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || printf '')"
    line="$(printf 'axon-lifecycle: operation_id=%s op_type=%s step=%s status=%s seq=%s ts=%s' \
        "$OP_ID" "$OP_TYPE" "$step" "$status" "$LIFECYCLE_SEQ" "$ts")"
    [ -z "$error_code" ] || line="$line error_code=$error_code"
    [ -z "$message" ] || line="$line message=\"$message\""
    printf '%s\n' "$line" >&2
}

maybe_inject_failure() {
    if [ -n "${AXON_FAIL_AT:-}" ] && [ "${AXON_FAIL_AT}" = "$1" ]; then
        log "fault injection (AXON_FAIL_AT=$1): forcing failure"
        return 1
    fi
    return 0
}

# ── Rollback journal + transaction control ──────────────────────────────────
ROLLBACK_ARMED=0
ROLLED_BACK=0
JOURNAL_FILE=""
BACKUP_DIR=""
UPDATE_SWAPPED=0
UPDATE_PREV_SLOT=""
UPDATE_OPT_DIR=""
UPDATE_WORKDIR=""
# Snapshot whether the classifier was locally managed before an update starts.
# Re-checking active/enabled state after a failed restart can hide a classifier
# that was active-but-disabled and has just failed to come back, causing both the
# rollback restart and its health check to skip the unit that most needs them.
UPDATE_CLASSIFIER_MANAGED=0
# Set to 1 by resolve_update_package when the payload was fetched from a REMOTE
# (non-file://) URL. verify_update_checksum fails closed in that case so a binary
# that will be executed as root is never installed without integrity verification.
UPDATE_REMOTE_DOWNLOAD=0
# resolve_update_package sets this to the resolved package dir. It writes a global
# (rather than stdout) so it runs in the CURRENT shell and its side effects
# (UPDATE_REMOTE_DOWNLOAD, UPDATE_WORKDIR) persist — a command-substitution subshell
# would discard them.
RESOLVED_PKG_DIR=""

begin_transaction() {
    JOURNAL_FILE="$(mktemp "${TMPDIR:-/tmp}/axon-install-journal.XXXXXX")"
    BACKUP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/axon-install-backup.XXXXXX")"
    ROLLBACK_ARMED=1
    ROLLED_BACK=0
    trap 'on_err' ERR
    trap 'on_exit' EXIT
}

commit_transaction() {
    ROLLBACK_ARMED=0
    trap - ERR
}

do_rollback() {
    [ "$ROLLBACK_ARMED" = "1" ] || return 0
    [ "$ROLLED_BACK" = "0" ] || return 0
    ROLLED_BACK=1
    set +e
    local rollback_rc=0
    case "$OP_TYPE" in
        update)
            emit revert_symlink started
            if update_revert; then
                emit revert_symlink rolled_back "$LAST_ERROR_CODE"
            else
                rollback_rc=$?
                emit revert_symlink failed HEALTH_CHECK_FAILED "previous slot selected but rollback restart/health verification failed"
            fi
            ;;
        *)
            emit revert_journal started
            replay_journal
            emit revert_journal rolled_back "$LAST_ERROR_CODE"
            ;;
    esac
    if [ "$rollback_rc" -eq 0 ]; then
        emit operation rolled_back "$LAST_ERROR_CODE"
    else
        emit operation failed HEALTH_CHECK_FAILED "rollback did not restore healthy services"
    fi
    return "$rollback_rc"
}

on_err() {
    local code=$?
    [ "$code" -ne 0 ] || code=1
    # A mid-step command failure jumps here before the step could emit its own
    # `failed`. Report the failing step (with its mapped error_code) so the event
    # sequence keeps step-level statuses instead of jumping straight to rollback.
    if [ -n "${CURRENT_STEP:-}" ]; then
        emit "$CURRENT_STEP" failed "$LAST_ERROR_CODE"
    fi
    do_rollback
    # Re-exit with the original failure code so set -e does not lose it; this
    # drives the EXIT trap, which performs cleanup (rollback is idempotent).
    exit "$code"
}

on_exit() {
    local code=$?
    trap - ERR EXIT
    set +e
    if [ "$ROLLBACK_ARMED" = "1" ] && [ "$code" -ne 0 ]; then
        do_rollback
    fi
    cleanup_transaction_temps
    exit "$code"
}

cleanup_transaction_temps() {
    if [ -n "${UPDATE_OPT_DIR:-}" ]; then
        rm -f "$UPDATE_OPT_DIR/.current.tmp" 2>/dev/null || true
        rm -rf "$UPDATE_OPT_DIR/.slot-a.staging" "$UPDATE_OPT_DIR/.slot-b.staging" 2>/dev/null || true
    fi
    if [ -n "${UPDATE_WORKDIR:-}" ]; then
        rm -rf "$UPDATE_WORKDIR" 2>/dev/null || true
    fi
    if [ -n "${JOURNAL_FILE:-}" ]; then
        rm -f "$JOURNAL_FILE" 2>/dev/null || true
    fi
    if [ -n "${BACKUP_DIR:-}" ]; then
        rm -rf "$BACKUP_DIR" 2>/dev/null || true
    fi
    return 0
}

journal_record() {
    [ -n "${JOURNAL_FILE:-}" ] || return 0
    printf '%s\t%s\t%s\n' "$1" "${2:-}" "${3:-}" >>"$JOURNAL_FILE"
}

replay_journal() {
    if [ -z "${JOURNAL_FILE:-}" ] || [ ! -f "$JOURNAL_FILE" ]; then
        return 0
    fi
    local -a entries=()
    mapfile -t entries <"$JOURNAL_FILE"
    local i
    for (( i = ${#entries[@]} - 1; i >= 0; i-- )); do
        replay_one "${entries[i]}"
    done
}

replay_one() {
    local line="$1" verb a b
    IFS=$'\t' read -r verb a b <<<"$line"
    case "$verb" in
        rmdir)           rmdir "$a" 2>/dev/null || true ;;
        rm_file)         rm -f "$a" 2>/dev/null || true ;;
        rm_symlink)      rm -f "$a" 2>/dev/null || true ;;
        rm_tree)         rm -rf "$a" 2>/dev/null || true ;;
        restore_file)    mv -f "$b" "$a" 2>/dev/null || true ;;
        restore_symlink) ln -sfn "$b" "$a" 2>/dev/null || true ;;
        restore_dir)     rm -rf "$a" 2>/dev/null || true; mv -f "$b" "$a" 2>/dev/null || true ;;
        disable_unit)
            run_systemctl disable "$a" 2>/dev/null || true
            run_systemctl stop "$a" 2>/dev/null || true
            ;;
        disable_only_unit)
            # Unit was active-but-not-enabled before this run: undo the enable
            # without stopping it, so it returns to its prior active-but-disabled state.
            run_systemctl disable "$a" 2>/dev/null || true
            ;;
        restore_enabled_active)
            # Legacy unit was enabled AND running before migrate_python stopped+
            # disabled it: re-enable and restart it on rollback.
            run_systemctl enable "$a" 2>/dev/null || true
            run_systemctl start "$a" 2>/dev/null || true
            ;;
        restore_enabled)
            # Legacy unit was enabled (but not running): re-enable only.
            run_systemctl enable "$a" 2>/dev/null || true
            ;;
        restore_active)
            # Legacy unit was running but not enabled: restart only.
            run_systemctl start "$a" 2>/dev/null || true
            ;;
        daemon_reload)   run_systemctl daemon-reload 2>/dev/null || true ;;
        keep_unit)       : ;;  # unit was already enabled before this run; leave it as-is
        ovs_add_flow)
            # Re-add a classifier flow flushed during migrate_python so a post-migrate
            # rollback returns the managed bridge to its pre-install flow state.
            if command -v ovs-ofctl >/dev/null 2>&1; then
                ovs-ofctl add-flow "$a" "$b" 2>/dev/null || true
            fi
            ;;
        *)               log "rollback: unknown journal verb '$verb'" ;;
    esac
}

# ── Journaled mutation helpers (AXON_ROOT-aware via callers) ─────────────────
je_mkdir() {
    local mode="$1"
    shift
    local dir
    for dir in "$@"; do
        je_mkdir_one "$mode" "$dir"
    done
}

je_mkdir_one() {
    local mode="$1" dir="$2"
    [ -d "$dir" ] && return 0
    local -a created=()
    local d="$dir"
    while [ -n "$d" ] && [ "$d" != "/" ] && [ "$d" != "." ] && [ ! -d "$d" ]; do
        created=("$d" "${created[@]}")
        d="$(dirname "$d")"
    done
    install -d -m "$mode" "$dir"
    local p
    for p in "${created[@]}"; do
        [ -n "$p" ] || continue
        journal_record rmdir "$p"
    done
}

je_install_file() {
    local mode="$1" src="$2" dst="$3"
    local backup
    if [ -e "$dst" ] && [ ! -L "$dst" ]; then
        backup="$(mktemp "$BACKUP_DIR/file.XXXXXX")"
        cp -p "$dst" "$backup"
        journal_record restore_file "$dst" "$backup"
    elif [ -L "$dst" ]; then
        journal_record restore_symlink "$dst" "$(readlink "$dst")"
        rm -f "$dst"
    else
        journal_record rm_file "$dst"
    fi
    install -m "$mode" "$src" "$dst"
}

je_symlink() {
    local target="$1" link="$2"
    local backup
    if [ -L "$link" ]; then
        journal_record restore_symlink "$link" "$(readlink "$link")"
    elif [ -e "$link" ]; then
        backup="$(mktemp "$BACKUP_DIR/file.XXXXXX")"
        cp -p "$link" "$backup"
        journal_record restore_file "$link" "$backup"
        rm -f "$link"
    else
        journal_record rm_symlink "$link"
    fi
    ln -sfn "$target" "$link"
}

# je_copy_symlink copies a symlink into place (preserving it AS a symlink via
# `cp -P`) while journaling a restore so rollback puts back whatever was at the
# destination before — the original symlink+target, a regular file, or nothing.
# Mirrors je_install_file's backup/restore but for the symlink case (e.g. the
# libndpi.so -> libndpi.so.N compatibility link), which install -m cannot preserve.
je_copy_symlink() {
    local src="$1" dst="$2"
    if [ -L "$dst" ]; then
        journal_record restore_symlink "$dst" "$(readlink "$dst")"
        rm -f "$dst"
    elif [ -e "$dst" ]; then
        local backup
        backup="$(mktemp "$BACKUP_DIR/file.XXXXXX")"
        cp -p "$dst" "$backup"
        journal_record restore_file "$dst" "$backup"
        rm -f "$dst"
    else
        journal_record rm_file "$dst"
    fi
    cp -P "$src" "$dst"
}

je_daemon_reload() {
    journal_record daemon_reload
    run_systemctl daemon-reload
}

je_enable_now() {
    local unit="$1"
    # Journal a restore-to-PRIOR-state action distinguishing the three prior states
    # so rollback returns the unit to exactly how it was before this run:
    #   enabled          -> keep_unit         (no-op on rollback)
    #   active, !enabled  -> disable_only_unit (disable, do NOT stop: stays active)
    #   neither           -> disable_unit      (disable + stop)
    # Checking is-enabled first matters: an active-but-disabled (manually started)
    # unit must NOT be left enabled-on-boot after a rollback.
    if run_systemctl is-enabled --quiet "$unit"; then
        journal_record keep_unit "$unit"
    elif run_systemctl is-active --quiet "$unit"; then
        journal_record disable_only_unit "$unit"
    else
        journal_record disable_unit "$unit"
    fi
    run_systemctl enable --now "$unit"
}

je_remove_legacy_unit() {
    local unit_path="$1"
    [ -e "$unit_path" ] || return 0
    local backup
    backup="$(mktemp "$BACKUP_DIR/file.XXXXXX")"
    cp -p "$unit_path" "$backup"
    journal_record restore_file "$unit_path" "$backup"
    rm -f "$unit_path"
}

# je_capture_unit_state captures a unit's PRIOR enabled/active state and journals
# the inverse restore BEFORE it is stopped+disabled, so a failed migration rolls
# back to the working (previously enabled and/or running) unit. Journaled before
# je_remove_legacy_unit so the reverse replay restores the unit file first, then
# re-enables/restarts it. Mirrors je_enable_now's three-state logic, inverted.
je_capture_unit_state() {
    local unit="$1" en=0 ac=0
    if run_systemctl is-enabled --quiet "$unit"; then en=1; fi
    if run_systemctl is-active --quiet "$unit"; then ac=1; fi
    if [ "$en" = 1 ] && [ "$ac" = 1 ]; then
        journal_record restore_enabled_active "$unit"
    elif [ "$en" = 1 ]; then
        journal_record restore_enabled "$unit"
    elif [ "$ac" = 1 ]; then
        journal_record restore_active "$unit"
    fi
}

je_remove_dir() {
    local dir="$1"
    [ -d "$dir" ] || return 0
    local backup
    backup="$(mktemp -u "$BACKUP_DIR/dir.XXXXXX")"
    mv "$dir" "$backup"
    journal_record restore_dir "$dir" "$backup"
}

# ── Path + JSON helpers ─────────────────────────────────────────────────────
root_path() {
    local rel="${1#/}"
    if [ "$AXON_ROOT" = "/" ]; then
        printf '/%s\n' "$rel"
    else
        printf '%s/%s\n' "${AXON_ROOT%/}" "$rel"
    fi
}

json_string() {
    # Minimal JSON string escape for token/interface values used in enrollment.
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

json_field() {
    local file="$1"
    local key="$2"
    sed -n "s/.*\"$key\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\\1/p" "$file" 2>/dev/null | head -n 1
}

detect_os() {
    local os_release
    os_release="$(root_path /etc/os-release)"
    [ -f "$os_release" ] || os_release="/etc/os-release"
    if [ ! -f "$os_release" ]; then
        log "warning: cannot find os-release; continuing with generic systemd install"
        return 0
    fi

    # shellcheck disable=SC1090
    . "$os_release"
    case "${ID:-}" in
        ubuntu|debian|dietpi)
            return 0
            ;;
        *)
            case "${ID_LIKE:-}" in
                *debian*)
                    return 0
                    ;;
            esac
            log "warning: unsupported OS ID '${ID:-unknown}'; continuing because layout is systemd-compatible"
            ;;
    esac
}

require_root_for_real_install() {
    if [ "$AXON_ROOT" = "/" ] && [ "$(id -u)" -ne 0 ]; then
        log "real installs must run as root"
        exit 1
    fi
}

# ── Interface preflight (inspect-only NIC validation) ────────────────────────
# Validate the operator-supplied NIC names against the host's real interfaces
# BEFORE any config is written or any service is enabled (i.e. before
# begin_transaction), so a typo aborts cleanly without leaving partial state.
# Outcomes use the shared LifecycleProgress error_code vocabulary so the
# live-streaming work (AG-3) can forward them verbatim:
#   PRIMARY_IFACE_NOT_FOUND   primary NIC does not exist             (abort)
#   MIRROR_IFACE_NOT_FOUND    mirror/monitor NIC does not exist      (abort)
#   MIRROR_IFACE_DOWN         monitor NIC exists but is admin-down   (warn)
#   MIRROR_IFACE_NOT_PROMISC  monitor NIC exists but not promiscuous (warn)
# SPAN up+promiscuous is operator-managed: the preflight only inspects and
# reports — it never runs `ip link set ... up` or `promisc on`.

# iface_exists <iface> <brief>: true when a line in the `ip -br link` snapshot
# names this interface (VLAN/`name@parent` forms are matched on the base name).
iface_exists() {
    local iface="$1" brief="$2"
    [ -n "$iface" ] || return 1
    printf '%s\n' "$brief" | awk -v want="$iface" '
        { name = $1; sub(/@.*/, "", name); if (name == want) { found = 1 } }
        END { exit(found ? 0 : 1) }'
}

# iface_brief_line <iface> <brief>: print the snapshot line for this interface.
iface_brief_line() {
    local iface="$1" brief="$2"
    printf '%s\n' "$brief" | awk -v want="$iface" '
        { name = $1; sub(/@.*/, "", name); if (name == want) { print; exit } }'
}

# iface_has_flag <brief_line> <FLAG>: true when FLAG is present in the `<...>`
# flag list, matched on whole comma-delimited tokens (so UP never matches the
# carrier flag LOWER_UP).
iface_has_flag() {
    local line="$1" flag="$2" flags
    case "$line" in
        *'<'*'>'*) flags="${line#*<}"; flags="${flags%%>*}" ;;
        *) return 1 ;;
    esac
    case ",$flags," in
        *",$flag,"*) return 0 ;;
        *) return 1 ;;
    esac
}

# abort_iface_not_found <error_code> <kind> <iface> <brief>: emit the mapped
# failure, print the detected NIC inventory, and exit before any mutation.
abort_iface_not_found() {
    local code="$1" kind="$2" iface="$3" brief="$4"
    emit preflight failed "$code" "$kind interface '$iface' not found on host"
    log "$code: $kind interface '$iface' does not exist on this host; aborting before any install changes are made"
    log "detected NICs (ip -br link):"
    printf '%s\n' "$brief" >&2
    emit operation failed "$code"
    exit 2
}

preflight_interfaces() {
    local primary="$1" mode="$2" monitor="$3"

    # Nothing to validate when no primary hint is given and we are not in mirror
    # mode (switching/default does not open an AF_PACKET capture socket here).
    if [ -z "$primary" ] && [ "$mode" != "mirror" ]; then
        return 0
    fi

    if ! command -v ip >/dev/null 2>&1; then
        log "warning: 'ip' not found; skipping interface preflight (cannot validate primary='${primary:-}' monitor='${monitor:-}')"
        return 0
    fi
    local brief
    brief="$(ip -br link 2>/dev/null || true)"

    # Primary NIC must exist when an interface hint was supplied.
    if [ -n "$primary" ] && ! iface_exists "$primary" "$brief"; then
        abort_iface_not_found PRIMARY_IFACE_NOT_FOUND primary "$primary" "$brief"
    fi

    [ "$mode" = "mirror" ] || return 0
    # An empty monitor is handled (with a clearer message) by the existing
    # non-empty check in write_classifier_config; the existence check runs first.
    [ -n "$monitor" ] || return 0

    if ! iface_exists "$monitor" "$brief"; then
        abort_iface_not_found MIRROR_IFACE_NOT_FOUND monitor "$monitor" "$brief"
    fi

    # Monitor NIC exists: a down or non-promiscuous SPAN link is an operator
    # responsibility, so warn loudly but proceed with the install.
    local line
    line="$(iface_brief_line "$monitor" "$brief")"
    if ! iface_has_flag "$line" UP; then
        emit preflight warn MIRROR_IFACE_DOWN "monitor interface '$monitor' is administratively down"
        log "WARNING MIRROR_IFACE_DOWN: monitor interface '$monitor' is administratively DOWN; SPAN capture will see no frames until it is brought up (operator-managed; the installer does not modify NIC state)"
    fi
    if ! iface_has_flag "$line" PROMISC; then
        emit preflight warn MIRROR_IFACE_NOT_PROMISC "monitor interface '$monitor' is not in promiscuous mode"
        log "WARNING MIRROR_IFACE_NOT_PROMISC: monitor interface '$monitor' is not in promiscuous mode; the NIC drops foreign-dst-MAC SPAN frames at the hardware filter until promisc is enabled (operator-managed; the installer does not modify NIC state)"
    fi
}

ensure_prereqs() {
    command -v curl >/dev/null 2>&1 || missing="${missing:-} curl"
    command -v ovs-ofctl >/dev/null 2>&1 || missing="${missing:-} openvswitch-switch"
    # Tailscale is an OPTIONAL prerequisite (issue #190): only tailnet-adopted
    # switches (bootstrap carries tailscale_auth_key) need it, and it ships from
    # Tailscale's own apt repo — not the base distro — so it is NOT force-installed
    # on every switch. Warn with install guidance if absent; the agent degrades
    # gracefully (skips the join) when no tailscale_auth_key is present.
    if ! command -v tailscale >/dev/null 2>&1; then
        log "note: tailscale not installed — required only for tailnet adoption. Install with: curl -fsSL https://tailscale.com/install.sh | sh"
    fi
    if [ -z "${missing:-}" ]; then
        return 0
    fi
    if [ "${AXON_SKIP_APT:-0}" = "1" ] || [ "$AXON_ROOT" != "/" ]; then
        log "missing prerequisites:${missing}; skipping apt install"
        return 0
    fi
    if ! command -v apt-get >/dev/null 2>&1; then
        log "missing prerequisites:${missing}; apt-get not available"
        exit 1
    fi
    apt-get update
    # ca-certificates is intentionally harmless if already present and keeps
    # enrollment over HTTPS working on minimal DietPi images.
    apt-get install -y ca-certificates curl openvswitch-switch
}

run_systemctl() {
    if [ "$AXON_ROOT" != "/" ] && [ "${AXON_ALLOW_ROOTED_SYSTEMCTL:-0}" != "1" ]; then
        log "skipping systemctl $* for AXON_ROOT=$AXON_ROOT"
        return 0
    fi
    systemctl "$@"
}

legacy_units() {
    cat <<'UNITS'
axon-agent.service
axon-agent-ee.service
axon-agent-ovs.service
axon-agent-monitor.service
axon-agent-healthcheck.service
axon-agent-uptime.service
axon-agent-port-link.service
axon-agent-port-stats.service
axon-agent-classifier.service
axon-agent-ee-classifier.service
axon-agent-ee-classifier-flow-stats.service
UNITS
}

has_legacy_python_install() {
    [ -d "$(root_path /opt/axon-agent/venv)" ] && return 0
    [ -d "$(root_path /opt/axon-agent-ce)" ] && return 0
    [ -d "$(root_path /opt/axon-agent-ee)" ] && return 0
    while IFS= read -r unit; do
        local unit_path
        unit_path="$(root_path "/etc/systemd/system/$unit")"
        [ -f "$unit_path" ] || continue
        grep -Eiq 'python|venv|axon_agent|axon-agent-(ce|ee)' "$unit_path" && return 0
    done <<EOF_UNITS
$(legacy_units)
EOF_UNITS
    return 1
}

configured_bridges() {
    if [ -n "${AXON_MANAGED_BRIDGES:-}" ]; then
        # shellcheck disable=SC2086
        printf '%s\n' $AXON_MANAGED_BRIDGES
        return 0
    fi

    local classifier_config
    classifier_config="$(root_path /etc/axon/classifier_config.json)"
    if [ -f "$classifier_config" ]; then
        local bridge
        bridge="$(json_field "$classifier_config" bridge_name)"
        [ -z "$bridge" ] || printf '%s\n' "$bridge"
    fi
}

cookie_has_go_marker() {
    local hex="${1#0x}"
    hex="${hex#0X}"
    while [ "${#hex}" -lt 16 ]; do
        hex="0$hex"
    done
    case "${hex:0:1}" in
        [89aAbBcCdDeEfF])
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

# flow_to_addspec converts an `ovs-ofctl dump-flows` line into a re-addable
# `add-flow` spec: it drops the read-only stats fields (duration/n_packets/
# n_bytes/idle_age/hard_age) and normalizes ", " separators to "," so the cookie,
# table, priority, match, and actions round-trip exactly.
flow_to_addspec() {
    printf '%s\n' "$1" | sed -E '
        s/(duration|n_packets|n_bytes|idle_age|hard_age)=[^,]+,? ?//g
        s/^[[:space:]]+//
        s/[[:space:]]+$//
        s/, /,/g'
}

# Delete only individual OpenFlow rules carrying the Go-agent marker bit
# (cookie >= 0x8000000000000000) AND priority >= 4500 on managed bridges. The
# guard never enumerates or edits unmanaged bridges and never deletes a cookie=0,
# non-marker, or low-priority flow. Used by both Python migration and uninstall.
# During migration (inside a transaction) each flushed flow is journaled so a
# post-migrate rollback re-adds it; during uninstall there is no transaction, so
# journal_record is a no-op and the flush is permanent.
flush_marked_flows_on_managed_bridges() {
    command -v ovs-ofctl >/dev/null 2>&1 || {
        log "ovs-ofctl not found; skipping classifier rule flush"
        return 0
    }

    local bridge
    configured_bridges | while IFS= read -r bridge; do
        [ -n "$bridge" ] || continue
        log "flushing marked classifier rules on managed bridge $bridge"
        local flows
        if ! flows="$(ovs-ofctl dump-flows "$bridge" 2>/dev/null)"; then
            log "warning: could not dump flows for $bridge; skipping stale classifier rule flush"
            continue
        fi
        printf '%s\n' "$flows" | while IFS= read -r flow; do
            local cookie priority
            cookie="$(printf '%s\n' "$flow" | sed -n 's/.*cookie=\(0x[0-9A-Fa-f]\{1,\}\).*/\1/p')"
            priority="$(printf '%s\n' "$flow" | sed -n 's/.*priority=\([0-9][0-9]*\).*/\1/p')"
            [ -n "$cookie" ] || continue
            [ -n "$priority" ] || continue
            cookie_has_go_marker "$cookie" || continue
            [ "$priority" -ge 4500 ] || continue
            journal_record ovs_add_flow "$bridge" "$(flow_to_addspec "$flow")"
            ovs-ofctl --strict del-flows "$bridge" "cookie=$cookie/-1,priority=$priority" || true
        done
    done
}

# Backwards-compatible name used by the migration path.
flush_legacy_classifier_rules() {
    flush_marked_flows_on_managed_bridges
}

migrate_python() {
    emit migrate_python started
    log "migrating legacy Python agent units"
    while IFS= read -r unit; do
        [ -n "$unit" ] || continue
        # Capture prior enabled/active state BEFORE stopping+disabling so rollback
        # restores the previously-running Python agent.
        je_capture_unit_state "$unit"
        run_systemctl stop "$unit" || true
        run_systemctl disable "$unit" || true
        je_remove_legacy_unit "$(root_path "/etc/systemd/system/$unit")"
    done <<EOF_UNITS
$(legacy_units)
EOF_UNITS

    je_remove_dir "$(root_path /opt/axon-agent/venv)"
    je_remove_dir "$(root_path /opt/axon-agent-ce)"
    je_remove_dir "$(root_path /opt/axon-agent-ee)"
    flush_legacy_classifier_rules
    emit migrate_python ok
}

write_bootstrap() {
    local token="$1"
    local controller_url="$2"
    local primary_interface="$3"
    local etc_dir tmp enroll_url payload
    etc_dir="$(root_path /etc/axon)"
    je_mkdir 0755 "$etc_dir"
    tmp="$(mktemp "${TMPDIR:-/tmp}/axon-bootstrap.XXXXXX")"
    enroll_url="${controller_url%/}/api/v2/enrollment/enroll/"
    payload="{\"token\":\"$(json_string "$token")\""
    if [ -n "$primary_interface" ]; then
        payload="$payload,\"primary_interface\":\"$(json_string "$primary_interface")\""
    fi
    payload="$payload}"

    curl -fsSL -X POST \
        -H 'Content-Type: application/json' \
        --data "$payload" \
        "$enroll_url" >"$tmp"
    je_install_file 0600 "$tmp" "$etc_dir/bootstrap.json"
    rm -f "$tmp"
}

ensure_tailscale_for_bootstrap() {
    # Tailnet adoption (issue #190): when the enroll bootstrap carries a
    # tailscale_auth_key, the agent must join the tailnet BEFORE MQTT works
    # (controller_url is a tailnet address), so a missing tailscale binary
    # wedges the whole install invisibly. Auto-install it from the official
    # script (opt out with AXON_SKIP_TAILSCALE_INSTALL=1). Deliberately a
    # WARNING, never a hard failure: the transactional installer would roll
    # back and burn the already-consumed enrollment token, whereas leaving
    # the install in place lets the operator install tailscale and restart
    # the agent while the ~15-minute join key is still valid.
    local etc_dir auth_key
    etc_dir="$(root_path /etc/axon)"
    [ -f "$etc_dir/bootstrap.json" ] || return 0
    auth_key="$(json_field "$etc_dir/bootstrap.json" tailscale_auth_key)" || auth_key=""
    [ -n "$auth_key" ] || return 0

    if ! command -v tailscale >/dev/null 2>&1; then
        if [ "${AXON_SKIP_TAILSCALE_INSTALL:-0}" = "1" ]; then
            log "WARNING: bootstrap requires a tailnet join but tailscale is not installed (AXON_SKIP_TAILSCALE_INSTALL=1). Install it within ~15 min (join key expiry) or re-enroll: curl -fsSL https://tailscale.com/install.sh | sh"
            return 0
        fi
        log "bootstrap carries a tailnet join key; installing tailscale..."
        if ! curl -fsSL https://tailscale.com/install.sh | sh; then
            log "WARNING: tailscale auto-install FAILED. The agent cannot reach the controller until tailscale is installed and running — install it manually within ~15 min (join key expiry) or re-enroll the switch."
            return 0
        fi
    fi
    # The daemon must be up for the agent's `tailscale up` to work at startup.
    if ! run_systemctl enable --now tailscaled 2>/dev/null; then
        log "WARNING: could not enable/start tailscaled; the tailnet join will fail until it runs"
    fi
}

write_classifier_config() {
    # Writes /etc/axon/classifier_config.json for mirror mode. site_id falls back
    # to the enrollment response (bootstrap.json). device_id is left empty unless
    # explicitly given (--device-id): the classifier resolves it from the adopted
    # identity in config.json (written by the control plane at adoption), so the
    # device publishes under its controller-assigned device_id automatically.
    local mode="$1" monitor="$2" site="$3" device="$4"
    local etc_dir cfg tmp
    etc_dir="$(root_path /etc/axon)"
    cfg="$etc_dir/classifier_config.json"

    if [ -z "$site" ] && [ -f "$etc_dir/bootstrap.json" ]; then
        site="$(json_field "$etc_dir/bootstrap.json" site_id)"
    fi
    if [ "$mode" = "mirror" ] && [ -z "$monitor" ]; then
        log "mirror mode requires --monitor-interface"
        exit 2
    fi
    [ -n "$site" ] || log "warning: mirror site_id is empty (set --site-id or enroll first)"
    [ -n "$device" ] || log "device_id left empty; the classifier resolves it from the adopted identity (config.json) after enrollment"

    log "writing classifier_config.json (deployment_mode=$mode, monitor_interface=${monitor:-none}, site_id=${site:-unset}, device_id=${device:-unset})"
    je_mkdir 0755 "$etc_dir"
    tmp="$(mktemp "${TMPDIR:-/tmp}/axon-classifier.XXXXXX")"
    cat >"$tmp" <<EOF
{
  "deployment_mode": "$(json_string "$mode")",
  "monitor_interface": "$(json_string "$monitor")",
  "site_id": "$(json_string "$site")",
  "device_id": "$(json_string "$device")",
  "snapshot_interval_sec": 5,
  "max_flow_entries_per_snapshot": 2000,
  "feed_budget": 20,
  "classified_flow_batch_size": 50,
  "max_concurrent_flows": 100000,
  "active_timeout_sec": 600,
  "num_bytes": 225,
  "num_packets": 5,
  "batch_interval": 1.0,
  "idle_timeout": 30,
  "policy_enabled": false
}
EOF
    je_install_file 0644 "$tmp" "$cfg"
    rm -f "$tmp"
}

mirror_capture_notice() {
    # Mirror mode needs the SPAN/monitor NIC UP and in promiscuous mode, or the
    # NIC silently drops foreign-dst-MAC SPAN frames at the hardware filter.
    # Configuring NIC state is the operator's responsibility on their own
    # hardware, NOT the installer's, so we never change it — we only remind.
    #
    # We also remove the promisc drop-in that older installer versions wrote
    # (which forced `ip link set <iface> up promisc on` on every classifier
    # start), reverting that overstep so an upgrade stops mutating host
    # networking. Removing our own drop-in only stops us from forcing promisc;
    # it does not touch promisc state the operator set themselves.
    local monitor="$1"
    local dropin
    dropin="$(root_path /etc/systemd/system/axon-agent-classifier.service.d/10-mirror-promisc.conf)"
    if [ -f "$dropin" ]; then
        # Journal a daemon-reload BEFORE the removal so that on rollback (reverse
        # replay) it runs AFTER the drop-in is restored — systemd must reload once
        # the recovered file is back. je_remove_legacy_unit then backs up + journals
        # the restore. A real reload is run now for the forward (removal) path.
        journal_record daemon_reload
        je_remove_legacy_unit "$dropin"
        run_systemctl daemon-reload || true
        log "mirror: removed legacy promisc drop-in ($dropin); promiscuous mode is operator-managed"
    fi
    [ -n "$monitor" ] || return 0
    log "mirror: capture interface '$monitor' must stay UP and in promiscuous mode for SPAN frames — operator-managed (see any preflight interface warnings above); the installer does not modify NIC state"
}

install_payload() {
    local opt_dir slot_dir etc_dir state_dir systemd_dir src_bin
    opt_dir="$(root_path /opt/axon-agent)"
    slot_dir="$opt_dir/slot-a"
    etc_dir="$(root_path /etc/axon)"
    state_dir="$(root_path /var/lib/axon)"
    systemd_dir="$(root_path /etc/systemd/system)"
    src_bin="$AXON_PACKAGE_DIR/axon-agent"
    [ -f "$src_bin" ] || src_bin="$AXON_PACKAGE_DIR/bin/axon-agent"
    [ -f "$src_bin" ] || {
        log "missing axon-agent binary in $AXON_PACKAGE_DIR"
        exit 1
    }

    je_mkdir 0755 "$slot_dir" "$slot_dir/lib" "$etc_dir" "$state_dir" "$systemd_dir"
    je_install_file 0755 "$src_bin" "$slot_dir/axon-agent"

    if compgen -G "$AXON_PACKAGE_DIR/lib/libndpi.so*" >/dev/null; then
        local ndpi base
        for ndpi in "$AXON_PACKAGE_DIR"/lib/libndpi.so*; do
            [ -e "$ndpi" ] || continue
            base="$(basename "$ndpi")"
            if [ -L "$ndpi" ]; then
                je_copy_symlink "$ndpi" "$slot_dir/lib/$base"
            else
                je_install_file 0644 "$ndpi" "$slot_dir/lib/$base"
            fi
        done
    else
        log "warning: no libndpi.so* found in $AXON_PACKAGE_DIR/lib"
    fi

    je_install_file 0644 "$AXON_PACKAGE_DIR/systemd/axon-agent.service" \
        "$systemd_dir/axon-agent.service"
    je_install_file 0644 "$AXON_PACKAGE_DIR/systemd/axon-agent-classifier.service" \
        "$systemd_dir/axon-agent-classifier.service"

    je_symlink slot-a "$opt_dir/current"
}

# Record the release channel on the host and point the agent's self-update
# default at this channel's release index. Writes /etc/axon/agent.env, which the
# systemd unit sources via `EnvironmentFile=-/etc/axon/agent.env`. The agent
# reads AXON_UPDATE_INDEX_URL (internal/agent/update_handlers.go) and uses it
# whenever an AgentUpdateCommand omits index_url, so a device installed on a
# non-main channel self-updates within that channel rather than falling back to
# a flat/main default. A controller-supplied index_url still wins. When no
# download base is known (e.g. AXON_AGENT_URL override or a dev install) only the
# channel is recorded; AXON_UPDATE_INDEX_URL is left unset.
write_channel() {
    local chan="$1" base="$2"
    local etc_dir tmp index_url
    etc_dir="$(root_path /etc/axon)"
    je_mkdir 0755 "$etc_dir"
    tmp="$(mktemp "${TMPDIR:-/tmp}/axon-agent-env.XXXXXX")"
    {
        printf '# Managed by axon-agent install.sh. Sourced by the systemd unit\n'
        printf '# (EnvironmentFile=-/etc/axon/agent.env). Records the release channel\n'
        printf '# and the per-channel release index the agent self-update path honors.\n'
        printf 'AXON_CHANNEL=%s\n' "$chan"
    } >"$tmp"
    if [ -n "$base" ]; then
        index_url="${base%/}/$chan/index.json"
        printf 'AXON_UPDATE_INDEX_URL=%s\n' "$index_url" >>"$tmp"
        log "recording channel '$chan'; agent update index default -> $index_url"
    else
        log "recording channel '$chan'; no download base, AXON_UPDATE_INDEX_URL left unset (controller index_url still honored)"
    fi
    je_install_file 0644 "$tmp" "$etc_dir/agent.env"
    rm -f "$tmp"
}

# Smart Uplink per-device activation tuple (issue #108). A systemd drop-in —
# not agent.env — for two reasons: write_channel rewrites agent.env wholesale
# on channel changes, and A/B updates never reinstall unit files, so a drop-in
# keeps working across both. Replaces the hand-placed lab files this flow used
# to require (qos-lab-ceilings.conf); those remain operator-owned and are never
# touched here. Journaled (je_install_file) so a failed transaction rolls the
# tuple back with everything else. The tuple was already validated at parse
# time (all-or-none, numeric ranges).
write_qos_tier_dropin() {
    local dropin_dir tmp other
    dropin_dir="$(root_path /etc/systemd/system/axon-agent.service.d)"
    # systemd merges drop-ins in lexical order (later assignments win) and the
    # unit also sources agent.env, so any OTHER source assigning a tuple key
    # would silently shadow or splice the values we write here. Refuse instead
    # of producing mixed-provenance config; the transaction rolls this back.
    for other in $(qos_external_tuple_files); do
        if [ -n "$(qos_assigned_keys "$other")" ]; then
            log "refusing --qos-tier: $other already assigns activation-tuple keys and would shadow the installer-managed tuple; remove or migrate it first"
            return 1
        fi
    done
    je_mkdir 0755 "$dropin_dir"
    tmp="$(mktemp "${TMPDIR:-/tmp}/axon-agent-qos-tier.XXXXXX")"
    {
        printf '# Managed by axon-agent install.sh (--qos-tier). Smart Uplink\n'
        printf '# evidence-backed activation tuple for this device SKU. All three\n'
        printf '# values are required together: a partial tuple prevents agent\n'
        printf '# startup. Keep these at or below the approved benchmark row for\n'
        printf '# this hardware tier.\n'
        printf '[Service]\n'
        printf 'Environment=AXON_QOS_PLATFORM_TIER=%s\n' "$qos_tier"
        printf 'Environment=AXON_QOS_MAX_RATE_KBIT=%s\n' "$qos_max_rate_kbit"
        printf 'Environment=AXON_QOS_MAX_MEMLIMIT_BYTES=%s\n' "$qos_max_memlimit_bytes"
    } >"$tmp"
    je_install_file 0644 "$tmp" "$dropin_dir/20-qos-tier.conf"
    rm -f "$tmp"
    log "smart uplink: recorded platform tier '$qos_tier' (max rate $qos_max_rate_kbit kbit/s, max memlimit $qos_max_memlimit_bytes bytes)"
}

# The three activation keys. AXON_QOS_STATS_INTERVAL_S is cadence, not part of
# the tuple, and must never influence provisioning decisions.
QOS_TUPLE_KEYS='AXON_QOS_PLATFORM_TIER AXON_QOS_MAX_RATE_KBIT AXON_QOS_MAX_MEMLIMIT_BYTES'

# Print each activation key assigned a NON-EMPTY value in the given files —
# systemd drop-in form (Environment=KEY=value) or env-file form (KEY=value) at
# line start. Comments, unrelated AXON_QOS_ settings, and empty overrides
# (Environment=KEY=) never count. Best-effort by design: exotic systemd
# quoting or multi-assignment lines are not resolved here — the agent itself
# is the authoritative validator and refuses to start on a bad tuple, which
# the install/update health check then surfaces.
qos_assigned_keys() {
    local key file
    for key in $QOS_TUPLE_KEYS; do
        for file in "$@"; do
            [ -f "$file" ] || continue
            if grep -Eq "^(Environment=)?${key}=." "$file" 2>/dev/null; then
                printf '%s\n' "$key"
                break
            fi
        done
    done
}

# Every effective AXON_QOS_ source OTHER than the installer-owned drop-in:
# operator/lab drop-ins plus /etc/axon/agent.env (sourced by the unit).
qos_external_tuple_files() {
    local dropin_dir file
    dropin_dir="$(root_path /etc/systemd/system/axon-agent.service.d)"
    for file in "$dropin_dir"/*.conf; do
        [ -e "$file" ] || continue
        [ "${file##*/}" = "20-qos-tier.conf" ] && continue
        printf '%s\n' "$file"
    done
    file="$(root_path /etc/axon/agent.env)"
    [ -f "$file" ] && printf '%s\n' "$file"
    return 0
}

# A PARTIAL activation tuple anywhere in the effective config prevents the
# agent from starting and would otherwise surface only as an opaque
# health-check failure and rollback; fail early with the actual cause. A
# complete tuple is left alone — the agent validates values itself, and since
# v0.4.2 it also SELF-ACTIVATES approved hardware from embedded evidence rows,
# so no tuple at all is the normal, healthy state.
preflight_qos_tuple() {
    local own keys n
    own="$(root_path /etc/systemd/system/axon-agent.service.d/20-qos-tier.conf)"
    local -a files=()
    mapfile -t files < <(qos_external_tuple_files)
    [ -f "$own" ] && files+=("$own")
    keys="$(qos_assigned_keys ${files[@]+"${files[@]}"})"
    [ -n "$keys" ] || return 0
    n="$(printf '%s\n' "$keys" | grep -c .)"
    if [ "$n" -lt 3 ]; then
        log "smart uplink: PARTIAL activation tuple configured ($(printf '%s' "$keys" | tr '\n' ' ')— the agent refuses to start on a partial tuple); fix or remove it and re-run"
        return 1
    fi
}

# Retry a single-shot health predicate up to 3 times with a 1s grace between
# attempts, so a service still activating right after (re)start is not declared
# unhealthy by a single immediate probe. Shared by install and update health.
health_check_with_grace() {
    local probe="$1"
    local i=0
    while :; do
        if "$probe"; then
            return 0
        fi
        i=$((i + 1))
        [ "$i" -lt 3 ] || return 1
        sleep 1 2>/dev/null || true
    done
}

# Single-shot install health probe: axon-agent.service must be active, plus the
# classifier in mirror mode (which the installer enables locally).
install_health_probe() {
    run_systemctl is-active --quiet axon-agent.service || return 1
    if [ "$deployment_mode" = "mirror" ]; then
        run_systemctl is-active --quiet axon-agent-classifier.service || return 1
    fi
    return 0
}

install_health_ok() {
    health_check_with_grace install_health_probe
}

# ── A/B slot helpers (consistent with internal/update/slots.go) ──────────────
current_slot_name() {
    local opt_dir="$1"
    local link="$opt_dir/current"
    [ -L "$link" ] || { printf ''; return 0; }
    local target
    target="$(basename "$(readlink "$link")")"
    case "$target" in
        slot-a|slot-b) printf '%s\n' "$target" ;;
        *) printf '' ;;
    esac
}

inactive_slot_name() {
    if [ "$1" = "slot-a" ]; then
        printf 'slot-b\n'
    else
        printf 'slot-a\n'
    fi
}

atomic_symlink_swap() {
    local opt_dir="$1" slot="$2"
    local tmp="$opt_dir/.current.tmp"
    rm -f "$tmp"
    ln -s "$slot" "$tmp"
    mv -fT "$tmp" "$opt_dir/current"
}

unit_installed() {
    [ -f "$(root_path "/etc/systemd/system/$1")" ]
}

# classifier_locally_managed: true only when the classifier is actually managed on
# THIS host (enabled or active), not merely when its unit file exists. The unit file
# is installed unconditionally — including switching deployments, which leave the
# classifier to the controller — so the update path must gate the classifier restart
# and post-swap health probe on local management. Restarting/health-checking a
# locally-unmanaged classifier could start a controller-managed service unexpectedly
# or fail the health check and roll back a perfectly good update.
classifier_locally_managed() {
    unit_installed axon-agent-classifier.service || return 1
    if run_systemctl is-enabled --quiet axon-agent-classifier.service; then return 0; fi
    if run_systemctl is-active --quiet axon-agent-classifier.service; then return 0; fi
    return 1
}

restart_units_forward() {
    # Forward compatibility is directional: an old classifier can use the new
    # daemon because the daemon retains the legacy RegisterFlowSNI RPC. Restart
    # the daemon first, then the classifier, so no new-classifier/old-daemon
    # interval can silently discard the combined flow_cookies field.
    run_systemctl daemon-reload || return $?
    run_systemctl restart axon-agent.service || return $?
    if [ "$UPDATE_CLASSIFIER_MANAGED" = "1" ]; then
        run_systemctl restart axon-agent-classifier.service || return $?
    fi
}

restart_units_rollback() {
    # Rollback is the inverse compatibility direction. Restore the old
    # classifier while the new daemon (which accepts the legacy RPC) is still
    # running, then restore the old daemon. If the classifier restart fails, do
    # NOT downgrade the daemon underneath a possibly-new classifier; leave the
    # semantically safe old-classifier/new-daemon or stopped-classifier state for
    # the health check to diagnose.
    run_systemctl daemon-reload || return $?
    if [ "$UPDATE_CLASSIFIER_MANAGED" = "1" ]; then
        run_systemctl restart axon-agent-classifier.service || return $?
    fi
    run_systemctl restart axon-agent.service || return $?
}

# Single-shot post-swap update health probe: axon-agent.service must be active, plus
# the classifier only if it is actually managed locally (see classifier_locally_managed).
update_health_probe() {
    run_systemctl is-active --quiet axon-agent.service || return 1
    if [ "$UPDATE_CLASSIFIER_MANAGED" = "1" ]; then
        run_systemctl is-active --quiet axon-agent-classifier.service || return 1
    fi
    return 0
}

update_health_ok() {
    # Use the same retry/grace window as install: a freshly swapped binary may still
    # be activating right after a restart sequence, so a single immediate probe could
    # fail and trigger an unnecessary symlink revert + restart.
    health_check_with_grace update_health_probe
}

update_revert() {
    # Revert the `current` symlink to the pre-update slot and restart, but ONLY if
    # the swap actually happened (post-swap health failure). Then always replay the
    # journal so the prior inactive slot that stage_slot moved aside is restored —
    # staging runs before validate_slot/swap_current, so a failure BEFORE the swap
    # (UPDATE_SWAPPED=0) must still put the prior inactive slot back rather than
    # leave it destroyed.
    local rollback_failed=0
    if [ "$UPDATE_SWAPPED" = "1" ] && [ -n "$UPDATE_OPT_DIR" ] && [ -n "$UPDATE_PREV_SLOT" ]; then
        if ! atomic_symlink_swap "$UPDATE_OPT_DIR" "$UPDATE_PREV_SLOT"; then
            log "rollback symlink restore failed"
            rollback_failed=1
        fi
        # Replay the journal BEFORE the rollback restart so the reverted
        # process generation starts from the pre-update on-disk configuration
        # (agent.env channel, QoS tier drop-in, restored slot) instead of the
        # failed update's writes. daemon-reload inside restart_units_rollback
        # then loads the restored drop-ins.
        replay_journal
        if [ "$rollback_failed" -eq 0 ] && ! restart_units_rollback; then
            # A command failure is material even if a process happened to remain
            # active: its version is then unverified. Still run the active checks
            # below so the failure report distinguishes downtime from uncertainty.
            log "rollback restart failed; verifying service health"
            rollback_failed=1
        fi
        if ! update_health_ok; then
            log "rollback health check failed"
            rollback_failed=1
        fi
        UPDATE_SWAPPED=0
    else
        replay_journal
    fi
    [ "$rollback_failed" -eq 0 ]
}

# Resolve the --update payload directory: a staged dir (AXON_UPDATE_PACKAGE_DIR
# or AXON_PACKAGE_DIR containing axon-agent) or a downloaded+unpacked tarball.
# Sets RESOLVED_PKG_DIR (NOT stdout) so it runs in the current shell and its side
# effects (UPDATE_REMOTE_DOWNLOAD, UPDATE_WORKDIR) survive — a command-substitution
# subshell would discard them. Non-zero return maps to DOWNLOAD_FAILED.
resolve_update_package() {
    RESOLVED_PKG_DIR=""
    local src="${AXON_UPDATE_PACKAGE_DIR:-$AXON_PACKAGE_DIR}"
    if [ -f "$src/axon-agent" ] || [ -f "$src/bin/axon-agent" ]; then
        RESOLVED_PKG_DIR="$src"
        return 0
    fi

    local url="${AXON_AGENT_URL:-}"
    if [ -z "$url" ]; then
        log "no update payload: set AXON_PACKAGE_DIR/AXON_UPDATE_PACKAGE_DIR or AXON_AGENT_URL"
        return 1
    fi
    command -v curl >/dev/null 2>&1 || { log "curl required to download update"; return 1; }
    command -v tar >/dev/null 2>&1 || { log "tar required to unpack update"; return 1; }

    # Record whether this is a remote fetch: a file:// URL is a local source whose
    # integrity is the operator's call, anything else is remote and MUST be
    # checksum-verified before the binary is executed as root (see verify_update_checksum).
    case "$url" in
        file://*) UPDATE_REMOTE_DOWNLOAD=0 ;;
        *) UPDATE_REMOTE_DOWNLOAD=1 ;;
    esac

    UPDATE_WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/axon-update.XXXXXX")"
    local tarball="$UPDATE_WORKDIR/payload.tar.gz"
    log "downloading update from $url"
    curl -fSL "$url" -o "$tarball" || return 1
    mkdir -p "$UPDATE_WORKDIR/pkg"
    tar -xzf "$tarball" -C "$UPDATE_WORKDIR/pkg" || return 1
    local root="$UPDATE_WORKDIR/pkg/axon-agent"
    [ -d "$root" ] || root="$UPDATE_WORKDIR/pkg"
    RESOLVED_PKG_DIR="$root"
    return 0
}

# Verify the staged binary's sha256 against AXON_UPDATE_SHA256. The staged binary
# is executed as root (validate_slot --version, then the swapped service), so a
# remotely-downloaded payload MUST be integrity-verified: FAIL CLOSED when
# verification is impossible (no expected hash, or no sha256sum tool) for a remote
# source. Skipping is allowed ONLY for local/file:// sources (operator-controlled).
# Non-zero exit maps to CHECKSUM_MISMATCH.
verify_update_checksum() {
    local pkg_dir="$1"
    local want="${AXON_UPDATE_SHA256:-}"
    local remote="${UPDATE_REMOTE_DOWNLOAD:-0}"

    if [ -z "$want" ]; then
        if [ "$remote" = "1" ]; then
            log "SECURITY: refusing remote update without AXON_UPDATE_SHA256 (cannot verify the root-executed binary); set AXON_UPDATE_SHA256"
            return 1
        fi
        log "no AXON_UPDATE_SHA256; skipping checksum verification (local source)"
        return 0
    fi
    if ! command -v sha256sum >/dev/null 2>&1; then
        if [ "$remote" = "1" ]; then
            log "SECURITY: refusing remote update; sha256sum unavailable to verify AXON_UPDATE_SHA256"
            return 1
        fi
        log "sha256sum unavailable; skipping checksum verification (local source)"
        return 0
    fi
    local bin="$pkg_dir/axon-agent"
    [ -f "$bin" ] || bin="$pkg_dir/bin/axon-agent"
    [ -f "$bin" ] || { log "staged binary not found for checksum"; return 1; }
    local got
    got="$(sha256sum "$bin" | awk '{print $1}')"
    if [ "$got" != "$want" ]; then
        log "checksum mismatch: got $got want $want"
        return 1
    fi
    log "update checksum verified"
}

stage_slot() {
    local opt_dir="$1" slot="$2" pkg_dir="$3"
    local slot_dir="$opt_dir/$slot"
    local staging="$opt_dir/.$slot.staging"
    local src_bin
    src_bin="$pkg_dir/axon-agent"
    [ -f "$src_bin" ] || src_bin="$pkg_dir/bin/axon-agent"
    [ -f "$src_bin" ] || { log "missing axon-agent binary in $pkg_dir"; return 1; }

    rm -rf "$staging"
    install -d -m 0755 "$staging" "$staging/lib"
    install -m 0755 "$src_bin" "$staging/axon-agent"

    if compgen -G "$pkg_dir/lib/libndpi.so*" >/dev/null; then
        local ndpi base
        for ndpi in "$pkg_dir"/lib/libndpi.so*; do
            [ -e "$ndpi" ] || continue
            base="$(basename "$ndpi")"
            if [ -L "$ndpi" ]; then
                cp -P "$ndpi" "$staging/lib/$base"
            else
                install -m 0644 "$ndpi" "$staging/lib/$base"
            fi
        done
    fi

    if [ -f "$pkg_dir/systemd/axon-agent.service" ]; then
        install -d -m 0755 "$staging/systemd"
        install -m 0644 "$pkg_dir/systemd/axon-agent.service" "$staging/systemd/axon-agent.service"
        [ -f "$pkg_dir/systemd/axon-agent-classifier.service" ] && \
            install -m 0644 "$pkg_dir/systemd/axon-agent-classifier.service" "$staging/systemd/axon-agent-classifier.service"
    fi

    # Atomically activate the freshly staged inactive slot, journaling so a rollback
    # BEFORE swap_current returns the tree to exactly its pre-update state:
    #   - slot exists  -> je_remove_dir backs it up + journals restore_dir (restore it).
    #   - slot absent  -> journal rm_tree of the slot we are about to create (first
    #     --update after a fresh install has no slot-b yet), so rollback deletes it
    #     rather than leaving the newly-created slot on disk.
    if [ -d "$slot_dir" ]; then
        je_remove_dir "$slot_dir"
    else
        journal_record rm_tree "$slot_dir"
    fi
    mv "$staging" "$slot_dir"
}

validate_slot() {
    local slot_dir="$1"
    local bin="$slot_dir/axon-agent"
    [ -x "$bin" ] || { log "staged binary not executable: $bin"; return 1; }
    if ! LD_LIBRARY_PATH="$slot_dir/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" "$bin" --version >/dev/null 2>&1; then
        log "staged binary failed --version validation"
        return 1
    fi
}

# ── Operations ──────────────────────────────────────────────────────────────
do_install() {
    lifecycle_init install
    emit operation started

    emit preflight started
    require_root_for_real_install
    detect_os
    case "$deployment_mode" in
        ""|switching|mirror) : ;;
        *) log "unknown --deployment-mode: $deployment_mode (expected 'switching' or 'mirror')"; exit 2 ;;
    esac
    # Inspect-only NIC validation BEFORE begin_transaction: a wrong primary or
    # (mirror) monitor NIC aborts here, leaving no partial state to roll back; a
    # down/non-promiscuous monitor NIC warns but proceeds.
    preflight_interfaces "$primary_interface" "$deployment_mode" "$monitor_interface"
    preflight_qos_tuple
    ensure_prereqs
    emit preflight ok
    maybe_inject_failure preflight

    begin_transaction

    if $force_migration || has_legacy_python_install; then
        migrate_python
    else
        emit migrate_python ok "" "no Python-agent footprint detected; migration skipped"
        log "no Python-agent footprint detected; migration cleanup skipped"
    fi
    maybe_inject_failure migrate_python

    emit install_payload started
    install_payload
    emit install_payload ok
    maybe_inject_failure install_payload

    emit write_channel started
    write_channel "$channel" "$download_base"
    emit write_channel ok
    maybe_inject_failure write_channel

    # No lifecycle emit for the QoS drop-in: lifecycle step names are parsed by
    # update reporting and this write is journaled/rolled back like any other.
    if [ -n "$qos_tier" ]; then
        write_qos_tier_dropin
    fi

    if [ -n "$enrollment_token" ]; then
        emit write_bootstrap started
        LAST_ERROR_CODE=ENROLL_FAILED
        write_bootstrap "$enrollment_token" "$controller_url" "$primary_interface"
        LAST_ERROR_CODE=""
        emit write_bootstrap ok
        # Post-enroll, pre-enable: make sure the tailnet prerequisite exists when
        # the bootstrap demands it (warn-only; see ensure_tailscale_for_bootstrap).
        ensure_tailscale_for_bootstrap
    fi
    maybe_inject_failure write_bootstrap

    if [ "$deployment_mode" = "mirror" ]; then
        emit write_classifier_config started
        write_classifier_config "$deployment_mode" "$monitor_interface" "$site_id" "$device_id"
        mirror_capture_notice "$monitor_interface"
        emit write_classifier_config ok
    fi
    maybe_inject_failure write_classifier_config

    emit enable_units started
    je_daemon_reload
    je_enable_now axon-agent.service
    # Mirror mode is locally configured (no controller bridge/classifier-install
    # step), so the installer enables + starts the classifier directly. Switching
    # mode leaves the classifier to the controller (started after OVS provisioning).
    if [ "$deployment_mode" = "mirror" ]; then
        je_enable_now axon-agent-classifier.service
    fi
    emit enable_units ok
    maybe_inject_failure enable_units

    emit health_check started
    # install_health_ok already retries 3x with a 1s grace, so a slow-but-successful
    # start is not rolled back. A genuine failure to come active MUST fail the
    # transaction (roll back to pristine) rather than warn + commit a broken install.
    LAST_ERROR_CODE=HEALTH_CHECK_FAILED
    if ! install_health_ok; then
        emit health_check failed HEALTH_CHECK_FAILED "axon-agent.service did not become active"
        return 1
    fi
    LAST_ERROR_CODE=""
    emit health_check ok

    commit_transaction
    emit operation ok
    log "install complete"
}

do_update() {
    lifecycle_init update
    emit operation started

    emit preflight started
    require_root_for_real_install
    detect_os
    ensure_prereqs
    local opt_dir
    opt_dir="$(root_path /opt/axon-agent)"
    [ -d "$opt_dir" ] || { log "no existing install at $opt_dir; run install first"; exit 1; }
    UPDATE_OPT_DIR="$opt_dir"
    preflight_qos_tuple
    if classifier_locally_managed; then
        UPDATE_CLASSIFIER_MANAGED=1
    else
        UPDATE_CLASSIFIER_MANAGED=0
    fi
    emit preflight ok

    begin_transaction

    # Persist an explicitly-changed release channel / download base so future
    # controller-omitted updates resolve through the NEW channel index. Only when
    # the operator passed --channel/--download-base: an update without them must
    # leave agent.env untouched. Journaled (je_install_file) so it rolls back with
    # the rest of the update transaction.
    if $channel_explicit || $download_base_explicit; then
        emit write_channel started
        write_channel "$channel" "$download_base"
        emit write_channel ok
        maybe_inject_failure write_channel
    fi

    # Smart Uplink activation tuple (issue #108): explicit flags rewrite the
    # installer-owned drop-in. No flags, no writes — since v0.4.2 the agent
    # itself self-activates approved hardware from embedded evidence rows, so
    # a plain update needs no extra fields. restart_units_forward
    # daemon-reloads before restarting, so a rewritten tuple is live once the
    # updated agent is back.
    if [ -n "$qos_tier" ]; then
        write_qos_tier_dropin
    fi

    local pkg_dir
    emit download started
    LAST_ERROR_CODE=DOWNLOAD_FAILED
    resolve_update_package
    pkg_dir="$RESOLVED_PKG_DIR"
    LAST_ERROR_CODE=""
    emit download ok
    maybe_inject_failure download

    emit verify_checksum started
    LAST_ERROR_CODE=CHECKSUM_MISMATCH
    verify_update_checksum "$pkg_dir"
    LAST_ERROR_CODE=""
    emit verify_checksum ok
    maybe_inject_failure verify_checksum

    local active inactive
    active="$(current_slot_name "$opt_dir")"
    [ -n "$active" ] || active="slot-a"
    inactive="$(inactive_slot_name "$active")"
    UPDATE_PREV_SLOT="$active"

    emit stage_inactive_slot started
    stage_slot "$opt_dir" "$inactive" "$pkg_dir"
    emit stage_inactive_slot ok
    maybe_inject_failure stage_inactive_slot

    emit validate_slot started
    LAST_ERROR_CODE=HEALTH_CHECK_FAILED
    validate_slot "$opt_dir/$inactive"
    LAST_ERROR_CODE=""
    emit validate_slot ok
    maybe_inject_failure validate_slot

    emit swap_current started
    atomic_symlink_swap "$opt_dir" "$inactive"
    UPDATE_SWAPPED=1
    emit swap_current ok
    maybe_inject_failure swap_current

    emit restart started
    LAST_ERROR_CODE=HEALTH_CHECK_FAILED
    restart_units_forward
    emit restart ok
    maybe_inject_failure restart
    LAST_ERROR_CODE=""

    emit post_swap_health_check started
    LAST_ERROR_CODE=HEALTH_CHECK_FAILED
    if ! update_health_ok; then
        emit post_swap_health_check failed HEALTH_CHECK_FAILED
        return 1
    fi
    emit post_swap_health_check ok
    maybe_inject_failure post_swap_health_check
    LAST_ERROR_CODE=""

    commit_transaction
    emit operation ok
    log "update complete (current -> $inactive)"
}

do_uninstall() {
    lifecycle_init uninstall
    emit operation started

    emit preflight started
    require_root_for_real_install
    emit preflight ok

    local opt_dir etc_dir state_dir systemd_dir
    opt_dir="$(root_path /opt/axon-agent)"
    etc_dir="$(root_path /etc/axon)"
    state_dir="$(root_path /var/lib/axon)"
    systemd_dir="$(root_path /etc/systemd/system)"

    emit stop_units started
    run_systemctl stop axon-agent.service || true
    run_systemctl stop axon-agent-classifier.service || true
    emit stop_units ok

    emit disable_units started
    run_systemctl disable axon-agent.service || true
    run_systemctl disable axon-agent-classifier.service || true
    emit disable_units ok

    emit remove_units started
    rm -f "$systemd_dir/axon-agent.service" "$systemd_dir/axon-agent-classifier.service"
    rm -f "$systemd_dir/axon-agent-classifier.service.d/10-mirror-promisc.conf" 2>/dev/null || true
    rmdir "$systemd_dir/axon-agent-classifier.service.d" 2>/dev/null || true
    # Remove only the installer-managed QoS tuple; hand-placed operator drop-ins
    # in the same directory (e.g. qos-lab-ceilings.conf) are left alone.
    rm -f "$systemd_dir/axon-agent.service.d/20-qos-tier.conf" 2>/dev/null || true
    rmdir "$systemd_dir/axon-agent.service.d" 2>/dev/null || true
    run_systemctl daemon-reload || true
    emit remove_units ok

    emit remove_opt started
    rm -rf "$opt_dir"
    emit remove_opt ok

    # OVS cleanup runs before any purge so classifier_config.json bridge_name is
    # still readable. Reuses the marker+priority guard: never touches unmanaged
    # bridges or non-Axon/low-priority flows.
    emit ovs_cleanup started
    flush_marked_flows_on_managed_bridges
    emit ovs_cleanup ok

    if $purge; then
        emit purge started
        rm -rf "$etc_dir" "$state_dir"
        emit purge ok
    else
        log "preserving $etc_dir and $state_dir (use --purge to remove config/state)"
    fi

    emit operation ok
    log "uninstall complete"
}

# ── Argument parsing ────────────────────────────────────────────────────────
operation="install"
purge=false
enrollment_token=""
controller_url="https://controller.axon.local"
primary_interface=""
deployment_mode=""
monitor_interface=""
site_id=""
device_id=""
channel="${AXON_CHANNEL:-main}"
download_base="${AXON_DOWNLOAD_BASE:-}"
# Track whether the channel / download base were EXPLICITLY passed on the CLI, so
# the --update path only rewrites /etc/axon/agent.env when the operator changed
# them (otherwise an update must leave the recorded channel/index URL untouched).
channel_explicit=false
download_base_explicit=false
force_migration=false
qos_tier=""
qos_max_rate_kbit=""
qos_max_memlimit_bytes=""

while [ "$#" -gt 0 ]; do
    case "$1" in
        --update)
            operation="update"
            shift
            ;;
        --uninstall)
            operation="uninstall"
            shift
            ;;
        --purge)
            purge=true
            shift
            ;;
        --enrollment-token)
            enrollment_token="${2:?missing token}"
            shift 2
            ;;
        --controller-url)
            controller_url="${2:?missing controller URL}"
            shift 2
            ;;
        --primary-interface)
            primary_interface="${2:?missing interface}"
            shift 2
            ;;
        --deployment-mode)
            deployment_mode="${2:?missing deployment mode}"
            shift 2
            ;;
        --monitor-interface)
            monitor_interface="${2:?missing monitor interface}"
            shift 2
            ;;
        --site-id)
            site_id="${2:?missing site id}"
            shift 2
            ;;
        --device-id)
            device_id="${2:?missing device id}"
            shift 2
            ;;
        --channel)
            channel="${2:?missing channel}"
            channel_explicit=true
            shift 2
            ;;
        --download-base)
            download_base="${2:?missing download base}"
            download_base_explicit=true
            shift 2
            ;;
        --qos-tier)
            qos_tier="${2:?missing qos tier}"
            shift 2
            ;;
        --qos-max-rate-kbit)
            qos_max_rate_kbit="${2:?missing qos max rate}"
            shift 2
            ;;
        --qos-max-memlimit-bytes)
            qos_max_memlimit_bytes="${2:?missing qos max memlimit}"
            shift 2
            ;;
        --migrate-python)
            force_migration=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            log "unknown argument: $1"
            usage >&2
            exit 2
            ;;
    esac
done

# --purge implies uninstall; reject mixing it with install/update.
if $purge; then
    case "$operation" in
        install) operation="uninstall" ;;
        uninstall) : ;;
        *) log "--purge is only valid with --uninstall"; exit 2 ;;
    esac
fi

# Validate the release channel before any work so a typo aborts cleanly. main is
# the default; only alpha|beta|main are accepted.
case "$channel" in
    alpha|beta|main) : ;;
    *) log "invalid --channel '$channel' (expected one of: alpha, beta, main)"; exit 2 ;;
esac

# Smart Uplink activation tuple (issue #108): validate before any work. The
# agent enforces all-or-none at startup (internal/sqm/activation.go) and an
# incomplete tuple prevents it from booting, so the installer rejects a partial
# or implausible tuple upfront instead of committing a broken install.
if [ -n "$qos_tier$qos_max_rate_kbit$qos_max_memlimit_bytes" ]; then
    if [ -z "$qos_tier" ] || [ -z "$qos_max_rate_kbit" ] || [ -z "$qos_max_memlimit_bytes" ]; then
        log "--qos-tier, --qos-max-rate-kbit and --qos-max-memlimit-bytes are all-or-none: a partial tuple prevents agent startup"
        exit 2
    fi
    case "$operation" in
        install|update) : ;;
        *) log "--qos-* flags are only valid with install or --update"; exit 2 ;;
    esac
    # Mirror internal/sqm/activation.go exactly: tier ^[a-z0-9][a-z0-9._-]{2,63}$
    # and never containing "unvalidated". Digit-count anchors in the numeric
    # regexes keep the range comparisons overflow-safe (an oversized literal
    # would make `[ -gt ]` error out and the check silently pass).
    if ! printf '%s' "$qos_tier" | grep -Eq '^[a-z0-9][a-z0-9._-]{2,63}$' \
        || printf '%s' "$qos_tier" | grep -Fq 'unvalidated'; then
        log "invalid --qos-tier '$qos_tier' (3-64 chars of a-z 0-9 . _ -, starting with a letter or digit, not containing 'unvalidated')"
        exit 2
    fi
    if ! printf '%s' "$qos_max_rate_kbit" | grep -Eq '^[1-9][0-9]{0,8}$' \
        || [ "$qos_max_rate_kbit" -gt 100000000 ]; then
        log "invalid --qos-max-rate-kbit '$qos_max_rate_kbit' (expected integer 1..100000000)"
        exit 2
    fi
    if ! printf '%s' "$qos_max_memlimit_bytes" | grep -Eq '^[1-9][0-9]{0,9}$' \
        || [ "$qos_max_memlimit_bytes" -lt 1048576 ] || [ "$qos_max_memlimit_bytes" -gt 1073741824 ]; then
        log "invalid --qos-max-memlimit-bytes '$qos_max_memlimit_bytes' (expected integer 1048576..1073741824)"
        exit 2
    fi
fi

AXON_ROOT="${AXON_ROOT:-/}"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AXON_PACKAGE_DIR="${AXON_PACKAGE_DIR:-$script_dir}"

case "$operation" in
    install) do_install ;;
    update) do_update ;;
    uninstall) do_uninstall ;;
    *) log "unknown operation: $operation"; exit 2 ;;
esac
