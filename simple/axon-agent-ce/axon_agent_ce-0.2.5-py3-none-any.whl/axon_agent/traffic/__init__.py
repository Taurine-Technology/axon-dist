"""Traffic capture and analysis module.

This module provides traffic sniffing and flow classification functionality
for the Axon Agent. The sniffer can be run as a standalone script via:
    python -m axon_agent.traffic.sniffer

To avoid RuntimeWarnings when running the sniffer as a standalone script,
imports are done lazily via __getattr__. Import directly from submodules:
    from axon_agent.traffic.sniffer import start_sniffer_process
    from axon_agent.traffic.sniffer import stop_sniffer
"""

__all__ = [
    "start_sniffer_process",
    "stop_sniffer",
    "TrafficSniffer",
]


def __getattr__(name: str):
    """Lazy import to avoid RuntimeWarning when running sniffer as script."""
    if name == "start_sniffer_process":
        from .sniffer import start_sniffer_process

        return start_sniffer_process
    elif name == "stop_sniffer":
        from .sniffer import stop_sniffer

        return stop_sniffer
    elif name == "TrafficSniffer":
        from .sniffer import TrafficSniffer

        return TrafficSniffer
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
