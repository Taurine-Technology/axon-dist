# File: sniffer.py

"""Traffic sniffer that captures flows and publishes to MQTT via protobuf.

Extends BaseAgent for lifecycle management (config loading, MQTT connection
with infinite retry, signal handling, graceful shutdown).

Run as standalone:
    python -m axon_agent.traffic.sniffer
"""

import hashlib
import ipaddress
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from typing import Optional, Set, Tuple

import dpkt
import pcapy
import psutil
import zstandard as zstd

from ..base_agent import BaseAgent
from ..hostname_resolver import HostnameResolver
from ..utils import stop_systemd_service, disable_systemd_service
from axon_shared.proto.flow_messages_pb2 import FlowBatch
from axon_shared.mqtt.topics import data_topic, FLOWS

logger = logging.getLogger(__name__)

# Default configuration values
DEFAULT_NUM_BYTES = 225
DEFAULT_NUM_PACKETS = 5
DEFAULT_BATCH_INTERVAL = 1  # seconds
DEFAULT_FLOW_EXPIRATION = 30  # seconds for flow expiration
MAX_BATCH_SIZE = 500  # Max flows retained in batch during MQTT outages

# Sniffer config file path
SNIFFER_CONFIG_PATH = "/etc/axon/sniffer_config.json"


class TrafficSniffer(BaseAgent):
    """Captures network traffic and publishes flow data to MQTT.

    Extends BaseAgent with infinite MQTT retries. Config is loaded from
    sniffer_config.json (overrides default _load_config). Background
    threads handle batch sending and flow expiration while the main loop
    runs pcapy packet capture.
    """

    agent_name = "Traffic Sniffer"
    mqtt_client_id_suffix = "sniffer"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 5.0
    use_counted_retries = False
    publish_buffer_size = 60

    def __init__(self):
        """Initialize traffic sniffer."""
        super().__init__()

        # Configuration from sniffer_config.json
        self.bridge_name: Optional[str] = None
        self.monitor_interface: Optional[str] = None
        self.num_bytes: int = DEFAULT_NUM_BYTES
        self.num_packets: int = DEFAULT_NUM_PACKETS
        self.model_name: Optional[str] = None

        # MQTT topic for publishing flows
        self.flows_topic: Optional[str] = None

        # Flow state tracking (protected by flow_lock)
        self.flow_dict: dict = {}  # flow_key -> list of payload bytes
        self.flow_predicted: dict = (
            {}
        )  # flow_key -> bool (already sent for classification)
        self.total_flow_len: dict = {}  # flow_key -> packet count
        self.flow_last_seen: dict = {}  # flow_key -> timestamp
        self.flow_lock = threading.Lock()  # Protects all flow_* dictionaries

        # Batching for MQTT publish
        self.classification_batch: list = []  # List of (flow_key, flow_data_dict)
        self.batch_lock = threading.Lock()
        self.batch_interval: float = DEFAULT_BATCH_INTERVAL

        # Zstd compressor for payload compression
        self.compressor = zstd.ZstdCompressor(level=3)

        # Hostname resolver for client device name discovery
        self._hostname_resolver: Optional[HostnameResolver] = None

        # OVS query state tracking (for graceful degradation)
        self._ovs_available: bool = True  # Assume available until proven otherwise
        self._ovs_last_warning_time: float = 0  # Prevent log spam

    # ------------------------------------------------------------------
    # Config loading (overrides BaseAgent._load_config entirely)
    # ------------------------------------------------------------------

    def _load_config(self) -> bool:
        """Load sniffer-specific configuration from sniffer_config.json.

        Overrides BaseAgent._load_config because the sniffer reads from
        its own config file rather than config.json.

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            if not os.path.exists(SNIFFER_CONFIG_PATH):
                logger.error(f"Sniffer config not found: {SNIFFER_CONFIG_PATH}")
                return False

            with open(SNIFFER_CONFIG_PATH, "r") as f:
                config = json.load(f)

            self.bridge_name = config.get("bridge_name")
            self.monitor_interface = config.get("monitor_interface")
            # Note: port_to_client and port_to_router are deprecated and ignored
            self.num_bytes = config.get("num_bytes", DEFAULT_NUM_BYTES)
            self.num_packets = config.get("num_packets", DEFAULT_NUM_PACKETS)
            self.site_id = config.get("site_id")
            self.device_id = config.get("device_id")
            self.model_name = config.get("model_name")

            # Validate required fields
            if not self.monitor_interface:
                logger.error("Sniffer config missing monitor_interface")
                return False

            if not self.site_id or not self.device_id:
                logger.error("Sniffer config missing site_id or device_id")
                return False

            # Build MQTT topic
            self.flows_topic = data_topic(self.site_id, self.device_id, FLOWS)

            logger.info(
                f"Loaded sniffer config: interface={self.monitor_interface}, "
                f"num_bytes={self.num_bytes}, num_packets={self.num_packets}, "
                f"site_id={self.site_id}, device_id={self.device_id}"
            )
            return True

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in sniffer config: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to load sniffer config: {e}")
            return False

    def _load_service_config(self, config: dict) -> bool:
        """Not used -- _load_config is overridden entirely.

        Required by BaseAgent ABC but never called because _load_config
        does not delegate to this method.

        Args:
            config: Unused

        Returns:
            True (no-op)
        """
        return True

    # ------------------------------------------------------------------
    # Lifecycle hooks
    # ------------------------------------------------------------------

    def _setup(self):
        """Start background threads after MQTT connection."""
        batch_thread = threading.Thread(
            target=self._batch_sender, daemon=True
        )
        batch_thread.start()

        cleanup_thread = threading.Thread(
            target=self._clear_expired_flows, daemon=True
        )
        cleanup_thread.start()

        # Start hostname resolver for client device name discovery.
        # This populates the shared hostname cache file so that flow stats
        # monitors can enrich flow data with client hostnames.
        if self.monitor_interface:
            self._hostname_resolver = HostnameResolver(
                interface=self.monitor_interface,
            )
            self._hostname_resolver.start()

    def _run_loop(self):
        """Main capture loop -- runs pcapy packet capture."""
        logger.info(
            f"Starting packet capture on interface: {self.monitor_interface}"
        )

        try:
            cap = pcapy.open_live(
                self.monitor_interface,
                65536,  # snaplen (max bytes per packet)
                True,  # promiscuous mode
                1000,  # timeout in ms
            )

            while self.running:
                try:
                    header, data = cap.next()
                    if header is not None:
                        self._packet_handler(header, data)
                except pcapy.PcapError as e:
                    if "timeout" in str(e).lower():
                        # Timeout is normal, continue
                        continue
                    else:
                        raise

        except PermissionError:
            logger.error(
                f"Permission denied to capture on {self.monitor_interface}. "
                "Try running as root or with CAP_NET_RAW capability."
            )
        except OSError as e:
            logger.error(
                f"OS error capturing on {self.monitor_interface}: {e}. "
                "Check if interface exists and is up."
            )
        except Exception as e:
            logger.error(
                f"Error during packet capture: {e}", exc_info=True
            )

    def _cleanup(self):
        """Stop hostname resolver on shutdown."""
        if self._hostname_resolver:
            self._hostname_resolver.stop()

    # ------------------------------------------------------------------
    # Packet processing
    # ------------------------------------------------------------------

    def _is_private_ip(self, ip: str) -> bool:
        """Check if an IP address is private.

        Args:
            ip: IP address string

        Returns:
            True if private, False otherwise
        """
        try:
            return ipaddress.ip_address(ip).is_private
        except ValueError:
            logger.warning(f"Invalid IP address: {ip}")
            return False

    def _compute_flow_key(
        self,
        ip_src: str,
        ip_dst: str,
        protocol: str,
        sport: int,
        dport: int,
        mac: str,
    ) -> Tuple:
        """Compute a unique flow key based on client perspective.

        The flow key is always oriented from the client's perspective:
        (client_ip, remote_ip, protocol, client_port, remote_port, client_mac)

        Args:
            ip_src: Source IP
            ip_dst: Destination IP
            protocol: "TCP" or "UDP"
            sport: Source port
            dport: Destination port
            mac: Client MAC address

        Returns:
            Tuple identifying the flow
        """
        if self._is_private_ip(ip_src):
            # Source is client
            return (ip_src, ip_dst, protocol, str(sport), str(dport), mac)
        else:
            # Destination is client
            return (ip_dst, ip_src, protocol, str(dport), str(sport), mac)

    def _generate_flow_id(self, flow_key: Tuple) -> int:
        """Generate a deterministic 32-bit flow ID from the flow tuple.

        The flow ID is used for correlation between the sniffer and controller,
        and forms the lower 32 bits of the OpenFlow cookie.

        Args:
            flow_key: Tuple identifying the flow

        Returns:
            32-bit unsigned integer flow ID
        """
        key_str = "|".join(str(x) for x in flow_key)
        hash_bytes = hashlib.sha256(key_str.encode()).digest()
        # Take first 4 bytes as 32-bit unsigned integer
        return int.from_bytes(hash_bytes[:4], byteorder="big")

    def _packet_handler(self, header, data: bytes):
        """Handle captured packet from pcapy.

        Args:
            header: pcapy packet header
            data: Raw packet bytes
        """
        if not self.running:
            return

        try:
            eth = dpkt.ethernet.Ethernet(data)

            # Only process IP packets
            if not isinstance(eth.data, dpkt.ip.IP):
                return

            ip = eth.data
            src_ip = dpkt.utils.inet_to_str(ip.src)
            dst_ip = dpkt.utils.inet_to_str(ip.dst)

            # Extract MAC addresses
            src_mac = ":".join("%02x" % b for b in eth.src)
            dst_mac = ":".join("%02x" % b for b in eth.dst)

            # Determine protocol and extract ports/payload
            protocol: Optional[str] = None
            sport: Optional[int] = None
            dport: Optional[int] = None
            payload: bytes = b""

            if isinstance(ip.data, dpkt.tcp.TCP):
                protocol = "TCP"
                tcp = ip.data
                sport = tcp.sport
                dport = tcp.dport
                payload = bytes(tcp.data) if tcp.data else b""
            elif isinstance(ip.data, dpkt.udp.UDP):
                protocol = "UDP"
                udp = ip.data
                sport = udp.sport
                dport = udp.dport
                payload = bytes(udp.data) if udp.data else b""
            else:
                # Not TCP or UDP, ignore
                return

            # Determine client MAC based on which IP is private
            src_is_private = self._is_private_ip(src_ip)
            dst_is_private = self._is_private_ip(dst_ip)

            # Skip LAN to LAN traffic (both IPs are private)
            if src_is_private and dst_is_private:
                logger.debug(
                    f"LAN to LAN traffic: {src_ip} -> {dst_ip}, skipping"
                )
                return

            # Skip if neither IP is private (no client identified)
            if not src_is_private and not dst_is_private:
                logger.debug(
                    f"Packet with no private IP: {src_ip} -> {dst_ip}, "
                    "skipping"
                )
                return

            client_mac: Optional[str] = None
            src_is_client: bool = False

            if src_is_private:
                client_mac = src_mac
                src_is_client = True
            else:
                # dst must be private (we've already filtered out other cases)
                client_mac = dst_mac
                src_is_client = False

            # Compute flow key
            flow_key = self._compute_flow_key(
                src_ip, dst_ip, protocol, sport, dport, client_mac
            )

            # Skip packets with empty payloads (e.g., TCP ACK-only packets)
            # These should not count toward the 5 packets needed for classification
            if len(payload) == 0:
                # Still update flow tracking for expiry purposes
                with self.flow_lock:
                    self.flow_last_seen[flow_key] = time.time()
                return

            # Prepare payload sample outside lock
            if len(payload) >= self.num_bytes:
                payload_sample = payload[: self.num_bytes]
            else:
                # Pad with zeros if payload is shorter (but non-empty)
                payload_sample = payload + b"\x00" * (
                    self.num_bytes - len(payload)
                )

            # Variables to track state after lock release
            is_new_flow = False
            ready_for_classification = False
            payload_samples_copy = None

            # Update flow state (protected by flow_lock)
            with self.flow_lock:
                self.total_flow_len[flow_key] = (
                    self.total_flow_len.get(flow_key, 0) + 1
                )
                self.flow_last_seen[flow_key] = time.time()

                # Initialize flow if new
                if flow_key not in self.flow_dict:
                    self.flow_dict[flow_key] = []
                    self.flow_predicted[flow_key] = False
                    is_new_flow = True

                # Collect payload samples (first num_bytes of each packet)
                if len(self.flow_dict[flow_key]) < self.num_packets:
                    self.flow_dict[flow_key].append(payload_sample)

                # Check if we have enough packets to classify
                if (
                    len(self.flow_dict[flow_key]) == self.num_packets
                    and not self.flow_predicted.get(flow_key, False)
                ):
                    self.flow_predicted[flow_key] = True
                    ready_for_classification = True
                    # Copy payload samples while holding lock
                    payload_samples_copy = list(self.flow_dict[flow_key])

            # Logging outside lock to avoid blocking
            if is_new_flow:
                logger.debug(f"New flow started: {flow_key}")

            if ready_for_classification:
                logger.info(
                    f"Collected {self.num_packets} packets for flow "
                    f"{flow_key}. Queueing for classification."
                )

                # Build flow data for batch (using copied data)
                # Orient flow from client perspective: client is always "src"
                # This means swapping BOTH MACs AND IPs when src is the server
                if src_is_client:
                    # Already oriented correctly: src is client
                    flow_src_ip = src_ip
                    flow_dst_ip = dst_ip
                    flow_src_port = sport
                    flow_dst_port = dport
                    flow_src_mac = src_mac
                    flow_dst_mac = dst_mac
                else:
                    # Need to swap: dst is client, so flip everything
                    flow_src_ip = dst_ip
                    flow_dst_ip = src_ip
                    flow_src_port = dport
                    flow_dst_port = sport
                    flow_src_mac = dst_mac
                    flow_dst_mac = src_mac

                flow_data = {
                    "src_ip": flow_src_ip,
                    "dst_ip": flow_dst_ip,
                    "src_port": flow_src_port,
                    "dst_port": flow_dst_port,
                    "src_mac": flow_src_mac,
                    "dst_mac": flow_dst_mac,
                    "payload_samples": payload_samples_copy,
                    "is_tcp": protocol == "TCP",
                    "src_is_client": True,  # After normalization, src is always client
                    "packet_count": self.num_packets,
                }

                with self.batch_lock:
                    self.classification_batch.append(
                        (flow_key, flow_data)
                    )

        except dpkt.dpkt.NeedData:
            # Incomplete packet, skip
            pass
        except Exception as e:
            logger.error(f"Error processing packet: {e}", exc_info=True)

    # ------------------------------------------------------------------
    # Background threads
    # ------------------------------------------------------------------

    def _batch_sender(self):
        """Background thread that sends batched flows to MQTT."""
        logger.info("Batch sender thread started")

        while self.running:
            time.sleep(self.batch_interval)

            with self.batch_lock:
                if not self.classification_batch:
                    continue

                if (
                    not self.mqtt_client
                    or not self.mqtt_client.is_connected()
                ):
                    logger.warning(
                        "MQTT not connected, skipping batch send"
                    )
                    continue

                try:
                    # Build protobuf FlowBatch message
                    flow_batch = FlowBatch()
                    flow_batch.switch_id = self.bridge_name or ""
                    flow_batch.site_id = self.site_id or ""
                    flow_batch.device_id = self.device_id or ""
                    flow_batch.timestamp_ms = int(time.time() * 1000)
                    if self.model_name:
                        flow_batch.model_name = self.model_name

                    for flow_key, flow_data in self.classification_batch:
                        flow = flow_batch.flows.add()
                        flow.src_ip = flow_data["src_ip"]
                        flow.dst_ip = flow_data["dst_ip"]
                        flow.src_port = flow_data["src_port"]
                        flow.dst_port = flow_data["dst_port"]
                        flow.src_mac = flow_data["src_mac"]
                        flow.dst_mac = flow_data["dst_mac"]
                        flow.is_tcp = flow_data["is_tcp"]
                        flow.src_is_client = flow_data["src_is_client"]
                        flow.packet_count = flow_data["packet_count"]
                        # Generate deterministic 32-bit flow ID from flow tuple
                        flow.flow_id = self._generate_flow_id(flow_key)

                        # Flatten payload samples into single bytes object
                        flow.payload_sample = b"".join(
                            flow_data["payload_samples"]
                        )

                    # Serialize and compress
                    serialized = flow_batch.SerializeToString()
                    compressed = self.compressor.compress(serialized)

                    # Publish to MQTT (fire-and-forget, QoS 0)
                    if self.mqtt_client.publish_raw(
                        self.flows_topic, compressed, qos=0
                    ):
                        logger.debug(
                            f"Published batch of "
                            f"{len(self.classification_batch)} flows "
                            f"to {self.flows_topic} "
                            f"({len(compressed)} bytes compressed)"
                        )
                        # Only clear batch on successful publish
                        self.classification_batch.clear()
                    else:
                        logger.warning(
                            f"Failed to publish batch of "
                            f"{len(self.classification_batch)} flows "
                            f"to {self.flows_topic}. Batch retained for "
                            "retry on next interval."
                        )

                except Exception as e:
                    logger.error(
                        f"Error sending batch of "
                        f"{len(self.classification_batch)} flows: {e}. "
                        "Batch retained for retry on next interval.",
                        exc_info=True,
                    )
                    # Do not clear batch on exception - will retry next interval

                # Cap batch size to prevent unbounded memory growth
                if len(self.classification_batch) > MAX_BATCH_SIZE:
                    dropped = (
                        len(self.classification_batch) - MAX_BATCH_SIZE
                    )
                    self.classification_batch = (
                        self.classification_batch[-MAX_BATCH_SIZE:]
                    )
                    logger.warning(
                        f"Batch exceeded {MAX_BATCH_SIZE} flows, "
                        f"dropped {dropped} oldest entries to cap "
                        "memory usage"
                    )

        logger.info("Batch sender thread stopped")

    def _get_active_flow_ids_from_ovs(self) -> Optional[Set[int]]:
        """Get set of active flow IDs from OVS by extracting from cookies.

        Queries OVS for all flows and extracts the lower 32 bits of each
        cookie, which represents the flow_id.

        Returns:
            Set of 32-bit flow IDs if query successful (may be empty if
            no flows), None if OVS query failed (caller should skip
            OVS-based expiry)
        """
        if not self.bridge_name:
            return None

        try:
            result = subprocess.run(
                [
                    "ovs-ofctl", "dump-flows",
                    self.bridge_name, "-OOpenflow13",
                ],
                capture_output=True,
                text=True,
                timeout=3,  # Short timeout since called frequently
            )

            if result.returncode != 0:
                self._log_ovs_unavailable(
                    f"Failed to dump flows from bridge "
                    f"{self.bridge_name}: {result.stderr}"
                )
                return None

            # OVS query successful - mark as available
            if not self._ovs_available:
                logger.info("OVS connectivity restored")
            self._ovs_available = True

            active_ids: Set[int] = set()
            for line in result.stdout.splitlines():
                # Extract cookie=0x{hex digits} from flow entries
                match = re.search(r"cookie=0x([0-9a-fA-F]+)", line)
                if match:
                    try:
                        cookie = int(match.group(1), 16)
                        # Lower 32 bits is the flow_id
                        flow_id = cookie & 0xFFFFFFFF
                        active_ids.add(flow_id)
                    except ValueError:
                        continue
            logger.debug(f"Active flow IDs: {active_ids}")
            return active_ids

        except subprocess.TimeoutExpired:
            self._log_ovs_unavailable(
                f"Timeout (3s) querying OVS flows from bridge "
                f"{self.bridge_name}"
            )
            return None
        except FileNotFoundError:
            self._log_ovs_unavailable(
                "ovs-ofctl command not found - OVS flow monitoring disabled"
            )
            return None
        except Exception as e:
            self._log_ovs_unavailable(f"Error querying OVS flows: {e}")
            return None

    def _log_ovs_unavailable(self, message: str):
        """Log OVS unavailability with rate limiting to prevent log spam.

        Logs at WARNING level on first occurrence and then at most once
        per minute.
        """
        current_time = time.time()
        was_available = self._ovs_available
        self._ovs_available = False

        # Log immediately on first failure, then rate-limit to once per minute
        if was_available or (
            current_time - self._ovs_last_warning_time >= 60
        ):
            logger.warning(message)
            self._ovs_last_warning_time = current_time
        else:
            logger.debug(message)

    def _clear_expired_flows(self):
        """Background thread that clears expired flow state.

        Expiration logic:
        - If OVS is queryable: Flow expires when NOT in OVS AND idle for
          DEFAULT_FLOW_EXPIRATION seconds (OVS-aware expiry)
        - If OVS query fails: Fall back to time-based expiry only, using a
          longer timeout (3x DEFAULT_FLOW_EXPIRATION) to avoid premature
          expiration

        This allows the same flow tuple to be re-classified if it reappears
        after the OVS flow rule has expired.
        """
        logger.info("Flow cleanup thread started")

        # Fallback timeout when OVS is unavailable (more conservative)
        fallback_expiration = DEFAULT_FLOW_EXPIRATION * 3

        while self.running:
            try:
                # Try to get active flow_ids from OVS
                active_flow_ids = self._get_active_flow_ids_from_ovs()
                ovs_available = active_flow_ids is not None
                current_time = time.time()
                expired_keys = []

                # Find expired flows while holding lock
                with self.flow_lock:
                    for flow_key in list(self.flow_dict.keys()):
                        last_seen = self.flow_last_seen.get(flow_key, 0)
                        idle_time = current_time - last_seen

                        if ovs_available:
                            # OVS-aware expiry: must be absent from OVS AND idle
                            flow_id = self._generate_flow_id(flow_key)
                            if flow_id not in active_flow_ids:
                                if idle_time >= DEFAULT_FLOW_EXPIRATION:
                                    expired_keys.append(flow_key)
                        else:
                            # Fallback: time-based only with longer timeout
                            if idle_time >= fallback_expiration:
                                expired_keys.append(flow_key)

                    # Remove expired flows while still holding lock
                    for key in expired_keys:
                        self.flow_dict.pop(key, None)
                        self.flow_predicted.pop(key, None)
                        self.total_flow_len.pop(key, None)
                        self.flow_last_seen.pop(key, None)

                # Logging outside lock
                if expired_keys:
                    if ovs_available:
                        logger.info(
                            f"Cleared {len(expired_keys)} expired flows "
                            f"(not in OVS and idle for "
                            f"{DEFAULT_FLOW_EXPIRATION}s)"
                        )
                    else:
                        logger.info(
                            f"Cleared {len(expired_keys)} expired flows "
                            f"(OVS unavailable, idle for "
                            f"{fallback_expiration}s)"
                        )
                    for key in expired_keys:
                        logger.debug(f"Cleared expired flow: {key}")

            except Exception as e:
                logger.error(
                    f"Error in flow cleanup: {e}", exc_info=True
                )

            time.sleep(1)

        logger.info("Flow cleanup thread stopped")


# ------------------------------------------------------------------
# Module-level process management functions
# ------------------------------------------------------------------


def start_sniffer_process() -> Optional[subprocess.Popen]:
    """Start the traffic sniffer script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if sniffer process is already running
    if _is_sniffer_running():
        logger.info("Traffic sniffer process is already running")
        return None

    try:
        python_executable = sys.executable
        module_path = "axon_agent.traffic.sniffer"

        logger.info("Starting traffic sniffer process...")

        # Start process in background
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Give it a moment to start
        time.sleep(0.5)

        if process.poll() is None:
            logger.info(
                f"Traffic sniffer process started (PID: {process.pid})"
            )
            return process
        else:
            logger.error("Traffic sniffer process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start traffic sniffer process: {e}")
        return None


def _is_sniffer_running() -> bool:
    """Check if traffic sniffer process is already running.

    Returns:
        True if running, False otherwise
    """
    try:
        # Check if running as systemd service
        try:
            result = subprocess.run(
                [
                    "systemctl", "is-active", "--quiet",
                    "axon-agent-sniffer.service",
                ],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            pass

        current_pid = os.getpid()

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.traffic.sniffer" in cmdline_str:
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return False
    except Exception as e:
        logger.error(f"Error checking for sniffer process: {e}")
        return False


def stop_sniffer() -> bool:
    """Stop traffic sniffer service/process.

    Returns:
        True if stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    sniffer_service = "axon-agent-sniffer.service"

    # Try to stop systemd service first
    try:
        if stop_systemd_service(sniffer_service):
            logger.info("Stopped traffic sniffer systemd service")
            if disable_systemd_service(sniffer_service):
                logger.info("Disabled traffic sniffer systemd service")
                return True
    except Exception as e:
        logger.warning(f"Failed to stop sniffer systemd service: {e}")

    # Fallback: stop subprocess
    try:
        current_pid = os.getpid()
        stopped_any = False

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.traffic.sniffer" in cmdline_str:
                        if proc.is_running():
                            logger.info(
                                f"Stopping sniffer process "
                                f"(PID: {proc.pid})"
                            )
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                            except psutil.TimeoutExpired:
                                proc.kill()
                                proc.wait()
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return stopped_any
    except Exception as e:
        logger.error(f"Error stopping sniffer process: {e}")
        return False


def main():
    """Main entry point for traffic sniffer."""
    sniffer = TrafficSniffer()
    sniffer.run()


if __name__ == "__main__":
    main()
