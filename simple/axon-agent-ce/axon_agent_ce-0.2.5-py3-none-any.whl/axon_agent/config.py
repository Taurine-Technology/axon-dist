"""Configuration management for Axon Agent."""

import fcntl
import json
import logging
import os
import tempfile
from typing import Optional

logger = logging.getLogger(__name__)


class ConfigManager:
    """Manages loading and saving of bootstrap and config files."""

    def __init__(self, bootstrap_path: str = None, config_path: str = None):
        """Initialize ConfigManager with file paths.

        Args:
            bootstrap_path: Path to bootstrap.json. If None, tries /etc/axon/bootstrap.json then ./bootstrap.json
            config_path: Path to config.json. If None, tries /etc/axon/config.json then ./config.json
        """
        logger.debug("Initializing ConfigManager...")
        logger.debug(f"Current working directory: {os.getcwd()}")

        self.bootstrap_path = bootstrap_path or self._find_bootstrap()
        logger.debug(f"Using bootstrap path: {os.path.abspath(self.bootstrap_path)}")

        self.config_path = config_path or self._find_config()
        logger.debug(f"Using config path: {os.path.abspath(self.config_path)}")

    def _find_bootstrap(self) -> str:
        """Find bootstrap.json file path."""
        paths = ["/etc/axon/bootstrap.json", "./bootstrap.json"]
        logger.debug(f"Searching for bootstrap.json in: {paths}")
        for path in paths:
            abs_path = os.path.abspath(path)
            exists = os.path.exists(path)
            logger.debug(f"  Checking {path} (absolute: {abs_path}) - exists: {exists}")
            if exists:
                logger.debug(f"Found bootstrap.json at: {abs_path}")
                return path
        default_path = "./bootstrap.json"
        logger.debug(
            f"No bootstrap.json found, defaulting to: {os.path.abspath(default_path)}"
        )
        return default_path  # Default to current directory

    def _find_config(self) -> str:
        """Find config.json file path."""
        paths = ["/etc/axon/config.json", "./config.json"]
        logger.debug(f"Searching for config.json in: {paths}")
        for path in paths:
            abs_path = os.path.abspath(path)
            exists = os.path.exists(path)
            logger.debug(f"  Checking {path} (absolute: {abs_path}) - exists: {exists}")
            if exists:
                logger.debug(f"Found existing config.json at: {abs_path}")
                return path
        default_path = "./config.json"
        abs_default = os.path.abspath(default_path)
        logger.info(f"No existing config.json found, will use: {abs_default}")
        return default_path  # Default to current directory

    def load_bootstrap(self) -> dict:
        """Load bootstrap.json configuration.

        Returns:
            Bootstrap configuration dictionary

        Raises:
            FileNotFoundError: If bootstrap.json doesn't exist
            json.JSONDecodeError: If bootstrap.json is invalid JSON
        """
        try:
            with open(self.bootstrap_path, "r") as f:
                config = json.load(f)
            logger.info(f"Loaded bootstrap config from {self.bootstrap_path}")
            return config
        except FileNotFoundError:
            logger.error(f"Bootstrap file not found: {self.bootstrap_path}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in bootstrap file: {e}")
            raise

    def load_config(self) -> Optional[dict]:
        """Load config.json (adopted device configuration).

        Returns:
            Config dictionary if file exists, None otherwise
        """
        abs_config_path = os.path.abspath(self.config_path)
        logger.debug(f"Loading config from: {abs_config_path}")
        logger.debug(f"Config path (relative): {self.config_path}")
        logger.debug(f"Current working directory: {os.getcwd()}")
        logger.debug(f"File exists: {os.path.exists(self.config_path)}")

        if os.path.exists(self.config_path):
            file_size = os.path.getsize(self.config_path)
            logger.debug(f"Config file size: {file_size} bytes")

        try:
            with open(self.config_path, "r") as f:
                config = json.load(f)
            logger.debug(f"Successfully loaded config from {abs_config_path}")
            logger.debug(f"Config contains keys: {list(config.keys())}")

            return config
        except FileNotFoundError:
            logger.debug(
                f"Config file not found: {abs_config_path} (device not adopted)"
            )
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config file {abs_config_path}: {e}")
            return None

    def save_config(self, config: dict) -> None:
        """Save config.json atomically (write to temp file, then rename).

        Args:
            config: Configuration dictionary to save

        Raises:
            OSError: If file cannot be written
        """
        abs_config_path = os.path.abspath(self.config_path)
        logger.debug(f"Saving config to: {abs_config_path}")
        logger.debug(f"Config path (relative): {self.config_path}")
        logger.debug(f"Current working directory: {os.getcwd()}")

        config_dir = os.path.dirname(self.config_path)
        abs_config_dir = os.path.abspath(config_dir) if config_dir else os.getcwd()
        logger.debug(f"Config directory: {abs_config_dir}")

        if config_dir and not os.path.exists(config_dir):
            logger.debug(f"Config directory does not exist, creating: {abs_config_dir}")
            try:
                os.makedirs(config_dir, mode=0o755, exist_ok=True)
                logger.debug(f"Successfully created config directory: {abs_config_dir}")
            except OSError as e:
                logger.error(f"Could not create config directory {abs_config_dir}: {e}")
                raise
        else:
            logger.debug(f"Config directory exists: {abs_config_dir}")

        # Write to temp file first
        temp_dir = config_dir or "."
        abs_temp_dir = os.path.abspath(temp_dir)
        logger.debug(f"Creating temporary file in: {abs_temp_dir}")
        temp_fd, temp_path = tempfile.mkstemp(
            dir=temp_dir, prefix=".config.json.tmp.", suffix=""
        )
        abs_temp_path = os.path.abspath(temp_path)
        logger.debug(f"Temporary file created: {abs_temp_path}")

        try:
            with os.fdopen(temp_fd, "w") as f:
                json.dump(config, f, indent=2)
            logger.debug(f"Wrote config data to temporary file: {abs_temp_path}")

            # Atomic rename
            logger.debug(f"Renaming temporary file to: {abs_config_path}")
            os.replace(temp_path, self.config_path)

            # Verify the file exists after rename
            if os.path.exists(self.config_path):
                abs_final = os.path.abspath(self.config_path)
                file_size = os.path.getsize(self.config_path)
                logger.debug(
                    f"Successfully saved config to {abs_final} (size: {file_size} bytes)"
                )
            else:
                logger.error(
                    f"Config file does not exist after save: {abs_config_path}"
                )
        except Exception as e:
            # Clean up temp file on error
            try:
                os.unlink(temp_path)
                logger.debug(f"Cleaned up temporary file: {abs_temp_path}")
            except OSError:
                pass
            logger.error(
                f"Failed to save config to {abs_config_path}: {e}", exc_info=True
            )
            raise

    @property
    def _config_lock_path(self) -> str:
        """Path to the lock file used for config read-modify-write operations."""
        return self.config_path + ".lock"

    def _locked_config_update(self, updater) -> None:
        """Perform an atomic read-modify-write on config.json under a file lock.

        Acquires an exclusive file lock, reloads config inside the lock,
        calls updater(config) to mutate it, then saves.

        Args:
            updater: Callable that receives the config dict and mutates it in-place
        """
        lock_path = self._config_lock_path
        config_dir = os.path.dirname(lock_path)
        if config_dir and not os.path.exists(config_dir):
            os.makedirs(config_dir, mode=0o755, exist_ok=True)

        lock_fd = open(lock_path, "w")
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            # Reload inside lock to get latest state
            config = self.load_config() or {}
            updater(config)
            self.save_config(config)
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()

    def get_bridge_config(self, bridge_name: str) -> Optional[dict]:
        """Get config for a specific bridge from bridge_configs.

        Args:
            bridge_name: Name of the bridge

        Returns:
            Bridge config dict if found, None otherwise
        """
        config = self.load_config()
        if not config:
            return None
        return config.get("bridge_configs", {}).get(bridge_name)

    def set_bridge_config(self, bridge_name: str, bridge_config: dict) -> None:
        """Save config for a bridge under file lock.

        Updates bridge_configs[bridge_name].

        Args:
            bridge_name: Name of the bridge
            bridge_config: Bridge configuration dictionary
        """
        def _update(config):
            if "bridge_configs" not in config:
                config["bridge_configs"] = {}
            config["bridge_configs"][bridge_name] = bridge_config

        self._locked_config_update(_update)

    def delete_bridge_config(self, bridge_name: str) -> None:
        """Remove config for a bridge under file lock.

        Args:
            bridge_name: Name of the bridge to remove
        """
        def _update(config):
            bridge_configs = config.get("bridge_configs", {})
            bridge_configs.pop(bridge_name, None)
            config["bridge_configs"] = bridge_configs

        self._locked_config_update(_update)

    def get_all_bridge_configs(self) -> dict:
        """Get all bridge configs.

        Returns:
            Dict of bridge_name -> bridge_config, empty dict if none
        """
        config = self.load_config()
        if not config:
            return {}
        return config.get("bridge_configs", {})

    def is_adopted(self) -> bool:
        """Check if device is adopted (config.json exists and contains device_id).

        Returns:
            True if device is adopted, False otherwise
        """
        config = self.load_config()
        if config is None:
            return False

        # Check if device_id is present
        return "device_id" in config and config["device_id"]
