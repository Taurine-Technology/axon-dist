"""Device monitoring module.

This module provides monitoring functionality for the Axon Agent.
Individual monitors can be run as scripts via `python -m axon_agent.monitoring.<monitor>`.

To avoid RuntimeWarnings when running monitors as standalone scripts,
imports are done lazily via __getattr__. Import directly from submodules:
    from axon_agent.monitoring.device_monitor import start_monitoring_process
    from axon_agent.monitoring.port_stats_monitor import start_port_stats_monitoring_process
    from axon_agent.monitoring.port_link_monitor import start_port_link_monitoring_process
    from axon_agent.monitoring.flow_stats_monitor import start_flow_stats_monitoring_process
"""

__all__ = [
    "start_monitoring_process",
    "start_port_stats_monitoring_process",
    "start_port_link_monitoring_process",
    "start_flow_stats_monitoring_process",
]


def __getattr__(name: str):
    """Lazy import to avoid RuntimeWarning when running monitors as scripts."""
    if name == "start_monitoring_process":
        from .device_monitor import start_monitoring_process

        return start_monitoring_process
    elif name == "start_port_stats_monitoring_process":
        from .port_stats_monitor import start_port_stats_monitoring_process

        return start_port_stats_monitoring_process
    elif name == "start_port_link_monitoring_process":
        from .port_link_monitor import start_port_link_monitoring_process

        return start_port_link_monitoring_process
    elif name == "start_flow_stats_monitoring_process":
        from .flow_stats_monitor import start_flow_stats_monitoring_process

        return start_flow_stats_monitoring_process
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
