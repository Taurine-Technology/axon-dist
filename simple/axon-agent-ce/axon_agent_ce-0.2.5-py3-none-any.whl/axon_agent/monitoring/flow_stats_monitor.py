"""Flow statistics monitoring script that publishes OpenFlow flow statistics to MQTT.

This module polls OVS flow tables every 10 seconds, extracts statistics for metered
flows (flows with meter actions and non-zero cookies), and publishes them to the
Axon controller via MQTT using protobuf + zstd compression.

Only flows that have been classified by the Axon controller (indicated by having
a meter action and non-zero cookie) are collected.
"""

import json
import logging
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import List, Optional

import psutil
import zstandard as zstd

from ..base_agent import BaseAgent
from ..hostname_resolver import HostnameCache
from ..utils import stop_systemd_service, disable_systemd_service
from axon_shared.proto.flow_stats_messages_pb2 import FlowStatsBatch
from axon_shared.mqtt.topics import data_topic, FLOW_STATS

logger = logging.getLogger(__name__)

# Configuration constants
DEFAULT_POLL_INTERVAL = 10  # seconds
SNIFFER_CONFIG_PATH = "/etc/axon/sniffer_config.json"
DEFAULT_OPENFLOW_VERSION = "OpenFlow13"


@dataclass
class ParsedFlowStats:
    """Parsed flow statistics from OVS."""

    cookie: int
    meter_id: int
    byte_count: int
    packet_count: int
    duration_sec: float
    priority: int
    protocol: str
    mac_address: str
    hostname: str = ""  # Client device hostname from DHCP/mDNS


class FlowStatsMonitor(BaseAgent):
    """Monitors OpenFlow flow statistics for metered flows and publishes to MQTT."""

    agent_name = "Flow Stats Monitor"
    mqtt_client_id_suffix = "flow-stats"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 5.0
    use_counted_retries = False
    publish_buffer_size = 60

    def __init__(self):
        """Initialize flow stats monitor."""
        super().__init__()

        # Agent-specific configuration
        self.bridge_name: Optional[str] = None
        self.openflow_version: str = DEFAULT_OPENFLOW_VERSION
        self.poll_interval: int = DEFAULT_POLL_INTERVAL
        self.flow_stats_topic: Optional[str] = None

        # Zstd compressor for message compression
        self.compressor = zstd.ZstdCompressor(level=3)

        # Hostname cache for client device name lookups (read-only)
        self.hostname_cache: Optional[HostnameCache] = None

    # ------------------------------------------------------------------
    # Config loading (overrides BaseAgent._load_config entirely)
    # ------------------------------------------------------------------

    def _load_config(self) -> bool:
        """Load configuration from sniffer_config.json and config.json.

        The flow stats monitor uses the same configuration as the sniffer since
        it needs to know which bridge to poll and the site/device IDs for publishing.

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            # Load sniffer config (contains site_id, device_id, bridge_name)
            if not os.path.exists(SNIFFER_CONFIG_PATH):
                logger.error(f"Sniffer config not found: {SNIFFER_CONFIG_PATH}")
                logger.warning(
                    "Flow stats monitor requires sniffer to be installed first. "
                    "The service will be started when sniffer is installed via MQTT command."
                )
                return False

            with open(SNIFFER_CONFIG_PATH, "r") as f:
                sniffer_config = json.load(f)

            self.site_id = sniffer_config.get("site_id")
            self.device_id = sniffer_config.get("device_id")
            self.bridge_name = sniffer_config.get("bridge_name")

            if not self.site_id or not self.device_id:
                logger.error("Sniffer config missing site_id or device_id")
                return False

            # Load device config for additional settings
            config = self.config_manager.load_config()
            if config:
                # Get OpenFlow version from bridge_configs if available
                bridge_configs = config.get("bridge_configs", {})
                if isinstance(bridge_configs, dict) and bridge_configs:
                    # Prefer the bridge specified by sniffer config
                    if self.bridge_name and self.bridge_name in bridge_configs:
                        bridge_cfg = bridge_configs[self.bridge_name]
                    else:
                        if len(bridge_configs) > 1:
                            selected = next(iter(bridge_configs))
                            logger.warning(
                                f"Multiple bridges found ({list(bridge_configs.keys())}), "
                                f"selecting '{selected}'"
                            )
                        bridge_cfg = next(iter(bridge_configs.values()))
                    if isinstance(bridge_cfg, dict):
                        openflow_version = bridge_cfg.get("openflow_version")
                        if openflow_version:
                            self.openflow_version = openflow_version
                        if not self.bridge_name:
                            self.bridge_name = bridge_cfg.get("bridge_name")

            if not self.bridge_name:
                logger.error("Bridge name not found in sniffer config or device config")
                return False

            # Build flow stats topic
            self.flow_stats_topic = data_topic(self.site_id, self.device_id, FLOW_STATS)

            logger.info(
                f"Loaded config: site_id={self.site_id}, device_id={self.device_id}, "
                f"bridge={self.bridge_name}, openflow_version={self.openflow_version}"
            )
            return True

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in sniffer config: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            return False

    def _load_service_config(self, config: dict) -> bool:
        """Not used - this agent overrides _load_config() entirely."""
        return True

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def _run_loop(self):
        """Main monitoring loop: collect, build, compress, publish, sleep."""
        logger.info(
            f"Publishing to {self.flow_stats_topic} "
            f"every {self.poll_interval} seconds"
        )

        while self.running:
            # Collect flow stats
            flow_stats = self._collect_flow_stats()

            if flow_stats:
                # Build protobuf batch
                batch = self._build_protobuf_batch(flow_stats)

                # Compress and publish
                self._compress_and_publish(batch)
            else:
                logger.debug("No metered flows found")

            # Wait for next poll
            time.sleep(self.poll_interval)

    # ------------------------------------------------------------------
    # Business logic
    # ------------------------------------------------------------------

    def _get_flows_from_ovs(self) -> str:
        """Retrieve flow statistics from OVS bridge.

        Returns:
            Output from ovs-ofctl dump-flows command, or empty string on error
        """
        try:
            cmd = [
                "ovs-ofctl",
                "dump-flows",
                self.bridge_name,
                "-O",
                self.openflow_version,
            ]
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                logger.error(f"Error retrieving flows: {result.stderr}")
                return ""

            return result.stdout

        except subprocess.TimeoutExpired:
            logger.error("Timeout retrieving flows from OVS")
            return ""
        except Exception as e:
            logger.error(f"Exception retrieving flows: {e}")
            return ""

    def _parse_flow_line(self, line: str) -> Optional[ParsedFlowStats]:
        """Parse an OVS flow dump line to extract stats.

        Only returns stats for flows that:
        1. Have a meter action (actions=meter:N)
        2. Have a non-zero cookie (cookie=0x...)
        3. Are not controller flows (actions=CONTROLLER)

        Args:
            line: Single line from ovs-ofctl dump-flows output

        Returns:
            ParsedFlowStats if flow meets criteria, None otherwise
        """
        # Skip if no cookie or no actions
        if "cookie=" not in line or "actions=" not in line:
            return None

        # Extract cookie (required)
        cookie_match = re.search(r"cookie=0x([0-9a-fA-F]+)", line)
        if not cookie_match:
            return None

        try:
            cookie = int(cookie_match.group(1), 16)
        except ValueError:
            return None

        # Skip zero cookies (unclassified flows)
        if cookie == 0:
            return None

        # Extract actions and check for meter
        actions_match = re.search(r"actions=(.*)", line)
        if not actions_match:
            return None

        actions_str = actions_match.group(1)

        # Skip controller flows
        if "controller" in actions_str.lower():
            return None

        # Must have meter action
        meter_match = re.search(r"meter:(\d+)", actions_str)
        if not meter_match:
            return None

        meter_id = int(meter_match.group(1))

        # Extract other fields
        duration_match = re.search(r"duration=([\d\.]+)s", line)
        duration_sec = float(duration_match.group(1)) if duration_match else 0.0

        packets_match = re.search(r"n_packets=(\d+)", line)
        packet_count = int(packets_match.group(1)) if packets_match else 0

        bytes_match = re.search(r"n_bytes=(\d+)", line)
        byte_count = int(bytes_match.group(1)) if bytes_match else 0

        priority_match = re.search(r"priority=(\d+)", line)
        priority = int(priority_match.group(1)) if priority_match else 0

        # Determine protocol from match fields
        protocol = "OTHER"
        line_lower = line.lower()
        if (
            ",tcp," in line_lower
            or ",tcp " in line_lower
            or line_lower.endswith(",tcp")
        ):
            protocol = "TCP"
        elif (
            ",udp," in line_lower
            or ",udp " in line_lower
            or line_lower.endswith(",udp")
        ):
            protocol = "UDP"
        elif (
            ",icmp," in line_lower
            or ",icmp " in line_lower
            or line_lower.endswith(",icmp")
        ):
            protocol = "ICMP"
        elif (
            ",arp," in line_lower
            or ",arp " in line_lower
            or line_lower.endswith(",arp")
        ):
            protocol = "ARP"

        # Extract source MAC
        mac_match = re.search(r"dl_src=([0-9a-fA-F:]+)", line)
        mac_address = mac_match.group(1).lower() if mac_match else ""

        return ParsedFlowStats(
            cookie=cookie,
            meter_id=meter_id,
            byte_count=byte_count,
            packet_count=packet_count,
            duration_sec=duration_sec,
            priority=priority,
            protocol=protocol,
            mac_address=mac_address,
        )

    def _collect_flow_stats(self) -> List[ParsedFlowStats]:
        """Collect all metered flow statistics from OVS.

        Reloads the hostname cache on each poll cycle to pick up new
        hostname discoveries from the resolver.

        Returns:
            List of ParsedFlowStats for flows that meet criteria
        """
        output = self._get_flows_from_ovs()
        if not output:
            return []

        # Reload hostname cache from disk on each poll cycle
        try:
            self.hostname_cache = HostnameCache.load_from_file()
        except Exception as e:
            logger.debug(f"Failed to load hostname cache: {e}")

        stats = []
        for line in output.strip().splitlines():
            flow_stats = self._parse_flow_line(line)
            if flow_stats:
                # Enrich with hostname from cache
                if self.hostname_cache and flow_stats.mac_address:
                    flow_stats.hostname = self.hostname_cache.get(
                        flow_stats.mac_address
                    )
                stats.append(flow_stats)

        return stats

    def _build_protobuf_batch(
        self, flow_stats: List[ParsedFlowStats]
    ) -> FlowStatsBatch:
        """Build a FlowStatsBatch protobuf message.

        Args:
            flow_stats: List of parsed flow statistics

        Returns:
            FlowStatsBatch protobuf message
        """
        batch = FlowStatsBatch()
        batch.site_id = self.site_id
        batch.device_id = self.device_id
        batch.bridge_name = self.bridge_name
        batch.timestamp_ms = int(time.time() * 1000)

        for fs in flow_stats:
            entry = batch.stats.add()
            entry.openflow_cookie = fs.cookie
            entry.meter_id = fs.meter_id
            entry.byte_count = fs.byte_count
            entry.packet_count = fs.packet_count
            entry.duration_sec = fs.duration_sec
            entry.priority = fs.priority
            entry.protocol = fs.protocol
            entry.mac_address = fs.mac_address
            if fs.hostname:
                entry.hostname = fs.hostname

        return batch

    def _compress_and_publish(self, batch: FlowStatsBatch) -> bool:
        """Serialize, compress, and publish the batch.

        Args:
            batch: FlowStatsBatch protobuf message

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            return False

        try:
            # Serialize to protobuf
            protobuf_bytes = batch.SerializeToString()

            # Compress with zstd
            compressed = self.compressor.compress(protobuf_bytes)

            # Publish to MQTT with QoS 0 (fire-and-forget)
            result = self.mqtt_client.publish_raw(
                self.flow_stats_topic, compressed, qos=0
            )

            if result:
                logger.debug(
                    f"Published {len(batch.stats)} flow stats "
                    f"({len(protobuf_bytes)} bytes -> {len(compressed)} bytes compressed)"
                )
                return True
            else:
                logger.warning(
                    f"Failed to publish flow stats to {self.flow_stats_topic}"
                )
                return False

        except Exception as e:
            logger.error(f"Error publishing flow stats: {e}")
            return False


def start_flow_stats_monitoring_process() -> Optional[subprocess.Popen]:
    """Start the flow statistics monitoring script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if flow stats monitoring process is already running
    if _is_flow_stats_monitoring_running():
        logger.info("Flow statistics monitoring process is already running")
        return None

    try:
        # Use Python to run the module
        python_executable = sys.executable
        module_path = "axon_agent.monitoring.flow_stats_monitor"

        logger.info("Starting flow statistics monitoring process...")

        # Start process in background (daemon-like)
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # Create new process group
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is None:
            logger.info(
                f"Flow statistics monitoring process started (PID: {process.pid})"
            )
            return process
        else:
            logger.error("Flow statistics monitoring process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start flow statistics monitoring process: {e}")
        return None


def _is_flow_stats_monitoring_running() -> bool:
    """Check if flow statistics monitoring process is already running.

    Checks both for running processes and systemd service status.

    Returns:
        True if monitoring process is running, False otherwise
    """
    try:
        # First check if running as systemd service
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "--quiet", "axon-agent-flow-stats.service"],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                logger = logging.getLogger(__name__)
                logger.info("Flow statistics monitoring is running as systemd service")
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            # systemctl not available or timed out, continue with process check
            pass

        current_pid = os.getpid()

        # Check for processes matching our module name
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process to avoid self-detection
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    # Check if this is our flow stats monitoring process
                    cmdline_str = " ".join(cmdline)
                    if "flow_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.flow_stats_monitor" in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for flow stats monitoring process: {e}")
        return False


def stop_flow_stats_monitoring() -> bool:
    """Stop flow statistics monitoring service/process.

    Tries to stop systemd service first, then falls back to killing subprocess
    if systemd is not available or service is not running as systemd.

    Returns:
        True if monitoring was stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    flow_stats_service = "axon-agent-flow-stats.service"

    # Try to stop systemd service first
    try:
        if stop_systemd_service(flow_stats_service):
            logger.info("Stopped flow statistics monitoring systemd service")
            # Also disable it so it doesn't start on boot
            if disable_systemd_service(flow_stats_service):
                logger.info("Disabled flow statistics monitoring systemd service")
                return True
            else:
                logger.error(
                    f"Failed to disable {flow_stats_service} after stopping it. "
                    "Service may restart on next boot."
                )
                return False
    except Exception as e:
        logger.warning(
            f"Failed to stop flow stats systemd service: {e}, "
            "trying to stop subprocess"
        )

    # Fallback: try to stop subprocess if systemd not available or service not running
    try:
        current_pid = os.getpid()
        stopped_any = False

        # Find and kill flow stats monitoring processes
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "flow_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.flow_stats_monitor" in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            logger.info(
                                f"Stopping flow statistics monitoring process (PID: {proc.pid})"
                            )
                            proc.terminate()
                            # Wait up to 5 seconds for graceful shutdown
                            try:
                                proc.wait(timeout=5)
                                logger.info(
                                    f"Flow statistics monitoring process {proc.pid} stopped gracefully"
                                )
                            except psutil.TimeoutExpired:
                                # Force kill if it doesn't terminate
                                logger.warning(
                                    f"Process {proc.pid} did not terminate, forcing kill"
                                )
                                proc.kill()
                                proc.wait()
                                logger.info(
                                    f"Flow statistics monitoring process {proc.pid} killed"
                                )
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if stopped_any:
            logger.info("Stopped flow statistics monitoring process(es)")
            return True
        else:
            logger.info("No flow statistics monitoring process found to stop")
            return True  # Consider this success (nothing to stop)
    except Exception as e:
        logger.error(f"Error stopping flow statistics monitoring process: {e}")
        return False


def main():
    """Main entry point for flow stats monitor."""
    monitor = FlowStatsMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
