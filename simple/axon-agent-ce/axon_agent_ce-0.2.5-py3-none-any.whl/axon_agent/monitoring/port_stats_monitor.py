"""Port statistics monitoring script that publishes OpenFlow port statistics to MQTT."""

import logging
import os
import psutil
import re
import subprocess
import sys
import time
from typing import Optional

from ..base_agent import BaseAgent
from ..hardware import HardwareInfo
from ..utils import stop_systemd_service, disable_systemd_service
from axon_shared.mqtt.topics import data_topic, PORT_STATS

logger = logging.getLogger(__name__)


class PortStatsMonitor(BaseAgent):
    """Monitors OpenFlow port statistics and publishes to MQTT."""

    agent_name = "Port Stats Monitor"
    mqtt_client_id_suffix = "port-stats"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 5.0
    use_counted_retries = False
    publish_buffer_size = 60

    def __init__(self):
        """Initialize port stats monitor."""
        super().__init__()
        self.bridge_name: Optional[str] = None
        self.openflow_version: str = "openflow13"
        self.primary_interface: Optional[str] = None
        self.device_ip: Optional[str] = None
        self.port_stats_topic: Optional[str] = None
        self.old_stats: dict = {}
        self.port_interface_map: dict = {}

    def _load_config(self) -> bool:
        """Load configuration from config.json and bootstrap.json.

        Overrides BaseAgent._load_config() entirely because this agent
        loads bridge_configs, primary_interface, and device IP from
        non-standard config sources.

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            # Load device config (must exist for adopted device)
            logger.debug(f"Loading config from: {self.config_manager.config_path}")
            logger.debug(f"ConfigManager working directory: {os.getcwd()}")
            config = self.config_manager.load_config()
            if not config:
                logger.error("Device not adopted - config.json not found")
                return False

            self.device_id = config.get("device_id")
            self.site_id = config.get("network_id")

            logger.info(
                f"Loaded device_id={self.device_id}, network_id={self.site_id} "
                f"from config file: {os.path.abspath(self.config_manager.config_path)}"
            )

            if not self.device_id or not self.site_id:
                logger.error("Config missing device_id or network_id")
                return False

            # Load bridge_name and openflow_version from bridge_configs
            bridge_configs = config.get("bridge_configs", {})
            if not isinstance(bridge_configs, dict):
                logger.error(
                    f"bridge_configs has unexpected type {type(bridge_configs).__name__}, "
                    "expected dict"
                )
                bridge_configs = {}
            if bridge_configs:
                first_bridge = next(iter(bridge_configs.values()))
                if isinstance(first_bridge, dict):
                    self.bridge_name = first_bridge.get("bridge_name")
                    openflow_version = first_bridge.get("openflow_version")
                    if openflow_version:
                        self.openflow_version = openflow_version.lower()
                    else:
                        self.openflow_version = os.getenv(
                            "OPENFLOW_VERSION", "openflow13"
                        ).lower()
                else:
                    self.openflow_version = os.getenv(
                        "OPENFLOW_VERSION", "openflow13"
                    ).lower()
            else:
                self.openflow_version = os.getenv(
                    "OPENFLOW_VERSION", "openflow13"
                ).lower()

            # Fallback to environment variable if bridge_name not in config
            if not self.bridge_name:
                self.bridge_name = os.getenv("BRIDGE")
                if self.bridge_name:
                    logger.info(
                        f"Using bridge name from BRIDGE environment variable: {self.bridge_name}"
                    )

            if not self.bridge_name:
                logger.error(
                    "Bridge name not found in config.json bridge_configs or BRIDGE env var"
                )
                return False

            # Load bootstrap config for MQTT connection details and primary interface
            bootstrap = self.config_manager.load_bootstrap()
            self.primary_interface = bootstrap.get("primary_interface", "eth0")

            # Get device IP address
            self.device_ip = HardwareInfo.get_interface_ip(self.primary_interface)
            if not self.device_ip:
                # Fallback to first available IP or localhost
                self.device_ip = "127.0.0.1"
                logger.warning(
                    f"Could not get IP for {self.primary_interface}, using fallback: {self.device_ip}"
                )

            # Build port stats topic
            self.port_stats_topic = data_topic(self.site_id, self.device_id, PORT_STATS)

            logger.info(
                f"Loaded config: device_id={self.device_id}, "
                f"network_id={self.site_id}, bridge={self.bridge_name}, "
                f"openflow_version={self.openflow_version}, "
                f"interface={self.primary_interface}, device_ip={self.device_ip}"
            )
            return True

        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            return False

    def _load_service_config(self, config: dict) -> bool:
        """Not used -- _load_config is overridden entirely."""
        raise NotImplementedError("PortStatsMonitor overrides _load_config directly")

    def _setup(self):
        """Get initial interface map after MQTT connection."""
        self.port_interface_map = self._get_interface_map()
        if not self.port_interface_map:
            logger.warning(
                "Could not retrieve interface map, will use port IDs directly"
            )

    def _run_loop(self):
        """Main monitoring loop: get port stats, compute differences, publish, sleep 1."""
        logger.info(
            f"Port stats monitor running, publishing to {self.port_stats_topic} every 1 second"
        )

        while self.running:
            # Collect current port statistics
            current_stats = self._get_port_stats()

            if current_stats is not None:
                # If we have old stats, compute differences and publish
                if self.old_stats:
                    differences = self._compute_differences(
                        current_stats, self.old_stats
                    )

                    # Map port IDs to interface names
                    interface_differences = {}
                    for port, stats in differences.items():
                        interface_name = self.port_interface_map.get(port, port)
                        # Only include rx_bytes_diff, tx_bytes_diff, and duration_diff
                        interface_differences[interface_name] = {
                            "rx_bytes_diff": stats["rx_bytes_diff"],
                            "tx_bytes_diff": stats["tx_bytes_diff"],
                            "duration_diff": stats["duration_diff"],
                        }

                    # Only publish if we have differences
                    if interface_differences:
                        self._publish_stats(interface_differences)

                # Update old_stats for next iteration
                self.old_stats = current_stats

            # Wait 1 second before next collection
            time.sleep(1)

    def _start_process(self, args):
        """Start a subprocess and return return code, stdout, and stderr.

        Args:
            args: List of command arguments

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        try:
            p = subprocess.Popen(
                args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            output, err = p.communicate()
            return p.returncode, output.decode("utf-8"), err.decode("utf-8")
        except OSError as e:
            return -1, None, str(e)

    def _parse_ovs_statistics(self, output: str) -> dict:
        """Parse OVS port statistics from ovs-ofctl dump-ports output.

        Args:
            output: Output from ovs-ofctl dump-ports command

        Returns:
            Dictionary mapping port IDs to statistics
        """
        lines = output.strip().split("\n")[1:]  # Skip header
        stats = {}

        # Process every three lines (rx, tx, duration)
        for i in range(0, len(lines), 3):
            if i + 2 >= len(lines):
                break

            # Use regex to extract the port name after "port" and before the colon
            m = re.search(r"port\s+(\S+):", lines[i])
            if m:
                port_id = m.group(1)
            else:
                port_id = "unknown"

            # Extract the stats values
            rx_stats = lines[i].strip().split(",")
            rx_pkts = rx_stats[0].split(":")[-1].split("=")[-1]
            rx_bytes = rx_stats[1].split("=")[-1]
            rx_drop = rx_stats[2].split("=")[-1]
            rx_errors = rx_stats[3].split("=")[-1]

            tx_stats = lines[i + 1].strip().split(",")
            tx_pkts = tx_stats[0].split("=")[-1]
            tx_bytes = tx_stats[1].split("=")[-1]
            tx_drop = tx_stats[2].split("=")[-1]
            tx_errors = tx_stats[3].split("=")[-1]

            duration_stats = lines[i + 2].strip().split("=")
            duration = duration_stats[-1][:-1]  # Remove trailing 's'

            stats[port_id] = {
                "rx_pkts": int(rx_pkts),
                "rx_bytes": int(rx_bytes),
                "rx_drop": int(rx_drop),
                "rx_errors": int(rx_errors),
                "tx_pkts": int(tx_pkts),
                "tx_bytes": int(tx_bytes),
                "tx_drop": int(tx_drop),
                "tx_errors": int(tx_errors),
                "duration": float(duration),
            }

        return stats

    def _parse_port_interface_map(self, output: str) -> dict:
        """Parse port to interface mapping from ovs-ofctl show output.

        Args:
            output: Output from ovs-ofctl show command

        Returns:
            Dictionary mapping port IDs to interface names
        """
        port_interface_map = {}
        lines = output.splitlines()

        for line in lines:
            if "addr" in line:
                parts = line.split()  # e.g., ["1(eth1):", "addr:9c:a2:f4:fc:24:eb"]
                port_info = parts[0].split("(")  # For "1(eth1):" -> ["1", "eth1):"]

                if len(port_info) > 1:
                    port_num = port_info[0]
                    interface_name = port_info[1].rstrip("):")

                    # Add both mappings: numeric port and interface name map to the interface name
                    port_interface_map[port_num] = interface_name
                    port_interface_map[interface_name] = interface_name
                else:
                    key = parts[0].rstrip(":")
                    port_interface_map[key] = key

        return port_interface_map

    def _get_interface_map(self) -> dict:
        """Get port to interface mapping from OVS.

        Returns:
            Dictionary mapping port IDs to interface names
        """
        ret, output, _err = self._start_process(
            ["ovs-ofctl", "show", self.bridge_name, "-O", self.openflow_version]
        )
        if ret == 0:
            logger.debug(f"Interface map output: {output}")
            return self._parse_port_interface_map(output)
        else:
            logger.error(f"Error retrieving interface map: {_err}")
            return {}

    def _compute_differences(self, new_stats: dict, old_stats: dict) -> dict:
        """Compute differences between current and previous statistics.

        Args:
            new_stats: Current statistics dictionary
            old_stats: Previous statistics dictionary

        Returns:
            Dictionary with differences (rx_bytes_diff, tx_bytes_diff, duration_diff)
        """
        diff = {}
        for port in new_stats:
            if port in old_stats:
                diff[port] = {
                    "rx_pkts_diff": new_stats[port]["rx_pkts"]
                    - old_stats[port]["rx_pkts"],
                    "tx_pkts_diff": new_stats[port]["tx_pkts"]
                    - old_stats[port]["tx_pkts"],
                    "rx_bytes_diff": new_stats[port]["rx_bytes"]
                    - old_stats[port]["rx_bytes"],
                    "tx_bytes_diff": new_stats[port]["tx_bytes"]
                    - old_stats[port]["tx_bytes"],
                    "duration_diff": new_stats[port]["duration"]
                    - old_stats[port]["duration"],
                }
        return diff

    def _get_port_stats(self) -> Optional[dict]:
        """Collect OVS port statistics.

        Returns:
            Dictionary with port statistics, or None on error
        """
        ret, out, _err = self._start_process(
            [
                "ovs-ofctl",
                "dump-ports",
                self.bridge_name,
                "-O",
                self.openflow_version,
            ]
        )
        if ret == 0:
            logger.debug(f"Port stats output: {out}")
            return self._parse_ovs_statistics(out)
        else:
            logger.error(f"Error retrieving port statistics: {_err}")
            return None

    def _publish_stats(self, stats: dict) -> bool:
        """Publish port statistics to MQTT topic.

        Args:
            stats: Statistics dictionary to publish (with interface names as keys)

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            return False

        try:
            # Build payload with timestamp, device_ip and stats
            payload = {
                "timestamp": time.time(),
                "device_ip": self.device_ip,
                "stats": stats,
            }

            result = self.mqtt_client.publish(self.port_stats_topic, payload, qos=0)
            if result:
                logger.debug(f"Published port stats to {self.port_stats_topic}")
                return True
            else:
                logger.warning(
                    f"Failed to publish port stats to {self.port_stats_topic}"
                )
                return False
        except Exception as e:
            logger.error(f"Error publishing port stats: {e}")
            return False


def start_port_stats_monitoring_process() -> Optional[subprocess.Popen]:
    """Start the port statistics monitoring script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if port stats monitoring process is already running
    if _is_port_stats_monitoring_running():
        logger.info("Port statistics monitoring process is already running")
        return None

    try:
        # Use Python to run the module
        python_executable = sys.executable
        module_path = "axon_agent.monitoring.port_stats_monitor"

        logger.info("Starting port statistics monitoring process...")

        # Start process in background (daemon-like)
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # Create new process group
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is None:
            logger.info(
                f"Port statistics monitoring process started (PID: {process.pid})"
            )
            return process
        else:
            logger.error("Port statistics monitoring process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start port statistics monitoring process: {e}")
        return None


def _is_port_stats_monitoring_running() -> bool:
    """Check if port statistics monitoring process is already running.

    Checks both for running processes and systemd service status.

    Returns:
        True if monitoring process is running, False otherwise
    """
    try:
        # First check if running as systemd service
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "--quiet", "axon-agent-port-stats.service"],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                logger = logging.getLogger(__name__)
                logger.info("Port statistics monitoring is running as systemd service")
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            # systemctl not available or timed out, continue with process check
            pass

        current_pid = os.getpid()

        # Check for processes matching our module name
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process to avoid self-detection
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    # Check if this is our port stats monitoring process
                    cmdline_str = " ".join(cmdline)
                    if "port_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.port_stats_monitor" in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for port stats monitoring process: {e}")
        return False


def stop_port_stats_monitoring() -> bool:
    """Stop port statistics monitoring service/process.

    Tries to stop systemd service first, then falls back to killing subprocess
    if systemd is not available or service is not running as systemd.

    Returns:
        True if monitoring was stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    port_stats_service = "axon-agent-port-stats.service"

    # Try to stop systemd service first
    try:
        if stop_systemd_service(port_stats_service):
            logger.info("Stopped port statistics monitoring systemd service")
            # Also disable it so it doesn't start on boot
            if disable_systemd_service(port_stats_service):
                logger.info("Disabled port statistics monitoring systemd service")
                return True
            else:
                logger.error(
                    f"Failed to disable {port_stats_service} after stopping it. "
                    "Service may restart on next boot."
                )
                return False
    except Exception as e:
        logger.warning(
            f"Failed to stop port stats systemd service: {e}, "
            "trying to stop subprocess"
        )

    # Fallback: try to stop subprocess if systemd not available or service not running
    try:
        current_pid = os.getpid()
        stopped_any = False

        # Find and kill port stats monitoring processes
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "port_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.port_stats_monitor" in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            logger.info(
                                f"Stopping port statistics monitoring process (PID: {proc.pid})"
                            )
                            proc.terminate()
                            # Wait up to 5 seconds for graceful shutdown
                            try:
                                proc.wait(timeout=5)
                                logger.info(
                                    f"Port statistics monitoring process {proc.pid} stopped gracefully"
                                )
                            except psutil.TimeoutExpired:
                                # Force kill if it doesn't terminate
                                logger.warning(
                                    f"Process {proc.pid} did not terminate, forcing kill"
                                )
                                proc.kill()
                                proc.wait()
                                logger.info(
                                    f"Port statistics monitoring process {proc.pid} killed"
                                )
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if stopped_any:
            logger.info("Stopped port statistics monitoring process(es)")
            return True
        else:
            logger.info("No port statistics monitoring process found to stop")
            return True  # Consider this success (nothing to stop)
    except Exception as e:
        logger.error(f"Error stopping port statistics monitoring process: {e}")
        return False


def main():
    """Main entry point for port stats monitor."""
    monitor = PortStatsMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
