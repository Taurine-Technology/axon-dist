"""Port link status monitoring script that publishes port link status to MQTT."""

import logging
import os
import psutil
import subprocess
import sys
import time
from typing import Optional

from ..base_agent import BaseAgent
from ..hardware import HardwareInfo
from ..port_utils import (
    get_all_port_statuses,
    get_iso_timestamp,
    bring_port_up,
    get_port_link_status,
)
from axon_shared.mqtt.topics import data_topic, PORT_STATUS

logger = logging.getLogger(__name__)

# Monitoring interval in seconds
MONITOR_INTERVAL = 30


class PortLinkMonitor(BaseAgent):
    """Monitors port link status and publishes to MQTT."""

    agent_name = "Port Link Monitor"
    mqtt_client_id_suffix = "port-link"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 10.0
    use_counted_retries = True
    publish_buffer_size = 20

    def __init__(self):
        """Initialize port link monitor."""
        super().__init__()
        self.interfaces: list = []
        self.primary_interface: Optional[str] = None
        self.device_ip: Optional[str] = None
        self.port_status_topic: Optional[str] = None

    def _load_service_config(self, config: dict) -> bool:
        """Load port link monitor specific configuration.

        Args:
            config: Full config.json dictionary

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        # Load interfaces from all bridge_configs
        bridge_configs = config.get("bridge_configs", {})
        all_interfaces = []
        for bc in bridge_configs.values():
            if isinstance(bc, dict):
                all_interfaces.extend(bc.get("interfaces", []))
        self.interfaces = list(dict.fromkeys(all_interfaces))

        if not self.interfaces:
            logger.error(
                "No interfaces found in config.json bridge_configs"
            )
            return False

        # Load bootstrap config for primary interface
        bootstrap = self.config_manager.load_bootstrap()
        self.primary_interface = bootstrap.get("primary_interface", "eth0")

        # Get device IP address
        self.device_ip = HardwareInfo.get_interface_ip(self.primary_interface)
        if not self.device_ip:
            # Fallback to localhost
            self.device_ip = "127.0.0.1"
            logger.warning(
                f"Could not get IP for {self.primary_interface}, "
                f"using fallback: {self.device_ip}"
            )

        # Build port status topic
        self.port_status_topic = data_topic(
            self.site_id, self.device_id, PORT_STATUS
        )

        logger.info(
            f"Loaded config: device_id={self.device_id}, "
            f"site_id={self.site_id}, interfaces={self.interfaces}, "
            f"primary_interface={self.primary_interface}, "
            f"device_ip={self.device_ip}"
        )
        return True

    def _setup(self):
        """Ensure ports are up and publish initial status after connection."""
        self._ensure_ports_up()

        # Publish initial status
        initial_statuses = get_all_port_statuses(self.interfaces)
        self._publish_port_status(initial_statuses)
        logger.info(f"Published initial port status: {initial_statuses}")

    def _run_loop(self):
        """Main monitoring loop.

        Sleeps for MONITOR_INTERVAL seconds between each check cycle.
        """
        logger.info(
            f"Port link monitor running, publishing to "
            f"{self.port_status_topic} every {MONITOR_INTERVAL} seconds"
        )
        while self.running:
            time.sleep(MONITOR_INTERVAL)
            self._check_and_publish_status()

    def _publish_port_status(self, port_statuses: dict) -> bool:
        """Publish port status to MQTT topic.

        Args:
            port_statuses: Dictionary of port statuses in the format:
                {
                    "eth1": {"status": "up", "timestamp": "..."},
                    "eth2": {"status": "down", "timestamp": "..."}
                }

        Returns:
            True if publish successful, False otherwise
        """
        # Ensure client is initialized
        if not self.mqtt_client:
            if not self._connect_mqtt():
                return False

        # If not connected, skip publishing - paho-mqtt will reconnect automatically
        if not self.mqtt_client.is_connected():
            return False

        try:
            payload = {
                "device_ip": self.device_ip,
                "timestamp": get_iso_timestamp(),
                "ports": port_statuses,
            }

            result = self.mqtt_client.publish(
                self.port_status_topic, payload, qos=0
            )
            if result:
                logger.debug(
                    f"Published port status to {self.port_status_topic}"
                )
                return True
            else:
                logger.warning(
                    f"Failed to publish port status to "
                    f"{self.port_status_topic}"
                )
                return False
        except Exception as e:
            logger.error(f"Error publishing port status: {e}")
            return False

    def _ensure_ports_up(self) -> None:
        """Bring all configured interfaces up on startup."""
        logger.info("Ensuring all bridge ports are up...")
        for interface in self.interfaces:
            bring_port_up(interface)

    def _check_and_publish_status(self) -> None:
        """Check port statuses, publish them, and bring down ports back up.

        This is the core monitoring logic that runs every 30 seconds:
        1. Get status of all ports
        2. Publish the status
        3. If any port is down, attempt to bring it up
        4. If successful, publish the updated status
        """
        # Get current status of all ports
        port_statuses = get_all_port_statuses(self.interfaces)

        # Publish current status (always, every 30 seconds)
        self._publish_port_status(port_statuses)

        # Check if any ports are down
        down_ports = [
            iface
            for iface, info in port_statuses.items()
            if info["status"] == "down"
        ]

        if down_ports:
            logger.info(f"Detected DOWN ports: {down_ports}")

            # Track which ports were successfully brought up
            ports_brought_up = []

            for interface in down_ports:
                logger.info(f"Attempting to bring {interface} up...")
                success = bring_port_up(interface)
                if success:
                    # Brief delay for kernel to update interface state
                    time.sleep(0.5)
                    # Verify the port is now up
                    new_status = get_port_link_status(interface)
                    if new_status == "up":
                        ports_brought_up.append(interface)
                        logger.info(
                            f"Successfully brought {interface} up "
                            f"and verified"
                        )
                    else:
                        # Log diagnostic info
                        logger.warning(
                            f"Command succeeded but {interface} status "
                            f"is still {new_status}. This may indicate "
                            f"a hardware or driver issue."
                        )
                else:
                    logger.error(f"Failed to bring {interface} up")

            # If any ports were successfully brought up, publish follow-up status
            if ports_brought_up:
                logger.info(
                    f"Publishing follow-up status for ports brought "
                    f"up: {ports_brought_up}"
                )
                # Get fresh status for all ports
                updated_statuses = get_all_port_statuses(self.interfaces)
                self._publish_port_status(updated_statuses)


def start_port_link_monitoring_process() -> Optional[subprocess.Popen]:
    """Start the port link monitoring script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if port link monitoring process is already running
    if _is_port_link_monitoring_running():
        logger.info("Port link monitoring process is already running")
        return None

    try:
        # Use Python to run the module
        python_executable = sys.executable
        module_path = "axon_agent.monitoring.port_link_monitor"

        logger.info("Starting port link monitoring process...")

        # Start process in background (daemon-like)
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # Create new process group
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is None:
            logger.info(
                f"Port link monitoring process started "
                f"(PID: {process.pid})"
            )
            return process
        else:
            logger.error(
                "Port link monitoring process exited immediately"
            )
            return None

    except Exception as e:
        logger.error(
            f"Failed to start port link monitoring process: {e}"
        )
        return None


def _is_port_link_monitoring_running() -> bool:
    """Check if port link monitoring process is already running.

    Checks both for running processes and systemd service status.

    Returns:
        True if monitoring process is running, False otherwise
    """
    try:
        # First check if running as systemd service
        try:
            result = subprocess.run(
                [
                    "systemctl",
                    "is-active",
                    "--quiet",
                    "axon-agent-port-link.service",
                ],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                logger = logging.getLogger(__name__)
                logger.info(
                    "Port link monitoring is running as systemd service"
                )
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            # systemctl not available or timed out, continue with process check
            pass

        current_pid = os.getpid()

        # Check for processes matching our module name
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process to avoid self-detection
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    # Check if this is our port link monitoring process
                    cmdline_str = " ".join(cmdline)
                    if "port_link_monitor" in cmdline_str or (
                        "axon_agent.monitoring.port_link_monitor"
                        in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(
            f"Error checking for port link monitoring process: {e}"
        )
        return False


def main():
    """Main entry point for port link monitor."""
    monitor = PortLinkMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
