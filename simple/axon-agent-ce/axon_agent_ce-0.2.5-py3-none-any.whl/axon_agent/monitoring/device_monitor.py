"""Device monitoring script that publishes system statistics to MQTT."""

import logging
import os
import subprocess
import sys
import time
from typing import Optional

import psutil

from ..base_agent import BaseAgent
from ..hardware import HardwareInfo
from ..network import get_interfaces
from axon_shared.proto.interface_messages_pb2 import (
    InterfaceChangeNotification,
    NetworkInterface,
    InterfaceChanges,
)
from axon_shared.mqtt.topics import data_topic, DEVICE_STATS, INTERFACES

logger = logging.getLogger(__name__)


class DeviceMonitor(BaseAgent):
    """Monitors device statistics and publishes to MQTT."""

    agent_name = "Device Monitor"
    mqtt_client_id_suffix = "monitor"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 10.0
    use_counted_retries = True
    publish_buffer_size = 300

    def __init__(self):
        """Initialize device monitor."""
        super().__init__()
        self.primary_interface: Optional[str] = None
        self.stats_topic: Optional[str] = None
        self.interfaces_topic: Optional[str] = None
        self._last_known_interfaces: dict = {}
        self._last_interface_check: float = 0.0
        self._interface_check_interval: float = 30.0

    def _load_service_config(self, config: dict) -> bool:
        """Load service-specific configuration.

        Loads bootstrap for primary_interface, builds MQTT topics.

        Args:
            config: Full config.json dictionary

        Returns:
            True if service config loaded successfully, False otherwise
        """
        # Load bootstrap config for primary interface
        bootstrap = self.config_manager.load_bootstrap()
        self.primary_interface = bootstrap.get("primary_interface", "eth0")

        # Build topics using self.site_id (which is network_id from config)
        self.stats_topic = data_topic(self.site_id, self.device_id, DEVICE_STATS)
        self.interfaces_topic = data_topic(self.site_id, self.device_id, INTERFACES)

        logger.info(
            f"Loaded config: device_id={self.device_id}, "
            f"site_id={self.site_id}, interface={self.primary_interface}"
        )
        return True

    def _setup(self):
        """Called after MQTT connection, before entering _run_loop().

        Primes CPU measurement, initializes interface tracking, and
        publishes initial interface state.
        """
        # Prime CPU percent measurement (first call returns 0.0, establishes baseline)
        psutil.cpu_percent(interval=None)

        # Initialize interface tracking with current interfaces
        self._last_known_interfaces = self._get_current_interfaces()
        logger.info(
            f"Initialized interface tracking with "
            f"{len(self._last_known_interfaces)} interfaces"
        )

        # Publish initial interface state (empty changes) so APIs can sync on startup
        try:
            initial_notification = InterfaceChangeNotification()
            initial_notification.timestamp = time.time()
            for iface_info in self._last_known_interfaces.values():
                interface = NetworkInterface()
                interface.name = iface_info["name"]
                interface.mac = iface_info["mac"]
                if "speed" in iface_info:
                    interface.speed = iface_info["speed"]
                initial_notification.interfaces.append(interface)
            # Empty changes section
            initial_notification.changes.CopyFrom(InterfaceChanges())
            self._publish_interfaces(initial_notification)
            logger.info(f"Initial interface state: {initial_notification}")
            logger.info("Published initial interface state on startup")
        except Exception as e:
            logger.warning(f"Failed to publish initial interface state: {e}")

    def _run_loop(self):
        """Main monitoring loop.

        Collects system stats, publishes them, checks for interface
        changes, and sleeps 1 second between iterations.
        """
        logger.info(
            f"Monitor running, publishing to {self.stats_topic} every 1 second"
        )
        logger.info(
            f"Interface monitoring enabled, checking every "
            f"{self._interface_check_interval} seconds"
        )

        while self.running:
            # Collect stats
            stats = self._get_system_stats()

            # Publish stats
            self._publish_stats(stats)

            # Check for interface changes (runs periodically based on interval)
            self._check_interface_changes()

            # Wait 1 second before next collection
            time.sleep(1)

    def _get_system_stats(self) -> dict:
        """Collect system statistics.

        Returns:
            Dictionary with IP address, CPU, memory, and disk usage
        """
        try:
            # Get IP address from primary interface
            ip_address = HardwareInfo.get_interface_ip(self.primary_interface)
            if not ip_address:
                # Fallback to first available IP
                ip_address = "127.0.0.1"
                logger.warning(
                    f"Could not get IP for {self.primary_interface}, using fallback"
                )

            # Get CPU usage (non-blocking)
            cpu_percent = psutil.cpu_percent(interval=None)

            # Get memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent

            # Get disk usage
            disk = psutil.disk_usage("/")
            disk_percent = disk.percent

            stats = {
                "timestamp": time.time(),
                "ip_address": ip_address,
                "cpu": round(cpu_percent, 1),
                "memory": round(memory_percent, 1),
                "disk": round(disk_percent, 1),
            }

            return stats

        except Exception as e:
            logger.error(f"Error collecting system stats: {e}")
            # Return default stats on error
            return {
                "timestamp": time.time(),
                "ip_address": "127.0.0.1",
                "cpu": 0.0,
                "memory": 0.0,
                "disk": 0.0,
            }

    def _publish_stats(self, stats: dict) -> bool:
        """Publish statistics to MQTT topic.

        Args:
            stats: Statistics dictionary to publish

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            return False

        try:
            result = self.mqtt_client.publish(self.stats_topic, stats, qos=0)
            if result:
                logger.debug(f"Published stats to {self.stats_topic}: {stats}")
                return True
            else:
                logger.warning(f"Failed to publish stats to {self.stats_topic}")
                return False
        except Exception as e:
            logger.error(f"Error publishing stats: {e}")
            return False

    def _get_ovs_bridges(self) -> set:
        """Get the names of all OVS bridges.

        Returns:
            Set of OVS bridge names, or empty set if OVS is not available
        """
        try:
            result = subprocess.run(
                ["ovs-vsctl", "list-br"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                bridges = set(result.stdout.strip().split("\n"))
                logger.debug(f"Found OVS bridges: {bridges}")
                return bridges
            return set()
        except FileNotFoundError:
            # OVS not installed
            logger.debug("ovs-vsctl not found, OVS not installed")
            return set()
        except subprocess.TimeoutExpired:
            logger.warning("Timeout getting OVS bridges")
            return set()
        except Exception as e:
            logger.warning(f"Error getting OVS bridges: {e}")
            return set()

    def _get_current_interfaces(self) -> dict:
        """Get current network interfaces with their details.

        Filters out OVS bridges and ovs-system interface to avoid duplicate
        MAC addresses (bridges inherit MAC from their ports).

        Returns:
            Dictionary mapping MAC address to interface info (name, mac, speed)
        """
        try:
            interfaces = get_interfaces()
            net_stats = psutil.net_if_stats()

            # Get OVS bridges to exclude them
            ovs_bridges = self._get_ovs_bridges()
            # Also exclude ovs-system internal interface
            excluded_interfaces = ovs_bridges | {"ovs-system"}

            current_interfaces = {}
            for iface, mac in interfaces:
                # Skip OVS bridges and ovs-system to avoid duplicate MACs
                if iface in excluded_interfaces:
                    logger.debug(
                        f"Excluding OVS interface from monitoring: {iface}"
                    )
                    continue

                interface_info = {"name": iface, "mac": mac}
                # Add speed if available
                if iface in net_stats:
                    speed = net_stats[iface].speed
                    if speed is not None:
                        interface_info["speed"] = speed  # Speed in Mbps
                current_interfaces[mac] = interface_info

            return current_interfaces
        except Exception as e:
            logger.error(f"Error getting current interfaces: {e}")
            return {}

    def _check_interface_changes(self) -> None:
        """Check for interface changes and publish notifications if detected."""
        current_time = time.time()

        # Only check interfaces periodically (every 30 seconds)
        if current_time - self._last_interface_check < self._interface_check_interval:
            return

        self._last_interface_check = current_time

        try:
            current_interfaces = self._get_current_interfaces()
            current_macs = set(current_interfaces.keys())
            last_macs = set(self._last_known_interfaces.keys())

            # Find new interfaces (in current but not in last)
            new_interfaces = current_macs - last_macs
            # Find removed interfaces (in last but not in current)
            removed_interfaces = last_macs - current_macs

            # If there are changes, publish notification
            if new_interfaces or removed_interfaces:
                # Build protobuf message
                notification = InterfaceChangeNotification()
                notification.timestamp = current_time

                # Add all current interfaces
                for iface_info in current_interfaces.values():
                    interface = NetworkInterface()
                    interface.name = iface_info["name"]
                    interface.mac = iface_info["mac"]
                    if "speed" in iface_info:
                        interface.speed = iface_info["speed"]
                    notification.interfaces.append(interface)

                # Add newly detected interfaces
                for mac in new_interfaces:
                    iface_info = current_interfaces[mac]
                    interface = NetworkInterface()
                    interface.name = iface_info["name"]
                    interface.mac = iface_info["mac"]
                    if "speed" in iface_info:
                        interface.speed = iface_info["speed"]
                    notification.changes.added.append(interface)

                # Add removed interfaces
                for mac in removed_interfaces:
                    iface_info = self._last_known_interfaces[mac]
                    interface = NetworkInterface()
                    interface.name = iface_info["name"]
                    interface.mac = iface_info["mac"]
                    if "speed" in iface_info:
                        interface.speed = iface_info["speed"]
                    notification.changes.removed.append(interface)

                # Publish interface change notification
                if self._publish_interfaces(notification):
                    logger.info(
                        f"Published interface changes: "
                        f"{len(new_interfaces)} added, "
                        f"{len(removed_interfaces)} removed"
                    )
                    if new_interfaces:
                        logger.info(
                            f"New interfaces: "
                            f"{[current_interfaces[mac]['name'] for mac in new_interfaces]}"
                        )
                    if removed_interfaces:
                        logger.info(
                            f"Removed interfaces: {list(removed_interfaces)}"
                        )

            # Update last known interfaces
            self._last_known_interfaces = current_interfaces.copy()

        except Exception as e:
            logger.error(f"Error checking interface changes: {e}")

    def _publish_interfaces(
        self, notification: InterfaceChangeNotification
    ) -> bool:
        """Publish interface information to MQTT topic.

        Args:
            notification: InterfaceChangeNotification protobuf message to publish

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            return False

        try:
            # Serialize protobuf message
            payload_bytes = notification.SerializeToString()

            # Publish as raw bytes (protobuf)
            result = self.mqtt_client.publish_raw(
                self.interfaces_topic, payload_bytes, qos=1
            )  # Use QoS 1 for interface changes
            if result:
                logger.debug(
                    f"Published interfaces to {self.interfaces_topic} "
                    f"({len(payload_bytes)} bytes, "
                    f"{len(notification.interfaces)} interfaces)"
                )
                return True
            else:
                logger.warning(
                    f"Failed to publish interfaces to {self.interfaces_topic}"
                )
                return False
        except Exception as e:
            logger.error(f"Error publishing interfaces: {e}")
            return False


def start_monitoring_process() -> Optional[subprocess.Popen]:
    """Start the device monitoring script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if monitoring process is already running
    if _is_monitoring_running():
        logger.info("Device monitoring process is already running")
        return None

    try:
        # Use Python to run the module
        # This works whether installed as package or run from source
        python_executable = sys.executable
        module_path = "axon_agent.monitoring.device_monitor"

        logger.info("Starting device monitoring process...")

        # Start process in background (daemon-like)
        # Use subprocess.Popen with appropriate flags for daemon behavior
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # Create new process group
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is None:
            logger.info(
                f"Device monitoring process started (PID: {process.pid})"
            )
            return process
        else:
            logger.error("Device monitoring process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start device monitoring process: {e}")
        return None


def _is_monitoring_running() -> bool:
    """Check if device monitoring process is already running.

    Checks both for running processes and systemd service status.

    Returns:
        True if monitoring process is running, False otherwise
    """
    try:
        # First check if running as systemd service
        try:
            result = subprocess.run(
                [
                    "systemctl",
                    "is-active",
                    "--quiet",
                    "axon-agent-monitor.service",
                ],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                logger = logging.getLogger(__name__)
                logger.info(
                    "Device monitoring is running as systemd service"
                )
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            # systemctl not available or timed out, continue with process check
            pass

        current_pid = os.getpid()

        # Check for processes matching our module name
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                # Skip the current process to avoid self-detection
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    # Check if this is our monitoring process
                    cmdline_str = " ".join(cmdline)
                    if "device_monitor" in cmdline_str or (
                        "axon_agent.monitoring.device_monitor" in cmdline_str
                    ):
                        # Verify it's actually running
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for monitoring process: {e}")
        return False


def main():
    """Main entry point for device monitor."""
    monitor = DeviceMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
