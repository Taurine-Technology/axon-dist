"""Data-driven companion service registry.

Allows CE to declare which companion services to start and under what
conditions, and EE to register additional services without modifying
CE code.

Usage:
    from axon_agent.service_registry import register_service, get_registry
    from axon_agent.service_registry import CompanionService, StartCondition

    register_service(CompanionService(
        service_name="axon-agent-custom.service",
        subprocess_starter=start_custom_process,
        display_name="custom agent",
        condition=StartCondition.ALWAYS,
    ))
"""

import logging
import os
from dataclasses import dataclass
from enum import Enum
from typing import Callable, List

logger = logging.getLogger(__name__)

# Sniffer config path (shared with main.py)
SNIFFER_CONFIG_PATH = "/etc/axon/sniffer_config.json"


class StartCondition(Enum):
    """Conditions that control when a companion service is started."""

    ALWAYS = "always"
    REQUIRES_BRIDGE = "bridge"
    REQUIRES_SNIFFER = "sniffer"


@dataclass
class CompanionService:
    """A companion service that can be started by the main agent."""

    service_name: str
    subprocess_starter: Callable
    display_name: str
    condition: StartCondition


class ServiceRegistry:
    """Registry of companion services to start during runtime phase."""

    def __init__(self):
        self._services: List[CompanionService] = []

    def register(self, service: CompanionService) -> None:
        """Register a companion service.

        Args:
            service: CompanionService to register
        """
        self._services.append(service)

    def get_services(self) -> List[CompanionService]:
        """Return all registered services."""
        return list(self._services)

    def should_start(self, service: CompanionService, config: dict) -> bool:
        """Check if a service should be started based on its condition.

        Args:
            service: The companion service to check
            config: Device configuration dictionary

        Returns:
            True if the service should be started
        """
        if service.condition == StartCondition.ALWAYS:
            return True

        if service.condition == StartCondition.REQUIRES_BRIDGE:
            bridge_configs = config.get("bridge_configs", {})
            return bool(bridge_configs)

        if service.condition == StartCondition.REQUIRES_SNIFFER:
            return os.path.exists(SNIFFER_CONFIG_PATH)

        return False


# Module-level singleton
_registry = ServiceRegistry()


def get_registry() -> ServiceRegistry:
    """Get the global service registry."""
    return _registry


def register_service(service: CompanionService) -> None:
    """Register a companion service in the global registry."""
    _registry.register(service)


def register_ce_services() -> None:
    """Register the default Community Edition companion services.

    Called by main.py at startup. EE can call this first, then register
    additional services via register_service().
    """
    from .monitoring import (
        start_monitoring_process,
        start_port_stats_monitoring_process,
        start_port_link_monitoring_process,
        start_flow_stats_monitoring_process,
    )
    from .ovs import start_ovs_agent_process
    from .uptime_monitoring import start_uptime_monitoring_agent_process

    register_service(CompanionService(
        service_name="axon-agent-monitor.service",
        subprocess_starter=start_monitoring_process,
        display_name="device monitoring",
        condition=StartCondition.ALWAYS,
    ))
    register_service(CompanionService(
        service_name="axon-agent-ovs.service",
        subprocess_starter=start_ovs_agent_process,
        display_name="OVS agent",
        condition=StartCondition.ALWAYS,
    ))
    register_service(CompanionService(
        service_name="axon-agent-uptime.service",
        subprocess_starter=start_uptime_monitoring_agent_process,
        display_name="uptime monitoring",
        condition=StartCondition.ALWAYS,
    ))
    register_service(CompanionService(
        service_name="axon-agent-port-stats.service",
        subprocess_starter=start_port_stats_monitoring_process,
        display_name="port statistics monitoring",
        condition=StartCondition.REQUIRES_BRIDGE,
    ))
    register_service(CompanionService(
        service_name="axon-agent-port-link.service",
        subprocess_starter=start_port_link_monitoring_process,
        display_name="port link monitoring",
        condition=StartCondition.REQUIRES_BRIDGE,
    ))
    register_service(CompanionService(
        service_name="axon-agent-flow-stats.service",
        subprocess_starter=start_flow_stats_monitoring_process,
        display_name="flow statistics monitoring",
        condition=StartCondition.REQUIRES_SNIFFER,
    ))
