"""Hardware information gathering."""

import logging
import platform
import subprocess
from typing import Optional

import netifaces
import psutil

from .network import get_interfaces

logger = logging.getLogger(__name__)


class HardwareInfo:
    """Collects hardware and system information."""

    @staticmethod
    def get_system_info() -> dict:
        """Get system information (RAM, CPU, disk, OS, kernel).

        Returns:
            Dictionary with system information
        """
        try:
            # RAM in GB
            ram_gb = round(psutil.virtual_memory().total / (1024**3), 2)

            # CPU cores
            cpu_cores = psutil.cpu_count()

            # Disk space in GB
            disk = psutil.disk_usage("/")
            disk_gb = round(disk.total / (1024**3), 2)

            # OS and kernel
            os_name = platform.system()
            kernel = platform.release()

            info = {
                "ram_gb": ram_gb,
                "cpu_cores": cpu_cores,
                "disk_gb": disk_gb,
                "os": os_name,
                "kernel": kernel,
            }

            logger.debug(f"System info: {info}")
            return info
        except Exception as e:
            logger.error(f"Error gathering system info: {e}")
            return {
                "ram_gb": 0,
                "cpu_cores": 0,
                "disk_gb": 0,
                "os": "unknown",
                "kernel": "unknown",
            }

    @staticmethod
    def get_ovs_version() -> Optional[str]:
        """Detect Open vSwitch version if installed.

        Returns:
            OVS version string if installed, None otherwise
        """
        try:
            result = subprocess.run(
                ["ovs-vsctl", "--version"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                # Parse version from output (e.g., "ovs-vsctl (Open vSwitch) 3.5.0")
                version_line = result.stdout.split("\n")[0]
                # Extract version number
                parts = version_line.split()
                for part in parts:
                    if part.replace(".", "").isdigit():
                        version = part
                        logger.debug(f"Found OVS version: {version}")
                        return version
        except FileNotFoundError:
            logger.debug("OVS not installed (ovs-vsctl not found)")
        except subprocess.TimeoutExpired:
            logger.warning("Timeout checking OVS version")
        except Exception as e:
            logger.debug(f"Error checking OVS version: {e}")

        return None

    @staticmethod
    def get_interface_ip(interface: str) -> Optional[str]:
        """Get IP address of a network interface.

        Args:
            interface: Network interface name

        Returns:
            IP address string if found, None otherwise
        """
        try:
            addrs = netifaces.ifaddresses(interface)
            logger.debug(f"Addrs for {interface}: {addrs}")
            # AF_INET (2) contains IPv4 addresses
            if netifaces.AF_INET in addrs:
                ip = addrs[netifaces.AF_INET][0].get("addr")
                logger.debug(f"IP for {interface}: {ip}")
                if ip:
                    logger.debug(f"Found IP address for {interface}: {ip}")
                    return ip
        except (ValueError, KeyError, IndexError) as e:
            logger.debug(f"Interface {interface} has no IPv4 address: {e}")
        except Exception as e:
            logger.warning(f"Error getting IP address for {interface}: {e}")

        return None

    @classmethod
    def collect_all(cls, primary_interface: Optional[str] = None) -> dict:
        """Collect all hardware information.

        Args:
            primary_interface: Optional primary interface name to get IP address for

        Returns:
            Dictionary with complete hardware_info structure
        """
        system_info = cls.get_system_info()
        interfaces = get_interfaces()
        ovs_version = cls.get_ovs_version()

        # Get network interface statistics (including speed)
        net_stats = psutil.net_if_stats()

        # Format interfaces as list of objects with name, mac, and speed
        interfaces_formatted = []
        for iface, mac in interfaces:
            interface_info = {"name": iface, "mac": mac}
            # Add speed if available
            if iface in net_stats:
                speed = net_stats[iface].speed
                if speed is not None:
                    logger.info(f"Speed for {iface}: {speed}")
                    interface_info["speed"] = speed  # Speed in Mbps
            interfaces_formatted.append(interface_info)

        hardware_info = {**system_info, "interfaces": interfaces_formatted}

        # Get IP address of primary interface if specified
        if primary_interface:
            primary_ip = cls.get_interface_ip(primary_interface)
            if primary_ip:
                hardware_info["ip"] = primary_ip
                logger.info(f"Primary interface {primary_interface} IP: {primary_ip}")

        if ovs_version:
            hardware_info["ovs_version"] = ovs_version

        logger.info("Collected hardware information")
        return hardware_info
