"""Network interface detection and MAC address handling."""

import logging
import netifaces
from typing import List, Tuple

from .utils import normalize_mac

logger = logging.getLogger(__name__)


def get_primary_mac(interface: str = "eth0") -> str:
    """Get MAC address from specified network interface.

    Args:
        interface: Network interface name (default: "eth0")

    Returns:
        Normalized MAC address (lowercase with colons)

    Raises:
        ValueError: If interface doesn't exist or has no MAC address
    """
    try:
        # Get address family for link layer (MAC address)
        addrs = netifaces.ifaddresses(interface)

        # AF_LINK (17) contains MAC address
        if netifaces.AF_LINK in addrs:
            mac = addrs[netifaces.AF_LINK][0].get("addr")
            if mac:
                normalized = normalize_mac(mac)
                logger.debug(f"Found MAC address for {interface}: {normalized}")
                return normalized

        raise ValueError(f"Interface {interface} has no MAC address")
    except ValueError:
        raise
    except Exception as e:
        logger.error(f"Error getting MAC address for {interface}: {e}")
        raise ValueError(f"Interface {interface} not found or error accessing it: {e}")


def get_interfaces() -> List[Tuple[str, str]]:
    """List all network interfaces with their MAC addresses.

    Returns:
        List of tuples containing (interface_name, mac_address) pairs
        (e.g., [('eth0', 'aa:bb:cc:dd:ee:ff'), ('eth1', '11:22:33:44:55:66')])
    """
    try:
        interfaces = netifaces.interfaces()
        interfaces_with_mac = []
        for iface in interfaces:
            if iface == "lo":
                continue
            try:
                addrs = netifaces.ifaddresses(iface)
                if netifaces.AF_LINK in addrs:
                    mac = addrs[netifaces.AF_LINK][0].get("addr")
                    if mac:
                        normalized = normalize_mac(mac)
                        logger.debug(f"Found MAC address for {iface}: {normalized}")
                        interfaces_with_mac.append((iface, normalized))
            except Exception as e:
                logger.error(f"Error getting MAC address for {iface}: {e}")
        logger.debug(f"Found network interfaces: {interfaces_with_mac}")
        return interfaces_with_mac
    except Exception as e:
        logger.error(f"Error listing interfaces: {e}")
        return []
