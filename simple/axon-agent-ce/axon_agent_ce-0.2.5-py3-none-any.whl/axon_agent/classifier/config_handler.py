"""Classifier Configuration Handler - MQTT-based configuration management.

This module handles classifier configuration commands received via MQTT,
similar to how the OVS agent handles meter commands. It can:
1. Write/update classifier configuration
2. Enable/disable the classifier service
3. Report classifier status
4. Handle initial installation with policies

The configuration is persisted to /etc/axon/classifier_config.json and
the classifier service is managed via systemd.
"""

import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass
from typing import Optional, Tuple

try:
    from axon_shared.proto.classifier_config_messages_pb2 import (
        ClassifierAction,
        ClassifierConfig,
        ClassifierStatus,
        ClassifierStatusResponse,
        ClassifierStats,
        ClassifierInstallRequest,
        ClassifierInstallResponse,
        BlockRuleConfig,
        RateLimitRuleConfig,
    )
    CONFIG_PROTOBUF_AVAILABLE = True
except ImportError:
    CONFIG_PROTOBUF_AVAILABLE = False
    ClassifierAction = None
    ClassifierConfig = None
    ClassifierStatus = None
    ClassifierStatusResponse = None
    ClassifierStats = None
    ClassifierInstallRequest = None
    ClassifierInstallResponse = None
    BlockRuleConfig = None
    RateLimitRuleConfig = None

from axon_shared.mqtt.topics import (
    control_topic, data_topic,
    CLASSIFIER_CONFIGURE, CLASSIFIER_ENABLE, CLASSIFIER_DISABLE,
    CLASSIFIER_STATUS_REQUEST, CLASSIFIER_INSTALL, CLASSIFIER_STATUS_RESPONSE,
    CLASSIFIER_INSTALL_RESPONSE,
)

logger = logging.getLogger(__name__)

# Configuration file paths
CLASSIFIER_CONFIG_PATH = "/etc/axon/classifier_config.json"
CLASSIFIER_CONFIG_DIR = "/etc/axon"
POLICY_DB_DIR = "/var/lib/axon"

# Systemd service names. Overridable via env var so downstream editions
# (e.g. EE) can redirect the install flow to their own systemd unit
# without forking this handler. Defaults preserve CE behaviour.
CLASSIFIER_SERVICE = os.environ.get(
    "AXON_CLASSIFIER_SERVICE", "axon-agent-classifier"
)
CLASSIFIER_FLOW_STATS_SERVICE = os.environ.get(
    "AXON_CLASSIFIER_FLOW_STATS_SERVICE", "axon-agent-classifier-flow-stats"
)

# Classifier version
CLASSIFIER_VERSION = "1.0.0"


@dataclass
class ClassifierConfigData:
    """Configuration data for the classifier."""

    monitor_interface: str
    site_id: str
    device_id: str
    bridge_name: str = ""
    num_bytes: int = 225
    num_packets: int = 5
    batch_interval: float = 1.0
    idle_timeout: int = 30
    policy_enabled: bool = False
    policy_db_path: str = "/var/lib/axon/policy_cache.db"


class ClassifierConfigHandler:
    """Handles classifier configuration via MQTT.

    This class manages classifier configuration, installation, and
    service lifecycle. It subscribes to MQTT topics for configuration
    commands and publishes status responses.

    Args:
        mqtt_client: MQTT client for publishing responses
        site_id: Site identifier
        device_id: Device identifier
    """

    def __init__(
        self,
        mqtt_client,
        site_id: str,
        device_id: str,
    ):
        self.mqtt_client = mqtt_client
        self.site_id = site_id
        self.device_id = device_id

        # MQTT topics
        self.config_topic = control_topic(site_id, device_id, CLASSIFIER_CONFIGURE)
        self.enable_topic = control_topic(site_id, device_id, CLASSIFIER_ENABLE)
        self.disable_topic = control_topic(site_id, device_id, CLASSIFIER_DISABLE)
        self.status_topic = control_topic(site_id, device_id, CLASSIFIER_STATUS_REQUEST)
        self.install_topic = control_topic(site_id, device_id, CLASSIFIER_INSTALL)

        self.response_topic = data_topic(site_id, device_id, CLASSIFIER_STATUS_RESPONSE)
        self.install_response_topic = data_topic(site_id, device_id, CLASSIFIER_INSTALL_RESPONSE)

        # Try to import zstandard for compression
        try:
            import zstandard as zstd

            self.compressor = zstd.ZstdCompressor(level=3)
            self.decompressor = zstd.ZstdDecompressor()
        except ImportError:
            self.compressor = None
            self.decompressor = None

    def subscribe_to_topics(self):
        """Subscribe to all classifier configuration topics."""
        topics = [
            (self.config_topic, self._handle_configure),
            (self.enable_topic, self._handle_enable),
            (self.disable_topic, self._handle_disable),
            (self.status_topic, self._handle_status),
            (self.install_topic, self._handle_install),
        ]

        for topic, handler in topics:
            try:
                self.mqtt_client.subscribe_raw(topic, handler, qos=2)
                logger.info(f"Subscribed to classifier topic: {topic}")
            except Exception as e:
                logger.error(f"Failed to subscribe to {topic}: {e}")

    def _decompress_payload(self, payload: bytes) -> bytes:
        """Decompress payload if compressed."""
        if self.decompressor:
            try:
                return self.decompressor.decompress(payload)
            except Exception:
                pass  # Not compressed
        return payload

    def _parse_install_payload(self, payload: bytes) -> Tuple[dict, str]:
        """Parse install payload as protobuf (ClassifierInstallRequest).

        Args:
            payload: Raw (possibly compressed) protobuf payload bytes

        Returns:
            Tuple of (parsed data dict, correlation_id)

        Raises:
            ValueError: If protobuf is not available or payload cannot be parsed
        """
        if not CONFIG_PROTOBUF_AVAILABLE:
            raise ValueError("Protobuf support not available - compile proto files")

        decompressed = self._decompress_payload(payload)

        msg = ClassifierInstallRequest()
        msg.ParseFromString(decompressed)

        logger.debug("Parsed install payload as protobuf")

        # Convert protobuf to dict format
        config = msg.config
        data = {
            "correlation_id": msg.correlation_id,
            "enable_after_install": msg.enable_after_install,
            "config": {
                "monitor_interface": config.monitor_interface,
                "bridge_name": config.bridge_name,
                "num_bytes": config.num_bytes or 225,
                "num_packets": config.num_packets or 5,
                "batch_interval": config.batch_interval or 1.0,
                "idle_timeout": config.idle_timeout or 30,
                "policy_enabled": config.policy_enabled,
                "policy_db_path": (
                    config.policy_db_path or "/var/lib/axon/policy_cache.db"
                ),
            },
            "initial_block_rules": [
                {
                    "app_name": r.app_name,
                    "app_pattern": r.app_pattern,
                    "priority": r.priority or 6000,
                    "idle_timeout": r.idle_timeout or 300,
                    "enabled": r.enabled,
                }
                for r in msg.initial_block_rules
            ],
            "initial_rate_limits": [
                {
                    "app_name": r.app_name,
                    "app_pattern": r.app_pattern,
                    "meter_id": r.meter_id,
                    "rate_kbps": r.rate_kbps,
                    "burst_kbps": r.burst_kbps,
                    "priority": r.priority or 5000,
                    "idle_timeout": r.idle_timeout or 300,
                    "enabled": r.enabled,
                }
                for r in msg.initial_rate_limits
            ],
        }
        return data, msg.correlation_id

    def _status_string_to_enum(self, status_str: str) -> int:
        """Convert status string to ClassifierStatus enum value."""
        if not CONFIG_PROTOBUF_AVAILABLE:
            return 0
        status_map = {
            "STOPPED": ClassifierStatus.CLASSIFIER_STATUS_STOPPED,
            "STARTING": ClassifierStatus.CLASSIFIER_STATUS_STARTING,
            "RUNNING": ClassifierStatus.CLASSIFIER_STATUS_RUNNING,
            "ERROR": ClassifierStatus.CLASSIFIER_STATUS_ERROR,
            "DISABLED": ClassifierStatus.CLASSIFIER_STATUS_DISABLED,
            "NOT_CONFIGURED": ClassifierStatus.CLASSIFIER_STATUS_NOT_CONFIGURED,
        }
        return status_map.get(
            status_str, ClassifierStatus.CLASSIFIER_STATUS_UNSPECIFIED
        )

    def _publish_response(self, response: dict, correlation_id: str = None):
        """Publish a status response as protobuf ClassifierStatusResponse."""
        if not CONFIG_PROTOBUF_AVAILABLE:
            logger.error("Cannot publish response: protobuf not available")
            return

        try:
            msg = ClassifierStatusResponse()
            msg.status = self._status_string_to_enum(response.get("status", ""))
            msg.message = response.get("message", "")
            msg.timestamp_ms = int(time.time() * 1000)
            msg.classifier_version = CLASSIFIER_VERSION

            if correlation_id:
                msg.correlation_id = correlation_id

            if response.get("error_details"):
                msg.error_details = response["error_details"]

            # Add current config if present
            current_config = response.get("current_config")
            if current_config:
                msg.current_config.monitor_interface = current_config.get(
                    "monitor_interface", ""
                )
                msg.current_config.bridge_name = current_config.get("bridge_name", "")
                msg.current_config.num_bytes = current_config.get("num_bytes", 225)
                msg.current_config.num_packets = current_config.get("num_packets", 5)
                msg.current_config.batch_interval = current_config.get(
                    "batch_interval", 1.0
                )
                msg.current_config.idle_timeout = current_config.get("idle_timeout", 30)
                msg.current_config.policy_enabled = current_config.get(
                    "policy_enabled", False
                )
                msg.current_config.policy_db_path = current_config.get(
                    "policy_db_path", "/var/lib/axon/policy_cache.db"
                )

            payload = msg.SerializeToString()
            if self.compressor:
                payload = self.compressor.compress(payload)
            self.mqtt_client.publish_raw(self.response_topic, payload, qos=1)
            logger.debug("Published classifier status response (protobuf)")
        except Exception as e:
            logger.error(f"Failed to publish status response: {e}")

    def _publish_install_response(
        self,
        success: bool,
        message: str,
        status_str: str,
        correlation_id: str = None,
        block_rules_installed: int = 0,
        rate_limit_rules_installed: int = 0,
        error_details: str = None,
    ):
        """Publish an install response as protobuf ClassifierInstallResponse."""
        if not CONFIG_PROTOBUF_AVAILABLE:
            logger.error("Cannot publish install response: protobuf not available")
            return

        try:
            msg = ClassifierInstallResponse()
            msg.success = success
            msg.message = message
            msg.status = self._status_string_to_enum(status_str)
            msg.block_rules_installed = block_rules_installed
            msg.rate_limit_rules_installed = rate_limit_rules_installed
            msg.timestamp_ms = int(time.time() * 1000)

            if correlation_id:
                msg.correlation_id = correlation_id

            if error_details:
                msg.error_details = error_details

            payload = msg.SerializeToString()
            if self.compressor:
                payload = self.compressor.compress(payload)
            self.mqtt_client.publish_raw(self.install_response_topic, payload, qos=1)
            logger.debug("Published classifier install response (protobuf)")
        except Exception as e:
            logger.error(f"Failed to publish install response: {e}")

    def _handle_configure(self, topic: str, payload: bytes):
        """Handle classifier configuration command."""
        logger.info("Received classifier configuration command")

        try:
            decompressed = self._decompress_payload(payload)
            msg = ClassifierConfig()
            msg.ParseFromString(decompressed)
            correlation_id = msg.correlation_id

            # Build configuration
            config = {
                "monitor_interface": msg.monitor_interface,
                "bridge_name": msg.bridge_name,
                "site_id": self.site_id,
                "device_id": self.device_id,
                "num_bytes": msg.num_bytes or 225,
                "num_packets": msg.num_packets or 5,
                "batch_interval": msg.batch_interval or 1.0,
                "idle_timeout": msg.idle_timeout or 30,
                "policy_enabled": msg.policy_enabled,
                "policy_db_path": msg.policy_db_path or "/var/lib/axon/policy_cache.db",
            }

            # Validate required fields
            if not config["monitor_interface"]:
                self._publish_response(
                    {
                        "status": "ERROR",
                        "message": "Missing required field: monitor_interface",
                    },
                    correlation_id,
                )
                return

            # Auto-enable policy if bridge is configured
            if config["bridge_name"] and msg.policy_enabled is not False:
                config["policy_enabled"] = True

            # Write configuration
            success, message = self._write_config(config)

            if success:
                # Restart service if running
                self._restart_if_running()

                self._publish_response(
                    {
                        "status": (
                            "RUNNING" if self._is_service_running() else "STOPPED"
                        ),
                        "message": "Configuration updated successfully",
                        "current_config": config,
                    },
                    correlation_id,
                )
            else:
                self._publish_response(
                    {
                        "status": "ERROR",
                        "message": message,
                    },
                    correlation_id,
                )

        except Exception as e:
            logger.error(f"Failed to parse configure payload: {e}")
            self._publish_response(
                {
                    "status": "ERROR",
                    "message": f"Failed to parse payload: {e}",
                }
            )

    def _handle_enable(self, topic: str, payload: bytes):
        """Handle classifier enable command."""
        logger.info("Received classifier enable command")

        try:
            decompressed = self._decompress_payload(payload)
            msg = ClassifierConfig()
            msg.ParseFromString(decompressed)
            correlation_id = msg.correlation_id
        except Exception:
            correlation_id = None

        # Check if configuration exists
        if not os.path.exists(CLASSIFIER_CONFIG_PATH):
            self._publish_response(
                {
                    "status": "NOT_CONFIGURED",
                    "message": "Classifier not configured. Send configuration first.",
                },
                correlation_id,
            )
            return

        # Enable and start service
        success, message = self._enable_service()

        if success:
            self._publish_response(
                {
                    "status": "RUNNING",
                    "message": "Classifier enabled and started",
                },
                correlation_id,
            )
        else:
            self._publish_response(
                {
                    "status": "ERROR",
                    "message": message,
                },
                correlation_id,
            )

    def _handle_disable(self, topic: str, payload: bytes):
        """Handle classifier disable command."""
        logger.info("Received classifier disable command")

        try:
            decompressed = self._decompress_payload(payload)
            msg = ClassifierConfig()
            msg.ParseFromString(decompressed)
            correlation_id = msg.correlation_id
        except Exception:
            correlation_id = None

        # Stop and disable service
        success, message = self._disable_service()

        if success:
            self._publish_response(
                {
                    "status": "DISABLED",
                    "message": "Classifier disabled and stopped",
                },
                correlation_id,
            )
        else:
            self._publish_response(
                {
                    "status": "ERROR",
                    "message": message,
                },
                correlation_id,
            )

    def _handle_status(self, topic: str, payload: bytes):
        """Handle classifier status request."""
        logger.debug("Received classifier status request")

        try:
            decompressed = self._decompress_payload(payload)
            msg = ClassifierConfig()
            msg.ParseFromString(decompressed)
            correlation_id = msg.correlation_id
        except Exception:
            correlation_id = None

        # Get current status
        status = self._get_service_status()
        config = self._read_config()

        response = {
            "status": status,
            "message": f"Classifier is {status.lower()}",
        }

        if config:
            response["current_config"] = config

        self._publish_response(response, correlation_id)

    def _handle_install(self, topic: str, payload: bytes):
        """Handle full classifier installation.

        Expects protobuf ClassifierInstallRequest format.
        """
        logger.info("Received classifier installation command")

        try:
            # Parse payload (protobuf or JSON)
            data, correlation_id = self._parse_install_payload(payload)

            # Extract configuration
            config_data = data.get("config", data)

            config = {
                "monitor_interface": config_data.get("monitor_interface"),
                "bridge_name": config_data.get("bridge_name", ""),
                "site_id": self.site_id,
                "device_id": self.device_id,
                "num_bytes": config_data.get("num_bytes", 225),
                "num_packets": config_data.get("num_packets", 5),
                "batch_interval": config_data.get("batch_interval", 1.0),
                "idle_timeout": config_data.get("idle_timeout", 30),
                "policy_enabled": config_data.get("policy_enabled", True),
                "policy_db_path": config_data.get(
                    "policy_db_path", "/var/lib/axon/policy_cache.db"
                ),
            }

            # Validate required fields
            if not config["monitor_interface"]:
                self._publish_install_response(
                    success=False,
                    message="Missing required field: monitor_interface",
                    status_str="ERROR",
                    correlation_id=correlation_id,
                )
                return

            # Auto-enable policy if bridge is configured
            if config["bridge_name"]:
                config["policy_enabled"] = True

            # Create directories
            self._ensure_directories()

            # Write configuration
            success, message = self._write_config(config)
            if not success:
                self._publish_install_response(
                    success=False,
                    message=message,
                    status_str="ERROR",
                    correlation_id=correlation_id,
                )
                return

            # Install initial policies if provided
            block_rules = data.get("initial_block_rules", [])
            rate_limits = data.get("initial_rate_limits", [])

            block_count = 0
            rate_count = 0

            if block_rules or rate_limits:
                from ..policy_cache import PolicyCache

                cache = PolicyCache(db_path=config["policy_db_path"])
                try:
                    for rule in block_rules:
                        if cache.add_block_rule(
                            app_name=rule.get("app_name"),
                            app_pattern=rule.get("app_pattern"),
                            priority=rule.get("priority", 6000),
                            idle_timeout=rule.get("idle_timeout", 300),
                            enabled=rule.get("enabled", True),
                        ):
                            block_count += 1

                    for rule in rate_limits:
                        if cache.add_rate_limit(
                            app_name=rule.get("app_name"),
                            meter_id=rule.get("meter_id"),
                            rate_kbps=rule.get("rate_kbps"),
                            burst_kbps=rule.get("burst_kbps"),
                            app_pattern=rule.get("app_pattern"),
                            priority=rule.get("priority", 5000),
                            idle_timeout=rule.get("idle_timeout", 300),
                            enabled=rule.get("enabled", True),
                        ):
                            rate_count += 1
                except Exception as e:
                    logger.error(f"Failed to install initial policies: {e}")
                finally:
                    cache.close()

            # Enable and start if requested
            enable_after = data.get("enable_after_install", True)
            service_running = False
            if enable_after:
                enable_success, enable_msg = self._enable_service()
                service_running = enable_success and self._is_service_running()
                if not enable_success:
                    logger.warning(f"Service enable failed after install: {enable_msg}")

            self._publish_install_response(
                success=True,
                message="Classifier installed successfully",
                status_str="RUNNING" if service_running else "STOPPED",
                correlation_id=correlation_id,
                block_rules_installed=block_count,
                rate_limit_rules_installed=rate_count,
            )

        except ValueError as e:
            logger.error(f"Failed to parse protobuf: {e}")
            self._publish_install_response(
                success=False,
                message=f"Invalid protobuf payload: {e}",
                status_str="ERROR",
                error_details=str(e),
            )
        except Exception as e:
            logger.error(f"Error handling installation: {e}", exc_info=True)
            self._publish_install_response(
                success=False,
                message=str(e),
                status_str="ERROR",
                error_details=str(e),
            )

    def _ensure_directories(self):
        """Ensure required directories exist."""
        for directory in [CLASSIFIER_CONFIG_DIR, POLICY_DB_DIR]:
            if not os.path.exists(directory):
                try:
                    os.makedirs(directory, mode=0o755, exist_ok=True)
                    logger.info(f"Created directory: {directory}")
                except PermissionError:
                    logger.warning(f"Cannot create directory: {directory}")

    def _write_config(self, config: dict) -> tuple[bool, str]:
        """Write configuration to file."""
        try:
            self._ensure_directories()

            with open(CLASSIFIER_CONFIG_PATH, "w") as f:
                json.dump(config, f, indent=4)

            logger.info(f"Wrote classifier config to {CLASSIFIER_CONFIG_PATH}")
            return True, "Configuration saved"
        except PermissionError:
            return False, f"Permission denied writing to {CLASSIFIER_CONFIG_PATH}"
        except Exception as e:
            return False, f"Failed to write config: {e}"

    def _read_config(self) -> Optional[dict]:
        """Read current configuration."""
        try:
            if os.path.exists(CLASSIFIER_CONFIG_PATH):
                with open(CLASSIFIER_CONFIG_PATH, "r") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to read config: {e}")
        return None

    def _is_service_running(self) -> bool:
        """Check if classifier service is running."""
        try:
            result = subprocess.run(
                ["systemctl", "is-active", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _get_service_status(self) -> str:
        """Get classifier service status."""
        if not os.path.exists(CLASSIFIER_CONFIG_PATH):
            return "NOT_CONFIGURED"

        try:
            # Check if enabled
            result = subprocess.run(
                ["systemctl", "is-enabled", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=5,
            )
            is_enabled = result.returncode == 0

            # Check if active
            result = subprocess.run(
                ["systemctl", "is-active", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=5,
            )
            is_active = result.returncode == 0

            if is_active:
                return "RUNNING"
            elif is_enabled:
                return "STOPPED"
            else:
                return "DISABLED"

        except Exception as e:
            logger.error(f"Failed to get service status: {e}")
            return "ERROR"

    def _enable_service(self) -> tuple[bool, str]:
        """Enable and start the classifier service and flow stats monitor."""
        try:
            # Enable classifier service
            result = subprocess.run(
                ["systemctl", "enable", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return False, f"Failed to enable service: {result.stderr}"

            # Start classifier service
            result = subprocess.run(
                ["systemctl", "start", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return False, f"Failed to start service: {result.stderr}"

            logger.info("Classifier service enabled and started")

            # Enable and start classifier flow stats service
            result = subprocess.run(
                ["systemctl", "enable", CLASSIFIER_FLOW_STATS_SERVICE],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                logger.warning(
                    f"Failed to enable classifier flow stats service: {result.stderr}"
                )
            else:
                result = subprocess.run(
                    ["systemctl", "start", CLASSIFIER_FLOW_STATS_SERVICE],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    logger.warning(
                        f"Failed to start classifier flow stats service: {result.stderr}"
                    )
                else:
                    logger.info("Classifier flow stats service enabled and started")

            return True, "Service enabled and started"

        except subprocess.TimeoutExpired:
            return False, "Timeout managing service"
        except Exception as e:
            return False, f"Failed to manage service: {e}"

    def _disable_service(self) -> tuple[bool, str]:
        """Stop and disable the classifier service and flow stats monitor."""
        try:
            # Stop classifier flow stats service first
            result = subprocess.run(
                ["systemctl", "stop", CLASSIFIER_FLOW_STATS_SERVICE],
                capture_output=True,
                text=True,
                timeout=20,
            )
            if result.returncode == 0:
                subprocess.run(
                    ["systemctl", "disable", CLASSIFIER_FLOW_STATS_SERVICE],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info("Classifier flow stats service disabled and stopped")

            # Stop classifier service
            result = subprocess.run(
                ["systemctl", "stop", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=20,
            )
            if result.returncode != 0:
                return False, f"Failed to stop service: {result.stderr}"

            # Disable classifier service
            result = subprocess.run(
                ["systemctl", "disable", CLASSIFIER_SERVICE],
                capture_output=True,
                text=True,
                timeout=10,
            )

            logger.info("Classifier service disabled and stopped")
            return True, "Service disabled and stopped"

        except subprocess.TimeoutExpired:
            return False, "Timeout managing service"
        except Exception as e:
            return False, f"Failed to manage service: {e}"

    def _restart_if_running(self):
        """Restart the classifier service and flow stats monitor if running."""
        if self._is_service_running():
            try:
                subprocess.run(
                    ["systemctl", "restart", CLASSIFIER_SERVICE],
                    capture_output=True,
                    text=True,
                    timeout=20,
                )
                logger.info("Classifier service restarted")

                # Also restart flow stats service if it's running
                subprocess.run(
                    ["systemctl", "restart", CLASSIFIER_FLOW_STATS_SERVICE],
                    capture_output=True,
                    text=True,
                    timeout=20,
                )
                logger.info("Classifier flow stats service restarted")
            except Exception as e:
                logger.error(f"Failed to restart service: {e}")
