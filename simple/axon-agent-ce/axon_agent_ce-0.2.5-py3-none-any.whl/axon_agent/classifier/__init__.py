"""NFStream-based traffic classifier module.

This module provides traffic classification using NFStream's nDPI engine,
collecting payload samples and sending classified flow data to the controller.

Usage:
    # For testing (console output only)
    sudo python3 -m axon_agent.classifier.classifier_test eth0

    # For production (MQTT integration)
    sudo python3 -m axon_agent.classifier.agent
"""

__all__ = [
    "ClassifierPlugin",
    "FlowCollector",
    "ClassifiedFlowData",
    "format_flow_console",
    "format_flow_log",
    "format_bytes",
    "DEFAULT_NUM_BYTES",
    "DEFAULT_NUM_PACKETS",
    "DEFAULT_BATCH_INTERVAL",
    "DEFAULT_IDLE_TIMEOUT",
]


def __getattr__(name: str):
    """Lazy import to defer nfstream dependency until actually needed."""
    if name in __all__:
        from .classifier import (
            ClassifierPlugin,
            FlowCollector,
            ClassifiedFlowData,
            format_flow_console,
            format_flow_log,
            format_bytes,
            DEFAULT_NUM_BYTES,
            DEFAULT_NUM_PACKETS,
            DEFAULT_BATCH_INTERVAL,
            DEFAULT_IDLE_TIMEOUT,
        )

        _exports = {
            "ClassifierPlugin": ClassifierPlugin,
            "FlowCollector": FlowCollector,
            "ClassifiedFlowData": ClassifiedFlowData,
            "format_flow_console": format_flow_console,
            "format_flow_log": format_flow_log,
            "format_bytes": format_bytes,
            "DEFAULT_NUM_BYTES": DEFAULT_NUM_BYTES,
            "DEFAULT_NUM_PACKETS": DEFAULT_NUM_PACKETS,
            "DEFAULT_BATCH_INTERVAL": DEFAULT_BATCH_INTERVAL,
            "DEFAULT_IDLE_TIMEOUT": DEFAULT_IDLE_TIMEOUT,
        }
        return _exports[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
