#!/usr/bin/env python3
"""NFStream Classifier Agent - Production MQTT Integration.

This agent captures network traffic using NFStream, classifies it using nDPI,
and sends the classified flow data to the controller via MQTT.

Configuration is loaded from /etc/axon/classifier_config.json

Usage:
    sudo python3 -m axon_agent.classifier.agent

Requirements:
    pip install nfstream zstandard paho-mqtt
"""

import base64
import json
import logging
import os
import threading
import time
from typing import Optional

try:
    from nfstream import NFStreamer
except ImportError:
    print("ERROR: nfstream not installed. Run: pip install nfstream")
    import sys
    sys.exit(1)

try:
    import zstandard as zstd
except ImportError:
    print("ERROR: zstandard not installed. Run: pip install zstandard")
    import sys
    sys.exit(1)

from ..base_agent import BaseAgent
from ..hostname_resolver import HostnameResolver
from ..policy_cache import PolicyCache
from axon_shared.mqtt.topics import data_topic, CLASSIFIED_FLOWS
from .classifier import (
    ClassifierPlugin,
    FlowCollector,
    ClassifiedFlowData,
    format_bytes,
    DEFAULT_NUM_BYTES,
    DEFAULT_NUM_PACKETS,
    DEFAULT_BATCH_INTERVAL,
    DEFAULT_IDLE_TIMEOUT,
)

try:
    from axon_shared.proto.classifier_messages_pb2 import ClassifiedFlowBatch
    PROTOBUF_AVAILABLE = True
except ImportError:
    PROTOBUF_AVAILABLE = False
    ClassifiedFlowBatch = None

logger = logging.getLogger(__name__)

# Configuration file path
CLASSIFIER_CONFIG_PATH = "/etc/axon/classifier_config.json"

# Classifier version for compatibility tracking
CLASSIFIER_VERSION = "1.0.0"


class ClassifierAgent(BaseAgent):
    """NFStream-based traffic classifier agent with MQTT publishing and policy enforcement.

    This agent:
    1. Captures traffic using NFStream
    2. Classifies flows using nDPI (local classification)
    3. Applies policy rules (blocklist/rate limits) via OVS
    4. Collects payload samples for controller ML
    5. Publishes classified flows to MQTT in batches
    """

    agent_name = "Classifier Agent"
    mqtt_client_id_suffix = "classifier"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 5.0
    use_counted_retries = False
    publish_buffer_size = 60

    def __init__(self):
        """Initialize the classifier agent."""
        super().__init__()

        # Configuration from classifier_config.json
        self.monitor_interface: Optional[str] = None
        self.bridge_name: Optional[str] = None
        self.num_bytes: int = DEFAULT_NUM_BYTES
        self.num_packets: int = DEFAULT_NUM_PACKETS
        self.batch_interval: float = DEFAULT_BATCH_INTERVAL
        self.idle_timeout: int = DEFAULT_IDLE_TIMEOUT

        # Policy enforcement
        self.policy_enabled: bool = False
        self.policy_cache: Optional[PolicyCache] = None

        # MQTT topic for publishing
        self.flows_topic: Optional[str] = None

        # Zstd compressor
        self.compressor = zstd.ZstdCompressor(level=3)

        # Flow collector
        self.collector: Optional[FlowCollector] = None

        # Plugin reference stored for _cleanup() stats access
        self.plugin: Optional[ClassifierPlugin] = None

        # Hostname resolver for client device name discovery
        self._hostname_resolver: Optional[HostnameResolver] = None

        # Shutdown support: event + streamer reference for watchdog termination
        self._shutdown_event = threading.Event()
        self._streamer: Optional[NFStreamer] = None
        self._streamer_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Shutdown support
    # ------------------------------------------------------------------

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals by setting running=False and triggering watchdog."""
        logger.info(
            f"Received signal {signum}, shutting down {self.agent_name}..."
        )
        self.running = False
        self._shutdown_event.set()

    def _shutdown_watchdog(self):
        """Watchdog thread that force-terminates NFStreamer on shutdown signal.

        Runs as a daemon thread. Waits for the shutdown event, gives the main
        thread a moment to break out of the iterator naturally, then destroys
        the NFStreamer to unblock the capture loop.
        """
        self._shutdown_event.wait()
        time.sleep(1)
        with self._streamer_lock:
            streamer = self._streamer
            self._streamer = None
        if streamer is not None:
            logger.info("Force-terminating NFStreamer capture...")
            try:
                del streamer
            except Exception as e:
                logger.warning(f"Error terminating streamer: {e}")

    # ------------------------------------------------------------------
    # Config loading (overrides BaseAgent._load_config entirely)
    # ------------------------------------------------------------------

    def _load_config(self) -> bool:
        """Load classifier configuration from classifier_config.json.

        Overrides BaseAgent._load_config() entirely because this agent
        loads from a dedicated classifier config file rather than
        config.json.

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            if not os.path.exists(CLASSIFIER_CONFIG_PATH):
                logger.error(f"Classifier config not found: {CLASSIFIER_CONFIG_PATH}")
                return False

            with open(CLASSIFIER_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)

            self.monitor_interface = config.get("monitor_interface")
            self.bridge_name = config.get("bridge_name")
            self.num_bytes = config.get("num_bytes", DEFAULT_NUM_BYTES)
            self.num_packets = config.get("num_packets", DEFAULT_NUM_PACKETS)
            self.batch_interval = config.get("batch_interval", DEFAULT_BATCH_INTERVAL)
            self.idle_timeout = config.get("idle_timeout", DEFAULT_IDLE_TIMEOUT)
            self.site_id = config.get("site_id")
            self.device_id = config.get("device_id")

            # Policy enforcement configuration
            self.policy_enabled = config.get("policy_enabled", False)
            self.install_normal_flows = config.get(
                "install_normal_flows", True
            )
            policy_db_path = config.get("policy_db_path")

            # Validate required fields
            if not self.monitor_interface:
                logger.error("Classifier config missing monitor_interface")
                return False

            if not self.site_id or not self.device_id:
                logger.error("Classifier config missing site_id or device_id")
                return False

            # Build MQTT topic
            self.flows_topic = data_topic(self.site_id, self.device_id, CLASSIFIED_FLOWS)

            # Validate bridge_name when OVS access is needed
            if (self.policy_enabled or self.install_normal_flows) \
                    and not self.bridge_name:
                logger.error(
                    "bridge_name required in config when policy_enabled "
                    "or install_normal_flows is active"
                )
                return False

            # Initialize policy cache if enabled
            if self.policy_enabled:
                if policy_db_path:
                    self.policy_cache = PolicyCache(db_path=policy_db_path)
                else:
                    self.policy_cache = PolicyCache()

                logger.info(f"Policy enforcement enabled on bridge: {self.bridge_name}")

            logger.info(
                f"Loaded classifier config: interface={self.monitor_interface}, "
                f"num_bytes={self.num_bytes}, num_packets={self.num_packets}, "
                f"batch_interval={self.batch_interval}s, idle_timeout={self.idle_timeout}s, "
                f"policy_enabled={self.policy_enabled}, "
                f"install_normal_flows={self.install_normal_flows}"
            )
            return True

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in classifier config: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to load classifier config: {e}")
            return False

    def _load_service_config(self, config: dict) -> bool:
        """Not used - _load_config() is overridden entirely.

        Provided to satisfy BaseAgent's abstract method contract.
        """
        return True

    # ------------------------------------------------------------------
    # Factory methods (override in subclasses to swap implementations)
    # ------------------------------------------------------------------

    def _create_collector(self):
        """Create flow collector with policy enforcement and async OVS worker.

        The collector creates an OVSActionWorker for batched async OVS
        operations.
        """
        needs_ovs = self.policy_enabled or self.install_normal_flows
        collector = FlowCollector(
            on_batch_ready=self._on_batch_ready,
            batch_interval=self.batch_interval,
            num_bytes=self.num_bytes,
            num_packets=self.num_packets,
            bridge=self.bridge_name if needs_ovs else None,
            policy_cache=self.policy_cache,
            use_async_ovs=needs_ovs,
            install_normal_flows=self.install_normal_flows,
            hostname_resolver=self._hostname_resolver,
        )

        # Initialize classification registry for SNI propagation
        # to the flow stats monitor via shared file
        from ..monitoring.classifier_flow_stats_monitor import (
            ClassificationRegistry,
        )
        collector.classification_registry = ClassificationRegistry()

        return collector

    def _create_plugin(self):
        """Create classifier plugin with multiprocessing queue for IPC.

        This allows NFStream's metering processes to write flows directly
        to the queue. Also enables early SNI and app-based blocking if
        policy enforcement is enabled.

        NOTE: We intentionally do NOT pass ovs_worker to the plugin
        because:
        - NFStream runs plugins in subprocesses (multiprocessing)
        - The OVSActionWorker uses threading.Queue which doesn't work
          across processes
        - Passing the worker would result in enqueued actions going to
          a dead queue
        - The plugin falls back to synchronous OVS calls
          (install_bidirectional_drop) which work correctly in the
          subprocess context
        """
        return ClassifierPlugin(
            num_bytes=self.num_bytes,
            num_packets=self.num_packets,
            flow_queue=self.collector.get_queue(),
            flow_converter=self.collector.get_flow_converter(),
            policy_cache=self.policy_cache if self.policy_enabled else None,
            bridge=self.bridge_name if self.policy_enabled else None,
        )

    # ------------------------------------------------------------------
    # Lifecycle hooks
    # ------------------------------------------------------------------

    def _run_loop(self):
        """Main classifier capture loop.

        Creates HostnameResolver, FlowCollector, ClassifierPlugin, and
        NFStreamer, then iterates over captured flows until self.running
        is False.
        """
        logger.info(f"Classifier version: {CLASSIFIER_VERSION}")
        logger.info(f"Protobuf available: {PROTOBUF_AVAILABLE}")

        # Start hostname resolver for client device name discovery
        self._hostname_resolver = HostnameResolver(
            interface=self.monitor_interface,
        )
        self._hostname_resolver.start()

        self.collector = self._create_collector()
        self.plugin = self._create_plugin()

        if self.policy_enabled:
            logger.info(
                "Early blocking ENABLED - SNI blocklists triggered at packet 1-2, "
                "app blocklists triggered at packet 2-3 (before full classification)"
            )
            logger.info(
                "Early blocking uses synchronous OVS calls (required for subprocess execution)"
            )

        # Start collector
        self.collector.start()

        # Start shutdown watchdog thread before capture loop
        watchdog = threading.Thread(
            target=self._shutdown_watchdog, daemon=True
        )
        watchdog.start()

        # Configure NFStreamer with retry for interface availability
        logger.info(f"Starting capture on interface: {self.monitor_interface}")

        backoff = 2
        max_backoff = 60
        while self.running:
            try:
                self._streamer = NFStreamer(
                    source=self.monitor_interface,
                    statistical_analysis=False,
                    splt_analysis=0,
                    n_dissections=20,
                    idle_timeout=self.idle_timeout,
                    active_timeout=300,
                    promiscuous_mode=True,
                    udps=self.plugin,
                    # n_meters defaults to 0 (all cores)
                )
                break
            except ValueError:
                logger.warning(
                    f"Interface {self.monitor_interface} not available, "
                    f"retrying in {backoff}s..."
                )
                time.sleep(backoff)
                backoff = min(backoff * 2, max_backoff)

        if not self.running:
            return

        logger.info("Classifier agent capture running...")

        try:
            for flow in self._streamer:
                if not self.running:
                    break
        finally:
            with self._streamer_lock:
                self._streamer = None

    def _cleanup(self):
        """Stop collector, hostname resolver, and log final statistics.

        MQTT cleanup is handled by BaseAgent.
        """
        if self._hostname_resolver:
            self._hostname_resolver.stop()

        if self.collector:
            self.collector.stop()

            # Log final stats
            stats_msg = (
                f"Classifier stopped. Total flows: {self.collector.total_flows:,}, "
                f"Packets: {self.collector.total_packets:,}, "
                f"Bytes: {format_bytes(self.collector.total_bytes)}"
            )
            if self.policy_enabled:
                # Include early blocking stats from plugin
                early_blocked = getattr(self.plugin, "early_blocked_flows", 0)
                early_rate_limited = getattr(self.plugin, "early_rate_limited_flows", 0)
                early_app_checks = getattr(self.plugin, "early_app_policy_checks", 0)
                stats_msg += (
                    f", Early blocked: {early_blocked:,}, "
                    f"Early rate limited: {early_rate_limited:,}, "
                    f"Early app checks: {early_app_checks:,}, "
                    f"Blocked: {self.collector.blocked_flows:,}, "
                    f"Rate limited: {self.collector.rate_limited_flows:,}"
                )
                # Log OVS worker stats if available
                if self.collector.ovs_worker:
                    worker = self.collector.ovs_worker
                    logger.info(
                        f"OVS Worker stats: queued={worker.actions_queued:,}, "
                        f"executed={worker.actions_executed:,}, "
                        f"batches={worker.batches_executed:,}, "
                        f"errors={worker.errors:,}"
                    )
            logger.info(stats_msg)

    # ------------------------------------------------------------------
    # Batch publishing
    # ------------------------------------------------------------------

    def _on_batch_ready(self, batch: list[ClassifiedFlowData]):
        """Handle a batch of classified flows - serialize and publish to MQTT.

        Args:
            batch: List of ClassifiedFlowData objects
        """
        logger.debug(f"_on_batch_ready called with {len(batch)} flows")

        if not self.mqtt_client:
            logger.warning("MQTT client is None, skipping batch")
            return

        if not self.mqtt_client.is_connected():
            logger.warning("MQTT not connected, skipping batch")
            return

        if not batch:
            logger.warning("Empty batch received")
            return

        try:
            logger.debug(f"PROTOBUF_AVAILABLE={PROTOBUF_AVAILABLE}")
            if PROTOBUF_AVAILABLE:
                # Use protobuf serialization
                self._publish_protobuf_batch(batch)
            else:
                # Fallback to JSON
                self._publish_json_batch(batch)

        except Exception as e:
            logger.error(
                f"Error publishing batch of {len(batch)} flows: {e}", exc_info=True
            )

    def _publish_protobuf_batch(self, batch: list[ClassifiedFlowData]):
        """Publish batch using protobuf serialization."""
        flow_batch = ClassifiedFlowBatch()
        flow_batch.switch_id = self.bridge_name or ""
        flow_batch.site_id = self.site_id or ""
        flow_batch.device_id = self.device_id or ""
        flow_batch.timestamp_ms = int(time.time() * 1000)
        flow_batch.classifier_version = CLASSIFIER_VERSION

        for flow_data in batch:
            flow = flow_batch.flows.add()
            flow.src_ip = flow_data.src_ip
            flow.dst_ip = flow_data.dst_ip
            flow.src_port = flow_data.src_port
            flow.dst_port = flow_data.dst_port
            flow.src_mac = flow_data.src_mac
            flow.dst_mac = flow_data.dst_mac
            flow.is_tcp = flow_data.is_tcp
            flow.payload_sample = flow_data.payload_sample
            flow.flow_id = flow_data.flow_id
            flow.application_name = flow_data.application_name
            flow.application_category = flow_data.application_category
            flow.application_confidence = flow_data.application_confidence
            flow.requested_server_name = flow_data.requested_server_name
            flow.client_fingerprint = flow_data.client_fingerprint
            flow.server_fingerprint = flow_data.server_fingerprint
            flow.bidirectional_packets = flow_data.bidirectional_packets
            flow.bidirectional_bytes = flow_data.bidirectional_bytes
            flow.bidirectional_duration_ms = flow_data.bidirectional_duration_ms
            flow.src2dst_packets = flow_data.src2dst_packets
            flow.dst2src_packets = flow_data.dst2src_packets
            flow.src2dst_bytes = flow_data.src2dst_bytes
            flow.dst2src_bytes = flow_data.dst2src_bytes
            flow.sni_source = flow_data.sni_source
            flow.payload_packet_count = flow_data.payload_packet_count
            # Cookie and classification tracking fields
            flow.openflow_cookie = flow_data.openflow_cookie
            flow.classification_id = flow_data.classification_id
            flow.normalized_app_name = flow_data.normalized_app_name
            if flow_data.src_hostname:
                flow.src_hostname = flow_data.src_hostname
                logger.debug(
                    f"Flow {flow_data.src_mac} hostname: {flow_data.src_hostname}"
                )

        # Serialize and compress
        serialized = flow_batch.SerializeToString()
        compressed = self.compressor.compress(serialized)

        # Publish
        if self.mqtt_client.publish_raw(self.flows_topic, compressed, qos=0):
            logger.debug(
                f"Published batch of {len(batch)} classified flows "
                f"to {self.flows_topic} ({len(compressed)} bytes compressed)"
            )
        else:
            logger.warning(f"Failed to publish batch of {len(batch)} flows")

    def _publish_json_batch(self, batch: list[ClassifiedFlowData]):
        """Publish batch using JSON serialization (fallback when protobuf unavailable)."""

        payload = {
            "switch_id": self.bridge_name or "",
            "site_id": self.site_id or "",
            "device_id": self.device_id or "",
            "timestamp_ms": int(time.time() * 1000),
            "classifier_version": CLASSIFIER_VERSION,
            "flows": [],
        }

        for flow_data in batch:
            flow_dict = {
                "src_ip": flow_data.src_ip,
                "dst_ip": flow_data.dst_ip,
                "src_port": flow_data.src_port,
                "dst_port": flow_data.dst_port,
                "src_mac": flow_data.src_mac,
                "dst_mac": flow_data.dst_mac,
                "is_tcp": flow_data.is_tcp,
                "payload_sample": base64.b64encode(flow_data.payload_sample).decode(
                    "ascii"
                ),
                "flow_id": flow_data.flow_id,
                "application_name": flow_data.application_name,
                "application_category": flow_data.application_category,
                "application_confidence": flow_data.application_confidence,
                "requested_server_name": flow_data.requested_server_name,
                "client_fingerprint": flow_data.client_fingerprint,
                "server_fingerprint": flow_data.server_fingerprint,
                "bidirectional_packets": flow_data.bidirectional_packets,
                "bidirectional_bytes": flow_data.bidirectional_bytes,
                "bidirectional_duration_ms": flow_data.bidirectional_duration_ms,
                "src2dst_packets": flow_data.src2dst_packets,
                "dst2src_packets": flow_data.dst2src_packets,
                "src2dst_bytes": flow_data.src2dst_bytes,
                "dst2src_bytes": flow_data.dst2src_bytes,
                "sni_source": flow_data.sni_source,
                "payload_packet_count": flow_data.payload_packet_count,
                # Cookie and classification tracking fields
                "openflow_cookie": flow_data.openflow_cookie,
                "classification_id": flow_data.classification_id,
                "normalized_app_name": flow_data.normalized_app_name,
                "src_hostname": flow_data.src_hostname,
            }
            payload["flows"].append(flow_dict)

        # Serialize and compress
        json_str = json.dumps(payload)
        compressed = self.compressor.compress(json_str.encode("utf-8"))

        # Publish
        if self.mqtt_client.publish_raw(self.flows_topic, compressed, qos=0):
            logger.debug(
                f"Published JSON batch of {len(batch)} classified flows "
                f"to {self.flows_topic} ({len(compressed)} bytes compressed)"
            )
        else:
            logger.warning(f"Failed to publish JSON batch of {len(batch)} flows")


def main():
    """Main entry point for classifier agent."""
    agent = ClassifierAgent()
    agent.run()


if __name__ == "__main__":
    main()
