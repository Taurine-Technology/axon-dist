"""Bridge utility functions for bridge deletion and cleanup operations."""

import logging
from typing import Tuple

from .config import ConfigManager
from .monitoring.port_stats_monitor import stop_port_stats_monitoring
from .ovs_bridge import OVSBridgeManager
from .utils import stop_systemd_service, disable_systemd_service, restart_systemd_service

logger = logging.getLogger(__name__)


def _stop_port_link_monitoring() -> bool:
    """Stop port link monitoring service.

    Returns:
        True if stopped and disabled successfully (or not running), False otherwise
    """
    port_link_service = "axon-agent-port-link.service"
    try:
        if stop_systemd_service(port_link_service):
            logger.info("Stopped port link monitoring systemd service")
            if disable_systemd_service(port_link_service):
                logger.info("Disabled port link monitoring systemd service")
                return True
            else:
                logger.warning(f"Failed to disable {port_link_service}")
                return False
        else:
            logger.debug("Port link monitoring systemd service not running")
            return True
    except Exception as e:
        logger.warning(f"Error stopping port link monitoring: {e}")
        return False


def delete_bridge_and_cleanup(
    bridge_name: str, config_manager: ConfigManager
) -> Tuple[bool, str]:
    """Delete an OVS bridge and perform complete cleanup.

    This function orchestrates the complete bridge deletion workflow:
    1. Delete OVS bridge using OVSBridgeManager.delete_bridge()
    2. Remove bridge config from config.json
    3. Stop monitoring services if no bridges remain

    Args:
        bridge_name: Name of the bridge to delete
        config_manager: ConfigManager instance for managing configuration

    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        # Step 1: Delete the OVS bridge
        logger.info(f"Deleting OVS bridge: {bridge_name}")
        bridge_manager = OVSBridgeManager()
        success, message = bridge_manager.delete_bridge(bridge_name)

        if not success:
            logger.error(f"Failed to delete bridge {bridge_name}: {message}")
            return False, f"Bridge deletion failed: {message}"

        logger.info(f"Successfully deleted bridge {bridge_name}")

        # Step 2: Remove bridge config from config.json
        logger.info(f"Removing bridge config for {bridge_name} from config.json...")
        try:
            config_manager.delete_bridge_config(bridge_name)
            logger.info(f"Removed bridge config for {bridge_name}")
        except Exception as e:
            logger.error(
                f"Failed to remove bridge config from config: {e}",
                exc_info=True,
            )
            return (
                True,
                f"Bridge {bridge_name} deleted successfully, but config cleanup failed: {str(e)}",
            )

        # Step 3: Stop monitoring services only if no bridges remain
        remaining_bridges = config_manager.get_all_bridge_configs()
        if not remaining_bridges:
            logger.info("No bridges remaining, stopping monitoring services...")
            try:
                stop_success = stop_port_stats_monitoring()
                if stop_success:
                    logger.info("Port statistics monitoring stopped successfully")
                else:
                    logger.warning(
                        "Port statistics monitoring stop had issues, continuing anyway"
                    )
            except Exception as e:
                logger.warning(
                    f"Error stopping port statistics monitoring: {e}, continuing"
                )

            try:
                link_stop_success = _stop_port_link_monitoring()
                if link_stop_success:
                    logger.info("Port link monitoring stopped successfully")
                else:
                    logger.warning(
                        "Port link monitoring stop had issues, continuing anyway"
                    )
            except Exception as e:
                logger.warning(
                    f"Error stopping port link monitoring: {e}, continuing"
                )
        else:
            logger.info(
                f"Other bridges still configured ({list(remaining_bridges.keys())}), "
                "restarting monitoring services to refresh config"
            )
            for service in [
                "axon-agent-port-stats.service",
                "axon-agent-port-link.service",
            ]:
                try:
                    restart_systemd_service(service)
                except Exception as e:
                    logger.warning(f"Failed to restart {service}: {e}")

        return True, f"Bridge {bridge_name} deleted and cleanup completed successfully"

    except Exception as e:
        error_msg = f"Unexpected error during bridge deletion and cleanup: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return False, error_msg
