"""Time-based policy enforcement for rules with TimeConstraint.

This module provides a background thread that periodically checks time constraints
on policy rules and removes OVS flows when rules become inactive (e.g., when the
current time moves outside the rule's active time window).

Usage:
    enforcer = TimeConstraintEnforcer(policy_cache, bridge_name)
    enforcer.start()
    # ... later ...
    enforcer.stop()
"""

import logging
import subprocess
import threading
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .policy_cache import PolicyCache

from .policy_cache import _time_constraint_active
from .utils import compute_classification_id

logger = logging.getLogger(__name__)


class TimeConstraintEnforcer:
    """Background thread that checks time constraints and removes flows when rules deactivate.

    This class monitors rules with time_constraint fields and:
    1. Tracks which rules are currently active
    2. Detects when a rule transitions from active to inactive
    3. Removes OVS flows for deactivated rules

    Args:
        policy_cache: PolicyCache instance to read rules from
        bridge: OVS bridge name for flow deletion
        check_interval: Seconds between constraint checks (default: 60)
    """

    def __init__(
        self,
        policy_cache: "PolicyCache",
        bridge: str,
        check_interval: int = 60,
    ):
        self.policy_cache = policy_cache
        self.bridge = bridge
        self.check_interval = check_interval

        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

        # Track rule state: (rule_type, app_name) -> was_active
        # Used to detect transitions from active -> inactive
        self._rule_state: dict[tuple[str, str], bool] = {}

    def start(self) -> None:
        """Start the background enforcement thread."""
        if self._thread is not None and self._thread.is_alive():
            logger.warning("TimeConstraintEnforcer already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info(
            f"TimeConstraintEnforcer started (check_interval={self.check_interval}s)"
        )

    def stop(self) -> None:
        """Stop the background enforcement thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            if self._thread.is_alive():
                logger.warning(
                    "TimeConstraintEnforcer thread did not stop within timeout"
                )
            else:
                self._thread = None
        logger.info("TimeConstraintEnforcer stopped")

    def _loop(self) -> None:
        """Main loop that periodically checks time constraints."""
        while not self._stop_event.is_set():
            try:
                self._check_constraints()
            except Exception as e:
                logger.error(f"Error checking time constraints: {e}", exc_info=True)
            # Use Event.wait() for interruptible sleep
            self._stop_event.wait(self.check_interval)

    def _check_constraints(self) -> None:
        """Check all time-constrained rules and handle transitions.

        For each rule with a time_constraint:
        - If it was active but is now inactive, delete associated flows
        - Update the tracked state for next check
        """
        # Track current rule keys to avoid double iteration in cleanup
        current_keys: set[tuple[str, str]] = set()

        # Check block rules
        for rule in self.policy_cache.get_all_block_rules():
            if not rule.time_constraint:
                continue

            key = ("block", rule.app_name)
            current_keys.add(key)
            is_active = _time_constraint_active(rule.time_constraint)
            was_active = self._rule_state.get(key, True)  # Assume active if new

            if was_active and not is_active:
                logger.info(f"Time constraint expired for block rule: {rule.app_name}")
                self._delete_flows_for_app(rule.app_name, "block")

            self._rule_state[key] = is_active

        # Check rate limit rules
        for rule in self.policy_cache.get_all_rate_limits():
            if not rule.time_constraint:
                continue

            key = ("ratelimit", rule.app_name)
            current_keys.add(key)
            is_active = _time_constraint_active(rule.time_constraint)
            was_active = self._rule_state.get(key, True)  # Assume active if new

            if was_active and not is_active:
                logger.info(
                    f"Time constraint expired for rate limit rule: {rule.app_name}"
                )
                self._delete_flows_for_app(rule.app_name, "ratelimit")

            self._rule_state[key] = is_active

        # Clean up tracked state for rules that no longer exist
        self._cleanup_stale_state(current_keys)

    def _delete_flows_for_app(self, app_name: str, rule_type: str) -> None:
        """Delete OVS flows associated with an application.

        This uses ovs-ofctl del-flows to remove flows that were installed
        for this application. Since flows don't directly encode the app name,
        we use a broader approach: delete by cookie pattern if available,
        or log a warning for manual cleanup.

        Note: For most accurate cleanup, flows should be tracked by cookie
        which encodes the classification_id (hash of normalized app name).

        Args:
            app_name: Application name (e.g., "Instagram")
            rule_type: Type of rule ("block" or "ratelimit")
        """
        if not self.bridge:
            logger.warning("No bridge configured, cannot delete flows")
            return

        # Calculate classification_id using shared utility function
        # This ensures consistency with generate_flow_cookie in classifier.py
        classification_id = compute_classification_id(app_name)

        # Delete flows by cookie mask (matches lower 32 bits = classification_id)
        # Cookie format: (flow_hash << 32) | classification_id
        # Mask: 0x00000000FFFFFFFF to match only classification_id
        cookie_mask = f"0x{classification_id:08x}/0x00000000FFFFFFFF"

        try:
            cmd = [
                "ovs-ofctl",
                "del-flows",
                self.bridge,
                f"cookie={cookie_mask}",
                "-OOpenflow13",
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                logger.info(
                    f"Deleted flows for {rule_type} rule '{app_name}' "
                    f"(cookie mask: {cookie_mask})"
                )
            else:
                logger.warning(
                    f"Failed to delete flows for {app_name}: {result.stderr}"
                )
        except subprocess.TimeoutExpired:
            logger.error(f"Timeout deleting flows for {app_name}")
        except FileNotFoundError:
            logger.error("ovs-ofctl not found")
        except Exception as e:
            logger.error(f"Error deleting flows for {app_name}: {e}")

    def _cleanup_stale_state(self, current_keys: set[tuple[str, str]]) -> None:
        """Remove tracked state for rules that no longer exist.

        Args:
            current_keys: Set of (rule_type, app_name) tuples for rules that
                currently exist with time constraints.
        """
        # Remove stale entries
        stale_keys = set(self._rule_state.keys()) - current_keys
        for key in stale_keys:
            del self._rule_state[key]
