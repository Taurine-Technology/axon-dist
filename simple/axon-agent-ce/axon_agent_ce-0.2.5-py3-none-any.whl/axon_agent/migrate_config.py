"""Migrate config.json from bridge_config (singular) to bridge_configs (plural).

Standalone, idempotent migration script. Safe to run multiple times.
Exits 0 on success or no-op, exits 1 on error.
"""

import json
import os
import stat
import sys
import tempfile


CONFIG_PATHS = ["/etc/axon/config.json", "./config.json"]


def _find_config() -> str:
    for path in CONFIG_PATHS:
        if os.path.exists(path):
            return path
    return ""


def migrate():
    config_path = _find_config()
    if not config_path:
        print("No config.json found, nothing to migrate.")
        return

    with open(config_path, "r") as f:
        config = json.load(f)

    changed = False

    # Migrate bridge_config -> bridge_configs if needed
    if "bridge_config" in config:
        bc = config["bridge_config"]
        if (
            bc
            and isinstance(bc, dict)
            and bc.get("bridge_name")
            and "bridge_configs" not in config
        ):
            config["bridge_configs"] = {bc["bridge_name"]: bc}
            print(f"Migrated bridge_config to bridge_configs[{bc['bridge_name']!r}]")
        # Always remove the legacy key
        del config["bridge_config"]
        changed = True

    if not changed:
        print("Config already migrated, nothing to do.")
        return

    # Atomic write: tempfile + os.replace, preserving original permissions
    config_dir = os.path.dirname(config_path) or "."
    original_mode = stat.S_IMODE(os.stat(config_path).st_mode)
    temp_fd, temp_path = tempfile.mkstemp(dir=config_dir, prefix=".config.json.tmp.")
    try:
        with os.fdopen(temp_fd, "w") as f:
            json.dump(config, f, indent=2)
        os.chmod(temp_path, original_mode)
        os.replace(temp_path, config_path)
        print(f"Saved migrated config to {config_path}")
    except Exception:
        try:
            os.unlink(temp_path)
        except OSError:
            pass
        raise


def main():
    try:
        migrate()
    except Exception as e:
        print(f"Migration failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
