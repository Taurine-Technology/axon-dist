"""Uptime Monitoring Agent - responds to heartbeat and ping requests via MQTT.

This agent subscribes to uptime check request topics, handles heartbeat requests
(immediate response), and performs ICMP ping operations for endpoint monitoring.

Run as standalone:
    python -m axon_agent.uptime_monitoring.agent
"""

import logging
import os
import subprocess
import sys
import time
from typing import Optional, Tuple

import psutil

from .. import __version__
from ..base_agent import BaseAgent
from ..utils import stop_systemd_service, disable_systemd_service
from axon_shared.proto.uptime_check_messages_pb2 import (
    AgentHeartbeatRequest,
    AgentHeartbeatResponse,
    EndpointPingRequest,
    EndpointPingResponse,
    UptimeStatus,
)
from axon_shared.mqtt.topics import control_topic, UPTIME_CHECK_HEARTBEAT, UPTIME_CHECK_REQUEST, UPTIME_CHECK_RESPONSE

logger = logging.getLogger(__name__)

# Agent version
AGENT_VERSION = __version__


class UptimeMonitoringAgent(BaseAgent):
    """Agent that handles uptime monitoring requests via MQTT."""

    agent_name = "Uptime Monitoring Agent"
    mqtt_client_id_suffix = "uptime"
    config_fail_exit_code = 1
    log_name = "uptime_monitoring_agent"
    connection_wait_timeout = 10.0
    use_counted_retries = True

    def __init__(self):
        """Initialize Uptime Monitoring Agent."""
        super().__init__()

        # MQTT topic patterns
        self.heartbeat_topic_pattern: Optional[str] = None
        self.ping_topic_pattern: Optional[str] = None

    def _load_service_config(self, config: dict) -> bool:
        """Load service-specific configuration from the device config dict.

        Builds MQTT topic patterns for heartbeat and ping requests.

        Args:
            config: Full config.json dictionary

        Returns:
            True if service config loaded successfully, False otherwise
        """
        # Build MQTT topic patterns
        # Subscribe to: axon/control/{site_id}/{device_id}/uptime_check/heartbeat
        self.heartbeat_topic_pattern = control_topic(self.site_id, self.device_id, UPTIME_CHECK_HEARTBEAT)
        # Subscribe to: axon/control/{site_id}/{device_id}/uptime_check/request
        self.ping_topic_pattern = control_topic(self.site_id, self.device_id, UPTIME_CHECK_REQUEST)

        return True

    def _on_reconnect(self):
        """Restore subscriptions on MQTT reconnection."""
        self._subscribe_to_topics()

    def _setup(self):
        """Subscribe to uptime check request topics after initial connection."""
        self._subscribe_to_topics()

    def _run_loop(self):
        """Main agent loop - wait for incoming requests."""
        while self.running:
            time.sleep(1)

    def _ping_host(
        self, target_ip: str, timeout: int, count: int = 1
    ) -> Tuple[bool, int, str, int, int]:
        """Ping a host and return results.

        Args:
            target_ip: IP address to ping
            timeout: Timeout in seconds
            count: Number of ping packets to send

        Returns:
            Tuple of (success, response_time_ms, error_message, successful_pings, failed_pings)
        """
        successful_pings = 0
        failed_pings = 0
        total_response_time = 0
        error_message = ""

        for i in range(count):
            try:
                start_time = time.time()
                result = subprocess.run(
                    ["ping", "-c", "1", "-W", str(timeout), target_ip],
                    capture_output=True,
                    timeout=timeout + 1,
                )
                elapsed_ms = int((time.time() - start_time) * 1000)

                if result.returncode == 0:
                    successful_pings += 1
                    total_response_time += elapsed_ms
                else:
                    failed_pings += 1
                    stderr = result.stderr.decode("utf-8", errors="replace")
                    if not error_message:
                        error_message = f"Ping failed: {stderr}"
            except subprocess.TimeoutExpired:
                failed_pings += 1
                if not error_message:
                    error_message = "Ping timeout"
            except Exception as e:
                failed_pings += 1
                if not error_message:
                    error_message = f"Ping error: {str(e)}"

        # Calculate average response time if we have successful pings
        if successful_pings > 0:
            response_time_ms = total_response_time // successful_pings
            success = True
        else:
            response_time_ms = 0
            success = False

        return success, response_time_ms, error_message, successful_pings, failed_pings

    def _publish_heartbeat_response(self, request: AgentHeartbeatRequest) -> bool:
        """Publish a heartbeat response to MQTT.

        Args:
            request: Original AgentHeartbeatRequest

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish response")
            return False

        # Build response
        response = AgentHeartbeatResponse()
        response.request_id = request.request_id
        response.timestamp_ms = int(time.time() * 1000)
        response.device_id = self.device_id or ""
        response.site_id = self.site_id or ""
        response.status = UptimeStatus.UPTIME_STATUS_UP
        response.agent_version = AGENT_VERSION

        # Build response topic
        response_topic = (
            control_topic(self.site_id, self.device_id, UPTIME_CHECK_RESPONSE)
        )

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published heartbeat response: request_id={request.request_id}, "
                f"status=UPTIME_STATUS_UP, agent_version={AGENT_VERSION}"
            )
        else:
            logger.error(f"Failed to publish heartbeat response to {response_topic}")

        return result

    def _publish_ping_response(self, request: EndpointPingRequest) -> bool:
        """Publish a ping response to MQTT.

        Args:
            request: Original EndpointPingRequest

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish response")
            return False

        target_ip = request.target_ip
        timeout = request.timeout_seconds if request.timeout_seconds > 0 else 5
        count = request.count if request.count > 0 else 1

        # Perform ICMP ping
        logger.info(
            f"Pinging {target_ip} (timeout={timeout}s, count={count}) for request_id={request.request_id}"
        )
        success, response_time_ms, error_message, successful_pings, failed_pings = (
            self._ping_host(target_ip, timeout, count)
        )

        # Build response
        response = EndpointPingResponse()
        response.request_id = request.request_id
        response.timestamp_ms = int(time.time() * 1000)
        response.device_id = self.device_id or ""
        response.site_id = self.site_id or ""
        response.target_ip = target_ip
        response.status = (
            UptimeStatus.UPTIME_STATUS_UP
            if success
            else UptimeStatus.UPTIME_STATUS_DOWN
        )
        response.response_time_ms = response_time_ms if success else 0
        response.error_message = error_message
        response.successful_pings = successful_pings
        response.failed_pings = failed_pings

        # Build response topic
        response_topic = (
            control_topic(self.site_id, self.device_id, UPTIME_CHECK_RESPONSE)
        )

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published ping response: request_id={request.request_id}, "
                f"target={target_ip}, status={'UP' if success else 'DOWN'}, "
                f"response_time={response_time_ms}ms, "
                f"successful={successful_pings}, failed={failed_pings}"
            )
        else:
            logger.error(f"Failed to publish ping response to {response_topic}")

        return result

    def _handle_heartbeat_request(self, topic: str, payload: bytes):
        """Handle incoming heartbeat request from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received heartbeat request on topic: {topic}")

        try:
            # Parse the protobuf request
            request = AgentHeartbeatRequest()
            request.ParseFromString(payload)

            logger.info(
                f"Heartbeat request: request_id={request.request_id}, "
                f"device_id={request.device_id}, site_id={request.site_id}"
            )

            # Validate request (optional - device_id/site_id in request for verification)
            if request.device_id and request.device_id != self.device_id:
                logger.warning(
                    f"Request device_id mismatch: {request.device_id} != {self.device_id}"
                )

            # Immediately respond with UP status
            self._publish_heartbeat_response(request)

        except Exception as e:
            logger.error(f"Error handling heartbeat request: {e}", exc_info=True)
            # Try to send error response (though heartbeat should always succeed)
            try:
                error_request = AgentHeartbeatRequest()
                try:
                    error_request.ParseFromString(payload)
                except Exception:
                    error_request.request_id = "unknown"

                # For heartbeat, we still respond with UP even on parse errors
                # (the agent is clearly running if we received the message)
                self._publish_heartbeat_response(error_request)
            except Exception as publish_error:
                logger.error(f"Failed to publish heartbeat response: {publish_error}")

    def _handle_ping_request(self, topic: str, payload: bytes):
        """Handle incoming ping request from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received ping request on topic: {topic}")

        try:
            # Parse the protobuf request
            request = EndpointPingRequest()
            request.ParseFromString(payload)

            logger.info(
                f"Ping request: request_id={request.request_id}, "
                f"target_ip={request.target_ip}, "
                f"timeout={request.timeout_seconds}s, count={request.count}"
            )

            # Validate request
            if not request.target_ip:
                logger.error("Ping request missing target_ip")
                return

            if request.device_id and request.device_id != self.device_id:
                logger.warning(
                    f"Request device_id mismatch: {request.device_id} != {self.device_id}"
                )

            # Perform ping and publish response
            self._publish_ping_response(request)

        except Exception as e:
            logger.error(f"Error handling ping request: {e}", exc_info=True)
            # Try to send error response
            try:
                error_request = EndpointPingRequest()
                try:
                    error_request.ParseFromString(payload)
                except Exception:
                    error_request.request_id = "unknown"
                    error_request.target_ip = "unknown"

                # Build error response
                response = EndpointPingResponse()
                response.request_id = error_request.request_id
                response.timestamp_ms = int(time.time() * 1000)
                response.device_id = self.device_id or ""
                response.site_id = self.site_id or ""
                response.target_ip = error_request.target_ip
                response.status = UptimeStatus.UPTIME_STATUS_DOWN
                response.response_time_ms = 0
                response.error_message = f"Error processing request: {str(e)}"
                response.successful_pings = 0
                response.failed_pings = 1

                response_topic = control_topic(self.site_id, self.device_id, UPTIME_CHECK_RESPONSE)
                payload_bytes = response.SerializeToString()
                self.mqtt_client.publish_raw(response_topic, payload_bytes, qos=2)
            except Exception as publish_error:
                logger.error(f"Failed to publish error response: {publish_error}")

    def _subscribe_to_topics(self):
        """Subscribe to uptime check request topics.

        This method is called on initial connection and on reconnection
        to ensure subscriptions are always active.
        """
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(
            f"Subscribing to uptime check topics: {self.heartbeat_topic_pattern}, "
            f"{self.ping_topic_pattern}"
        )

        try:
            # Subscribe to heartbeat topic
            self.mqtt_client.subscribe_raw(
                self.heartbeat_topic_pattern, self._handle_heartbeat_request, qos=2
            )
            logger.info(
                f"Successfully subscribed to heartbeat topic: {self.heartbeat_topic_pattern}"
            )

            # Subscribe to ping topic
            self.mqtt_client.subscribe_raw(
                self.ping_topic_pattern, self._handle_ping_request, qos=2
            )
            logger.info(
                f"Successfully subscribed to ping topic: {self.ping_topic_pattern}"
            )
        except Exception as e:
            logger.error(
                f"Failed to subscribe to uptime check topics: {e}", exc_info=True
            )


def start_uptime_monitoring_agent_process() -> Optional[subprocess.Popen]:
    """Start the Uptime Monitoring Agent as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if already running
    if _is_uptime_monitoring_agent_running():
        logger.info("Uptime Monitoring Agent is already running")
        return None

    try:
        python_executable = sys.executable
        module_path = "axon_agent.uptime_monitoring.agent"

        logger.info("Starting Uptime Monitoring Agent process...")

        # Start process in background
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Give it a moment to start
        time.sleep(0.5)

        if process.poll() is None:
            logger.info(f"Uptime Monitoring Agent process started (PID: {process.pid})")
            return process
        else:
            logger.error("Uptime Monitoring Agent process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start Uptime Monitoring Agent process: {e}")
        return None


def _is_uptime_monitoring_agent_running() -> bool:
    """Check if Uptime Monitoring Agent is already running.

    Returns:
        True if running, False otherwise
    """
    try:
        # Check if running as systemd service
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "--quiet", "axon-agent-uptime.service"],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            pass

        current_pid = os.getpid()

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.uptime_monitoring.agent" in cmdline_str:
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for Uptime Monitoring Agent process: {e}")
        return False


def stop_uptime_monitoring_agent() -> bool:
    """Stop Uptime Monitoring Agent service/process.

    Returns:
        True if stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    service_name = "axon-agent-uptime.service"
    # Try to stop systemd service first
    try:
        if stop_systemd_service(service_name):
            logger.info("Stopped Uptime Monitoring Agent systemd service")
            # Try to disable, but consider stop successful regardless
            try:
                if disable_systemd_service(service_name):
                    logger.info("Disabled Uptime Monitoring Agent systemd service")
            except Exception as e:
                logger.warning(f"Failed to disable systemd service: {e}")
            return True
    except Exception as e:
        logger.warning(f"Failed to stop Uptime Monitoring Agent systemd service: {e}")
    # Fallback: stop subprocess
    try:
        current_pid = os.getpid()
        stopped_any = False

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.uptime_monitoring.agent" in cmdline_str:
                        if proc.is_running():
                            logger.info(
                                f"Stopping Uptime Monitoring Agent process (PID: {proc.pid})"
                            )
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                            except psutil.TimeoutExpired:
                                proc.kill()
                                proc.wait()
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return stopped_any
    except Exception as e:
        logger.error(f"Error stopping Uptime Monitoring Agent process: {e}")
        return False


def main():
    """Main entry point for Uptime Monitoring Agent."""
    agent = UptimeMonitoringAgent()
    agent.run()


if __name__ == "__main__":
    main()
