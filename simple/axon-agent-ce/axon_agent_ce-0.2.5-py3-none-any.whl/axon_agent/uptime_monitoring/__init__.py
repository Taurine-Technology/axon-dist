"""Uptime monitoring agent for Axon Agent."""

__all__ = [
    "UptimeMonitoringAgent",
    "start_uptime_monitoring_agent_process",
]


def __getattr__(name: str):
    """Lazy import to avoid RuntimeWarning when running agent as script."""
    if name == "UptimeMonitoringAgent":
        from .agent import UptimeMonitoringAgent

        return UptimeMonitoringAgent
    elif name == "start_uptime_monitoring_agent_process":
        from .agent import start_uptime_monitoring_agent_process

        return start_uptime_monitoring_agent_process
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
