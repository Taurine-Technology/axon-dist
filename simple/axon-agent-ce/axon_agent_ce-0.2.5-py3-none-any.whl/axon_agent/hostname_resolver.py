"""Passive hostname discovery via DHCP snooping and mDNS listening.

This module provides client device hostname resolution by passively observing
DHCP and mDNS traffic on an OVS bridge interface. It maintains a thread-safe
MAC-to-hostname cache that is persisted to disk for use by other agent services.

Discovery methods:
    - DHCP Option 12: Extracted from DHCP DISCOVER/REQUEST packets (~85% coverage)
    - mDNS: Extracted from multicast DNS response/announcement records (~10-15% more)

The resolver runs as a daemon thread within the classifier or sniffer agent and
writes to a shared cache file at /var/lib/axon/hostname_cache.json. Flow stats
monitors read this cache file to enrich flow data with client hostnames.

Usage:
    # In the classifier or sniffer agent:
    resolver = HostnameResolver(interface="br-access")
    resolver.start()
    hostname = resolver.lookup("aa:bb:cc:dd:ee:ff")
    resolver.stop()

    # In flow stats monitors (read-only):
    cache = HostnameCache.load_from_file()
    hostname = cache.get("aa:bb:cc:dd:ee:ff")
"""

import json
import logging
import os
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

import dpkt

from .port_utils import _validate_interface_name

logger = logging.getLogger(__name__)

# Cache file location (shared across all agent services)
HOSTNAME_CACHE_PATH = "/var/lib/axon/hostname_cache.json"
HOSTNAME_CACHE_DIR = "/var/lib/axon"

# Cache entry TTL (24 hours) - devices re-announce via DHCP lease renewals
HOSTNAME_CACHE_TTL = 86400

# How often to save the cache to disk (seconds)
CACHE_SAVE_INTERVAL = 30

# BPF filter for DHCP (ports 67/68) and mDNS (port 5353)
BPF_FILTER = "udp port 67 or udp port 68 or udp port 5353"

# DHCP option codes
DHCP_OPTION_HOSTNAME = 12
DHCP_OPTION_END = 255
DHCP_OPTION_PAD = 0

# DHCP message types (option 53)
DHCP_DISCOVER = 1
DHCP_REQUEST = 3
DHCP_OPTION_MESSAGE_TYPE = 53

# DHCP magic cookie
DHCP_MAGIC_COOKIE = b'\x63\x82\x53\x63'


@dataclass
class HostnameEntry:
    """A cached hostname entry."""

    hostname: str
    source: str  # "dhcp" or "mdns"
    last_seen: float = field(default_factory=time.time)

    def is_expired(self, ttl: float = HOSTNAME_CACHE_TTL) -> bool:
        return (time.time() - self.last_seen) > ttl

    def to_dict(self) -> dict:
        return {
            "hostname": self.hostname,
            "source": self.source,
            "last_seen": self.last_seen,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "HostnameEntry":
        return cls(
            hostname=data["hostname"],
            source=data.get("source", "unknown"),
            last_seen=data.get("last_seen", 0.0),
        )


class HostnameCache:
    """Thread-safe MAC-to-hostname cache with disk persistence.

    Used by the HostnameResolver to store discovered hostnames, and by
    flow stats monitors to look up hostnames for MAC addresses.
    """

    def __init__(self, cache_path: str = HOSTNAME_CACHE_PATH):
        self._cache: Dict[str, HostnameEntry] = {}
        self._lock = threading.Lock()
        self._cache_path = cache_path
        self._dirty = False
        self._load_from_disk()

    def _load_from_disk(self):
        """Load cache from disk if available."""
        try:
            if os.path.exists(self._cache_path):
                with open(self._cache_path, "r") as f:
                    data = json.load(f)
                with self._lock:
                    for mac, entry_data in data.items():
                        entry = HostnameEntry.from_dict(entry_data)
                        if not entry.is_expired():
                            self._cache[mac.lower()] = entry
                logger.debug(
                    f"Loaded {len(self._cache)} hostname entries from cache"
                )
        except Exception as e:
            logger.warning(f"Failed to load hostname cache: {e}")

    def save_to_disk(self):
        """Save cache to disk."""
        with self._lock:
            if not self._dirty:
                return
            data = {
                mac: entry.to_dict()
                for mac, entry in self._cache.items()
                if not entry.is_expired()
            }

        try:
            os.makedirs(os.path.dirname(self._cache_path), exist_ok=True)
            # Write atomically via temp file
            tmp_path = self._cache_path + ".tmp"
            with open(tmp_path, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp_path, self._cache_path)
            with self._lock:
                self._dirty = False
        except Exception as e:
            logger.warning(f"Failed to save hostname cache: {e}")

    def put(self, mac: str, hostname: str, source: str):
        """Add or update a hostname entry.

        Args:
            mac: MAC address (will be normalized to lowercase)
            hostname: Device hostname
            source: Discovery source ("dhcp" or "mdns")
        """
        mac = mac.lower()
        # Strip .local suffix from mDNS hostnames
        if hostname.endswith(".local"):
            hostname = hostname[:-6]

        with self._lock:
            existing = self._cache.get(mac)
            # DHCP is more authoritative than mDNS
            if existing and existing.source == "dhcp" and source == "mdns":
                # Just update last_seen, keep DHCP hostname
                existing.last_seen = time.time()
            else:
                self._cache[mac] = HostnameEntry(
                    hostname=hostname,
                    source=source,
                    last_seen=time.time(),
                )
            self._dirty = True

        logger.debug(f"Hostname cache: {mac} -> {hostname} (via {source})")

    def get(self, mac: str) -> str:
        """Look up hostname for a MAC address.

        Args:
            mac: MAC address (case-insensitive)

        Returns:
            Hostname string, or empty string if not found/expired
        """
        mac = mac.lower()
        with self._lock:
            entry = self._cache.get(mac)
            if entry and not entry.is_expired():
                return entry.hostname
        return ""

    def size(self) -> int:
        """Return the number of entries in the cache."""
        with self._lock:
            return len(self._cache)

    @classmethod
    def load_from_file(
        cls, cache_path: str = HOSTNAME_CACHE_PATH
    ) -> "HostnameCache":
        """Load a read-only cache from disk.

        This is used by flow stats monitors that only need to read
        the hostname cache without writing to it.

        Returns:
            HostnameCache loaded from disk
        """
        return cls(cache_path=cache_path)


def _normalize_mac(raw_mac: bytes) -> str:
    """Convert raw 6-byte MAC to colon-separated lowercase string."""
    return ":".join(f"{b:02x}" for b in raw_mac)


def _parse_dhcp_hostname(udp_payload: bytes) -> Optional[tuple]:
    """Parse DHCP packet to extract client MAC and hostname (Option 12).

    Args:
        udp_payload: Raw UDP payload bytes (DHCP message)

    Returns:
        Tuple of (mac_address, hostname) or None if not a valid DHCP
        packet with hostname option
    """
    # Minimum DHCP packet size: 236 bytes header + 4 bytes magic cookie
    if len(udp_payload) < 240:
        return None

    try:
        # DHCP header fields
        op = udp_payload[0]

        # Only process BOOTREQUEST (client -> server, op=1)
        if op != 1:
            return None

        htype = udp_payload[1]
        hlen = udp_payload[2]

        # Only handle Ethernet (htype=1, hlen=6)
        if htype != 1 or hlen != 6:
            return None

        # Client hardware address at offset 28, 6 bytes for Ethernet
        client_mac_bytes = udp_payload[28:34]
        client_mac = _normalize_mac(client_mac_bytes)

        # Magic cookie at offset 236
        if udp_payload[236:240] != DHCP_MAGIC_COOKIE:
            return None

        # Parse options starting at offset 240
        hostname = _extract_dhcp_option(udp_payload[240:], DHCP_OPTION_HOSTNAME)
        if hostname:
            return (client_mac, hostname)

    except (IndexError, struct.error):
        pass

    return None


def _extract_dhcp_option(options_data: bytes, target_option: int) -> Optional[str]:
    """Extract a specific DHCP option value from options data.

    Args:
        options_data: Raw bytes of DHCP options (after magic cookie)
        target_option: Option code to find

    Returns:
        Option value as string, or None if not found
    """
    i = 0
    while i < len(options_data):
        option_code = options_data[i]
        i += 1

        if option_code == DHCP_OPTION_PAD:
            continue
        if option_code == DHCP_OPTION_END:
            break

        if i >= len(options_data):
            break
        option_len = options_data[i]
        i += 1

        if i + option_len > len(options_data):
            break

        if option_code == target_option:
            try:
                return options_data[i:i + option_len].decode("utf-8", errors="ignore").strip()
            except Exception:
                return None

        i += option_len

    return None


def _parse_mdns_hostname(dns_data: bytes, src_mac: str) -> Optional[tuple]:
    """Parse mDNS packet to extract hostname from response records.

    Looks for A/AAAA records in answers/authority/additional sections
    that contain .local hostnames.

    Args:
        dns_data: Raw DNS message bytes
        src_mac: Source MAC address of the packet

    Returns:
        Tuple of (mac_address, hostname) or None
    """
    try:
        dns = dpkt.dns.DNS(dns_data)
    except (dpkt.UnpackError, Exception):
        return None

    # Only process responses (QR=1) or announcements
    # mDNS announcements can be either queries with answers or responses
    hostname = None

    # Check answers, authority, and additional sections
    for rr in list(dns.an) + list(dns.ns) + list(dns.ar):
        # Look for A (1) or AAAA (28) records with .local names
        if rr.type in (dpkt.dns.DNS_A, dpkt.dns.DNS_AAAA):
            name = rr.name
            if name and ".local" in name.lower():
                # Extract hostname (part before .local)
                parts = name.lower().split(".")
                if len(parts) >= 2 and parts[-1] == "local":
                    hostname = ".".join(parts[:-1])
                    break

    # Also check PTR records for device names
    if not hostname:
        for rr in list(dns.an) + list(dns.ns) + list(dns.ar):
            if rr.type == dpkt.dns.DNS_PTR:
                name = getattr(rr, "ptrname", "") or ""
                if name and ".local" in name.lower():
                    parts = name.lower().split(".")
                    if len(parts) >= 2 and parts[-1] == "local":
                        hostname = ".".join(parts[:-1])
                        break

    if hostname:
        return (src_mac, hostname)

    return None


class HostnameResolver:
    """Passive hostname discovery using DHCP snooping and mDNS listening.

    Runs a BPF-filtered packet capture on the bridge interface in a daemon
    thread, parsing DHCP and mDNS packets to discover client device hostnames.

    The discovered hostnames are stored in a shared HostnameCache that
    persists to disk for other agent services to read.

    Args:
        interface: Network interface to capture on (e.g., "br-access")
        cache_path: Path to the hostname cache file
    """

    def __init__(
        self,
        interface: str,
        cache_path: str = HOSTNAME_CACHE_PATH,
    ):
        if not _validate_interface_name(interface):
            raise ValueError(f"Invalid interface name: {interface}")
        self.interface = interface
        self.cache = HostnameCache(cache_path=cache_path)
        self._running = False
        self._capture_thread: Optional[threading.Thread] = None
        self._save_thread: Optional[threading.Thread] = None

    def start(self):
        """Start the hostname resolver capture thread."""
        if self._running:
            return

        self._running = True

        self._capture_thread = threading.Thread(
            target=self._capture_loop,
            daemon=True,
            name="hostname-resolver",
        )
        self._capture_thread.start()

        self._save_thread = threading.Thread(
            target=self._periodic_save,
            daemon=True,
            name="hostname-cache-saver",
        )
        self._save_thread.start()

        logger.info(
            f"Hostname resolver started on interface {self.interface}"
        )

    def stop(self):
        """Stop the hostname resolver."""
        self._running = False
        # Save final state
        self.cache.save_to_disk()
        logger.info(
            f"Hostname resolver stopped "
            f"({self.cache.size()} entries cached)"
        )

    def lookup(self, mac: str) -> str:
        """Look up hostname for a MAC address.

        Args:
            mac: MAC address (case-insensitive)

        Returns:
            Hostname string, or empty string if unknown
        """
        return self.cache.get(mac)

    def _capture_loop(self):
        """Main capture loop - runs pcapy with BPF filter for DHCP + mDNS."""
        backoff = 2
        max_backoff = 60

        while self._running:
            try:
                cap = None
                try:
                    import pcapy
                    cap = pcapy.open_live(
                        self.interface,
                        1500,   # snaplen - DHCP/mDNS packets are small
                        True,   # promiscuous
                        1000,   # timeout ms
                    )
                    cap.setfilter(BPF_FILTER)
                except ImportError:
                    logger.error(
                        "pcapy not available for hostname resolver"
                    )
                    return
                except Exception as e:
                    logger.warning(
                        f"Hostname resolver: interface {self.interface} "
                        f"not available, retrying in {backoff}s: {e}"
                    )
                    time.sleep(backoff)
                    backoff = min(backoff * 2, max_backoff)
                    continue

                # Reset backoff on successful capture open
                backoff = 2
                logger.info(
                    f"Hostname resolver capturing on {self.interface}"
                )

                while self._running:
                    try:
                        header, data = cap.next()
                        if header is not None and data:
                            self._process_packet(data)
                    except Exception as e:
                        err_str = str(e).lower()
                        if "timeout" in err_str:
                            continue
                        logger.debug(
                            f"Hostname resolver packet error: {e}"
                        )

            except Exception as e:
                if self._running:
                    logger.warning(
                        f"Hostname resolver error, restarting "
                        f"in {backoff}s: {e}"
                    )
                    time.sleep(backoff)
                    backoff = min(backoff * 2, max_backoff)

    def _process_packet(self, raw_packet: bytes):
        """Process a captured packet, extracting hostname if present.

        Args:
            raw_packet: Raw Ethernet frame bytes
        """
        try:
            eth = dpkt.ethernet.Ethernet(raw_packet)
        except (dpkt.UnpackError, Exception):
            return

        # Extract source MAC from Ethernet header
        src_mac = _normalize_mac(eth.src)

        # Must be IP
        if not isinstance(eth.data, dpkt.ip.IP):
            return

        ip_pkt = eth.data

        # Must be UDP
        if not isinstance(ip_pkt.data, dpkt.udp.UDP):
            return

        udp_pkt = ip_pkt.data
        udp_payload = bytes(udp_pkt.data)

        if not udp_payload:
            return

        # DHCP: destination port 67 (server) or source port 68 (client)
        if udp_pkt.dport == 67 or udp_pkt.sport == 68:
            result = _parse_dhcp_hostname(udp_payload)
            if result:
                mac, hostname = result
                if hostname:
                    self.cache.put(mac, hostname, "dhcp")

        # mDNS: port 5353
        elif udp_pkt.dport == 5353 or udp_pkt.sport == 5353:
            result = _parse_mdns_hostname(udp_payload, src_mac)
            if result:
                mac, hostname = result
                if hostname:
                    self.cache.put(mac, hostname, "mdns")

    def _periodic_save(self):
        """Periodically save the cache to disk."""
        while self._running:
            time.sleep(CACHE_SAVE_INTERVAL)
            if self._running:
                self.cache.save_to_disk()
