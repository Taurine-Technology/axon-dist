"""Utility functions for network port operations."""

import logging
import re
import subprocess
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# Valid interface name pattern: alphanumeric, hyphens, underscores, dots
# Must start with alphanumeric, max 15 chars (Linux IFNAMSIZ - 1)
_VALID_INTERFACE_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,14}$")


def _validate_interface_name(interface: str) -> bool:
    """Validate that an interface name is safe and well-formed.

    Checks that the interface name:
    - Is not empty or None
    - Contains only valid characters (alphanumeric, hyphens, underscores, dots)
    - Starts with an alphanumeric character
    - Is at most 15 characters (Linux IFNAMSIZ limit)

    Args:
        interface: Name of the network interface to validate

    Returns:
        True if the interface name is valid, False otherwise
    """
    if not interface or not isinstance(interface, str):
        return False
    return bool(_VALID_INTERFACE_PATTERN.match(interface))


def get_port_link_status(interface: str) -> str:
    """Get link status for a network interface.

    Uses 'ip link show' to check if the interface is UP or DOWN.

    Args:
        interface: Name of the network interface (e.g., 'eth1').
            Must be a valid Linux interface name (alphanumeric, hyphens,
            underscores, dots; max 15 chars).

    Returns:
        'up', 'down', or 'unknown' based on the interface state.
        Returns 'unknown' if the interface name is invalid.
    """
    if not _validate_interface_name(interface):
        logger.error(f"Invalid interface name: {interface!r}")
        return "unknown"

    try:
        result = subprocess.run(
            ["ip", "link", "show", interface],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode != 0:
            logger.warning(
                f"Failed to get status for interface {interface}: {result.stderr.strip()}"
            )
            return "unknown"

        output = result.stdout

        # Check for state in the output
        # Format examples:
        # - "3: eth1: <BROADCAST,MULTICAST> ... state DOWN ..." (admin down)
        # - "3: eth1: <NO-CARRIER,BROADCAST,MULTICAST,UP> ... state DOWN ..." (up, no cable)
        # - "3: eth1: <BROADCAST,MULTICAST,UP,LOWER_UP> ... state UP ..." (up with link)
        #
        # We check for the UP flag in the angle brackets to determine if the interface
        # is administratively enabled, regardless of carrier/link state.
        if "state UP" in output:
            # Interface is up and has carrier (physical link)
            return "up"
        elif ",UP" in output or ",UP>" in output:
            # Interface is administratively up but no carrier (no physical link)
            # This is still considered "up" for our purposes since we just want
            # to ensure the interface is enabled
            return "up"
        elif "state DOWN" in output:
            # Interface is administratively down
            return "down"
        else:
            # Interface exists but state is unclear
            logger.debug(f"Could not determine state for {interface} from: {output}")
            return "unknown"

    except subprocess.TimeoutExpired:
        logger.error(f"Timeout getting status for interface {interface}")
        return "unknown"
    except FileNotFoundError:
        logger.error("'ip' command not found")
        return "unknown"
    except Exception as e:
        logger.error(f"Error getting status for interface {interface}: {e}")
        return "unknown"


def bring_port_up(interface: str) -> bool:
    """Bring a network interface up.

    Uses 'ip link set <interface> up' to bring the interface up.

    Note:
        This command requires root/sudo privileges to execute successfully.
        When running as a non-root user, the command will fail with a
        permission error.

    Args:
        interface: Name of the network interface (e.g., 'eth1').
            Must be a valid Linux interface name (alphanumeric, hyphens,
            underscores, dots; max 15 chars).

    Returns:
        True if the interface was successfully brought up, False otherwise.
        Returns False if the interface name is invalid or if the process
        lacks sufficient privileges.
    """
    if not _validate_interface_name(interface):
        logger.error(f"Invalid interface name: {interface!r}")
        return False

    try:
        cmd = ["ip", "link", "set", interface, "up"]
        logger.debug(f"Running command: {' '.join(cmd)}")
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            logger.info(f"Successfully brought interface {interface} up")
            # Log any output for debugging
            if result.stdout.strip():
                logger.debug(f"stdout: {result.stdout.strip()}")
            if result.stderr.strip():
                logger.debug(f"stderr: {result.stderr.strip()}")
            return True
        else:
            logger.error(
                f"Failed to bring interface {interface} up (rc={result.returncode}): "
                f"{result.stderr.strip()}"
            )
            return False

    except subprocess.TimeoutExpired:
        logger.error(f"Timeout bringing interface {interface} up")
        return False
    except FileNotFoundError:
        logger.error("'ip' command not found")
        return False
    except Exception as e:
        logger.error(f"Error bringing interface {interface} up: {e}")
        return False


def get_iso_timestamp() -> str:
    """Get current timestamp in ISO 8601 format with timezone.

    Returns:
        ISO 8601 formatted timestamp string (e.g., '2025-01-15T10:00:00.123456Z')
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def get_all_port_statuses(interfaces: list) -> dict:
    """Get link status for multiple interfaces.

    Args:
        interfaces: List of interface names to check

    Returns:
        Dictionary mapping interface names to their status info:
        {
            "eth1": {"status": "up", "timestamp": "2025-01-15T10:00:00.123456Z"},
            "eth2": {"status": "down", "timestamp": "2025-01-15T10:00:00.456789Z"}
        }
    """
    statuses = {}
    for interface in interfaces:
        status = get_port_link_status(interface)
        statuses[interface] = {
            "status": status,
            "timestamp": get_iso_timestamp(),
        }
    return statuses


def bring_down_ports_up(interfaces: list) -> dict:
    """Check interfaces and bring any DOWN ports up.

    Args:
        interfaces: List of interface names to check and potentially bring up

    Returns:
        Dictionary mapping interface names that were DOWN to whether they
        were successfully brought up:
        {"eth1": True, "eth2": False}
    """
    results = {}
    for interface in interfaces:
        status = get_port_link_status(interface)
        if status == "down":
            success = bring_port_up(interface)
            results[interface] = success
    return results
