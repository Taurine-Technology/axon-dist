"""Discovery phase management."""

import logging
import threading
from typing import Callable, Optional

from . import __version__
from axon_shared.mqtt.topics import (
    DISCOVERY,
    DISCOVERY_FIELD_ENROLLMENT_SECRET,
    provision_topic,
)

logger = logging.getLogger(__name__)


class DiscoveryManager:
    """Manages device discovery phase."""

    def __init__(
        self,
        mqtt_client,
        mac_address: str,
        hardware_info: dict,
        axon_agent_version: Optional[str] = None,
        is_switch: bool = False,
        enrollment_secret: Optional[str] = None,
    ):
        """Initialize DiscoveryManager.

        Args:
            mqtt_client: MQTTClient instance
            mac_address: Primary MAC address (normalized)
            hardware_info: Hardware information dictionary
            axon_agent_version: Agent version string (defaults to package version)
            is_switch: Whether device is a switch (default: False)
            enrollment_secret: Optional enrollment secret for auto-adoption (EE)
        """
        self.mqtt_client = mqtt_client
        self.mac_address = mac_address
        self.hardware_info = hardware_info
        self.axon_agent_version = axon_agent_version or f"v{__version__}"
        self.is_switch = is_switch
        self.enrollment_secret = enrollment_secret
        self.provisioning_topic = provision_topic(mac_address)
        self._provisioning_received = None
        self._provisioning_lock = threading.Lock()
        self._provisioning_event = threading.Event()

    def publish_discovery(self) -> bool:
        """Publish discovery message to axon/discovery topic.

        Returns:
            True if publish was successful, False otherwise
        """
        payload = {
            "unique_id": self.mac_address,
            "status": "unclaimed",
            "is_switch": self.is_switch,
            "axon_agent_version": self.axon_agent_version,
            "hardware_info": self.hardware_info,
        }

        if self.enrollment_secret:
            payload[DISCOVERY_FIELD_ENROLLMENT_SECRET] = self.enrollment_secret

        topic = DISCOVERY
        success = self.mqtt_client.publish(topic, payload, qos=2)

        if success:
            logger.info(f"Published discovery message for {self.mac_address}")
        else:
            logger.error("Failed to publish discovery message")

        return success

    def subscribe_to_provisioning(self, callback: Callable) -> None:
        """Subscribe to provisioning topic.

        Args:
            callback: Callback function(topic, payload) to call when provisioning message received
        """

        def provisioning_callback(topic: str, payload: dict):
            """Handle provisioning message."""
            logger.info(f"Received provisioning message on {topic}")
            with self._provisioning_lock:
                self._provisioning_received = payload
            self._provisioning_event.set()
            # Also call user callback
            callback(topic, payload)

        self.mqtt_client.subscribe(
            self.provisioning_topic, provisioning_callback, qos=2
        )
        logger.info(f"Subscribed to provisioning topic: {self.provisioning_topic}")

    def wait_for_provisioning(self, timeout: int = 300) -> Optional[dict]:
        """Wait for provisioning message with timeout.

        Args:
            timeout: Timeout in seconds (default: 300)

        Returns:
            Provisioning message payload if received, None on timeout
        """
        logger.info(f"Waiting for provisioning message (timeout: {timeout}s)")

        if self._provisioning_event.wait(timeout=timeout):
            with self._provisioning_lock:
                return self._provisioning_received
        else:
            logger.warning(f"Timeout waiting for provisioning message after {timeout}s")
            return None
