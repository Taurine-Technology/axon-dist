"""Health Check Agent - responds to health check requests via MQTT.

This agent subscribes to health check request topics, collects the current
OVS configuration state, and publishes responses back to the controller.

Run as standalone:
    python -m axon_agent.health_check.agent
"""

import logging
import os
import subprocess
import sys
import time
from typing import Optional

import psutil

from ..base_agent import BaseAgent
from ..utils import stop_systemd_service, disable_systemd_service
from .ovs_state import (
    get_bridges,
    get_meters,
    get_all_meters,
    get_switch_uptime,
)
from axon_shared.proto.health_check_messages_pb2 import (
    HealthCheckRequest,
    HealthCheckResponse,
    HealthCheckStatus,
)
from axon_shared.mqtt.topics import control_topic, HEALTH_CHECK_REQUEST, HEALTH_CHECK_RESPONSE

logger = logging.getLogger(__name__)

# Agent version
AGENT_VERSION = "1.0.0"


class HealthCheckAgent(BaseAgent):
    """Agent that handles health check requests via MQTT."""

    agent_name = "Health Check Agent"
    mqtt_client_id_suffix = "health-check"
    config_fail_exit_code = 1
    log_name = "health_check_agent"
    connection_wait_timeout = 10.0
    use_counted_retries = True

    def __init__(self):
        """Initialize Health Check Agent."""
        super().__init__()

        # MQTT topic patterns (set during config load)
        self.request_topic_pattern: Optional[str] = None

    def _load_service_config(self, config: dict) -> bool:
        """Build the health check request topic pattern from config.

        Args:
            config: Full config.json dictionary

        Returns:
            True if service config loaded successfully, False otherwise
        """
        # Build MQTT topic pattern for health check requests
        # Subscribe to: axon/control/{site_id}/{device_id}/health_check/request
        self.request_topic_pattern = control_topic(
            self.site_id, self.device_id, HEALTH_CHECK_REQUEST
        )
        return True

    def _on_reconnect(self):
        """Restore subscriptions after MQTT reconnection."""
        self._subscribe_to_topics()

    def _setup(self):
        """Subscribe to health check topics after initial MQTT connection."""
        self._subscribe_to_topics()

    def _run_loop(self):
        """Main loop - wait for incoming health check requests."""
        logger.info(
            f"Health Check Agent running, listening on {self.request_topic_pattern}"
        )
        while self.running:
            time.sleep(1)

    def _publish_response(
        self,
        request: HealthCheckRequest,
        status: HealthCheckStatus,
        error_message: str = "",
    ) -> bool:
        """Publish a health check response to MQTT.

        Args:
            request: Original HealthCheckRequest
            status: Response status
            error_message: Error message if status is ERROR

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish response")
            return False

        # Build response
        response = HealthCheckResponse()
        response.request_id = request.request_id
        response.status = status
        response.timestamp_ms = int(time.time() * 1000)
        response.device_id = self.device_id or ""
        response.site_id = self.site_id or ""
        response.agent_version = AGENT_VERSION

        if error_message:
            response.error_message = error_message

        # Get system uptime
        uptime = get_switch_uptime()
        if uptime is not None:
            response.uptime_seconds = uptime

        # Collect requested data
        partial_errors = []

        if status != HealthCheckStatus.HEALTH_CHECK_STATUS_ERROR:
            # Collect bridge information
            if request.include_bridges:
                try:
                    if request.bridge_name:
                        # Query specific bridge
                        bridges, err = get_bridges()
                        if err:
                            partial_errors.append(f"bridges: {err}")
                        else:
                            for bridge in bridges:
                                if bridge.name == request.bridge_name:
                                    response.bridges.append(bridge)
                                    break
                    else:
                        # Query all bridges
                        bridges, err = get_bridges()
                        if err:
                            partial_errors.append(f"bridges: {err}")
                        else:
                            response.bridges.extend(bridges)
                except Exception as e:
                    partial_errors.append(f"bridges: {str(e)}")
                    logger.error(f"Error collecting bridge info: {e}", exc_info=True)

            # Collect meter information
            if request.include_meters:
                try:
                    if request.bridge_name:
                        meters, err = get_meters(request.bridge_name)
                    else:
                        meters, err = get_all_meters()

                    if err:
                        partial_errors.append(f"meters: {err}")
                    else:
                        response.meters.extend(meters)
                except Exception as e:
                    partial_errors.append(f"meters: {str(e)}")
                    logger.error(f"Error collecting meter info: {e}", exc_info=True)

            # Note: include_flows and include_ports are not currently implemented
            # The request may include these flags, but we ignore them for now

            # Update status if there were partial errors
            if partial_errors:
                response.status = HealthCheckStatus.HEALTH_CHECK_STATUS_PARTIAL
                response.partial_errors.extend(partial_errors)

        # Build response topic
        response_topic = control_topic(self.site_id, self.device_id, HEALTH_CHECK_RESPONSE)

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published health check response: request_id={request.request_id}, "
                f"status={status}, bridges={len(response.bridges)}, "
                f"meters={len(response.meters)}"
            )
        else:
            logger.error(f"Failed to publish health check response to {response_topic}")

        return result

    def _handle_health_check_request(self, topic: str, payload: bytes):
        """Handle incoming health check request from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received health check request on topic: {topic}")

        try:
            # Parse the protobuf request
            request = HealthCheckRequest()
            request.ParseFromString(payload)

            logger.info(
                f"Health check request: request_id={request.request_id}, "
                f"bridges={request.include_bridges}, meters={request.include_meters}, "
                f"bridge_name={request.bridge_name or 'all'}"
            )

            # Validate request (optional - device_id/site_id in request for verification)
            if request.device_id and request.device_id != self.device_id:
                logger.warning(
                    f"Request device_id mismatch: {request.device_id} != {self.device_id}"
                )

            # Publish response with collected data
            self._publish_response(
                request,
                HealthCheckStatus.HEALTH_CHECK_STATUS_SUCCESS,
            )

        except Exception as e:
            logger.error(f"Error handling health check request: {e}", exc_info=True)
            # Try to send error response
            try:
                error_request = HealthCheckRequest()
                try:
                    error_request.ParseFromString(payload)
                except Exception:
                    error_request.request_id = "unknown"

                self._publish_response(
                    error_request,
                    HealthCheckStatus.HEALTH_CHECK_STATUS_ERROR,
                    f"Error processing request: {str(e)}",
                )
            except Exception as publish_error:
                logger.error(f"Failed to publish error response: {publish_error}")

    def _subscribe_to_topics(self):
        """Subscribe to health check request topics.

        This method is called on initial connection and on reconnection
        to ensure subscriptions are always active.
        """
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(f"Subscribing to health check topic: {self.request_topic_pattern}")

        try:
            self.mqtt_client.subscribe_raw(
                self.request_topic_pattern, self._handle_health_check_request, qos=2
            )
            logger.info(
                f"Successfully subscribed to health check topics: {self.request_topic_pattern}"
            )
        except Exception as e:
            logger.error(
                f"Failed to subscribe to health check topics: {e}", exc_info=True
            )


def start_health_check_agent_process() -> Optional[subprocess.Popen]:
    """Start the Health Check Agent as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if already running
    if _is_health_check_agent_running():
        logger.info("Health Check Agent is already running")
        return None

    try:
        python_executable = sys.executable
        module_path = "axon_agent.health_check.agent"

        logger.info("Starting Health Check Agent process...")

        # Start process in background
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Give it a moment to start
        time.sleep(0.5)

        if process.poll() is None:
            logger.info(f"Health Check Agent process started (PID: {process.pid})")
            return process
        else:
            logger.error("Health Check Agent process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start Health Check Agent process: {e}")
        return None


def _is_health_check_agent_running() -> bool:
    """Check if Health Check Agent is already running.

    Returns:
        True if running, False otherwise
    """
    try:
        # Check if running as systemd service
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "--quiet", "axon-agent-healthcheck.service"],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            pass

        current_pid = os.getpid()

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.health_check.agent" in cmdline_str:
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for Health Check Agent process: {e}")
        return False


def stop_health_check_agent() -> bool:
    """Stop Health Check Agent service/process.

    Returns:
        True if stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    service_name = "axon-agent-healthcheck.service"
    # Try to stop systemd service first
    try:
        if stop_systemd_service(service_name):
            logger.info("Stopped Health Check Agent systemd service")
            # Try to disable, but consider stop successful regardless
            try:
                if disable_systemd_service(service_name):
                    logger.info("Disabled Health Check Agent systemd service")
            except Exception as e:
                logger.warning(f"Failed to disable systemd service: {e}")
            return True
    except Exception as e:
        logger.warning(f"Failed to stop Health Check Agent systemd service: {e}")
    # Fallback: stop subprocess
    try:
        current_pid = os.getpid()
        stopped_any = False

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.health_check.agent" in cmdline_str:
                        if proc.is_running():
                            logger.info(
                                f"Stopping Health Check Agent process (PID: {proc.pid})"
                            )
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                            except psutil.TimeoutExpired:
                                proc.kill()
                                proc.wait()
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return stopped_any
    except Exception as e:
        logger.error(f"Error stopping Health Check Agent process: {e}")
        return False


def main():
    """Main entry point for Health Check Agent."""
    agent = HealthCheckAgent()
    agent.run()


if __name__ == "__main__":
    main()
