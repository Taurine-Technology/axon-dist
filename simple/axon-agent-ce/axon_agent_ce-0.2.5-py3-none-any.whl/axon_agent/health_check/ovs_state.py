"""OVS state query functions for health check.

This module provides functions to query the current state of OVS bridges,
meters, flows, and ports. These functions are used by the health check agent
to collect switch configuration for comparison with the controller's database.
"""

import logging
import re
import subprocess
from typing import Any, List, Optional, Tuple

from axon_shared.proto.health_check_messages_pb2 import (
    BridgeState,
    MeterState,
)

# Note: FlowState, PortState, FlowMatchFields, and PortLinkState are not in the current proto
# These are kept for future use but not currently used in health check responses
try:
    from axon_shared.proto.health_check_messages_pb2 import (
        FlowMatchFields,
        FlowState,
        PortLinkState,
        PortState,
    )
except ImportError:
    # These types don't exist in the current proto (only bridges and meters are implemented)
    FlowMatchFields = None
    FlowState = None
    PortLinkState = None
    PortState = None

# Type alias for port link state enum (can't use directly in Tuple type hint)
# Only used if PortLinkState is available
if PortLinkState is not None:
    PortLinkStateType = Any  # Actually PortLinkState enum value
else:
    PortLinkStateType = Any  # Fallback when not available

logger = logging.getLogger(__name__)

# Default timeout for OVS commands
OVS_COMMAND_TIMEOUT = 10


def _run_command(
    cmd: List[str], timeout: int = OVS_COMMAND_TIMEOUT
) -> Tuple[bool, str, str]:
    """Run a shell command and return result.

    Args:
        cmd: Command and arguments as list
        timeout: Command timeout in seconds

    Returns:
        Tuple of (success, stdout, stderr)
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode == 0, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out: {' '.join(cmd)}")
        return False, "", "Command timed out"
    except FileNotFoundError as e:
        logger.error(f"Command not found: {cmd[0]}")
        return False, "", str(e)
    except Exception as e:
        logger.error(f"Error running command {' '.join(cmd)}: {e}")
        return False, "", str(e)


def get_bridges() -> Tuple[List[BridgeState], Optional[str]]:
    """Get list of all OVS bridges and their configuration.

    Returns:
        Tuple of (list of BridgeState, error message if any)
    """
    bridges = []

    # Get list of bridge names
    success, stdout, stderr = _run_command(["ovs-vsctl", "list-br"])
    if not success:
        return [], f"Failed to list bridges: {stderr}"

    bridge_names = [name.strip() for name in stdout.strip().split("\n") if name.strip()]

    for bridge_name in bridge_names:
        bridge_state = BridgeState()
        bridge_state.name = bridge_name
        bridge_state.exists = True

        # Get ports for this bridge
        ports, _ = get_bridge_ports(bridge_name)
        bridge_state.ports.extend(ports)

        # Get OpenFlow version
        success, stdout, _ = _run_command(
            ["ovs-vsctl", "get", "bridge", bridge_name, "protocols"]
        )
        if success and stdout.strip():
            # Output format: ["OpenFlow13"] or ["OpenFlow10", "OpenFlow13"]
            protocols = stdout.strip().strip("[]").replace('"', "").replace("'", "")
            bridge_state.openflow_version = protocols

        # Get datapath ID
        success, stdout, _ = _run_command(
            ["ovs-vsctl", "get", "bridge", bridge_name, "datapath_id"]
        )
        if success and stdout.strip():
            bridge_state.datapath_id = stdout.strip().strip('"')

        bridges.append(bridge_state)

    return bridges, None


def get_bridge_ports(bridge_name: str) -> Tuple[List[str], Optional[str]]:
    """Get list of ports attached to a bridge.

    Args:
        bridge_name: Name of the OVS bridge

    Returns:
        Tuple of (list of port names, error message if any)
    """
    success, stdout, stderr = _run_command(["ovs-vsctl", "list-ports", bridge_name])

    if not success:
        return [], f"Failed to list ports for bridge {bridge_name}: {stderr}"

    ports = [port.strip() for port in stdout.strip().split("\n") if port.strip()]
    return ports, None


def bridge_exists(bridge_name: str) -> bool:
    """Check if a bridge exists.

    Args:
        bridge_name: Name of the OVS bridge

    Returns:
        True if bridge exists, False otherwise
    """
    success, _, _ = _run_command(["ovs-vsctl", "br-exists", bridge_name])
    return success


def get_meters(bridge_name: str) -> Tuple[List[MeterState], Optional[str]]:
    """Get list of meters configured on a bridge.

    Args:
        bridge_name: Name of the OVS bridge

    Returns:
        Tuple of (list of MeterState, error message if any)
    """
    meters = []

    # Check if bridge exists first
    if not bridge_exists(bridge_name):
        return [], f"Bridge {bridge_name} does not exist"

    success, stdout, stderr = _run_command(
        ["ovs-ofctl", "dump-meters", bridge_name, "-OOpenflow13"]
    )

    if not success:
        return [], f"Failed to dump meters for bridge {bridge_name}: {stderr}"

    # Parse meter output
    # Example output:
    # OFPST_METER_CONFIG reply (OF1.3) (xid=0x2):
    # meter=1 kbps burst bands=
    # type=drop rate=1000 burst_size=1000

    current_meter = None

    for line in stdout.split("\n"):
        line = line.strip()

        # Match meter line: meter=N flags...
        meter_match = re.match(r"meter=(\d+)\s+(.*)", line)
        if meter_match:
            if current_meter is not None:
                meters.append(current_meter)

            current_meter = MeterState()
            current_meter.bridge_name = bridge_name
            current_meter.meter_id = int(meter_match.group(1))

            # Parse flags (e.g., "kbps burst bands=")
            flags_str = meter_match.group(2)
            if "kbps" in flags_str:
                current_meter.flags.append("kbps")
            if "burst" in flags_str:
                current_meter.flags.append("burst")

            continue

        # Match band line: type=drop rate=N burst_size=N
        band_match = re.match(r"type=(\w+)\s+rate=(\d+)(?:\s+burst_size=(\d+))?", line)
        if band_match and current_meter is not None:
            current_meter.meter_type = band_match.group(1)
            current_meter.rate = int(band_match.group(2))
            if band_match.group(3):
                current_meter.burst_size = int(band_match.group(3))

    # Don't forget the last meter
    if current_meter is not None:
        meters.append(current_meter)

    return meters, None


def get_flows(
    bridge_name: str, include_stats: bool = False
) -> Tuple[List[Any], Optional[str]]:
    """Get list of flow rules on a bridge.

    Note: FlowState is not currently in the health check proto.
    This function is kept for future use but returns empty list.

    Args:
        bridge_name: Name of the OVS bridge
        include_stats: Whether to include packet/byte counts

    Returns:
        Tuple of (list of FlowState, error message if any)
    """
    if FlowState is None:
        logger.warning("FlowState not available in proto - flows not implemented yet")
        return [], None

    flows = []

    # Check if bridge exists first
    if not bridge_exists(bridge_name):
        return [], f"Bridge {bridge_name} does not exist"

    success, stdout, stderr = _run_command(
        ["ovs-ofctl", "dump-flows", bridge_name, "-OOpenflow13"]
    )

    if not success:
        return [], f"Failed to dump flows for bridge {bridge_name}: {stderr}"

    # Parse flow output
    # Example output:
    # cookie=0x2d66b79ec3d350aa, duration=123.456s, table=0, n_packets=100, n_bytes=10000,
    #   priority=100,tcp,dl_src=aa:bb:cc:dd:ee:ff actions=meter:1,NORMAL

    for line in stdout.split("\n"):
        line = line.strip()

        # Skip header lines
        if not line or line.startswith("NXST_FLOW") or line.startswith("OFPST_FLOW"):
            continue

        if FlowState is None:
            # FlowState not available, skip parsing
            continue

        flow_state = FlowState()
        flow_state.bridge_name = bridge_name

        # Parse cookie
        cookie_match = re.search(r"cookie=0x([0-9a-fA-F]+)", line)
        if cookie_match:
            flow_state.cookie = int(cookie_match.group(1), 16)

        # Parse table
        table_match = re.search(r"table=(\d+)", line)
        if table_match:
            flow_state.table_id = int(table_match.group(1))

        # Parse priority
        priority_match = re.search(r"priority=(\d+)", line)
        if priority_match:
            flow_state.priority = int(priority_match.group(1))

        # Parse timeouts
        idle_match = re.search(r"idle_timeout=(\d+)", line)
        if idle_match:
            flow_state.idle_timeout = int(idle_match.group(1))

        hard_match = re.search(r"hard_timeout=(\d+)", line)
        if hard_match:
            flow_state.hard_timeout = int(hard_match.group(1))

        # Parse stats if requested
        if include_stats:
            packets_match = re.search(r"n_packets=(\d+)", line)
            if packets_match:
                flow_state.packet_count = int(packets_match.group(1))

            bytes_match = re.search(r"n_bytes=(\d+)", line)
            if bytes_match:
                flow_state.byte_count = int(bytes_match.group(1))

        # Parse match fields
        if FlowMatchFields is None:
            # Skip match fields parsing if not available
            continue

        match_fields = FlowMatchFields()

        # Protocol
        if ",tcp," in line or line.endswith(",tcp") or " tcp " in line:
            match_fields.protocol = "tcp"
        elif ",udp," in line or line.endswith(",udp") or " udp " in line:
            match_fields.protocol = "udp"
        elif ",icmp," in line or line.endswith(",icmp") or " icmp " in line:
            match_fields.protocol = "icmp"

        # Source MAC
        src_mac_match = re.search(r"dl_src=([0-9a-fA-F:]+)", line)
        if src_mac_match:
            match_fields.src_mac = src_mac_match.group(1)

        # Destination MAC
        dst_mac_match = re.search(r"dl_dst=([0-9a-fA-F:]+)", line)
        if dst_mac_match:
            match_fields.dst_mac = dst_mac_match.group(1)

        # Source IP
        src_ip_match = re.search(r"nw_src=([0-9./]+)", line)
        if src_ip_match:
            match_fields.src_ip = src_ip_match.group(1)

        # Destination IP
        dst_ip_match = re.search(r"nw_dst=([0-9./]+)", line)
        if dst_ip_match:
            match_fields.dst_ip = dst_ip_match.group(1)

        # Source port
        tp_src_match = re.search(r"tp_src=(\d+)", line)
        if tp_src_match:
            match_fields.src_port = int(tp_src_match.group(1))

        # Destination port
        tp_dst_match = re.search(r"tp_dst=(\d+)", line)
        if tp_dst_match:
            match_fields.dst_port = int(tp_dst_match.group(1))

        # VLAN ID
        vlan_match = re.search(r"dl_vlan=(\d+)", line)
        if vlan_match:
            match_fields.vlan_id = int(vlan_match.group(1))

        # Input port
        in_port_match = re.search(r"in_port=(\w+)", line)
        if in_port_match:
            match_fields.in_port = in_port_match.group(1)

        flow_state.match_fields.CopyFrom(match_fields)

        # Parse actions
        actions_match = re.search(r"actions=(.+)$", line)
        if actions_match:
            flow_state.actions = actions_match.group(1).strip()

            # Extract meter ID from actions
            meter_action_match = re.search(r"meter:(\d+)", flow_state.actions)
            if meter_action_match:
                flow_state.meter_id = int(meter_action_match.group(1))

        # Only add flows with valid cookies (skip default flows)
        if flow_state.cookie != 0 or flow_state.priority > 0:
            flows.append(flow_state)

    return flows, None


def get_port_states(bridge_name: str) -> Tuple[List[Any], Optional[str]]:
    """Get the state of all ports on a bridge.

    Note: PortState is not currently in the health check proto.
    This function is kept for future use but returns empty list.

    Args:
        bridge_name: Name of the OVS bridge

    Returns:
        Tuple of (list of PortState, error message if any)
    """
    if PortState is None:
        logger.warning("PortState not available in proto - ports not implemented yet")
        return [], None

    port_states = []

    # Check if bridge exists first
    if not bridge_exists(bridge_name):
        return [], f"Bridge {bridge_name} does not exist"

    # Get list of ports
    ports, err = get_bridge_ports(bridge_name)
    if err:
        return [], err

    for port_name in ports:
        if PortState is None:
            # PortState not available, skip
            continue

        port_state = PortState()
        port_state.bridge_name = bridge_name
        port_state.port_name = port_name

        # Get link state using ip link show
        link_state, admin_state, mac_address = _get_interface_info(port_name)
        port_state.link_state = link_state
        port_state.admin_state = admin_state
        port_state.mac_address = mac_address

        # Get OpenFlow port number
        success, stdout, _ = _run_command(
            ["ovs-vsctl", "get", "interface", port_name, "ofport"]
        )
        if success and stdout.strip():
            try:
                port_state.ofport = int(stdout.strip())
            except ValueError:
                pass

        # Get port type
        success, stdout, _ = _run_command(
            ["ovs-vsctl", "get", "interface", port_name, "type"]
        )
        if success and stdout.strip():
            port_type = stdout.strip().strip('"')
            port_state.port_type = port_type if port_type else "system"

        port_states.append(port_state)

    return port_states, None


def _get_interface_info(interface_name: str) -> Tuple[PortLinkStateType, str, str]:
    """Get interface information using ip link show.

    Args:
        interface_name: Name of the network interface

    Returns:
        Tuple of (link_state, admin_state, mac_address)
    """
    success, stdout, _ = _run_command(["ip", "link", "show", interface_name])

    if not success:
        if PortLinkState is not None:
            return PortLinkState.PORT_LINK_STATE_UNKNOWN, "unknown", ""
        else:
            return 3, "unknown", ""  # PORT_LINK_STATE_UNKNOWN = 3

    # Parse output
    # Example: 2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 ...
    #          link/ether aa:bb:cc:dd:ee:ff brd ff:ff:ff:ff:ff:ff

    if PortLinkState is not None:
        link_state = PortLinkState.PORT_LINK_STATE_UNKNOWN
    else:
        link_state = 3  # PORT_LINK_STATE_UNKNOWN = 3
    admin_state = "unknown"
    mac_address = ""

    # Check for UP flag (admin state) and LOWER_UP (link state)
    flags_match = re.search(r"<([^>]+)>", stdout)
    if flags_match:
        flags = flags_match.group(1).split(",")

        if "UP" in flags:
            admin_state = "up"
        else:
            admin_state = "down"

        if PortLinkState is not None:
            if "LOWER_UP" in flags:
                link_state = PortLinkState.PORT_LINK_STATE_UP
            elif "NO-CARRIER" in flags or admin_state == "down":
                link_state = PortLinkState.PORT_LINK_STATE_DOWN
        else:
            # Use numeric values when PortLinkState is not available
            if "LOWER_UP" in flags:
                link_state = 1  # PORT_LINK_STATE_UP = 1
            elif "NO-CARRIER" in flags or admin_state == "down":
                link_state = 2  # PORT_LINK_STATE_DOWN = 2

    # Parse MAC address
    mac_match = re.search(r"link/ether\s+([0-9a-fA-F:]+)", stdout)
    if mac_match:
        mac_address = mac_match.group(1)

    return link_state, admin_state, mac_address


def get_switch_uptime() -> Optional[int]:
    """Get the switch/system uptime in seconds.

    Returns:
        Uptime in seconds, or None if unable to determine
    """
    try:
        with open("/proc/uptime", "r") as f:
            uptime_str = f.read().split()[0]
            return int(float(uptime_str))
    except Exception as e:
        logger.warning(f"Failed to get system uptime: {e}")
        return None


def get_all_meters() -> Tuple[List[MeterState], Optional[str]]:
    """Get all meters from all bridges.

    Returns:
        Tuple of (list of MeterState, error message if any)
    """
    all_meters = []
    errors = []

    bridges, err = get_bridges()
    if err:
        return [], err

    for bridge in bridges:
        meters, err = get_meters(bridge.name)
        if err:
            errors.append(err)
        else:
            all_meters.extend(meters)

    error_msg = "; ".join(errors) if errors else None
    return all_meters, error_msg


def get_all_flows(include_stats: bool = False) -> Tuple[List[Any], Optional[str]]:
    """Get all flows from all bridges.

    Note: FlowState is not currently in the health check proto.
    This function is kept for future use but returns empty list.

    Args:
        include_stats: Whether to include packet/byte counts

    Returns:
        Tuple of (list of FlowState, error message if any)
    """
    if FlowState is None:
        logger.warning("FlowState not available in proto - flows not implemented yet")
        return [], None

    all_flows = []
    errors = []

    bridges, err = get_bridges()
    if err:
        return [], err

    for bridge in bridges:
        flows, err = get_flows(bridge.name, include_stats)
        if err:
            errors.append(err)
        else:
            all_flows.extend(flows)

    error_msg = "; ".join(errors) if errors else None
    return all_flows, error_msg


def get_all_port_states() -> Tuple[List[Any], Optional[str]]:
    """Get port states for all bridges.

    Note: PortState is not currently in the health check proto.
    This function is kept for future use but returns empty list.

    Returns:
        Tuple of (list of PortState, error message if any)
    """
    if PortState is None:
        logger.warning("PortState not available in proto - ports not implemented yet")
        return [], None

    all_ports = []
    errors = []

    bridges, err = get_bridges()
    if err:
        return [], err

    for bridge in bridges:
        ports, err = get_port_states(bridge.name)
        if err:
            errors.append(err)
        else:
            all_ports.extend(ports)

    error_msg = "; ".join(errors) if errors else None
    return all_ports, error_msg
