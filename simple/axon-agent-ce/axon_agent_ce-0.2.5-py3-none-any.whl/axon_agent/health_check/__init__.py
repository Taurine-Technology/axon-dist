"""Health check module for Axon Agent.

This module provides health check functionality that allows the Axon controller
to query the current OVS configuration state on the switch and compare it with
the expected configuration in the database.
"""

__all__ = ["HealthCheckAgent"]


def __getattr__(name: str):
    """Lazy import to avoid RuntimeWarning when running agent as script."""
    if name == "HealthCheckAgent":
        from .agent import HealthCheckAgent

        return HealthCheckAgent
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
