"""Provisioning phase management."""

import logging
from typing import Optional
import time

from .mqtt_client import MQTTClient
from .monitoring import start_monitoring_process
from .health_check.agent import start_health_check_agent_process
from .uptime_monitoring.agent import start_uptime_monitoring_agent_process
from .utils import get_timestamp, start_agent_service

logger = logging.getLogger(__name__)


class ProvisioningManager:
    """Manages device provisioning and adoption."""

    @staticmethod
    def handle_provisioning(
        message: dict, mac_address: str, config_manager
    ) -> Optional[dict]:
        """Handle provisioning message and save configuration.

        Args:
            message: Provisioning message payload
            mac_address: Primary MAC address
            config_manager: ConfigManager instance

        Returns:
            Config dictionary if successful, None on failure
        """
        # Validate message structure
        if message.get("status") != "claimed":
            logger.error(f"Invalid provisioning status: {message.get('status')}")
            return None

        if "device_id" not in message:
            logger.error("Provisioning message missing device_id")
            return None

        if "network_id" not in message:
            logger.error("Provisioning message missing network_id")
            return None

        # Create config dictionary
        config = {
            "device_id": message["device_id"],
            "network_id": message["network_id"],
            "mac_address": mac_address,
            "adopted_at": get_timestamp(),
        }
        bc = message.get("bridge_config", {})
        if bc and isinstance(bc, dict) and bc.get("bridge_name"):
            config["bridge_configs"] = {bc["bridge_name"]: bc}

        logger.debug(
            f"Preparing to save config with device_id={config['device_id']}, network_id={config['network_id']}"
        )
        logger.debug(f"ConfigManager config_path: {config_manager.config_path}")

        # Save configuration
        try:
            logger.debug("Calling config_manager.save_config()...")
            config_manager.save_config(config)
            logger.info(
                f"Device adopted: device_id={config['device_id']}, network_id={config['network_id']}"
            )
            logger.debug(f"Config saved successfully to: {config_manager.config_path}")

            # Enable and start agent services with subprocess fallback
            start_agent_service(
                "axon-agent-monitor.service",
                start_monitoring_process,
                "device monitoring",
            )
            start_agent_service(
                "axon-agent-healthcheck.service",
                start_health_check_agent_process,
                "health check agent",
            )
            start_agent_service(
                "axon-agent-uptime.service",
                start_uptime_monitoring_agent_process,
                "uptime monitoring agent",
            )

            return config
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            return None

    @staticmethod
    def reconnect_with_identity(
        mqtt_client: MQTTClient, device_id: str, on_connect_callback=None
    ) -> MQTTClient:
        """Reconnect MQTT client with new device identity.

        Args:
            mqtt_client: Current MQTTClient instance
            device_id: Device ID to use as new client_id

        Returns:
            New MQTTClient instance with device_id as client_id
        """

        # Get connection parameters from old client
        host = mqtt_client.host
        port = mqtt_client.port
        username = mqtt_client.username
        password = mqtt_client.password

        # Stop the message loop first to prevent new messages
        try:
            mqtt_client.loop_stop()
            # Wait for loop to stop
            time.sleep(0.3)
        except Exception as e:
            logger.warning(f"Error stopping message loop: {e}")

        # Disconnect old client gracefully
        try:
            # Clear callbacks to prevent them from firing after disconnect
            old_client_id = (
                mqtt_client.client._client_id.decode()
                if hasattr(mqtt_client.client._client_id, "decode")
                else mqtt_client.client._client_id
            )
            logger.info(f"Disconnecting old client: {old_client_id}")
            # Force disconnect to ensure clean break
            mqtt_client.client.disconnect()
            # Wait longer for disconnect to fully complete and broker to clean up
            time.sleep(1.5)
            logger.info(f"Old client {old_client_id} disconnected")
        except Exception as e:
            logger.warning(f"Error disconnecting old client: {e}")

        # Create new client with device_id
        logger.info(f"Reconnecting with new identity: {device_id}")
        new_client = MQTTClient(
            host=host,
            port=port,
            username=username,
            password=password,
            client_id=device_id,
        )

        # Set on_connect callback BEFORE connecting
        if on_connect_callback:
            new_client.set_on_connect_callback(on_connect_callback)

        # Connect new client
        new_client.connect()
        new_client.loop_start()

        # Wait for connection to fully establish (check connection state)
        max_wait = 5.0
        waited = 0.0
        while not new_client.is_connected() and waited < max_wait:
            time.sleep(0.1)
            waited += 0.1

        if not new_client.is_connected():
            logger.warning("New client connection not established within timeout")
        else:
            logger.info("New client connection fully established")
            # Callback should have been called from on_connect, but if it wasn't set in time,
            # call it now as fallback
            if on_connect_callback and not new_client._on_connect_callback:
                # Only call if callback wasn't set (shouldn't happen, but safety check)
                try:
                    logger.debug("Calling on_connect callback as fallback")
                    on_connect_callback()
                except Exception as e:
                    logger.error(f"Error calling on_connect callback: {e}")

        return new_client
