"""SQLite-based policy cache for blocklist and rate limit rules.

This module provides a local cache for policy rules that are dynamically
updated by the OVS agent via MQTT. The classifier reads from this cache
to determine whether to block or rate-limit traffic.

Database location: /var/lib/axon/policy_cache.db

Tables:
    - blocklist: Applications to block (DROP action)
    - rate_limits: Applications to rate limit (METER action)
    - cached_blocks: Tracks which LAN devices have been blocked for which destinations
    - ip_block_rules: IP/CIDR block rules
    - url_block_rules: Domain/URL pattern block rules
    - block_lists: Block list metadata
    - block_list_entries: Block list IP/domain entries
"""

import fnmatch
import ipaddress
import json
import logging
import os
import re
import sqlite3
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Default database path
DEFAULT_DB_PATH = "/var/lib/axon/policy_cache.db"

# Default TTL for cached blocks (10 minutes)
DEFAULT_BLOCK_CACHE_TTL = 600

# Default cleanup interval (run cleanup every N lookups)
DEFAULT_CLEANUP_INTERVAL = 100


@dataclass
class TimeConstraint:
    """Represents a time-based constraint for rule enforcement.

    All time comparisons use UTC for consistent enforcement across systems.
    The timezone field is stored for future use but currently ignored -
    all times are interpreted as UTC.
    """

    time_start: Optional[str] = None  # HH:MM format (UTC)
    time_end: Optional[str] = None  # HH:MM format (UTC)
    days_of_week: Optional[list[int]] = None  # 0=Monday, 6=Sunday; None=all days
    timezone: Optional[str] = (
        None  # Reserved for future use (currently all times are UTC)
    )


@dataclass
class BlockRule:
    """Represents a blocklist rule."""

    app_name: str
    app_pattern: Optional[str] = None
    priority: int = 6000
    idle_timeout: int = 300
    enabled: bool = True
    target_mac: Optional[str] = None
    target_ip: Optional[str] = None
    target_network: Optional[str] = None
    time_constraint: Optional[TimeConstraint] = None


@dataclass
class RateLimitRule:
    """Represents a rate limit rule."""

    app_name: str
    meter_id: int
    rate_kbps: int
    burst_kbps: Optional[int] = None
    app_pattern: Optional[str] = None
    priority: int = 5000
    idle_timeout: int = 300
    enabled: bool = True
    target_mac: Optional[str] = None
    target_ip: Optional[str] = None
    target_network: Optional[str] = None
    time_constraint: Optional[TimeConstraint] = None


@dataclass
class CachedBlock:
    """Represents a cached block entry."""

    lan_ip: str
    destination: str
    app_name: Optional[str]
    blocked_at: datetime
    expires_at: datetime


@dataclass
class CachedMeter:
    """Represents a cached meter entry for rate-limited flows."""

    lan_ip: str
    destination: str
    app_name: Optional[str]
    meter_id: int
    rate_kbps: int
    created_at: datetime
    expires_at: datetime


@dataclass
class IPBlockRuleRow:
    """Row representation for an IP block rule."""

    rule_id: int
    ip_address: Optional[str]
    cidr_range: Optional[str]
    direction: str  # 'src', 'dst', 'both'
    priority: int
    idle_timeout: int
    enabled: bool
    description: Optional[str]


@dataclass
class URLBlockRuleRow:
    """Row representation for a URL block rule."""

    rule_id: int
    domain: Optional[str]
    domain_pattern: Optional[str]
    match_subdomains: bool
    priority: int
    idle_timeout: int
    enabled: bool
    description: Optional[str]


@dataclass
class BlockListRow:
    """Row representation for a block list."""

    list_id: int
    name: str
    enabled: bool
    priority: int


# -----------------------------------------------------------------------------
# SQL helper functions
# -----------------------------------------------------------------------------


def _escape_like_pattern(value: str, escape_char: str = "\\") -> str:
    """Escape SQL LIKE wildcards in a value.

    This ensures that literal '%', '_', and the escape character in the
    value are treated as literals, not as wildcards, in LIKE patterns.

    Args:
        value: The string value to escape
        escape_char: The escape character to use (default: backslash)

    Returns:
        Escaped string safe for use in LIKE patterns
    """
    # Escape the escape character first, then the wildcards
    result = value.replace(escape_char, escape_char + escape_char)
    result = result.replace("%", escape_char + "%")
    result = result.replace("_", escape_char + "_")
    return result


# -----------------------------------------------------------------------------
# IP and domain matching helpers (module-level, used by PolicyCache)
# -----------------------------------------------------------------------------


def _ip_matches_single(ip: str, rule_ip: str) -> bool:
    """Check if IP matches a single IP address."""
    try:
        return ipaddress.ip_address(ip) == ipaddress.ip_address(rule_ip)
    except ValueError:
        return False


def _ip_matches_cidr(ip: str, cidr: str) -> bool:
    """Check if IP falls within a CIDR range."""
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        return ipaddress.ip_address(ip) in network
    except ValueError:
        return False


def _domain_matches_exact(sni: str, domain: str) -> bool:
    """Check if SNI exactly matches domain (case-insensitive)."""
    return sni.lower() == domain.lower()


def _domain_matches_subdomain(sni: str, domain: str) -> bool:
    """Check if SNI is a subdomain of domain."""
    sni_lower = sni.lower()
    domain_lower = domain.lower()
    if sni_lower == domain_lower:
        return True
    return sni_lower.endswith("." + domain_lower)


def _domain_matches_pattern(sni: str, pattern: str) -> bool:
    """Check if SNI matches a wildcard pattern (e.g. *.example.com)."""
    return fnmatch.fnmatch(sni.lower(), pattern.lower())


# -----------------------------------------------------------------------------
# Policy targeting helpers (MAC, IP, time constraint matching)
# -----------------------------------------------------------------------------


def _mac_matches(
    src_mac: Optional[str], dst_mac: Optional[str], target_mac: Optional[str]
) -> bool:
    """Check if flow matches target MAC (src OR dst).

    Args:
        src_mac: Source MAC address from flow
        dst_mac: Destination MAC address from flow
        target_mac: Target MAC to match against

    Returns:
        True if no target_mac specified or if src_mac/dst_mac matches target
    """
    if not target_mac:
        return True
    target = target_mac.lower().replace("-", ":")
    src = (src_mac or "").lower().replace("-", ":")
    dst = (dst_mac or "").lower().replace("-", ":")
    return src == target or dst == target


def _ip_matches_target(
    src_ip: Optional[str],
    dst_ip: Optional[str],
    target_ip: Optional[str],
    target_network: Optional[str],
) -> bool:
    """Check if flow matches target IP or network.

    Args:
        src_ip: Source IP address from flow
        dst_ip: Destination IP address from flow
        target_ip: Specific IP to match (src OR dst)
        target_network: CIDR notation network to match (src OR dst)

    Returns:
        True if no targeting specified, or if src_ip/dst_ip matches target
    """
    if not target_ip and not target_network:
        return True

    if target_ip:
        if src_ip == target_ip or dst_ip == target_ip:
            return True

    if target_network:
        try:
            net = ipaddress.ip_network(target_network, strict=False)
            if src_ip:
                try:
                    if ipaddress.ip_address(src_ip) in net:
                        return True
                except ValueError:
                    pass
            if dst_ip:
                try:
                    if ipaddress.ip_address(dst_ip) in net:
                        return True
                except ValueError:
                    pass
        except ValueError:
            pass

    # If targeting was specified but nothing matched, return False
    # If no targeting specified, return True (matches all)
    return not (target_ip or target_network)


def _parse_time_to_mins(time_str: str) -> int:
    """Parse HH:MM time string to minutes since midnight.

    Args:
        time_str: Time in HH:MM format (e.g., "09:00", "17:30")

    Returns:
        Minutes since midnight (0-1439)

    Raises:
        ValueError: If time_str is malformed or out of range
    """
    time_str = time_str.strip()
    if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", time_str):
        raise ValueError(
            f"Invalid time format: '{time_str}', expected HH:MM 00:00-23:59"
        )
    h, m = map(int, time_str.split(":"))
    return h * 60 + m


def _time_constraint_active(tc: Optional[TimeConstraint]) -> bool:
    """Check if current UTC time satisfies time constraint.

    All time comparisons use UTC for consistent enforcement across systems.

    Args:
        tc: TimeConstraint object (or None for always active)

    Returns:
        True if rule should be active now (based on UTC time)
    """
    if not tc or (not tc.time_start and not tc.time_end and not tc.days_of_week):
        return True

    # Use UTC for consistent time enforcement across all systems
    now = datetime.now(timezone.utc)

    # Check day of week - API uses Monday=0, same as Python's weekday()
    if tc.days_of_week:
        if now.weekday() not in tc.days_of_week:
            return False

    # If only days specified (no time range), we're done
    if not tc.time_start and not tc.time_end:
        return True

    # Parse times
    current_mins = now.hour * 60 + now.minute
    start_mins = _parse_time_to_mins(tc.time_start) if tc.time_start else 0
    end_mins = _parse_time_to_mins(tc.time_end) if tc.time_end else 24 * 60 - 1

    # Handle overnight ranges (e.g., 22:00 - 06:00)
    if start_mins <= end_mins:
        return start_mins <= current_mins <= end_mins
    else:
        return current_mins >= start_mins or current_mins <= end_mins


def _row_to_block_rule(row) -> BlockRule:
    """Convert database row to BlockRule with targeting fields.

    Args:
        row: SQLite Row object with blocklist columns

    Returns:
        BlockRule object constructed from the row
    """
    time_constraint = None
    if row["time_start"] or row["time_end"] or row["days_of_week"]:
        days = None
        if row["days_of_week"]:
            try:
                days = json.loads(row["days_of_week"])
            except (json.JSONDecodeError, TypeError):
                days = None
        time_constraint = TimeConstraint(
            time_start=row["time_start"],
            time_end=row["time_end"],
            days_of_week=days,
            timezone=row["timezone"],
        )

    return BlockRule(
        app_name=row["app_name"],
        app_pattern=row["app_pattern"],
        priority=row["priority"],
        idle_timeout=row["idle_timeout"],
        enabled=bool(row["enabled"]),
        target_mac=row["target_mac"],
        target_ip=row["target_ip"],
        target_network=row["target_network"],
        time_constraint=time_constraint,
    )


def _row_to_rate_limit_rule(row) -> RateLimitRule:
    """Convert database row to RateLimitRule with targeting fields.

    Args:
        row: SQLite Row object with rate_limits columns

    Returns:
        RateLimitRule object constructed from the row
    """
    time_constraint = None
    if row["time_start"] or row["time_end"] or row["days_of_week"]:
        days = None
        if row["days_of_week"]:
            try:
                days = json.loads(row["days_of_week"])
            except (json.JSONDecodeError, TypeError):
                days = None
        time_constraint = TimeConstraint(
            time_start=row["time_start"],
            time_end=row["time_end"],
            days_of_week=days,
            timezone=row["timezone"],
        )

    return RateLimitRule(
        app_name=row["app_name"],
        app_pattern=row["app_pattern"],
        meter_id=row["meter_id"],
        rate_kbps=row["rate_kbps"],
        burst_kbps=row["burst_kbps"],
        priority=row["priority"],
        idle_timeout=row["idle_timeout"],
        enabled=bool(row["enabled"]),
        target_mac=row["target_mac"],
        target_ip=row["target_ip"],
        target_network=row["target_network"],
        time_constraint=time_constraint,
    )


class PolicyCache:
    """SQLite-based policy cache for blocklist and rate limits.

    Thread-safe implementation using connection per thread and WAL mode.

    Args:
        db_path: Path to the SQLite database file
        cleanup_interval: Number of check_cached_block() calls between cleanup runs.
            Set to 0 to disable periodic cleanup. Default is 100.
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB_PATH,
        cleanup_interval: int = DEFAULT_CLEANUP_INTERVAL,
    ):
        self.db_path = db_path
        self._local = threading.local()
        self._init_lock = threading.Lock()

        # Cleanup interval configuration (cleanup every N lookups)
        self._cleanup_interval = cleanup_interval
        self._cleanup_counter = 0
        self._cleanup_counter_lock = threading.Lock()

        # Ensure directory exists
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, mode=0o755, exist_ok=True)
            except PermissionError:
                # Fall back to /tmp if we can't create /var/lib/axon
                self.db_path = "/tmp/axon_policy_cache.db"
                logger.warning(f"Cannot create {db_dir}, using {self.db_path}")

        # Initialize database schema
        self._init_database()

    def _get_connection(self) -> sqlite3.Connection:
        """Get a thread-local database connection."""
        if not hasattr(self._local, "connection") or self._local.connection is None:
            self._local.connection = sqlite3.connect(
                self.db_path, check_same_thread=False, timeout=10.0
            )
            # Enable WAL mode for better concurrency
            self._local.connection.execute("PRAGMA journal_mode=WAL")
            self._local.connection.execute("PRAGMA synchronous=NORMAL")
            # Enable foreign keys for CASCADE deletes to work
            self._local.connection.execute("PRAGMA foreign_keys = ON")
            self._local.connection.row_factory = sqlite3.Row
        return self._local.connection

    def _init_database(self):
        """Initialize the database schema."""
        with self._init_lock:
            conn = self._get_connection()
            cursor = conn.cursor()

            # Create blocklist table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS blocklist (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_name TEXT NOT NULL,
                    app_pattern TEXT,
                    priority INTEGER DEFAULT 6000,
                    idle_timeout INTEGER DEFAULT 300,
                    enabled BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(app_name)
                )
            """
            )

            # Create rate_limits table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS rate_limits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_name TEXT NOT NULL,
                    app_pattern TEXT,
                    meter_id INTEGER NOT NULL,
                    rate_kbps INTEGER NOT NULL,
                    burst_kbps INTEGER DEFAULT 0,
                    priority INTEGER DEFAULT 5000,
                    idle_timeout INTEGER DEFAULT 300,
                    enabled BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(app_name)
                )
            """
            )

            # Create cached_blocks table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS cached_blocks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    lan_ip TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    app_name TEXT,
                    blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    UNIQUE(lan_ip, destination)
                )
            """
            )

            # Create cached_meters table (for rate-limited flows)
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS cached_meters (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    lan_ip TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    app_name TEXT,
                    meter_id INTEGER NOT NULL,
                    rate_kbps INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    UNIQUE(lan_ip, destination)
                )
            """
            )

            # Create meters registry table (for meter reuse tracking)
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS meters (
                    meter_id INTEGER PRIMARY KEY,
                    bridge_name TEXT NOT NULL,
                    rate_kbps INTEGER NOT NULL,
                    burst_kbps INTEGER DEFAULT 0,
                    reference_count INTEGER DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # IP block rules
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS ip_block_rules (
                    rule_id INTEGER PRIMARY KEY,
                    ip_address TEXT,
                    cidr_range TEXT,
                    direction TEXT NOT NULL DEFAULT 'both',
                    priority INTEGER NOT NULL DEFAULT 7000,
                    idle_timeout INTEGER NOT NULL DEFAULT 300,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # URL block rules
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS url_block_rules (
                    rule_id INTEGER PRIMARY KEY,
                    domain TEXT,
                    domain_pattern TEXT,
                    match_subdomains INTEGER NOT NULL DEFAULT 1,
                    priority INTEGER NOT NULL DEFAULT 7000,
                    idle_timeout INTEGER NOT NULL DEFAULT 300,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # Block lists
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS block_lists (
                    list_id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 0,
                    priority INTEGER NOT NULL DEFAULT 7000,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # Block list entries
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS block_list_entries (
                    list_id INTEGER NOT NULL,
                    entry_type TEXT NOT NULL,
                    value TEXT NOT NULL,
                    PRIMARY KEY (list_id, entry_type, value),
                    FOREIGN KEY (list_id) REFERENCES block_lists(list_id) ON DELETE CASCADE
                )
            """
            )

            # Create indexes
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_cached_blocks_lookup
                ON cached_blocks(lan_ip, destination)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_cached_blocks_expiry
                ON cached_blocks(expires_at)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_cached_meters_lookup
                ON cached_meters(lan_ip, destination)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_cached_meters_expiry
                ON cached_meters(expires_at)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_blocklist_app_name
                ON blocklist(app_name)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_rate_limits_app_name
                ON rate_limits(app_name)
            """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_meters_rate
                ON meters(rate_kbps, burst_kbps)
            """
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_ip_block_rules_ip ON ip_block_rules(ip_address)"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_ip_block_rules_enabled ON ip_block_rules(enabled)"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_url_block_rules_domain ON url_block_rules(domain)"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_url_block_rules_enabled ON url_block_rules(enabled)"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_block_list_entries_list ON block_list_entries(list_id)"
            )
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_block_list_entries_value ON block_list_entries(value)"
            )
            # Case-insensitive index for fast domain lookups
            cursor.execute(
                "CREATE INDEX IF NOT EXISTS idx_block_list_entries_value_nocase "
                "ON block_list_entries(value COLLATE NOCASE)"
            )

            # Migration: Add new targeting columns to blocklist table if not present
            # Check each column individually to handle partial migrations
            cursor.execute("PRAGMA table_info(blocklist)")
            blocklist_columns = {row[1] for row in cursor.fetchall()}
            targeting_columns = [
                "target_mac",
                "target_ip",
                "target_network",
                "time_start",
                "time_end",
                "days_of_week",
                "timezone",
            ]
            blocklist_added = []
            for col in targeting_columns:
                if col not in blocklist_columns:
                    try:
                        cursor.execute(f"ALTER TABLE blocklist ADD COLUMN {col} TEXT")
                        blocklist_added.append(col)
                    except sqlite3.OperationalError as e:
                        logger.error(f"Failed to add column {col} to blocklist: {e}")
            if blocklist_added:
                logger.info(
                    f"Migrated blocklist table: added columns {blocklist_added}"
                )

            # Migration: Add new targeting columns to rate_limits table if not present
            cursor.execute("PRAGMA table_info(rate_limits)")
            ratelimits_columns = {row[1] for row in cursor.fetchall()}
            ratelimits_added = []
            for col in targeting_columns:
                if col not in ratelimits_columns:
                    try:
                        cursor.execute(f"ALTER TABLE rate_limits ADD COLUMN {col} TEXT")
                        ratelimits_added.append(col)
                    except sqlite3.OperationalError as e:
                        logger.error(f"Failed to add column {col} to rate_limits: {e}")
            if ratelimits_added:
                logger.info(
                    f"Migrated rate_limits table: added columns {ratelimits_added}"
                )

            conn.commit()
            logger.info(f"Policy cache database initialized at {self.db_path}")

    # =========================================================================
    # Blocklist Operations
    # =========================================================================

    def is_blocked(
        self,
        app_name: str,
        src_mac: Optional[str] = None,
        dst_mac: Optional[str] = None,
        src_ip: Optional[str] = None,
        dst_ip: Optional[str] = None,
    ) -> Optional[BlockRule]:
        """Check if an application is in the blocklist.

        Also checks for pattern matches (e.g., "QUIC.Instagram" matches "Instagram").
        Matching is case-insensitive. If targeting fields are provided, only returns
        rules that match the specified MAC/IP criteria and are active based on
        time constraints.

        Args:
            app_name: Application name from NFStream (e.g., "QUIC.Instagram")
            src_mac: Source MAC address (for target_mac filtering)
            dst_mac: Destination MAC address (for target_mac filtering)
            src_ip: Source IP address (for target_ip/target_network filtering)
            dst_ip: Destination IP address (for target_ip/target_network filtering)

        Returns:
            BlockRule if blocked, None otherwise
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        def _rule_matches_flow(rule: BlockRule) -> bool:
            """Check if rule matches the flow's targeting criteria."""
            # Check MAC targeting
            if not _mac_matches(src_mac, dst_mac, rule.target_mac):
                return False
            # Check IP targeting
            if not _ip_matches_target(
                src_ip, dst_ip, rule.target_ip, rule.target_network
            ):
                return False
            # Check time constraint
            if not _time_constraint_active(rule.time_constraint):
                return False
            return True

        # First try exact match (case-insensitive)
        cursor.execute(
            """
            SELECT app_name, app_pattern, priority, idle_timeout, enabled,
                   target_mac, target_ip, target_network,
                   time_start, time_end, days_of_week, timezone
            FROM blocklist
            WHERE app_name = ? COLLATE NOCASE AND enabled = 1
        """,
            (app_name,),
        )
        logger.debug(f"checking blocklist for {app_name}")
        row = cursor.fetchone()
        if row:
            rule = _row_to_block_rule(row)
            if _rule_matches_flow(rule):
                logger.info(f"blocklist match found for {app_name}")
                return rule

        # Check for sub-protocol match (e.g., "QUIC.Instagram" -> check "Instagram")
        # Case-insensitive matching
        if "." in app_name:
            _, sub_proto = app_name.split(".", 1)
            cursor.execute(
                """
                SELECT app_name, app_pattern, priority, idle_timeout, enabled,
                       target_mac, target_ip, target_network,
                       time_start, time_end, days_of_week, timezone
                FROM blocklist
                WHERE LOWER(app_name) = LOWER(?) AND enabled = 1
            """,
                (sub_proto,),
            )

            row = cursor.fetchone()
            if row:
                rule = _row_to_block_rule(row)
                if _rule_matches_flow(rule):
                    logger.info(f"blocklist match found for {app_name}")
                    return rule

        return None

    def add_block_rule(
        self,
        app_name: str,
        app_pattern: Optional[str] = None,
        priority: int = 6000,
        idle_timeout: int = 300,
        enabled: bool = True,
        target_mac: Optional[str] = None,
        target_ip: Optional[str] = None,
        target_network: Optional[str] = None,
        time_constraint: Optional[TimeConstraint] = None,
    ) -> bool:
        """Add or update a block rule.

        Args:
            app_name: Application name to block
            app_pattern: Optional regex pattern for matching
            priority: OVS flow priority
            idle_timeout: Flow idle timeout in seconds
            enabled: Whether the rule is enabled
            target_mac: MAC address to target (matches src OR dst)
            target_ip: IP address to target (matches src OR dst)
            target_network: CIDR network to target (matches src OR dst)
            time_constraint: Time-based enforcement constraint

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        # Serialize time constraint fields
        time_start = time_constraint.time_start if time_constraint else None
        time_end = time_constraint.time_end if time_constraint else None
        days_of_week = None
        if time_constraint and time_constraint.days_of_week:
            days_of_week = json.dumps(time_constraint.days_of_week)
        timezone = time_constraint.timezone if time_constraint else None

        try:
            cursor.execute(
                """
                INSERT INTO blocklist (app_name, app_pattern, priority, idle_timeout, enabled,
                                       target_mac, target_ip, target_network,
                                       time_start, time_end, days_of_week, timezone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(app_name) DO UPDATE SET
                    app_pattern = excluded.app_pattern,
                    priority = excluded.priority,
                    idle_timeout = excluded.idle_timeout,
                    enabled = excluded.enabled,
                    target_mac = excluded.target_mac,
                    target_ip = excluded.target_ip,
                    target_network = excluded.target_network,
                    time_start = excluded.time_start,
                    time_end = excluded.time_end,
                    days_of_week = excluded.days_of_week,
                    timezone = excluded.timezone,
                    updated_at = CURRENT_TIMESTAMP
            """,
                (
                    app_name,
                    app_pattern,
                    priority,
                    idle_timeout,
                    enabled,
                    target_mac,
                    target_ip,
                    target_network,
                    time_start,
                    time_end,
                    days_of_week,
                    timezone,
                ),
            )
            conn.commit()
            logger.info(f"Added/updated block rule for {app_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to add block rule for {app_name}: {e}")
            return False

    def remove_block_rule(self, app_name: str) -> bool:
        """Remove a block rule and clear related cached block entries.

        Args:
            app_name: Application name to unblock

        Returns:
            True if rule was removed
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("DELETE FROM blocklist WHERE app_name = ?", (app_name,))
            conn.commit()
            removed = cursor.rowcount > 0
            if removed:
                logger.info(f"Removed block rule for {app_name}")
                # Also clear cached block entries for this app (case-insensitive)
                # Match both exact name and protocol-prefixed versions
                # e.g., "Instagram" and "QUIC.Instagram", "TLS.Instagram"
                # Escape SQL wildcards in app_name to prevent injection
                escaped_app_name = _escape_like_pattern(app_name)
                cursor.execute(
                    """
                    DELETE FROM cached_blocks
                    WHERE app_name = ? COLLATE NOCASE
                       OR app_name LIKE ? ESCAPE '\\' COLLATE NOCASE
                """,
                    (app_name, f"%.{escaped_app_name}"),
                )
                conn.commit()
                cleared = cursor.rowcount
                if cleared > 0:
                    logger.info(
                        f"Cleared {cleared} cached block entries for {app_name}"
                    )
            return removed
        except Exception as e:
            logger.error(f"Failed to remove block rule for {app_name}: {e}")
            return False

    def get_all_block_rules(self) -> list[BlockRule]:
        """Get all block rules.

        Returns:
            List of BlockRule objects including targeting fields
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT app_name, app_pattern, priority, idle_timeout, enabled,
                   target_mac, target_ip, target_network,
                   time_start, time_end, days_of_week, timezone
            FROM blocklist
            WHERE enabled = 1
        """
        )

        return [_row_to_block_rule(row) for row in cursor.fetchall()]

    # =========================================================================
    # Rate Limit Operations
    # =========================================================================

    def get_rate_limit(
        self,
        app_name: str,
        src_mac: Optional[str] = None,
        dst_mac: Optional[str] = None,
        src_ip: Optional[str] = None,
        dst_ip: Optional[str] = None,
    ) -> Optional[RateLimitRule]:
        """Get rate limit rule for an application.

        Also checks for pattern matches (e.g., "QUIC.YouTube" matches "YouTube").
        Matching is case-insensitive. If targeting fields are provided, only returns
        rules that match the specified MAC/IP criteria and are active based on
        time constraints.

        Args:
            app_name: Application name from NFStream
            src_mac: Source MAC address (for target_mac filtering)
            dst_mac: Destination MAC address (for target_mac filtering)
            src_ip: Source IP address (for target_ip/target_network filtering)
            dst_ip: Destination IP address (for target_ip/target_network filtering)

        Returns:
            RateLimitRule if found, None otherwise
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        def _rule_matches_flow(rule: RateLimitRule) -> bool:
            """Check if rule matches the flow's targeting criteria."""
            # Check MAC targeting
            if not _mac_matches(src_mac, dst_mac, rule.target_mac):
                return False
            # Check IP targeting
            if not _ip_matches_target(
                src_ip, dst_ip, rule.target_ip, rule.target_network
            ):
                return False
            # Check time constraint
            if not _time_constraint_active(rule.time_constraint):
                return False
            return True

        # First try exact match (case-insensitive)
        cursor.execute(
            """
            SELECT app_name, app_pattern, meter_id, rate_kbps, burst_kbps,
                   priority, idle_timeout, enabled,
                   target_mac, target_ip, target_network,
                   time_start, time_end, days_of_week, timezone
            FROM rate_limits
            WHERE app_name = ? COLLATE NOCASE AND enabled = 1
        """,
            (app_name,),
        )
        logger.debug(f"checking rate limit list for {app_name}")
        row = cursor.fetchone()
        if row:
            rule = _row_to_rate_limit_rule(row)
            if _rule_matches_flow(rule):
                return rule

        # Check for sub-protocol match (case-insensitive)
        if "." in app_name:
            _, sub_proto = app_name.split(".", 1)
            cursor.execute(
                """
                SELECT app_name, app_pattern, meter_id, rate_kbps, burst_kbps,
                       priority, idle_timeout, enabled,
                       target_mac, target_ip, target_network,
                       time_start, time_end, days_of_week, timezone
                FROM rate_limits
                WHERE LOWER(app_name) = LOWER(?) AND enabled = 1
            """,
                (sub_proto,),
            )

            row = cursor.fetchone()
            if row:
                rule = _row_to_rate_limit_rule(row)
                if _rule_matches_flow(rule):
                    return rule

        return None

    def add_rate_limit(
        self,
        app_name: str,
        meter_id: int,
        rate_kbps: int,
        burst_kbps: Optional[int] = None,
        app_pattern: Optional[str] = None,
        priority: int = 5000,
        idle_timeout: int = 300,
        enabled: bool = True,
        target_mac: Optional[str] = None,
        target_ip: Optional[str] = None,
        target_network: Optional[str] = None,
        time_constraint: Optional[TimeConstraint] = None,
    ) -> bool:
        """Add or update a rate limit rule.

        Args:
            app_name: Application name to rate limit
            meter_id: OVS meter ID to use
            rate_kbps: Rate limit in kbps
            burst_kbps: Burst size in kbps (None = no burst)
            app_pattern: Optional regex pattern
            priority: OVS flow priority
            idle_timeout: Flow idle timeout in seconds
            enabled: Whether the rule is enabled
            target_mac: MAC address to target (matches src OR dst)
            target_ip: IP address to target (matches src OR dst)
            target_network: CIDR network to target (matches src OR dst)
            time_constraint: Time-based enforcement constraint

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        # Serialize time constraint fields
        time_start = time_constraint.time_start if time_constraint else None
        time_end = time_constraint.time_end if time_constraint else None
        days_of_week = None
        if time_constraint and time_constraint.days_of_week:
            days_of_week = json.dumps(time_constraint.days_of_week)
        timezone = time_constraint.timezone if time_constraint else None

        try:
            cursor.execute(
                """
                INSERT INTO rate_limits
                (app_name, app_pattern, meter_id, rate_kbps, burst_kbps, priority, idle_timeout, enabled,
                 target_mac, target_ip, target_network, time_start, time_end, days_of_week, timezone)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(app_name) DO UPDATE SET
                    app_pattern = excluded.app_pattern,
                    meter_id = excluded.meter_id,
                    rate_kbps = excluded.rate_kbps,
                    burst_kbps = excluded.burst_kbps,
                    priority = excluded.priority,
                    idle_timeout = excluded.idle_timeout,
                    enabled = excluded.enabled,
                    target_mac = excluded.target_mac,
                    target_ip = excluded.target_ip,
                    target_network = excluded.target_network,
                    time_start = excluded.time_start,
                    time_end = excluded.time_end,
                    days_of_week = excluded.days_of_week,
                    timezone = excluded.timezone,
                    updated_at = CURRENT_TIMESTAMP
            """,
                (
                    app_name,
                    app_pattern,
                    meter_id,
                    rate_kbps,
                    burst_kbps,
                    priority,
                    idle_timeout,
                    enabled,
                    target_mac,
                    target_ip,
                    target_network,
                    time_start,
                    time_end,
                    days_of_week,
                    timezone,
                ),
            )
            conn.commit()
            logger.info(f"Added/updated rate limit for {app_name}: {rate_kbps} kbps")
            return True
        except Exception as e:
            logger.error(f"Failed to add rate limit for {app_name}: {e}")
            return False

    def update_rate_limit_meter_id(self, app_name: str, meter_id: int) -> bool:
        """Update the meter_id for a rate limit rule.

        Used when the stored meter_id is 0 (placeholder) and we've discovered
        the actual meter_id from OVS.

        Args:
            app_name: Application name (case-insensitive match)
            meter_id: The correct OVS meter ID

        Returns:
            True if updated successfully
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE rate_limits
                SET meter_id = ?, updated_at = CURRENT_TIMESTAMP
                WHERE app_name = ? COLLATE NOCASE
            """,
                (meter_id, app_name),
            )
            conn.commit()
            updated = cursor.rowcount > 0
            if updated:
                logger.info(f"Updated meter_id for {app_name} to {meter_id}")
                # Clear cached meter entries for this app so they get recreated
                # with the new meter_id on next lookup (case-insensitive).
                # Match both exact name and protocol-prefixed versions
                # e.g., "Instagram" and "QUIC.Instagram", "TLS.Instagram"
                # Escape SQL wildcards in app_name to prevent injection
                escaped_app_name = _escape_like_pattern(app_name)
                cursor.execute(
                    """
                    DELETE FROM cached_meters
                    WHERE app_name = ? COLLATE NOCASE
                       OR app_name LIKE ? ESCAPE '\\' COLLATE NOCASE
                """,
                    (app_name, f"%.{escaped_app_name}"),
                )
                conn.commit()
                cleared = cursor.rowcount
                if cleared > 0:
                    logger.info(
                        f"Cleared {cleared} cached meter entries for {app_name} "
                        f"after meter_id update"
                    )
            return updated
        except Exception as e:
            logger.error(f"Failed to update meter_id for {app_name}: {e}")
            return False

    def remove_rate_limit(self, app_name: str) -> bool:
        """Remove a rate limit rule and clear related cached meter entries.

        Args:
            app_name: Application name

        Returns:
            True if rule was removed
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("DELETE FROM rate_limits WHERE app_name = ?", (app_name,))
            conn.commit()
            removed = cursor.rowcount > 0
            if removed:
                logger.info(f"Removed rate limit for {app_name}")
                # Also clear cached meter entries for this app (case-insensitive)
                # Match both exact name and protocol-prefixed versions
                # e.g., "Instagram" and "QUIC.Instagram", "TLS.Instagram"
                # Escape SQL wildcards in app_name to prevent injection
                escaped_app_name = _escape_like_pattern(app_name)
                cursor.execute(
                    """
                    DELETE FROM cached_meters
                    WHERE app_name = ? COLLATE NOCASE
                       OR app_name LIKE ? ESCAPE '\\' COLLATE NOCASE
                """,
                    (app_name, f"%.{escaped_app_name}"),
                )
                conn.commit()
                cleared = cursor.rowcount
                if cleared > 0:
                    logger.info(
                        f"Cleared {cleared} cached meter entries for {app_name}"
                    )
            return removed
        except Exception as e:
            logger.error(f"Failed to remove rate limit for {app_name}: {e}")
            return False

    def get_all_rate_limits(self) -> list[RateLimitRule]:
        """Get all rate limit rules.

        Returns:
            List of RateLimitRule objects including targeting fields
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT app_name, app_pattern, meter_id, rate_kbps, burst_kbps,
                   priority, idle_timeout, enabled,
                   target_mac, target_ip, target_network,
                   time_start, time_end, days_of_week, timezone
            FROM rate_limits
            WHERE enabled = 1
        """
        )

        return [_row_to_rate_limit_rule(row) for row in cursor.fetchall()]

    # =========================================================================
    # Cached Block Operations (replaces in-memory dict)
    # =========================================================================

    def check_cached_block(
        self, lan_ip: str, destination: str
    ) -> tuple[bool, Optional[str]]:
        """Check if a flow should be blocked based on cached block registry.

        Args:
            lan_ip: LAN device IP
            destination: Destination identifier (SNI or dst_ip)

        Returns:
            Tuple of (should_block, other_blocked_device_ip or None)
            - (True, None) if same device was blocked before
            - (False, other_ip) if different device was blocked for this destination
            - (False, None) if no cached block exists
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        # Periodic cleanup: only run every N lookups to avoid write pressure
        self._maybe_cleanup_expired_blocks()

        # Check if same device has a cached block for this destination
        cursor.execute(
            """
            SELECT lan_ip, destination, app_name, expires_at
            FROM cached_blocks
            WHERE lan_ip = ? AND destination = ? AND expires_at > ?
        """,
            (lan_ip, destination, current_time),
        )

        row = cursor.fetchone()
        if row:
            # Update expiry (sliding window) by extending TTL
            new_expiry = datetime.fromtimestamp(
                time.time() + DEFAULT_BLOCK_CACHE_TTL, timezone.utc
            ).isoformat()
            cursor.execute(
                """
                UPDATE cached_blocks
                SET expires_at = ?
                WHERE lan_ip = ? AND destination = ?
            """,
                (new_expiry, lan_ip, destination),
            )
            conn.commit()
            return (True, None)

        # Check if any other device has a cached block for this destination
        cursor.execute(
            """
            SELECT lan_ip
            FROM cached_blocks
            WHERE destination = ? AND lan_ip != ? AND expires_at > ?
            LIMIT 1
        """,
            (destination, lan_ip, current_time),
        )

        row = cursor.fetchone()
        if row:
            return (False, row["lan_ip"])

        return (False, None)

    def register_cached_block(
        self,
        lan_ip: str,
        destination: str,
        app_name: Optional[str] = None,
        ttl: int = DEFAULT_BLOCK_CACHE_TTL,
    ) -> bool:
        """Register a block in the cached block registry.

        Args:
            lan_ip: LAN device IP that was blocked
            destination: Destination identifier (SNI or dst_ip)
            app_name: Original app that triggered the block
            ttl: Time-to-live in seconds

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        expires_at = datetime.fromtimestamp(time.time() + ttl, timezone.utc).isoformat()

        try:
            cursor.execute(
                """
                INSERT INTO cached_blocks (lan_ip, destination, app_name, expires_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(lan_ip, destination) DO UPDATE SET
                    app_name = excluded.app_name,
                    expires_at = excluded.expires_at,
                    blocked_at = CURRENT_TIMESTAMP
            """,
                (lan_ip, destination, app_name, expires_at),
            )
            conn.commit()
            logger.debug(f"Registered cached block: {lan_ip} -> {destination}")
            return True
        except Exception as e:
            logger.error(f"Failed to register cached block: {e}")
            return False

    def _maybe_cleanup_expired_blocks(self) -> None:
        """Periodically trigger cleanup based on counter interval.

        This method implements a counter-based approach to avoid running
        cleanup_expired_blocks() on every lookup, reducing write pressure.
        Cleanup runs every self._cleanup_interval calls.

        Thread-safe: uses a lock to ensure counter consistency across threads.
        """
        if self._cleanup_interval <= 0:
            # Periodic cleanup disabled
            return

        should_cleanup = False
        with self._cleanup_counter_lock:
            self._cleanup_counter += 1
            if self._cleanup_counter >= self._cleanup_interval:
                self._cleanup_counter = 0
                should_cleanup = True

        if should_cleanup:
            self.cleanup_expired_blocks()

    def cleanup_expired_blocks(self) -> int:
        """Remove expired entries from the cached block registry.

        Returns:
            Number of entries removed
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        try:
            cursor.execute(
                """
                DELETE FROM cached_blocks WHERE expires_at < ?
            """,
                (current_time,),
            )
            conn.commit()
            count = cursor.rowcount
            if count > 0:
                logger.debug(f"Cleaned up {count} expired cached blocks")
            return count
        except Exception as e:
            logger.error(f"Failed to cleanup expired blocks: {e}")
            return 0

    def get_cached_block_count(self) -> int:
        """Get the number of active cached blocks.

        Returns:
            Number of non-expired cached blocks
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        cursor.execute(
            """
            SELECT COUNT(*) FROM cached_blocks WHERE expires_at > ?
        """,
            (current_time,),
        )

        return cursor.fetchone()[0]

    # =========================================================================
    # Cached Meter Operations (for rate-limited flows)
    # =========================================================================

    def check_cached_meter(
        self, lan_ip: str, destination: str
    ) -> tuple[bool, Optional[int], Optional[int]]:
        """Check if a flow should be rate-limited based on cached meter registry.

        Args:
            lan_ip: LAN device IP
            destination: Destination identifier (SNI or dst_ip)

        Returns:
            Tuple of (should_limit, meter_id, rate_kbps)
            - (True, meter_id, rate_kbps) if same device was rate-limited before
            - (False, None, None) if no cached meter exists
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        # Periodic cleanup: only run every N lookups to avoid write pressure
        self._maybe_cleanup_expired_meters()

        # Check if same device has a cached meter for this destination
        cursor.execute(
            """
            SELECT lan_ip, destination, meter_id, rate_kbps, expires_at
            FROM cached_meters
            WHERE lan_ip = ? AND destination = ? AND expires_at > ?
        """,
            (lan_ip, destination, current_time),
        )

        row = cursor.fetchone()
        if row:
            # Update expiry (sliding window) by extending TTL
            new_expiry = datetime.fromtimestamp(
                time.time() + DEFAULT_BLOCK_CACHE_TTL, timezone.utc
            ).isoformat()
            cursor.execute(
                """
                UPDATE cached_meters
                SET expires_at = ?
                WHERE lan_ip = ? AND destination = ?
            """,
                (new_expiry, lan_ip, destination),
            )
            conn.commit()
            return (True, row["meter_id"], row["rate_kbps"])

        return (False, None, None)

    def register_cached_meter(
        self,
        lan_ip: str,
        destination: str,
        meter_id: int,
        rate_kbps: int,
        app_name: Optional[str] = None,
        ttl: int = DEFAULT_BLOCK_CACHE_TTL,
    ) -> bool:
        """Register a meter in the cached meter registry.

        Args:
            lan_ip: LAN device IP that was rate-limited
            destination: Destination identifier (SNI or dst_ip)
            meter_id: OVS meter ID applied
            rate_kbps: Rate limit in kbps
            app_name: Original app that triggered the rate limit
            ttl: Time-to-live in seconds

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        expires_at = datetime.fromtimestamp(time.time() + ttl, timezone.utc).isoformat()

        try:
            cursor.execute(
                """
                INSERT INTO cached_meters (lan_ip, destination, app_name, meter_id, rate_kbps, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(lan_ip, destination) DO UPDATE SET
                    app_name = excluded.app_name,
                    meter_id = excluded.meter_id,
                    rate_kbps = excluded.rate_kbps,
                    expires_at = excluded.expires_at,
                    created_at = CURRENT_TIMESTAMP
            """,
                (lan_ip, destination, app_name, meter_id, rate_kbps, expires_at),
            )
            conn.commit()
            logger.debug(
                f"Registered cached meter: {lan_ip} -> {destination} (meter={meter_id})"
            )
            return True
        except Exception as e:
            logger.error(f"Failed to register cached meter: {e}")
            return False

    def _maybe_cleanup_expired_meters(self) -> None:
        """Periodically trigger meter cleanup based on counter interval.

        This method implements a counter-based approach to avoid running
        cleanup_expired_meters() on every lookup, reducing write pressure.
        Cleanup runs every self._cleanup_interval calls.

        Thread-safe: uses the same lock as _maybe_cleanup_expired_blocks to
        ensure counter consistency across threads.
        """
        if self._cleanup_interval <= 0:
            # Periodic cleanup disabled
            return

        should_cleanup = False
        with self._cleanup_counter_lock:
            self._cleanup_counter += 1
            if self._cleanup_counter >= self._cleanup_interval:
                self._cleanup_counter = 0
                should_cleanup = True

        if should_cleanup:
            self.cleanup_expired_meters()

    def cleanup_expired_meters(self) -> int:
        """Remove expired entries from the cached meter registry.

        Returns:
            Number of entries removed
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        try:
            cursor.execute(
                """
                DELETE FROM cached_meters WHERE expires_at < ?
            """,
                (current_time,),
            )
            conn.commit()
            count = cursor.rowcount
            if count > 0:
                logger.debug(f"Cleaned up {count} expired cached meters")
            return count
        except Exception as e:
            logger.error(f"Failed to cleanup expired meters: {e}")
            return 0

    def get_cached_meter_count(self) -> int:
        """Get the number of active cached meters.

        Returns:
            Number of non-expired cached meters
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        current_time = datetime.now(timezone.utc).isoformat()

        cursor.execute(
            """
            SELECT COUNT(*) FROM cached_meters WHERE expires_at > ?
        """,
            (current_time,),
        )

        return cursor.fetchone()[0]

    # =========================================================================
    # Sync Operations
    # =========================================================================

    def sync_block_rules(self, rules: list[BlockRule]) -> bool:
        """Sync blocklist with a full list of rules (replace all).

        Args:
            rules: Complete list of block rules

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("DELETE FROM blocklist")
            for rule in rules:
                # Serialize time constraint fields
                time_start = (
                    rule.time_constraint.time_start if rule.time_constraint else None
                )
                time_end = (
                    rule.time_constraint.time_end if rule.time_constraint else None
                )
                days_of_week = None
                if rule.time_constraint and rule.time_constraint.days_of_week:
                    days_of_week = json.dumps(rule.time_constraint.days_of_week)
                timezone = (
                    rule.time_constraint.timezone if rule.time_constraint else None
                )

                cursor.execute(
                    """
                    INSERT INTO blocklist (app_name, app_pattern, priority, idle_timeout, enabled,
                                           target_mac, target_ip, target_network,
                                           time_start, time_end, days_of_week, timezone)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        rule.app_name,
                        rule.app_pattern,
                        rule.priority,
                        rule.idle_timeout,
                        rule.enabled,
                        rule.target_mac,
                        rule.target_ip,
                        rule.target_network,
                        time_start,
                        time_end,
                        days_of_week,
                        timezone,
                    ),
                )
            conn.commit()
            logger.info(f"Synced {len(rules)} block rules")
            return True
        except Exception as e:
            logger.error(f"Failed to sync block rules: {e}")
            conn.rollback()
            return False

    def sync_rate_limits(self, rules: list[RateLimitRule]) -> bool:
        """Sync rate limits with a full list of rules (replace all).

        Args:
            rules: Complete list of rate limit rules

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("DELETE FROM rate_limits")
            for rule in rules:
                # Serialize time constraint fields
                time_start = (
                    rule.time_constraint.time_start if rule.time_constraint else None
                )
                time_end = (
                    rule.time_constraint.time_end if rule.time_constraint else None
                )
                days_of_week = None
                if rule.time_constraint and rule.time_constraint.days_of_week:
                    days_of_week = json.dumps(rule.time_constraint.days_of_week)
                timezone = (
                    rule.time_constraint.timezone if rule.time_constraint else None
                )

                cursor.execute(
                    """
                    INSERT INTO rate_limits
                    (app_name, app_pattern, meter_id, rate_kbps, burst_kbps, priority, idle_timeout, enabled,
                     target_mac, target_ip, target_network, time_start, time_end, days_of_week, timezone)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        rule.app_name,
                        rule.app_pattern,
                        rule.meter_id,
                        rule.rate_kbps,
                        rule.burst_kbps,
                        rule.priority,
                        rule.idle_timeout,
                        rule.enabled,
                        rule.target_mac,
                        rule.target_ip,
                        rule.target_network,
                        time_start,
                        time_end,
                        days_of_week,
                        timezone,
                    ),
                )
            conn.commit()
            logger.info(f"Synced {len(rules)} rate limit rules")
            return True
        except Exception as e:
            logger.error(f"Failed to sync rate limits: {e}")
            conn.rollback()
            return False

    # =========================================================================
    # IP / URL block and block list operations
    # =========================================================================

    def check_ip_block(
        self, src_ip: str, dst_ip: str
    ) -> tuple[bool, Optional[dict[str, Any]]]:
        """Check if flow matches any enabled IP block rule.

        Returns:
            (is_blocked, info_dict) or (False, None). info_dict has rule_id, priority.
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT rule_id, ip_address, cidr_range, direction, priority
            FROM ip_block_rules
            WHERE enabled = 1
            ORDER BY priority DESC
            """
        )
        for row in cursor.fetchall():
            rule_id = row["rule_id"]
            ip_addr = row["ip_address"]
            cidr = row["cidr_range"]
            direction = row["direction"] or "both"
            priority = row["priority"] or 7000
            target = ip_addr or cidr
            if not target:
                continue
            if direction in ("src", "both"):
                if ip_addr and _ip_matches_single(src_ip, ip_addr):
                    return True, {"rule_id": rule_id, "priority": priority}
                if cidr and _ip_matches_cidr(src_ip, cidr):
                    return True, {"rule_id": rule_id, "priority": priority}
            if direction in ("dst", "both"):
                if ip_addr and _ip_matches_single(dst_ip, ip_addr):
                    return True, {"rule_id": rule_id, "priority": priority}
                if cidr and _ip_matches_cidr(dst_ip, cidr):
                    return True, {"rule_id": rule_id, "priority": priority}
        return False, None

    def check_url_block(self, sni: str) -> tuple[bool, Optional[dict[str, Any]]]:
        """Check if SNI matches any enabled URL block rule.

        Returns:
            (is_blocked, info_dict) or (False, None). info_dict has rule_id, priority.
        """
        if not sni:
            return False, None
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT rule_id, domain, domain_pattern, match_subdomains, priority
            FROM url_block_rules
            WHERE enabled = 1
            ORDER BY priority DESC
            """
        )
        for row in cursor.fetchall():
            rule_id = row["rule_id"]
            domain = row["domain"]
            pattern = row["domain_pattern"]
            match_subs = bool(row["match_subdomains"])
            priority = row["priority"] or 7000
            if domain:
                if _domain_matches_exact(sni, domain):
                    return True, {"rule_id": rule_id, "priority": priority}
                if match_subs and _domain_matches_subdomain(sni, domain):
                    return True, {"rule_id": rule_id, "priority": priority}
            if pattern and _domain_matches_pattern(sni, pattern):
                return True, {"rule_id": rule_id, "priority": priority}
        return False, None

    def check_block_list_ip(self, ip: str) -> tuple[bool, Optional[dict[str, Any]]]:
        """Check if IP matches any enabled block list IP entry.

        Returns:
            (is_blocked, info_dict) or (False, None). info_dict has list_id, name, priority.
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT bl.list_id, bl.name, bl.priority, ble.value
            FROM block_lists bl
            JOIN block_list_entries ble ON bl.list_id = ble.list_id
            WHERE bl.enabled = 1 AND ble.entry_type IN ('ip', 'ip_range')
            ORDER BY bl.priority DESC
            """
        )
        for row in cursor.fetchall():
            list_id = row["list_id"]
            name = row["name"]
            priority = row["priority"] or 7000
            value = row["value"]
            if "/" in value:
                if _ip_matches_cidr(ip, value):
                    return True, {
                        "list_id": list_id,
                        "name": name,
                        "priority": priority,
                    }
            else:
                if _ip_matches_single(ip, value):
                    return True, {
                        "list_id": list_id,
                        "name": name,
                        "priority": priority,
                    }
        return False, None

    def check_block_list_domain(
        self, sni: str
    ) -> tuple[bool, Optional[dict[str, Any]]]:
        """Check if SNI matches any enabled block list domain entry.

        OPTIMIZED: Uses SQL-level matching to avoid fetching all entries.
        1. First checks for exact domain match (fast, indexed)
        2. Then checks for subdomain matches using SQL LIKE
        3. Finally checks wildcard patterns (slower, but only fetches patterns)

        Returns:
            (is_blocked, info_dict) or (False, None). info_dict has list_id, name, priority.
        """
        if not sni:
            return False, None

        sni_lower = sni.lower()
        conn = self._get_connection()
        cursor = conn.cursor()

        # Step 1: Check for exact domain match (fastest - uses COLLATE NOCASE index)
        cursor.execute(
            """
            SELECT bl.list_id, bl.name, bl.priority
            FROM block_lists bl
            JOIN block_list_entries ble ON bl.list_id = ble.list_id
            WHERE bl.enabled = 1
              AND ble.entry_type = 'domain'
              AND ble.value = ? COLLATE NOCASE
            ORDER BY bl.priority DESC
            LIMIT 1
            """,
            (sni_lower,),
        )
        row = cursor.fetchone()
        if row:
            return True, {
                "list_id": row["list_id"],
                "name": row["name"],
                "priority": row["priority"] or 7000,
            }

        # Step 2: Check if SNI is a subdomain of any blocked domain
        # Split SNI into parts and check each suffix
        # e.g., for "www.evil.example.com", check "evil.example.com", "example.com", "com"
        parts = sni_lower.split(".")
        for i in range(1, len(parts)):
            parent_domain = ".".join(parts[i:])
            cursor.execute(
                """
                SELECT bl.list_id, bl.name, bl.priority
                FROM block_lists bl
                JOIN block_list_entries ble ON bl.list_id = ble.list_id
                WHERE bl.enabled = 1
                  AND ble.entry_type = 'domain'
                  AND ble.value = ? COLLATE NOCASE
                ORDER BY bl.priority DESC
                LIMIT 1
                """,
                (parent_domain,),
            )
            row = cursor.fetchone()
            if row:
                return True, {
                    "list_id": row["list_id"],
                    "name": row["name"],
                    "priority": row["priority"] or 7000,
                }

        # Step 3: Check wildcard patterns (only fetch patterns, not all domains)
        cursor.execute(
            """
            SELECT bl.list_id, bl.name, bl.priority, ble.value
            FROM block_lists bl
            JOIN block_list_entries ble ON bl.list_id = ble.list_id
            WHERE bl.enabled = 1
              AND ble.entry_type = 'url_pattern'
              AND ble.value LIKE '%*%'
            ORDER BY bl.priority DESC
            """
        )
        for row in cursor.fetchall():
            pattern = row["value"]
            if _domain_matches_pattern(sni, pattern):
                return True, {
                    "list_id": row["list_id"],
                    "name": row["name"],
                    "priority": row["priority"] or 7000,
                }

        return False, None

    def add_ip_block_rule(
        self,
        rule_id: int,
        ip_address: Optional[str] = None,
        cidr_range: Optional[str] = None,
        direction: str = "both",
        priority: int = 7000,
        idle_timeout: int = 300,
        enabled: bool = True,
        description: Optional[str] = None,
    ) -> bool:
        """Add or update an IP block rule."""
        # Validate direction parameter
        direction = direction.lower() if direction else "both"
        if direction not in ("src", "dst", "both"):
            logger.error(
                f"Invalid direction '{direction}' for IP block rule {rule_id}. "
                f"Must be 'src', 'dst', or 'both'"
            )
            return False

        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO ip_block_rules
                (rule_id, ip_address, cidr_range, direction, priority, idle_timeout, enabled, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(rule_id) DO UPDATE SET
                    ip_address = excluded.ip_address,
                    cidr_range = excluded.cidr_range,
                    direction = excluded.direction,
                    priority = excluded.priority,
                    idle_timeout = excluded.idle_timeout,
                    enabled = excluded.enabled,
                    description = excluded.description
                """,
                (
                    rule_id,
                    ip_address,
                    cidr_range,
                    direction,
                    priority,
                    idle_timeout,
                    1 if enabled else 0,
                    description,
                ),
            )
            conn.commit()
            logger.info(f"Added/updated IP block rule {rule_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to add IP block rule {rule_id}: {e}")
            return False

    def remove_ip_block_rule(self, rule_id: int) -> bool:
        """Remove an IP block rule."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM ip_block_rules WHERE rule_id = ?", (rule_id,))
            conn.commit()
            removed = cursor.rowcount > 0
            if removed:
                logger.info(f"Removed IP block rule {rule_id}")
            return bool(removed)
        except Exception as e:
            logger.error(f"Failed to remove IP block rule {rule_id}: {e}")
            return False

    def get_all_ip_block_rule_ids(self) -> list[int]:
        """Return all IP block rule IDs (for sync cleanup)."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT rule_id FROM ip_block_rules")
        return [row["rule_id"] for row in cursor.fetchall()]

    def get_all_url_block_rule_ids(self) -> list[int]:
        """Return all URL block rule IDs (for sync cleanup)."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT rule_id FROM url_block_rules")
        return [row["rule_id"] for row in cursor.fetchall()]

    def get_all_ip_block_rules(self) -> list[IPBlockRuleRow]:
        """Return all enabled IP block rules."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT rule_id, ip_address, cidr_range, direction, priority, idle_timeout, enabled, description "
            "FROM ip_block_rules WHERE enabled = 1"
        )
        return [
            IPBlockRuleRow(
                rule_id=row["rule_id"],
                ip_address=row["ip_address"],
                cidr_range=row["cidr_range"],
                direction=row["direction"] or "both",
                priority=row["priority"] or 7000,
                idle_timeout=row["idle_timeout"] or 300,
                enabled=bool(row["enabled"]),
                description=row["description"],
            )
            for row in cursor.fetchall()
        ]

    def sync_ip_block_rules(self, rules: list[IPBlockRuleRow]) -> bool:
        """Replace all IP block rules with the given list."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM ip_block_rules")
            for r in rules:
                cursor.execute(
                    """
                    INSERT INTO ip_block_rules
                    (rule_id, ip_address, cidr_range, direction, priority, idle_timeout, enabled, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        r.rule_id,
                        r.ip_address,
                        r.cidr_range,
                        r.direction,
                        r.priority,
                        r.idle_timeout,
                        1 if r.enabled else 0,
                        r.description,
                    ),
                )
            conn.commit()
            logger.info(f"Synced {len(rules)} IP block rules")
            return True
        except Exception as e:
            logger.error(f"Failed to sync IP block rules: {e}")
            conn.rollback()
            return False

    def add_url_block_rule(
        self,
        rule_id: int,
        domain: Optional[str] = None,
        domain_pattern: Optional[str] = None,
        match_subdomains: bool = True,
        priority: int = 7000,
        idle_timeout: int = 300,
        enabled: bool = True,
        description: Optional[str] = None,
    ) -> bool:
        """Add or update a URL block rule."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO url_block_rules
                (rule_id, domain, domain_pattern, match_subdomains, priority, idle_timeout, enabled, description)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(rule_id) DO UPDATE SET
                    domain = excluded.domain,
                    domain_pattern = excluded.domain_pattern,
                    match_subdomains = excluded.match_subdomains,
                    priority = excluded.priority,
                    idle_timeout = excluded.idle_timeout,
                    enabled = excluded.enabled,
                    description = excluded.description
                """,
                (
                    rule_id,
                    domain,
                    domain_pattern,
                    1 if match_subdomains else 0,
                    priority,
                    idle_timeout,
                    1 if enabled else 0,
                    description,
                ),
            )
            conn.commit()
            logger.info(f"Added/updated URL block rule {rule_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to add URL block rule {rule_id}: {e}")
            return False

    def remove_url_block_rule(self, rule_id: int) -> bool:
        """Remove a URL block rule."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM url_block_rules WHERE rule_id = ?", (rule_id,))
            conn.commit()
            removed = cursor.rowcount > 0
            if removed:
                logger.info(f"Removed URL block rule {rule_id}")
            return bool(removed)
        except Exception as e:
            logger.error(f"Failed to remove URL block rule {rule_id}: {e}")
            return False

    def get_all_url_block_rules(self) -> list[URLBlockRuleRow]:
        """Return all enabled URL block rules."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT rule_id, domain, domain_pattern, match_subdomains, priority, idle_timeout, enabled, description
            FROM url_block_rules WHERE enabled = 1
            """
        )
        return [
            URLBlockRuleRow(
                rule_id=row["rule_id"],
                domain=row["domain"],
                domain_pattern=row["domain_pattern"],
                match_subdomains=bool(row["match_subdomains"]),
                priority=row["priority"] or 7000,
                idle_timeout=row["idle_timeout"] or 300,
                enabled=bool(row["enabled"]),
                description=row["description"],
            )
            for row in cursor.fetchall()
        ]

    def sync_url_block_rules(self, rules: list[URLBlockRuleRow]) -> bool:
        """Replace all URL block rules with the given list."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM url_block_rules")
            for r in rules:
                cursor.execute(
                    """
                    INSERT INTO url_block_rules
                    (rule_id, domain, domain_pattern, match_subdomains, priority, idle_timeout, enabled, description)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        r.rule_id,
                        r.domain,
                        r.domain_pattern,
                        1 if r.match_subdomains else 0,
                        r.priority,
                        r.idle_timeout,
                        1 if r.enabled else 0,
                        r.description,
                    ),
                )
            conn.commit()
            logger.info(f"Synced {len(rules)} URL block rules")
            return True
        except Exception as e:
            logger.error(f"Failed to sync URL block rules: {e}")
            conn.rollback()
            return False

    def add_or_update_block_list(
        self,
        list_id: int,
        name: str,
        enabled: bool = False,
        priority: int = 7000,
        ip_entries: Optional[list[str]] = None,
        domain_entries: Optional[list[str]] = None,
    ) -> bool:
        """Add or update a block list and its entries."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                """
                INSERT INTO block_lists (list_id, name, enabled, priority)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(list_id) DO UPDATE SET
                    name = excluded.name,
                    enabled = excluded.enabled,
                    priority = excluded.priority
                """,
                (list_id, name, 1 if enabled else 0, priority),
            )
            cursor.execute(
                "DELETE FROM block_list_entries WHERE list_id = ?", (list_id,)
            )
            ip_entries = ip_entries or []
            domain_entries = domain_entries or []
            for v in ip_entries:
                entry_type = "ip_range" if "/" in v else "ip"
                cursor.execute(
                    "INSERT INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                    (list_id, entry_type, v),
                )
            for v in domain_entries:
                entry_type = "url_pattern" if "*" in v else "domain"
                cursor.execute(
                    "INSERT INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                    (list_id, entry_type, v),
                )
            conn.commit()
            logger.info(f"Added/updated block list {list_id} ({name})")
            return True
        except Exception as e:
            logger.error(f"Failed to add/update block list {list_id}: {e}")
            conn.rollback()
            return False

    def remove_block_list(self, list_id: int) -> bool:
        """Disable and remove a block list and its entries."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            # Delete entries first (CASCADE will handle this, but explicit for clarity)
            cursor.execute(
                "DELETE FROM block_list_entries WHERE list_id = ?", (list_id,)
            )
            cursor.execute("DELETE FROM block_lists WHERE list_id = ?", (list_id,))
            conn.commit()
            logger.info(f"Removed block list {list_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove block list {list_id}: {e}")
            conn.rollback()
            return False

    def add_block_list_entries(
        self,
        list_id: int,
        ip_entries: Optional[list[str]] = None,
        domain_entries: Optional[list[str]] = None,
    ) -> bool:
        """Add entries to an existing block list. Skips duplicates."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            # Verify block list exists
            cursor.execute(
                "SELECT list_id FROM block_lists WHERE list_id = ?", (list_id,)
            )
            if cursor.fetchone() is None:
                logger.error(
                    f"Cannot add entries: block list {list_id} does not exist"
                )
                return False

            ip_entries = ip_entries or []
            domain_entries = domain_entries or []
            for v in ip_entries:
                entry_type = "ip_range" if "/" in v else "ip"
                cursor.execute(
                    "INSERT OR IGNORE INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                    (list_id, entry_type, v),
                )
            for v in domain_entries:
                entry_type = "url_pattern" if "*" in v else "domain"
                cursor.execute(
                    "INSERT OR IGNORE INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                    (list_id, entry_type, v),
                )
            conn.commit()
            logger.info(
                f"Added entries to block list {list_id}: "
                f"{len(ip_entries)} IP, {len(domain_entries)} domain"
            )
            return True
        except Exception as e:
            logger.error(f"Failed to add entries to block list {list_id}: {e}")
            conn.rollback()
            return False

    def remove_block_list_entries(
        self,
        list_id: int,
        ip_entries: Optional[list[str]] = None,
        domain_entries: Optional[list[str]] = None,
    ) -> bool:
        """Remove specific entries from an existing block list."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            ip_entries = ip_entries or []
            domain_entries = domain_entries or []
            all_values = ip_entries + domain_entries
            if not all_values:
                return True
            placeholders = ",".join("?" for _ in all_values)
            cursor.execute(
                f"DELETE FROM block_list_entries WHERE list_id = ? AND value IN ({placeholders})",
                [list_id] + all_values,
            )
            conn.commit()
            logger.info(
                f"Removed entries from block list {list_id}: "
                f"{len(ip_entries)} IP, {len(domain_entries)} domain "
                f"({cursor.rowcount} rows deleted)"
            )
            return True
        except Exception as e:
            logger.error(f"Failed to remove entries from block list {list_id}: {e}")
            conn.rollback()
            return False

    def block_list_exists(self, list_id: int) -> bool:
        """Check if a block list exists in the cache."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT list_id FROM block_lists WHERE list_id = ?", (list_id,)
        )
        return cursor.fetchone() is not None

    def is_block_list_enabled(self, list_id: int) -> bool:
        """Check if a block list is enabled."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT enabled FROM block_lists WHERE list_id = ?", (list_id,)
        )
        row = cursor.fetchone()
        return bool(row["enabled"]) if row else False

    def get_block_list_entries(self, list_id: int) -> tuple[list[str], list[str]]:
        """Return (ip_entries, domain_entries) for a block list."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT entry_type, value FROM block_list_entries WHERE list_id = ?",
            (list_id,),
        )
        ip_entries = []
        domain_entries = []
        for row in cursor.fetchall():
            t, v = row["entry_type"], row["value"]
            if t in ("ip", "ip_range"):
                ip_entries.append(v)
            else:
                domain_entries.append(v)
        return (ip_entries, domain_entries)

    def get_all_block_list_ids(self) -> list[int]:
        """Return all block list IDs (for sync cleanup)."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT list_id FROM block_lists")
        return [row["list_id"] for row in cursor.fetchall()]

    def sync_block_lists(
        self,
        lists: list[tuple[BlockListRow, list[str], list[str]]],
    ) -> bool:
        """Replace all block lists. Each item is (BlockListRow, ip_entries, domain_entries)."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM block_list_entries")
            cursor.execute("DELETE FROM block_lists")
            for bl, ip_entries, domain_entries in lists:
                cursor.execute(
                    "INSERT INTO block_lists (list_id, name, enabled, priority) VALUES (?, ?, ?, ?)",
                    (bl.list_id, bl.name, 1 if bl.enabled else 0, bl.priority),
                )
                for v in ip_entries:
                    entry_type = "ip_range" if "/" in v else "ip"
                    cursor.execute(
                        "INSERT INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                        (bl.list_id, entry_type, v),
                    )
                for v in domain_entries:
                    entry_type = "url_pattern" if "*" in v else "domain"
                    cursor.execute(
                        "INSERT INTO block_list_entries (list_id, entry_type, value) VALUES (?, ?, ?)",
                        (bl.list_id, entry_type, v),
                    )
            conn.commit()
            logger.info(f"Synced {len(lists)} block lists")
            return True
        except Exception as e:
            logger.error(f"Failed to sync block lists: {e}")
            conn.rollback()
            return False

    # =========================================================================
    # Meter Registry Operations (for meter reuse)
    # =========================================================================

    def find_meter_by_rate(self, rate_kbps: int, burst_kbps: int = 0) -> Optional[int]:
        """Find an existing meter with the specified rate and burst.

        Args:
            rate_kbps: Rate limit in kbps
            burst_kbps: Burst size in kbps (default 0)

        Returns:
            meter_id if found, None otherwise
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT meter_id FROM meters
            WHERE rate_kbps = ? AND burst_kbps = ?
            LIMIT 1
        """,
            (rate_kbps, burst_kbps),
        )

        row = cursor.fetchone()
        if row:
            return row["meter_id"]
        return None

    def register_meter(
        self, meter_id: int, bridge_name: str, rate_kbps: int, burst_kbps: int = 0
    ) -> bool:
        """Register a meter in the registry.

        Args:
            meter_id: OVS meter ID
            bridge_name: Name of the OVS bridge
            rate_kbps: Rate limit in kbps
            burst_kbps: Burst size in kbps

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                INSERT INTO meters (meter_id, bridge_name, rate_kbps, burst_kbps, reference_count)
                VALUES (?, ?, ?, ?, 1)
                ON CONFLICT(meter_id) DO UPDATE SET
                    bridge_name = excluded.bridge_name,
                    rate_kbps = excluded.rate_kbps,
                    burst_kbps = excluded.burst_kbps
            """,
                (meter_id, bridge_name, rate_kbps, burst_kbps),
            )
            conn.commit()
            logger.debug(f"Registered meter {meter_id} ({rate_kbps} kbps)")
            return True
        except Exception as e:
            logger.error(f"Failed to register meter {meter_id}: {e}")
            return False

    def increment_meter_refs(self, meter_id: int) -> bool:
        """Increment the reference count for a meter.

        Args:
            meter_id: OVS meter ID

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                """
                UPDATE meters SET reference_count = reference_count + 1
                WHERE meter_id = ?
            """,
                (meter_id,),
            )
            conn.commit()
            if cursor.rowcount > 0:
                logger.debug(f"Incremented refs for meter {meter_id}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to increment meter refs: {e}")
            return False

    def decrement_meter_refs(self, meter_id: int) -> bool:
        """Decrement the reference count for a meter.

        This operation is atomic: uses BEGIN IMMEDIATE to acquire an exclusive
        lock before decrementing, ensuring no race between the UPDATE and
        potential DELETE.

        Args:
            meter_id: OVS meter ID

        Returns:
            True if meter can be deleted (reference_count reached 0)
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            # Use BEGIN IMMEDIATE to acquire write lock before reading/updating
            # This prevents race conditions between concurrent decrements
            cursor.execute("BEGIN IMMEDIATE")

            # Decrement reference count and read new value in one transaction
            cursor.execute(
                """
                UPDATE meters SET reference_count = reference_count - 1
                WHERE meter_id = ? AND reference_count > 0
            """,
                (meter_id,),
            )

            if cursor.rowcount == 0:
                cursor.execute("COMMIT")
                return False

            # Check the new reference count
            cursor.execute(
                "SELECT reference_count FROM meters WHERE meter_id = ?",
                (meter_id,),
            )
            row = cursor.fetchone()
            new_count = row["reference_count"] if row else None

            # Delete if reference count reached 0
            deleted = False
            if new_count is not None and new_count <= 0:
                cursor.execute(
                    "DELETE FROM meters WHERE meter_id = ?",
                    (meter_id,),
                )
                deleted = cursor.rowcount > 0

            cursor.execute("COMMIT")

            if deleted:
                logger.debug(
                    f"Meter {meter_id} has no more references, removed from registry"
                )
            else:
                logger.debug(f"Decremented refs for meter {meter_id}")
            return deleted
        except Exception as e:
            try:
                cursor.execute("ROLLBACK")
            except Exception:
                pass
            logger.error(f"Failed to decrement meter refs: {e}")
            return False

    def get_next_available_meter_id(self) -> int:
        """Get the next available meter ID (fills gaps in sequence).

        Returns:
            Next available meter ID (starting from 1)
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        # Find gaps in the sequence
        cursor.execute(
            """
            SELECT meter_id + 1 as next_id
            FROM meters m1
            WHERE NOT EXISTS (
                SELECT 1 FROM meters m2 WHERE m2.meter_id = m1.meter_id + 1
            )
            ORDER BY meter_id
            LIMIT 1
        """
        )

        row = cursor.fetchone()
        if row:
            return row["next_id"]

        # No gaps found, check if table is empty
        cursor.execute("SELECT MAX(meter_id) as max_id FROM meters")
        row = cursor.fetchone()

        if row and row["max_id"] is not None:
            return row["max_id"] + 1

        # Table is empty, start from 1
        return 1

    def get_all_registered_meters(self) -> list[dict]:
        """Get all registered meters.

        Returns:
            List of meter dictionaries with meter_id, bridge_name, rate_kbps, burst_kbps, reference_count
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT meter_id, bridge_name, rate_kbps, burst_kbps, reference_count
            FROM meters
            ORDER BY meter_id
        """
        )

        return [
            {
                "meter_id": row["meter_id"],
                "bridge_name": row["bridge_name"],
                "rate_kbps": row["rate_kbps"],
                "burst_kbps": row["burst_kbps"],
                "reference_count": row["reference_count"],
            }
            for row in cursor.fetchall()
        ]

    def get_meter_info(self, meter_id: int) -> Optional[dict]:
        """Get information about a specific meter.

        Args:
            meter_id: OVS meter ID

        Returns:
            Meter dict or None if not found
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT meter_id, bridge_name, rate_kbps, burst_kbps, reference_count
            FROM meters WHERE meter_id = ?
        """,
            (meter_id,),
        )

        row = cursor.fetchone()
        if row:
            return {
                "meter_id": row["meter_id"],
                "bridge_name": row["bridge_name"],
                "rate_kbps": row["rate_kbps"],
                "burst_kbps": row["burst_kbps"],
                "reference_count": row["reference_count"],
            }
        return None

    def clear_meter_registry(self) -> bool:
        """Clear all meters from the registry.

        Returns:
            True if successful
        """
        conn = self._get_connection()
        cursor = conn.cursor()

        try:
            cursor.execute("DELETE FROM meters")
            conn.commit()
            logger.info("Cleared meter registry")
            return True
        except Exception as e:
            logger.error(f"Failed to clear meter registry: {e}")
            return False

    def close(self):
        """Close the database connection."""
        if hasattr(self._local, "connection") and self._local.connection:
            self._local.connection.close()
            self._local.connection = None
