"""OVS (Open vSwitch) management module.

This module provides OVS control functionality for the Axon Agent,
including meter management, flow control, and other OVS operations.
The OVS agent can be run as a standalone script via:
    python -m axon_agent.ovs.agent

To avoid RuntimeWarnings when running the agent as a standalone script,
imports are done lazily via __getattr__. Import directly from submodules:
    from axon_agent.ovs.agent import start_ovs_agent_process
    from axon_agent.ovs.agent import stop_ovs_agent
"""

__all__ = [
    "start_ovs_agent_process",
    "stop_ovs_agent",
    "OVSAgent",
]


def __getattr__(name: str):
    """Lazy import to avoid RuntimeWarning when running agent as script."""
    if name == "start_ovs_agent_process":
        from .agent import start_ovs_agent_process

        return start_ovs_agent_process
    elif name == "stop_ovs_agent":
        from .agent import stop_ovs_agent

        return stop_ovs_agent
    elif name == "OVSAgent":
        from .agent import OVSAgent

        return OVSAgent
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
