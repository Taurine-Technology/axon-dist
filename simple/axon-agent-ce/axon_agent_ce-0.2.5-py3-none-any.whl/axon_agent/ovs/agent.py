"""OVS Agent - handles OVS commands via MQTT.

This agent subscribes to OVS control topics (meters, flows, etc.), executes
corresponding OVS operations, and publishes responses back to the controller.

Run as standalone:
    python -m axon_agent.ovs.agent
"""

import hashlib
import ipaddress
import logging
import os
import subprocess
import sys
import time
from typing import List, Optional, Tuple

import psutil

from ..base_agent import BaseAgent
from ..health_check.ovs_state import get_meters
from ..policy_cache import (
    BlockListRow,
    BlockRule,
    IPBlockRuleRow,
    PolicyCache,
    RateLimitRule,
    TimeConstraint,
    URLBlockRuleRow,
)
from ..time_enforcer import TimeConstraintEnforcer
from ..utils import (
    stop_systemd_service,
    disable_systemd_service,
    enable_systemd_service,
    start_systemd_service,
    restart_systemd_service,
)
from ..classifier.config_handler import ClassifierConfigHandler
from axon_shared.proto.meter_messages_pb2 import (
    MeterAction,
    MeterCommand,
    MeterResponse,
    MeterResponseSource,
    MeterResponseStatus,
    MeterType,
)
from axon_shared.proto.flow_mod_messages_pb2 import (
    FlowModAction,
    FlowModCommand,
    FlowModResponse,
    FlowModResponseStatus,
)
from axon_shared.proto.bridge_messages_pb2 import (
    BridgeAction,
    BridgeCommand,
    BridgeResponse,
    BridgeResponseStatus,
)
from axon_shared.mqtt.topics import control_topic as build_control_topic
from ..ovs_bridge import OVSBridgeManager
from ..bridge_utils import delete_bridge_and_cleanup
from ..monitoring.port_stats_monitor import start_port_stats_monitoring_process
from ..monitoring.port_link_monitor import start_port_link_monitoring_process

# Try to import policy protobuf messages (may not be compiled yet)
try:
    from axon_shared.proto.policy_messages_pb2 import (
        BlockListEntryUpdate,
        BlockListSync,
        Direction,
        IPBlockRule,
        PolicyAction,
        PolicyResponse,
        PolicyResponseStatus,
        PolicyRuleStatus,
        PolicySync,
        PolicyUpdate,
        URLBlockRule,
    )

    POLICY_PROTOBUF_AVAILABLE = True
except ImportError:
    POLICY_PROTOBUF_AVAILABLE = False
    BlockListEntryUpdate = None
    BlockListSync = None
    Direction = None
    IPBlockRule = None
    PolicySync = None
    URLBlockRule = None

# Try to import zstandard for decompression
try:
    import zstandard as zstd

    ZSTD_AVAILABLE = True
except ImportError:
    zstd = None
    ZSTD_AVAILABLE = False

logger = logging.getLogger(__name__)

# Maximum decompressed size to prevent decompression bombs (10 MB)
MAX_ZSTD_DECOMPRESSED_SIZE = 10 * 1024 * 1024

# Cookie namespace for agent-installed IP block / block list flows (del-flows by cookie)
COOKIE_IP_BLOCK_MASK = 0x0A01000000000000
COOKIE_BLOCK_LIST_MASK = 0x0A02000000000000

# Interval (seconds) for periodic meter integrity checks
METER_WATCHDOG_INTERVAL = 60


def _direction_to_str(direction) -> str:
    """Map Direction enum (0=both, 1=src, 2=dst) to 'src'|'dst'|'both'."""
    if direction is None:
        return "both"
    d = int(direction) if hasattr(direction, "__int__") else direction
    if d == 1:
        return "src"
    if d == 2:
        return "dst"
    return "both"


class OVSAgent(BaseAgent):
    """Agent that handles OVS commands (meters, flows, etc.) via MQTT."""

    agent_name = "OVS Agent"
    mqtt_client_id_suffix = "ovs-meter"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 10.0
    use_counted_retries = True

    def __init__(self):
        """Initialize OVS Agent."""
        super().__init__()

        # OVS bridge name for meter operations
        self.bridge_name: Optional[str] = None

        # MQTT topic patterns
        self.meter_topic_pattern: Optional[str] = None
        self.flow_mod_topic_pattern: Optional[str] = None
        self.policy_topic_pattern: Optional[str] = None
        self.bridge_topic_pattern: Optional[str] = None

        # Policy cache for blocklist/rate limits
        self.policy_cache: Optional[PolicyCache] = None

        # Time constraint enforcer for time-based rule enforcement
        self.time_enforcer: Optional[TimeConstraintEnforcer] = None

        # Classifier configuration handler
        self.classifier_config_handler: Optional[ClassifierConfigHandler] = None

        # Message deduplication: track processed messages to prevent duplicate processing
        # Key: (topic, payload_hash), Value: timestamp
        self._processed_messages: dict[tuple[str, int], float] = {}
        self._dedup_window = 10.0  # seconds - ignore duplicates within this window
        self._dedup_message_count = 0  # Counter for cleanup scheduling
        self._dedup_cleanup_interval = 100  # Run cleanup every N messages
        self._dedup_max_entries = 1000  # Max entries before forced cleanup

    def _load_service_config(self, config: dict) -> bool:
        """Load OVS-specific configuration from device config.

        Args:
            config: Full config.json dictionary

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        # Build MQTT topic pattern for meter commands
        # Subscribe to: axon/control/{site_id}/{device_id}/meter/+
        self.meter_topic_pattern = build_control_topic(self.site_id, self.device_id, "meter/+")

        # Build MQTT topic pattern for flow mod commands
        # Subscribe to: axon/control/{site_id}/{device_id}/flow_mod/+
        self.flow_mod_topic_pattern = build_control_topic(self.site_id, self.device_id, "flow_mod/+")

        # Build MQTT topic pattern for policy commands
        # Subscribe to: axon/control/{site_id}/{device_id}/policy/#
        self.policy_topic_pattern = build_control_topic(self.site_id, self.device_id, "policy/#")

        # Build MQTT topic pattern for bridge commands
        # Subscribe to: axon/control/{site_id}/{device_id}/bridge/+
        self.bridge_topic_pattern = build_control_topic(self.site_id, self.device_id, "bridge/+")

        # Load bridge name from bridge_configs (for meter operations)
        bridge_configs = config.get("bridge_configs", {})
        if bridge_configs:
            first_bridge = next(iter(bridge_configs.values()))
            self.bridge_name = first_bridge.get("bridge_name")
        else:
            self.bridge_name = None
        if not self.bridge_name:
            logger.warning(
                "No bridge_name in config - meter auto-creation disabled"
            )

        # Initialize policy cache
        self.policy_cache = PolicyCache()

        # Sync meter registry with existing OVS meters and rate limits
        self._sync_meter_registry()

        logger.info(
            f"Loaded config: device_id={self.device_id}, site_id={self.site_id}, "
            f"bridge_name={self.bridge_name}"
        )
        return True

    def _meter_exists(self, bridge_name: str, meter_id: int) -> bool:
        """Check if a meter exists on the bridge.

        Args:
            bridge_name: Name of the OVS bridge
            meter_id: Meter ID to check

        Returns:
            True if meter exists, False otherwise
        """
        try:
            result = subprocess.run(
                ["ovs-ofctl", "dump-meters", bridge_name, "-OOpenflow13"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                logger.warning(
                    f"Failed to dump meters for bridge {bridge_name}: {result.stderr}"
                )
                return False

            # Look for meter={meter_id} in the output
            search_pattern = f"meter={meter_id}"
            return search_pattern in result.stdout

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout checking meter {meter_id} on bridge {bridge_name}")
            return False
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found. Is Open vSwitch installed?")
            return False
        except Exception as e:
            logger.error(f"Error checking meter existence: {e}")
            return False

    def _add_meter(
        self, bridge_name: str, meter_id: int, rate: int, burst_size: int
    ) -> Tuple[bool, str]:
        """Add a meter to the OVS bridge.

        Args:
            bridge_name: Name of the OVS bridge
            meter_id: Unique meter ID
            rate: Rate limit in kbps
            burst_size: Burst size in kbits (0 for non-burst meter)

        Returns:
            Tuple of (success, message)
        """
        try:
            # Build OVS command based on burst_size
            if burst_size > 0:
                # Burst meter
                cmd = [
                    "ovs-ofctl",
                    "add-meter",
                    bridge_name,
                    f"meter={meter_id},kbps,burst,band=type=drop,rate={rate},burst_size={burst_size}",
                    "-OOpenflow13",
                ]
            else:
                # Non-burst meter
                cmd = [
                    "ovs-ofctl",
                    "add-meter",
                    bridge_name,
                    f"meter={meter_id},kbps,band=type=drop,rate={rate}",
                    "-OOpenflow13",
                ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                if burst_size > 0:
                    logger.info(
                        f"Created burst meter {meter_id} on bridge {bridge_name} "
                        f"(rate={rate}kbps, burst={burst_size}kbits)"
                    )
                else:
                    logger.info(
                        f"Created non-burst meter {meter_id} on bridge {bridge_name} "
                        f"(rate={rate}kbps)"
                    )
                return True, f"Meter {meter_id} created on {bridge_name}"
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to create meter {meter_id}: {error_msg}")
                return False, f"Failed to create meter: {error_msg}"

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout creating meter {meter_id} on bridge {bridge_name}")
            return False, "Timeout executing OVS command"
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?"
        except Exception as e:
            logger.error(f"Error creating meter: {e}")
            return False, f"Error: {str(e)}"

    def _delete_meter(self, bridge_name: str, meter_id: int) -> Tuple[bool, str]:
        """Delete a meter from the OVS bridge.

        Args:
            bridge_name: Name of the OVS bridge
            meter_id: Meter ID to delete

        Returns:
            Tuple of (success, message)
        """
        try:
            cmd = [
                "ovs-ofctl",
                "del-meter",
                bridge_name,
                f"meter={meter_id}",
                "-OOpenflow13",
            ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                logger.info(f"Deleted meter {meter_id} from bridge {bridge_name}")
                return True, f"Meter {meter_id} deleted from {bridge_name}"
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to delete meter {meter_id}: {error_msg}")
                return False, f"Failed to delete meter: {error_msg}"

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout deleting meter {meter_id} from bridge {bridge_name}")
            return False, "Timeout executing OVS command"
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?"
        except Exception as e:
            logger.error(f"Error deleting meter: {e}")
            return False, f"Error: {str(e)}"

    def _modify_meter(
        self, bridge_name: str, meter_id: int, rate: int, burst_size: int
    ) -> Tuple[bool, str]:
        """Modify an existing meter on the OVS bridge.

        Args:
            bridge_name: Name of the OVS bridge
            meter_id: Meter ID to modify
            rate: New rate limit in kbps
            burst_size: New burst size in kbits (0 for non-burst meter)

        Returns:
            Tuple of (success, message)
        """
        try:
            # Build OVS command based on burst_size
            if burst_size > 0:
                # Burst meter
                cmd = [
                    "ovs-ofctl",
                    "mod-meter",
                    bridge_name,
                    f"meter={meter_id},kbps,burst,band=type=drop,rate={rate},burst_size={burst_size}",
                    "-OOpenflow13",
                ]
            else:
                # Non-burst meter
                cmd = [
                    "ovs-ofctl",
                    "mod-meter",
                    bridge_name,
                    f"meter={meter_id},kbps,band=type=drop,rate={rate}",
                    "-OOpenflow13",
                ]

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                if burst_size > 0:
                    logger.info(
                        f"Modified meter {meter_id} on bridge {bridge_name} "
                        f"(rate={rate}kbps, burst={burst_size}kbits)"
                    )
                else:
                    logger.info(
                        f"Modified meter {meter_id} on bridge {bridge_name} "
                        f"(rate={rate}kbps, no burst)"
                    )
                return True, f"Meter {meter_id} modified on {bridge_name}"
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to modify meter {meter_id}: {error_msg}")
                return False, f"Failed to modify meter: {error_msg}"

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout modifying meter {meter_id} on bridge {bridge_name}")
            return False, "Timeout executing OVS command"
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?"
        except Exception as e:
            logger.error(f"Error modifying meter: {e}")
            return False, f"Error: {str(e)}"

    def _verify_meter_exists_in_ovs(self, meter_id: int) -> bool:
        """Check if a specific meter exists in OVS.

        Args:
            meter_id: OVS meter ID to verify

        Returns:
            True if meter exists in OVS, False otherwise
        """
        if not self.bridge_name:
            logger.warning("Bridge name not configured - cannot verify meter")
            return False

        ovs_meters, err = get_meters(self.bridge_name)
        if err:
            logger.warning(f"Failed to query OVS meters for verification: {err}")
            return False

        for meter in ovs_meters:
            if meter.meter_id == meter_id:
                return True

        return False

    def _ensure_meter_for_rate(
        self, rate_kbps: int, burst_kbps: int = 0
    ) -> Optional[int]:
        """Find or create a meter with the specified rate.

        This method implements meter reuse: if a meter with the same rate
        already exists, it will be reused. Otherwise, a new meter is created.

        Args:
            rate_kbps: Rate limit in kbps
            burst_kbps: Burst size in kbps (default 0)

        Returns:
            meter_id if successful, None if failed
        """
        if not self.policy_cache:
            logger.error("Policy cache not initialized")
            return None

        if not self.bridge_name:
            logger.error("Bridge name not configured - cannot create meters")
            return None

        # Step 1: Check if we have a meter with this rate in the registry
        existing_meter_id = self.policy_cache.find_meter_by_rate(rate_kbps, burst_kbps)
        if existing_meter_id is not None:
            logger.info(
                f"Reusing existing meter {existing_meter_id} for rate {rate_kbps} kbps"
            )
            self.policy_cache.increment_meter_refs(existing_meter_id)
            return existing_meter_id

        # Step 2: Query OVS for existing meters (may have been created externally)
        ovs_meters, err = get_meters(self.bridge_name)
        if err:
            logger.warning(f"Failed to query OVS meters: {err}")
        else:
            # Check if any OVS meter matches our rate
            for meter in ovs_meters:
                logger.info(
                    f"Checking OVS meter {meter.meter_id} for rate {rate_kbps} kbps"
                )
                logger.info(
                    f"OVS meter rate: {meter.rate}, OVS meter burst size: {meter.burst_size}"
                )
                logger.info(f"Rate: {rate_kbps}, Burst size: {burst_kbps}")
                if meter.rate == rate_kbps and (meter.burst_size or 0) == burst_kbps:
                    # Found matching meter in OVS, register and use it
                    meter_id = meter.meter_id
                    # Check if meter already exists in cache (race condition guard)
                    existing_info = self.policy_cache.get_meter_info(meter_id)
                    if existing_info is not None:
                        # Meter was registered by another thread, increment refs
                        self.policy_cache.increment_meter_refs(meter_id)
                        logger.info(
                            f"Meter {meter_id} already in cache, incremented refs"
                        )
                    else:
                        # Register new meter with ref count of 1
                        self.policy_cache.register_meter(
                            meter_id, self.bridge_name, rate_kbps, burst_kbps
                        )
                    logger.info(
                        f"Found existing OVS meter {meter_id} for rate {rate_kbps} kbps"
                    )
                    return meter_id

        # Step 3: No existing meter found, create a new one
        new_meter_id = self.policy_cache.get_next_available_meter_id()

        # Create the meter in OVS
        success, message = self._add_meter(
            self.bridge_name, new_meter_id, rate_kbps, burst_kbps
        )

        if not success:
            # Check if the error is METER_EXISTS - the meter exists in OVS
            # but wasn't found in our cache (e.g., after restart or cache clear)
            if "METER_EXISTS" in message:
                logger.info(
                    f"Meter {new_meter_id} already exists in OVS, checking compatibility"
                )
                # Query OVS to get the existing meter's settings
                existing_meters, err = get_meters(self.bridge_name)
                if not err:
                    for meter in existing_meters:
                        if meter.meter_id == new_meter_id:
                            if (
                                meter.rate == rate_kbps
                                and (meter.burst_size or 0) == burst_kbps
                            ):
                                # Rate matches - register and use this meter
                                logger.info(
                                    f"Existing meter {new_meter_id} has matching rate "
                                    f"{rate_kbps} kbps, reusing it"
                                )
                                self.policy_cache.register_meter(
                                    new_meter_id,
                                    self.bridge_name,
                                    rate_kbps,
                                    burst_kbps,
                                )
                                return new_meter_id
                            else:
                                # Rate doesn't match - try to modify the meter
                                logger.info(
                                    f"Meter {new_meter_id} exists with rate {meter.rate} "
                                    f"kbps, modifying to {rate_kbps} kbps"
                                )
                                mod_success, mod_msg = self._modify_meter(
                                    self.bridge_name,
                                    new_meter_id,
                                    rate_kbps,
                                    burst_kbps,
                                )
                                if mod_success:
                                    self.policy_cache.register_meter(
                                        new_meter_id,
                                        self.bridge_name,
                                        rate_kbps,
                                        burst_kbps,
                                    )
                                    return new_meter_id
                                else:
                                    logger.error(
                                        f"Failed to modify meter {new_meter_id}: {mod_msg}"
                                    )
                            break
            logger.error(f"Failed to create meter {new_meter_id}: {message}")
            return None

        # Register the new meter
        self.policy_cache.register_meter(
            new_meter_id, self.bridge_name, rate_kbps, burst_kbps
        )
        logger.info(f"Created new meter {new_meter_id} for rate {rate_kbps} kbps")

        return new_meter_id

    def _get_rate_info_for_meter(
        self, meter_id: int, rate_limits: list
    ) -> Optional[Tuple[int, int]]:
        """Find rate/burst info for a meter from rate limit rules.

        Args:
            meter_id: Meter ID to look up
            rate_limits: List of RateLimitRule objects

        Returns:
            Tuple of (rate_kbps, burst_kbps) or None if not found
        """
        for rule in rate_limits:
            if rule.meter_id == meter_id:
                return (rule.rate_kbps, rule.burst_kbps or 0)
        return None

    def _recover_meter(self, bridge_name: str, meter_id: int) -> bool:
        """Attempt to recreate a missing meter from policy cache info.

        Args:
            bridge_name: OVS bridge name
            meter_id: Missing meter ID

        Returns:
            True if meter was successfully recreated
        """
        if not self.policy_cache:
            return False

        # First check the meter registry for rate info
        rate_limits = self.policy_cache.get_all_rate_limits()
        meter_info = self.policy_cache.get_meter_info(meter_id)
        if meter_info:
            rate_kbps = meter_info["rate_kbps"]
            burst_kbps = meter_info["burst_kbps"]
        else:
            # Fall back to scanning rate limit rules
            rule_info = self._get_rate_info_for_meter(meter_id, rate_limits)
            if not rule_info:
                logger.warning(
                    f"No rate info found for meter {meter_id}, cannot recover"
                )
                return False
            rate_kbps, burst_kbps = rule_info

        success, msg = self._add_meter(bridge_name, meter_id, rate_kbps, burst_kbps)
        if success:
            # Ensure it's registered in the cache
            if not meter_info:
                self.policy_cache.register_meter(
                    meter_id, bridge_name, rate_kbps, burst_kbps
                )
            logger.info(
                f"Recovered missing meter {meter_id} "
                f"({rate_kbps} kbps) on {bridge_name}"
            )
            self._notify_meter_recovery([meter_id], rate_limits)
            return True
        else:
            # If meter already exists (race condition), that's fine
            if "METER_EXISTS" in msg:
                logger.info(
                    f"Meter {meter_id} already exists in OVS (concurrent recovery)"
                )
                return True
            logger.error(f"Failed to recover meter {meter_id}: {msg}")
            return False

    def _notify_meter_recovery(self, recovered_meter_ids: list, rate_limits: list) -> None:
        """Notify backend that meters were self-healed by publishing MeterResponses.

        Uses METER_ACTION_CREATE responses so the backend's MeterResponseHandler
        processes them identically to controller-initiated creates.
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.debug(
                "MQTT not connected, skipping meter recovery notification"
            )
            return

        for meter_id in recovered_meter_ids:
            response = MeterResponse()
            response.status = MeterResponseStatus.METER_RESPONSE_STATUS_SUCCESS
            response.meter_id = meter_id
            response.bridge_name = self.bridge_name or ""
            response.message = f"Meter {meter_id} self-healed by agent"
            response.action = MeterAction.METER_ACTION_CREATE
            response.timestamp_ms = int(time.time() * 1000)
            response.source = MeterResponseSource.METER_RESPONSE_SOURCE_AGENT_SELF_HEAL
            rate_info = self._get_rate_info_for_meter(meter_id, rate_limits)
            if rate_info:
                response.rate = rate_info[0]
                response.burst_size = rate_info[1]
            response.meter_type = MeterType.METER_TYPE_DROP

            response_topic = build_control_topic(
                self.site_id, self.device_id, "meter/create/response"
            )
            payload = response.SerializeToString()
            self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        logger.info(
            f"Notified backend of {len(recovered_meter_ids)} self-healed meter(s)"
        )

    def _sync_meter_registry(self) -> None:
        """Sync the meter registry with OVS and existing rate limits.

        This is called on startup to ensure the registry reflects the actual
        state of meters in OVS and the rate limits in the policy cache.
        """
        if not self.policy_cache:
            logger.warning("Policy cache not initialized, skipping meter sync")
            return

        if not self.bridge_name:
            logger.debug("No bridge configured, skipping meter sync")
            return

        logger.info("Syncing meter registry with OVS state...")

        # Clear existing registry and rebuild from scratch
        self.policy_cache.clear_meter_registry()

        # Step 1: Query existing meters from OVS
        ovs_meters, err = get_meters(self.bridge_name)
        if err:
            logger.warning(f"Failed to query OVS meters during sync: {err}")
            ovs_meters = []

        # Build a map of meter_id -> meter for quick lookup
        ovs_meter_map = {m.meter_id: m for m in ovs_meters}

        # Step 2: Get all rate limits from policy cache and register their meters
        rate_limits = self.policy_cache.get_all_rate_limits()

        # Count references for each meter_id
        meter_refs: dict[int, int] = {}
        for rule in rate_limits:
            meter_id = rule.meter_id
            meter_refs[meter_id] = meter_refs.get(meter_id, 0) + 1

        # Step 3: Register meters that are used by rate limits, recreate missing ones
        recovered_meters = []
        failed_meters = []

        for meter_id, ref_count in meter_refs.items():
            if meter_id in ovs_meter_map:
                # Meter exists in OVS - register with actual values
                ovs_meter = ovs_meter_map[meter_id]
                self.policy_cache.register_meter(
                    meter_id,
                    self.bridge_name,
                    ovs_meter.rate,
                    ovs_meter.burst_size or 0,
                )
                # Set correct reference count (register sets to 1, so add remaining)
                for _ in range(ref_count - 1):
                    self.policy_cache.increment_meter_refs(meter_id)
            else:
                # Meter referenced by policy but not in OVS - recreate it
                rule_info = self._get_rate_info_for_meter(meter_id, rate_limits)
                if rule_info:
                    rate_kbps, burst_kbps = rule_info
                    success, msg = self._add_meter(
                        self.bridge_name, meter_id, rate_kbps, burst_kbps
                    )
                    if success or "METER_EXISTS" in msg:
                        self.policy_cache.register_meter(
                            meter_id, self.bridge_name, rate_kbps, burst_kbps
                        )
                        for _ in range(ref_count - 1):
                            self.policy_cache.increment_meter_refs(meter_id)
                        recovered_meters.append(meter_id)
                        logger.info(
                            f"Recovered missing meter {meter_id} "
                            f"({rate_kbps} kbps) during sync"
                        )
                    else:
                        failed_meters.append(meter_id)
                        logger.error(
                            f"Failed to recover meter {meter_id} during sync: {msg}"
                        )
                else:
                    failed_meters.append(meter_id)
                    logger.warning(
                        f"Meter {meter_id} referenced by rate limit "
                        f"but no rate info found, cannot recover"
                    )

        # Notify backend of any meters we recovered
        if recovered_meters:
            self._notify_meter_recovery(recovered_meters, rate_limits)

        registered = len(meter_refs) - len(failed_meters)
        logger.info(
            f"Meter registry synced: {registered} registered, "
            f"{len(recovered_meters)} recovered, {len(failed_meters)} failed "
            f"from {len(rate_limits)} rate limit rules"
        )

    def _get_action_name(self, action: MeterAction) -> str:
        """Get string name for a MeterAction enum value.

        Args:
            action: MeterAction enum value

        Returns:
            String name for the action (e.g., "create", "delete", "modify")
        """
        action_names = {
            MeterAction.METER_ACTION_CREATE: "create",
            MeterAction.METER_ACTION_DELETE: "delete",
            MeterAction.METER_ACTION_MODIFY: "modify",
        }
        return action_names.get(action, "unknown")

    def _publish_response(
        self,
        command: MeterCommand,
        status: MeterResponseStatus,
        message: str,
        error_code: str = "",
    ) -> bool:
        """Publish a meter response to MQTT.

        Args:
            command: Original MeterCommand
            status: Response status
            message: Human-readable message
            error_code: Optional error code

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish response")
            return False

        # Build response
        response = MeterResponse()
        response.status = status
        response.meter_id = command.meter_id
        response.bridge_name = command.bridge_name
        response.message = message
        response.action = command.action
        response.timestamp_ms = int(time.time() * 1000)
        response.rate = command.rate
        response.burst_size = command.burst_size
        response.meter_type = command.meter_type
        if error_code:
            response.error_code = error_code

        # Build response topic
        action_name = self._get_action_name(command.action)
        response_topic = build_control_topic(self.site_id, self.device_id, f"meter/{action_name}/response")

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published meter response: action={action_name}, "
                f"meter_id={command.meter_id}, status={status}, message={message}"
            )
        else:
            logger.error(f"Failed to publish meter response to {response_topic}")

        return result

    def _publish_policy_response(
        self,
        rule_type: str,
        action: Optional[str],
        correlation_id: str,
        block_statuses: Optional[list] = None,
        ratelimit_statuses: Optional[list] = None,
        ip_block_rule_statuses: Optional[list] = None,
        url_block_rule_statuses: Optional[list] = None,
        block_list_statuses: Optional[list] = None,
    ) -> bool:
        """Publish a policy response to MQTT.

        Args:
            rule_type: Type of rule ("block", "ratelimit", "sync", "ipblock", "urlblock", "blocklist")
            action: Action performed ("add", "remove", or None for sync)
            correlation_id: Correlation ID from the request
            block_statuses: List of PolicyRuleStatus for app block rules
            ratelimit_statuses: List of PolicyRuleStatus for rate limit rules
            ip_block_rule_statuses: List of PolicyRuleStatus for IP block rules
            url_block_rule_statuses: List of PolicyRuleStatus for URL block rules
            block_list_statuses: List of PolicyRuleStatus for block lists

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish policy response")
            return False

        if not POLICY_PROTOBUF_AVAILABLE:
            logger.error("Policy protobuf not available, cannot publish response")
            return False

        block_statuses = block_statuses or []
        ratelimit_statuses = ratelimit_statuses or []
        ip_block_rule_statuses = ip_block_rule_statuses or []
        url_block_rule_statuses = url_block_rule_statuses or []
        block_list_statuses = block_list_statuses or []

        response = PolicyResponse()

        all_statuses = (
            block_statuses
            + ratelimit_statuses
            + ip_block_rule_statuses
            + url_block_rule_statuses
            + block_list_statuses
        )
        if not all_statuses:
            response.status = PolicyResponseStatus.POLICY_RESPONSE_STATUS_SUCCESS
            response.message = "No rules to process"
        else:
            all_success = all(s.success for s in all_statuses)
            any_success = any(s.success for s in all_statuses)
            if all_success:
                response.status = PolicyResponseStatus.POLICY_RESPONSE_STATUS_SUCCESS
                response.message = "All rules applied successfully"
            elif any_success:
                response.status = PolicyResponseStatus.POLICY_RESPONSE_STATUS_PARTIAL
                response.message = "Some rules failed to apply"
            else:
                response.status = PolicyResponseStatus.POLICY_RESPONSE_STATUS_ERROR
                response.message = "All rules failed to apply"

        if action == "add":
            response.action = PolicyAction.POLICY_ACTION_ADD
        elif action == "remove":
            response.action = PolicyAction.POLICY_ACTION_REMOVE
        elif rule_type == "sync":
            response.action = PolicyAction.POLICY_ACTION_SYNC
        else:
            response.action = PolicyAction.POLICY_ACTION_UPDATE

        response.block_rule_statuses.extend(block_statuses)
        response.rate_limit_rule_statuses.extend(ratelimit_statuses)
        response.ip_block_rule_statuses.extend(ip_block_rule_statuses)
        response.url_block_rule_statuses.extend(url_block_rule_statuses)
        response.block_list_statuses.extend(block_list_statuses)

        response.timestamp_ms = int(time.time() * 1000)
        response.correlation_id = correlation_id or ""

        if action:
            response_topic = build_control_topic(self.site_id, self.device_id, f"policy/{rule_type}/{action}/response")
        else:
            response_topic = build_control_topic(self.site_id, self.device_id, f"policy/{rule_type}/response")

        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published policy response: type={rule_type}, action={action}, "
                f"status={response.status}, blocks={len(block_statuses)}, "
                f"ratelimits={len(ratelimit_statuses)}"
            )
        else:
            logger.error(f"Failed to publish policy response to {response_topic}")

        return result

    def _create_policy_rule_status(
        self,
        rule_id: int,
        app_name: str,
        success: bool,
        error_message: str = "",
        meter_id: int = 0,
    ) -> "PolicyRuleStatus":
        """Create a PolicyRuleStatus object.

        Args:
            rule_id: Rule ID that was processed
            app_name: Application name for reference
            success: Whether the rule was applied successfully
            error_message: Error message if failed
            meter_id: Meter ID assigned (for rate limit rules)

        Returns:
            PolicyRuleStatus protobuf object
        """
        status = PolicyRuleStatus()
        status.rule_id = rule_id
        status.app_name = app_name
        status.success = success
        status.error_message = error_message
        status.meter_id = meter_id
        return status

    def _handle_meter_command(self, topic: str, payload: bytes):
        """Handle incoming meter command from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received meter command on topic: {topic}")

        try:
            # Parse the protobuf command
            command = MeterCommand()
            command.ParseFromString(payload)

            if command.burst_size > 0:
                logger.info(
                    f"Meter command: action={self._get_action_name(command.action)}, "
                    f"meter_id={command.meter_id}, bridge={command.bridge_name}, "
                    f"rate={command.rate}kbps, burst={command.burst_size}kbits"
                )
            else:
                logger.info(
                    f"Meter command: action={self._get_action_name(command.action)}, "
                    f"meter_id={command.meter_id}, bridge={command.bridge_name}, "
                    f"rate={command.rate}kbps, no burst"
                )

            # Validate command
            if not command.bridge_name:
                self._publish_response(
                    command,
                    MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                    "Missing bridge_name in command",
                    "INVALID_COMMAND",
                )
                return

            if command.meter_id == 0:
                self._publish_response(
                    command,
                    MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                    "Invalid meter_id (must be > 0)",
                    "INVALID_METER_ID",
                )
                return

            # Handle based on action
            if command.action == MeterAction.METER_ACTION_CREATE:
                self._handle_create(command)
            elif command.action == MeterAction.METER_ACTION_DELETE:
                self._handle_delete(command)
            elif command.action == MeterAction.METER_ACTION_MODIFY:
                self._handle_modify(command)
            else:
                self._publish_response(
                    command,
                    MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                    f"Unknown action: {command.action}",
                    "UNKNOWN_ACTION",
                )

        except Exception as e:
            logger.error(f"Error handling meter command: {e}", exc_info=True)
            # Try to send error response if we can parse enough of the command
            try:
                error_response = MeterResponse()
                error_response.status = MeterResponseStatus.METER_RESPONSE_STATUS_ERROR
                error_response.message = f"Error processing command: {str(e)}"
                error_response.timestamp_ms = int(time.time() * 1000)
                error_response.error_code = "PARSE_ERROR"

                # Extract action from topic
                topic_parts = topic.split("/")
                if len(topic_parts) >= 6:
                    action_name = topic_parts[5]  # meter/{action}
                    response_topic = build_control_topic(
                        self.site_id, self.device_id, f"meter/{action_name}/response"
                    )
                    self.mqtt_client.publish_raw(
                        response_topic, error_response.SerializeToString(), qos=2
                    )
            except Exception as publish_error:
                logger.error(f"Failed to publish error response: {publish_error}")

    def _handle_create(self, command: MeterCommand):
        """Handle meter CREATE action.

        Args:
            command: MeterCommand with CREATE action
        """
        # Validate rate
        if command.rate <= 0:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                "Rate must be > 0",
                "INVALID_RATE",
            )
            return

        # Check if meter already exists
        if self._meter_exists(command.bridge_name, command.meter_id):
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ALREADY_EXISTS,
                f"Meter {command.meter_id} already exists on {command.bridge_name}",
            )
            return

        # Create the meter
        success, message = self._add_meter(
            command.bridge_name, command.meter_id, command.rate, command.burst_size
        )

        if success:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_SUCCESS,
                message,
            )
        else:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
            )

    def _handle_delete(self, command: MeterCommand):
        """Handle meter DELETE action.

        Args:
            command: MeterCommand with DELETE action
        """
        # Check if meter exists
        if not self._meter_exists(command.bridge_name, command.meter_id):
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_NOT_FOUND,
                f"Meter {command.meter_id} not found on {command.bridge_name}",
            )
            return

        # Delete the meter
        success, message = self._delete_meter(command.bridge_name, command.meter_id)

        if success:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_SUCCESS,
                message,
            )
        else:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
            )

    def _handle_modify(self, command: MeterCommand):
        """Handle meter MODIFY action.

        Args:
            command: MeterCommand with MODIFY action
        """
        # Validate rate
        if command.rate <= 0:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                "Rate must be > 0",
                "INVALID_RATE",
            )
            return

        # Check if meter exists
        if not self._meter_exists(command.bridge_name, command.meter_id):
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_NOT_FOUND,
                f"Meter {command.meter_id} not found on {command.bridge_name}",
            )
            return

        # Modify the meter
        success, message = self._modify_meter(
            command.bridge_name, command.meter_id, command.rate, command.burst_size
        )

        if success:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_SUCCESS,
                message,
            )
        else:
            self._publish_response(
                command,
                MeterResponseStatus.METER_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
            )

    def _subscribe_to_all_topics(self):
        """Subscribe to all OVS command topics (meters, flow mods, policy, bridge, and classifier config).

        This method is called on initial connection and on reconnection
        to ensure subscriptions are always active.
        """
        self._subscribe_to_meter_topics()
        self._subscribe_to_flow_mod_topics()
        self._subscribe_to_policy_topics()
        self._subscribe_to_bridge_topics()
        self._subscribe_to_classifier_config_topics()

    def _subscribe_to_meter_topics(self):
        """Subscribe to meter command topics."""
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(f"Subscribing to meter topic pattern: {self.meter_topic_pattern}")

        try:
            self.mqtt_client.subscribe_raw(
                self.meter_topic_pattern, self._handle_meter_command, qos=2
            )
            logger.info(
                f"Successfully subscribed to meter topics: {self.meter_topic_pattern}"
            )
        except Exception as e:
            logger.error(f"Failed to subscribe to meter topics: {e}", exc_info=True)

    # =========================================================================
    # Bridge Command Handling
    # =========================================================================

    def _subscribe_to_bridge_topics(self):
        """Subscribe to bridge command topics."""
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(f"Subscribing to bridge topic pattern: {self.bridge_topic_pattern}")

        try:
            self.mqtt_client.subscribe_raw(
                self.bridge_topic_pattern, self._handle_bridge_command, qos=2
            )
            logger.info(
                f"Successfully subscribed to bridge topics: {self.bridge_topic_pattern}"
            )
        except Exception as e:
            logger.error(f"Failed to subscribe to bridge topics: {e}", exc_info=True)

    def _get_bridge_action_name(self, action: BridgeAction) -> str:
        """Get string name for a BridgeAction enum value.

        Args:
            action: BridgeAction enum value

        Returns:
            String name for the action (e.g., "create", "delete", "update_ports")
        """
        action_names = {
            BridgeAction.BRIDGE_ACTION_CREATE: "create",
            BridgeAction.BRIDGE_ACTION_DELETE: "delete",
            BridgeAction.BRIDGE_ACTION_UPDATE_PORTS: "update_ports",
        }
        return action_names.get(action, "unknown")

    def _publish_bridge_response(
        self,
        command: BridgeCommand,
        status: BridgeResponseStatus,
        message: str,
        active_ports: Optional[list] = None,
        error_code: str = "",
    ) -> bool:
        """Publish a bridge response to MQTT.

        Args:
            command: Original BridgeCommand
            status: Response status
            message: Human-readable message
            active_ports: List of active port names on the bridge
            error_code: Optional error code

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish bridge response")
            return False

        response = BridgeResponse()
        response.status = status
        response.bridge_name = command.bridge_name
        response.message = message
        response.action = command.action
        response.correlation_id = command.correlation_id
        response.timestamp_ms = int(time.time() * 1000)
        if active_ports:
            response.active_ports.extend(active_ports)
        if error_code:
            response.error_code = error_code

        action_name = self._get_bridge_action_name(command.action)
        response_topic = build_control_topic(self.site_id, self.device_id, f"bridge/{action_name}/response")

        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published bridge response: status={status}, bridge={command.bridge_name}, "
                f"action={action_name}, message={message}"
            )
        else:
            logger.error(f"Failed to publish bridge response to {response_topic}")

        return result

    def _handle_bridge_command(self, topic: str, payload: bytes):
        """Handle incoming bridge command from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received bridge command on topic: {topic}")

        try:
            command = BridgeCommand()
            command.ParseFromString(payload)

            logger.info(
                f"Bridge command: action={self._get_bridge_action_name(command.action)}, "
                f"bridge={command.bridge_name}, ports={list(command.ports)}, "
                f"correlation_id={command.correlation_id}"
            )

            if not command.bridge_name:
                self._publish_bridge_response(
                    command,
                    BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                    "Missing bridge_name in command",
                    error_code="INVALID_COMMAND",
                )
                return

            if command.action == BridgeAction.BRIDGE_ACTION_CREATE:
                self._handle_bridge_create(command)
            elif command.action == BridgeAction.BRIDGE_ACTION_DELETE:
                self._handle_bridge_delete(command)
            elif command.action == BridgeAction.BRIDGE_ACTION_UPDATE_PORTS:
                self._handle_bridge_update_ports(command)
            else:
                self._publish_bridge_response(
                    command,
                    BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                    f"Unknown bridge action: {command.action}",
                    error_code="UNKNOWN_ACTION",
                )

        except Exception as e:
            logger.error(f"Error handling bridge command: {e}", exc_info=True)
            try:
                self._publish_bridge_response(
                    BridgeCommand(),
                    BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                    f"Internal error: {str(e)}",
                    error_code="INTERNAL_ERROR",
                )
            except Exception as publish_error:
                logger.error(
                    f"Failed to publish bridge error response: {publish_error}"
                )

    def _handle_bridge_create(self, command: BridgeCommand):
        """Handle bridge creation command."""
        logger.info(f"Creating bridge: {command.bridge_name}")

        try:
            openflow_version = command.openflow_version or "OpenFlow13"
            success, message, active_ports = OVSBridgeManager.create_bridge(
                bridge_name=command.bridge_name,
                ports=list(command.ports),
                openflow_version=openflow_version,
            )
        except Exception as e:
            logger.error(f"Exception during bridge creation: {e}", exc_info=True)
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                f"Exception: {str(e)}",
                error_code="OVS_ERROR",
            )
            return

        if success:
            # Save bridge config to config.json
            try:
                bridge_config = {
                    "bridge_name": command.bridge_name,
                    "openflow_version": command.openflow_version or "OpenFlow13",
                    "interfaces": list(command.ports),
                }
                self.config_manager.set_bridge_config(command.bridge_name, bridge_config)
                logger.info(f"Saved bridge config for {command.bridge_name}")

                # Update in-memory bridge name so meter operations work immediately
                self.bridge_name = command.bridge_name

                # Start/restart monitoring services so they pick up the new bridge config
                self._restart_monitoring_services()
            except Exception as e:
                logger.error(
                    f"Failed to save bridge config or start monitoring: {e}",
                    exc_info=True,
                )

            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_SUCCESS,
                message,
                active_ports=active_ports,
            )
        elif "already exists" in message:
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ALREADY_EXISTS,
                message,
                active_ports=active_ports,
            )
        else:
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                message,
                active_ports=active_ports,
                error_code="OVS_ERROR",
            )

    def _handle_bridge_delete(self, command: BridgeCommand):
        """Handle bridge deletion command."""
        logger.info(f"Deleting bridge: {command.bridge_name}")

        try:
            success, message = delete_bridge_and_cleanup(
                command.bridge_name, self.config_manager
            )
        except Exception as e:
            logger.error(f"Exception during bridge deletion: {e}", exc_info=True)
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                f"Exception: {str(e)}",
                error_code="OVS_ERROR",
            )
            return

        if success:
            if "does not exist" in message:
                self._publish_bridge_response(
                    command,
                    BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_NOT_FOUND,
                    message,
                )
            else:
                # Clear in-memory bridge name if the deleted bridge was the active one
                if self.bridge_name == command.bridge_name:
                    self.bridge_name = None
                self._publish_bridge_response(
                    command,
                    BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_SUCCESS,
                    message,
                )
        else:
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                message,
                error_code="OVS_ERROR",
            )

    def _handle_bridge_update_ports(self, command: BridgeCommand):
        """Handle bridge update_ports command."""
        logger.info(
            f"Updating ports on bridge {command.bridge_name}: {list(command.ports)}"
        )

        try:
            success, message, active_ports = OVSBridgeManager.update_ports(
                command.bridge_name, list(command.ports)
            )
        except Exception as e:
            logger.error(f"Exception during port update: {e}", exc_info=True)
            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR,
                f"Exception: {str(e)}",
                error_code="OVS_ERROR",
            )
            return

        if success:
            # Update bridge config interfaces in config.json
            try:
                existing_config = self.config_manager.get_bridge_config(
                    command.bridge_name
                )
                if existing_config:
                    existing_config["interfaces"] = active_ports
                    self.config_manager.set_bridge_config(
                        command.bridge_name, existing_config
                    )
                    logger.info(
                        f"Updated bridge config interfaces for {command.bridge_name}"
                    )
                else:
                    logger.warning(
                        f"No existing config for bridge {command.bridge_name}, "
                        "creating new config entry"
                    )
                    bridge_config = {
                        "bridge_name": command.bridge_name,
                        "openflow_version": "OpenFlow13",
                        "interfaces": active_ports,
                    }
                    self.config_manager.set_bridge_config(
                        command.bridge_name, bridge_config
                    )
            except Exception as e:
                logger.error(
                    f"Failed to update bridge config: {e}", exc_info=True
                )

            # Restart monitoring services so they pick up the new port mappings
            try:
                self._restart_monitoring_services()
            except Exception as e:
                logger.warning(
                    f"Failed to restart monitoring services after port update: {e}"
                )

            self._publish_bridge_response(
                command,
                BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_SUCCESS,
                message,
                active_ports=active_ports,
            )
        else:
            status = BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR
            if "does not exist" in message:
                status = BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_NOT_FOUND
            self._publish_bridge_response(
                command,
                status,
                message,
                active_ports=active_ports,
                error_code="OVS_ERROR" if status == BridgeResponseStatus.BRIDGE_RESPONSE_STATUS_ERROR else "",
            )

    def _start_monitoring_service(self, service_name, description, subprocess_fallback):
        """Start a monitoring service via systemd with subprocess fallback.

        Args:
            service_name: Systemd service unit name (e.g. "axon-agent-port-stats.service")
            description: Human-readable description for log messages
            subprocess_fallback: Callable to start the service as a subprocess
        """
        try:
            if enable_systemd_service(service_name):
                logger.info(f"Enabled {description} systemd service")
                try:
                    start_systemd_service(service_name)
                    logger.info(
                        f"{description} systemd service started (or already running)"
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to start {description} systemd service: {e}, "
                        "falling back to subprocess"
                    )
                    subprocess_fallback()
                    logger.info(
                        f"{description} process started (or already running)"
                    )
            else:
                logger.debug(
                    f"Systemd service management not available for {description}, "
                    "trying subprocess"
                )
                subprocess_fallback()
                logger.info(
                    f"{description} process started (or already running)"
                )
        except Exception as e:
            logger.warning(f"Failed to start {description}: {e}")
            try:
                subprocess_fallback()
            except Exception as e2:
                logger.warning(f"Also failed subprocess fallback for {description}: {e2}")

    def _start_monitoring_services(self):
        """Start port stats and port link monitoring services."""
        self._start_monitoring_service(
            "axon-agent-port-stats.service",
            "port statistics monitoring",
            start_port_stats_monitoring_process,
        )
        self._start_monitoring_service(
            "axon-agent-port-link.service",
            "port link monitoring",
            start_port_link_monitoring_process,
        )

    def _restart_monitoring_services(self):
        """Restart port stats and port link monitoring services.

        Used after bridge config changes (port updates, bridge creation,
        bridge deletion) so monitors reload their config and pick up
        the latest interface mappings.
        """
        for service, description in [
            ("axon-agent-port-stats.service", "port statistics monitoring"),
            ("axon-agent-port-link.service", "port link monitoring"),
        ]:
            try:
                if restart_systemd_service(service):
                    logger.info(f"Restarted {description} service")
                else:
                    logger.warning(
                        f"Failed to restart {description} via systemd, "
                        "trying stop+start subprocess fallback"
                    )
                    subprocess.run(
                        ["pkill", "-f", service.replace(".service", "")],
                        capture_output=True, timeout=5,
                    )
                    time.sleep(0.5)
                    if service == "axon-agent-port-stats.service":
                        start_port_stats_monitoring_process()
                    else:
                        start_port_link_monitoring_process()
                    logger.info(f"Restarted {description} via subprocess fallback")
            except Exception as e:
                logger.warning(f"Failed to restart {description}: {e}")

    # =========================================================================
    # Flow Mod Command Handling
    # =========================================================================

    def _bridge_exists(self, bridge_name: str) -> bool:
        """Check if an OVS bridge exists.

        Args:
            bridge_name: Name of the OVS bridge

        Returns:
            True if bridge exists, False otherwise
        """
        try:
            result = subprocess.run(
                ["ovs-vsctl", "br-exists", bridge_name],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            logger.error(f"Timeout checking if bridge {bridge_name} exists")
            return False
        except FileNotFoundError:
            logger.error("ovs-vsctl command not found. Is Open vSwitch installed?")
            return False
        except Exception as e:
            logger.error(f"Error checking bridge existence: {e}")
            return False

    def _get_flow_mod_action_name(self, action: FlowModAction) -> str:
        """Get string name for a FlowModAction enum value.

        Args:
            action: FlowModAction enum value

        Returns:
            String name for the action (e.g., "add", "delete", "modify")
        """
        action_names = {
            FlowModAction.FLOW_MOD_ACTION_ADD: "add",
            FlowModAction.FLOW_MOD_ACTION_DELETE: "delete",
            FlowModAction.FLOW_MOD_ACTION_MODIFY: "modify",
        }
        return action_names.get(action, "unknown")

    def _publish_flow_mod_response(
        self,
        command: FlowModCommand,
        status: FlowModResponseStatus,
        message: str,
        error_code: str = "",
        ovs_command: str = "",
    ) -> bool:
        """Publish a flow mod response to MQTT.

        Args:
            command: Original FlowModCommand
            status: Response status
            message: Human-readable message
            error_code: Optional error code
            ovs_command: Optional OVS command executed (for debugging)

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            logger.error("MQTT client not connected, cannot publish flow mod response")
            return False

        # Build response
        response = FlowModResponse()
        response.status = status
        response.flow_id = command.flow_id
        response.openflow_cookie = command.openflow_cookie
        response.bridge_name = command.bridge_name
        response.message = message
        response.action = command.action
        response.timestamp_ms = int(time.time() * 1000)
        if error_code:
            response.error_code = error_code
        if ovs_command:
            response.ovs_command = ovs_command

        # Build response topic
        action_name = self._get_flow_mod_action_name(command.action)
        response_topic = build_control_topic(self.site_id, self.device_id, f"flow_mod/{action_name}/response")

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published flow mod response: action={action_name}, "
                f"flow_id={command.flow_id}, cookie=0x{command.openflow_cookie:016x}, "
                f"status={status}, message={message}"
            )
        else:
            logger.error(f"Failed to publish flow mod response to {response_topic}")

        return result

    def _build_actions(self, cmd: FlowModCommand) -> str:
        """Build the OpenFlow actions string from FlowModCommand.

        IMPORTANT: Meter MUST come before forwarding actions!

        Action construction logic:
        - Block action (DROP): If output_action is "DROP", use "actions=drop" (no meter)
        - Rate limit with meter: If meter_id > 0, use "actions=meter:N,{output_action}"
        - No meter: Just use "actions={output_action}" (defaults to NORMAL)

        Args:
            cmd: FlowModCommand with action parameters

        Returns:
            OpenFlow actions string (e.g., "actions=drop", "actions=meter:3,NORMAL")
        """
        # Case 1: Block action - DROP all traffic (ignore meter)
        if cmd.output_action and cmd.output_action.upper() == "DROP":
            return "actions=drop"

        # Case 2: Rate limit with meter (meter FIRST, then forward)
        if cmd.meter_id > 0:
            forward_action = cmd.output_action if cmd.output_action else "NORMAL"
            return f"actions=meter:{cmd.meter_id},{forward_action}"

        # Case 3: No meter - just forward
        forward_action = cmd.output_action if cmd.output_action else "NORMAL"
        return f"actions={forward_action}"

    def _build_flow_command(
        self, cmd: FlowModCommand, operation: str = "add-flow"
    ) -> Tuple[list, str]:
        """Build ovs-ofctl flow command from FlowModCommand.

        Builds the complete ovs-ofctl command for add-flow or mod-flows operations.

        For add-flow: Creates a new flow with the specified match and actions.
        For mod-flows: Uses match fields to identify existing flows, then replaces
                       their actions with the new actions specified.

        Args:
            cmd: FlowModCommand with flow parameters
            operation: OVS operation - "add-flow" or "mod-flows"

        Returns:
            Tuple of (command list, flow_spec string for debugging)

        Raises:
            ValueError: If operation is not "add-flow" or "mod-flows"
        """
        if operation not in ("add-flow", "mod-flows"):
            raise ValueError(
                f"Invalid operation: {operation}. Must be 'add-flow' or 'mod-flows'"
            )

        match_parts = []

        # Cookie (required)
        match_parts.append(f"cookie=0x{cmd.openflow_cookie:016x}")

        # Priority (use provided priority, or default to 500)
        if cmd.priority > 0:
            match_parts.append(f"priority={cmd.priority}")
        else:
            match_parts.append("priority=500")

        # Timeouts (only relevant for add-flow, but OVS ignores them for mod-flows)
        if cmd.idle_timeout > 0:
            match_parts.append(f"idle_timeout={cmd.idle_timeout}")
        if cmd.hard_timeout > 0:
            match_parts.append(f"hard_timeout={cmd.hard_timeout}")

        # Table ID (default 0)
        if cmd.table_id > 0:
            match_parts.append(f"table={cmd.table_id}")

        # Protocol (TCP or UDP) - REQUIRED for L4 port matching to work
        if cmd.is_tcp:
            match_parts.append("tcp")
        else:
            match_parts.append("udp")

        # L2 match fields
        if cmd.src_mac:
            match_parts.append(f"dl_src={cmd.src_mac}")
        if cmd.dst_mac:
            match_parts.append(f"dl_dst={cmd.dst_mac}")

        # VLAN
        if cmd.vlan_id > 0:
            match_parts.append(f"dl_vlan={cmd.vlan_id}")

        # L3 match fields - commented out as NORMAL action is L2 only
        # if cmd.src_ip:
        #     match_parts.append(f"nw_src={cmd.src_ip}")
        # if cmd.dst_ip:
        #     match_parts.append(f"nw_dst={cmd.dst_ip}")

        # L4 match fields (ports)
        if cmd.src_port > 0:
            match_parts.append(f"tp_src={cmd.src_port}")
        if cmd.dst_port > 0:
            match_parts.append(f"tp_dst={cmd.dst_port}")

        # Build actions using the dedicated helper
        actions_str = self._build_actions(cmd)

        # Combine match and actions
        flow_spec = ",".join(match_parts) + "," + actions_str

        return (
            ["ovs-ofctl", operation, cmd.bridge_name, flow_spec, "-OOpenflow13"],
            flow_spec,
        )

    def _add_flow(self, command: FlowModCommand) -> Tuple[bool, str, str]:
        """Add a flow rule to the OVS bridge.

        Args:
            command: FlowModCommand with flow parameters

        Returns:
            Tuple of (success, message, ovs_command)
        """
        try:
            cmd_list, flow_spec = self._build_flow_command(
                command, operation="add-flow"
            )
            ovs_command = " ".join(cmd_list)

            logger.info(f"Executing OVS command: {ovs_command}")

            result = subprocess.run(
                cmd_list,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                logger.info(
                    f"Added flow on bridge {command.bridge_name} "
                    f"(cookie=0x{command.openflow_cookie:016x}, flow_id={command.flow_id})"
                )
                return (
                    True,
                    f"Flow added with cookie 0x{command.openflow_cookie:016x}",
                    ovs_command,
                )
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to add flow: {error_msg}")
                return False, f"Failed to add flow: {error_msg}", ovs_command

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout adding flow on bridge {command.bridge_name}")
            return False, "Timeout executing OVS command", ""
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?", ""
        except Exception as e:
            logger.error(f"Error adding flow: {e}")
            return False, f"Error: {str(e)}", ""

    def _delete_flow_by_cookie(
        self, bridge_name: str, cookie: int, cookie_mask: int
    ) -> Tuple[bool, str, str]:
        """Delete flows matching a cookie from the OVS bridge.

        Args:
            bridge_name: Name of the OVS bridge
            cookie: Cookie value to match
            cookie_mask: Cookie mask for matching

        Returns:
            Tuple of (success, message, ovs_command)
        """
        try:
            # Format: cookie=value/mask where -1 means exact match
            cookie_spec = f"cookie=0x{cookie:016x}/0x{cookie_mask:016x}"
            cmd = [
                "ovs-ofctl",
                "del-flows",
                bridge_name,
                cookie_spec,
                "-OOpenflow13",
            ]
            ovs_command = " ".join(cmd)

            logger.info(f"Executing OVS command: {ovs_command}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                logger.info(
                    f"Deleted flow(s) with cookie 0x{cookie:016x} from bridge {bridge_name}"
                )
                return True, f"Flow deleted with cookie 0x{cookie:016x}", ovs_command
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to delete flow: {error_msg}")
                return False, f"Failed to delete flow: {error_msg}", ovs_command

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout deleting flow from bridge {bridge_name}")
            return False, "Timeout executing OVS command", ""
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?", ""
        except Exception as e:
            logger.error(f"Error deleting flow: {e}")
            return False, f"Error: {str(e)}", ""

    def _add_drop_flow(
        self,
        bridge_name: str,
        cookie: int,
        priority: int,
        idle_timeout: int,
        nw_src: Optional[str] = None,
        nw_dst: Optional[str] = None,
    ) -> Tuple[bool, str]:
        """Install a single DROP flow matching IP(s). Either nw_src or nw_dst must be set."""
        match_parts = ["ip"]
        if nw_src:
            match_parts.append(f"nw_src={nw_src}")
        if nw_dst:
            match_parts.append(f"nw_dst={nw_dst}")
        flow_spec = (
            f"cookie=0x{cookie:016x},priority={priority},idle_timeout={idle_timeout},"
            + ",".join(match_parts)
            + ",actions=drop"
        )
        cmd = ["ovs-ofctl", "add-flow", bridge_name, flow_spec, "-OOpenflow13"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                return True, ""
            return False, result.stderr.strip() or "Unknown error"
        except subprocess.TimeoutExpired:
            return False, "Timeout executing ovs-ofctl"
        except FileNotFoundError:
            return False, "ovs-ofctl not found"
        except Exception as e:
            return False, str(e)

    def _install_ip_block_flows(
        self,
        rule_id: int,
        ip_address: Optional[str],
        cidr_range: Optional[str],
        direction: str,
        priority: int = 7000,
        idle_timeout: int = 300,
    ) -> Tuple[bool, str]:
        """Install OVS DROP flows for an IP block rule. Retries once on failure."""
        if not self.bridge_name:
            return False, "bridge_name not configured"
        target = ip_address or cidr_range
        if not target:
            return False, "rule has neither ip_address nor cidr_range"
        cookie = COOKIE_IP_BLOCK_MASK | (rule_id & 0xFFFFFFFF)
        src_installed = False

        if direction in ("src", "both"):
            # Retry logic: attempt up to 2 times (initial + 1 retry)
            ok, err = None, None
            for attempt in range(2):
                ok, err = self._add_drop_flow(
                    self.bridge_name,
                    cookie,
                    priority,
                    idle_timeout,
                    nw_src=target,
                    nw_dst=None,
                )
                if ok:
                    src_installed = True
                    break
            if not ok:
                # Rollback not needed as nothing was installed yet
                return False, err

        if direction in ("dst", "both"):
            # Retry logic: attempt up to 2 times (initial + 1 retry)
            ok, err = None, None
            for attempt in range(2):
                ok, err = self._add_drop_flow(
                    self.bridge_name,
                    cookie,
                    priority,
                    idle_timeout,
                    nw_src=None,
                    nw_dst=target,
                )
                if ok:
                    break
            if not ok:
                # Rollback: delete the src flow if it was installed
                if src_installed:
                    self._delete_flow_by_cookie(
                        self.bridge_name, cookie, 0xFFFFFFFFFFFFFFFF
                    )
                return False, err

        return True, ""

    def _delete_ip_block_flows(self, rule_id: int) -> Tuple[bool, str]:
        """Remove OVS flows for an IP block rule by cookie."""
        if not self.bridge_name:
            return False, "bridge_name not configured"
        cookie = COOKIE_IP_BLOCK_MASK | (rule_id & 0xFFFFFFFF)
        success, _, _ = self._delete_flow_by_cookie(
            self.bridge_name, cookie, 0xFFFFFFFFFFFFFFFF
        )
        return success, ""

    def _install_block_list_ip_flows(
        self,
        list_id: int,
        priority: int,
        ip_entries: List[str],
        idle_timeout: int = 300,
    ) -> Tuple[bool, str]:
        """Install OVS DROP flows for block list IP entries (both directions)."""
        if not self.bridge_name:
            return False, "bridge_name not configured"
        cookie = COOKIE_BLOCK_LIST_MASK | (list_id & 0xFFFFFFFF)
        installed_flows = []  # Track successfully installed flows for rollback
        for value in ip_entries:
            ok, err = self._add_drop_flow(
                self.bridge_name,
                cookie,
                priority,
                idle_timeout,
                nw_src=value,
                nw_dst=None,
            )
            if not ok:
                # Rollback: delete all flows created for this cookie
                self._delete_flow_by_cookie(
                    self.bridge_name, cookie, 0xFFFFFFFFFFFFFFFF
                )
                return False, err
            installed_flows.append(("src", value))
            ok, err = self._add_drop_flow(
                self.bridge_name,
                cookie,
                priority,
                idle_timeout,
                nw_src=None,
                nw_dst=value,
            )
            if not ok:
                # Rollback: delete all flows created for this cookie
                self._delete_flow_by_cookie(
                    self.bridge_name, cookie, 0xFFFFFFFFFFFFFFFF
                )
                return False, err
            installed_flows.append(("dst", value))
        return True, ""

    def _delete_block_list_ip_flows(self, list_id: int) -> Tuple[bool, str]:
        """Remove OVS flows for a block list by cookie."""
        if not self.bridge_name:
            return False, "bridge_name not configured"
        cookie = COOKIE_BLOCK_LIST_MASK | (list_id & 0xFFFFFFFF)
        success, _, _ = self._delete_flow_by_cookie(
            self.bridge_name, cookie, 0xFFFFFFFFFFFFFFFF
        )
        return success, ""

    def _install_block_list_ip_flows_incremental(
        self,
        list_id: int,
        priority: int,
        ip_entries: List[str],
        idle_timeout: int = 300,
    ) -> Tuple[bool, str]:
        """Install OVS DROP flows for new IP entries without affecting existing flows.

        Unlike _install_block_list_ip_flows, on failure this only rolls back
        the flows installed in this call, leaving pre-existing flows for the
        same block list intact.
        """
        if not self.bridge_name:
            return False, "bridge_name not configured"
        cookie = COOKIE_BLOCK_LIST_MASK | (list_id & 0xFFFFFFFF)
        installed = []  # Track (direction, ip) for rollback
        for value in ip_entries:
            ok, err = self._add_drop_flow(
                self.bridge_name, cookie, priority, idle_timeout,
                nw_src=value, nw_dst=None,
            )
            if not ok:
                self._rollback_incremental_flows(installed, cookie)
                return False, f"nw_src={value}: {err}"
            installed.append(("src", value))

            ok, err = self._add_drop_flow(
                self.bridge_name, cookie, priority, idle_timeout,
                nw_src=None, nw_dst=value,
            )
            if not ok:
                self._rollback_incremental_flows(installed, cookie)
                return False, f"nw_dst={value}: {err}"
            installed.append(("dst", value))
        return True, ""

    def _rollback_incremental_flows(
        self, installed: List[Tuple[str, str]], cookie: int
    ) -> None:
        """Roll back only the flows installed in an incremental add."""
        cookie_spec = f"cookie=0x{cookie:016x}/0xffffffffffffffff"
        for direction, ip in installed:
            match_field = f"nw_src={ip}" if direction == "src" else f"nw_dst={ip}"
            flow_spec = f"{cookie_spec},ip,{match_field}"
            cmd = [
                "ovs-ofctl", "del-flows", self.bridge_name, flow_spec, "-OOpenflow13",
            ]
            try:
                subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            except Exception as e:
                logger.warning(f"Rollback failed for {match_field}: {e}")

    def _modify_flow(self, command: FlowModCommand) -> Tuple[bool, str, str]:
        """Modify the actions of an existing flow rule on the OVS bridge.

        Uses OVS mod-flows which finds existing flows by matching the specified
        criteria (cookie, protocol, MAC/IP/port fields) and replaces their actions
        with the new actions specified in the command.

        Note: mod-flows only changes actions, not match criteria or timeouts.
        The match fields in the command are used to identify which flows to modify.
        If you need to change match criteria, use delete followed by add.

        Args:
            command: FlowModCommand with match criteria to find flows and new actions

        Returns:
            Tuple of (success, message, ovs_command)
        """
        try:
            cmd_list, flow_spec = self._build_flow_command(
                command, operation="mod-flows"
            )
            ovs_command = " ".join(cmd_list)

            logger.info(f"Executing OVS command: {ovs_command}")

            result = subprocess.run(
                cmd_list,
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode == 0:
                logger.info(
                    f"Modified flow on bridge {command.bridge_name} "
                    f"(cookie=0x{command.openflow_cookie:016x}, flow_id={command.flow_id})"
                )
                return (
                    True,
                    f"Flow modified with cookie 0x{command.openflow_cookie:016x}",
                    ovs_command,
                )
            else:
                error_msg = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to modify flow: {error_msg}")
                return False, f"Failed to modify flow: {error_msg}", ovs_command

        except subprocess.TimeoutExpired:
            logger.error(f"Timeout modifying flow on bridge {command.bridge_name}")
            return False, "Timeout executing OVS command", ""
        except FileNotFoundError:
            logger.error("ovs-ofctl command not found")
            return False, "ovs-ofctl command not found. Is Open vSwitch installed?", ""
        except Exception as e:
            logger.error(f"Error modifying flow: {e}")
            return False, f"Error: {str(e)}", ""

    def _handle_flow_mod_command(self, topic: str, payload: bytes):
        """Handle incoming flow mod command from MQTT.

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
        """
        logger.info(f"Received flow mod command on topic: {topic}")

        try:
            # Parse the protobuf command
            command = FlowModCommand()
            command.ParseFromString(payload)

            logger.info(
                f"Flow mod command: action={self._get_flow_mod_action_name(command.action)}, "
                f"flow_id={command.flow_id}, bridge={command.bridge_name}, "
                f"cookie=0x{command.openflow_cookie:016x}, meter_id={command.meter_id}, "
                f"priority={command.priority}, classification={command.classification}"
            )

            # Validate bridge_name
            if not command.bridge_name:
                self._publish_flow_mod_response(
                    command,
                    FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR,
                    "Missing bridge_name in command",
                    "INVALID_COMMAND",
                )
                return

            # Check if bridge exists
            if not self._bridge_exists(command.bridge_name):
                self._publish_flow_mod_response(
                    command,
                    FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_BRIDGE_NOT_FOUND,
                    f"Bridge {command.bridge_name} does not exist",
                    "BRIDGE_NOT_FOUND",
                )
                return

            # Handle based on action
            if command.action == FlowModAction.FLOW_MOD_ACTION_ADD:
                self._handle_flow_add(command)
            elif command.action == FlowModAction.FLOW_MOD_ACTION_DELETE:
                self._handle_flow_delete(command)
            elif command.action == FlowModAction.FLOW_MOD_ACTION_MODIFY:
                self._handle_flow_modify(command)
            else:
                self._publish_flow_mod_response(
                    command,
                    FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR,
                    f"Unknown action: {command.action}",
                    "UNKNOWN_ACTION",
                )

        except Exception as e:
            logger.error(f"Error handling flow mod command: {e}", exc_info=True)
            # Try to send error response
            try:
                error_response = FlowModResponse()
                error_response.status = (
                    FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR
                )
                error_response.message = f"Error processing command: {str(e)}"
                error_response.timestamp_ms = int(time.time() * 1000)
                error_response.error_code = "PARSE_ERROR"

                # Extract action from topic
                topic_parts = topic.split("/")
                if len(topic_parts) >= 6:
                    action_name = topic_parts[5]  # flow_mod/{action}
                    response_topic = build_control_topic(
                        self.site_id, self.device_id, f"flow_mod/{action_name}/response"
                    )
                    self.mqtt_client.publish_raw(
                        response_topic, error_response.SerializeToString(), qos=2
                    )
            except Exception as publish_error:
                logger.error(f"Failed to publish error response: {publish_error}")

    def _handle_flow_add(self, command: FlowModCommand):
        """Handle flow ADD action.

        Args:
            command: FlowModCommand with ADD action
        """
        # Check if meter exists if meter_id is specified AND this is not a DROP rule
        # DROP rules don't use meters, so skip meter validation for them
        is_drop_action = (
            command.output_action and command.output_action.upper() == "DROP"
        )
        if command.meter_id > 0 and not is_drop_action:
            if not self._meter_exists(command.bridge_name, command.meter_id):
                # Attempt meter recovery before rejecting
                recovered = self._recover_meter(
                    command.bridge_name, command.meter_id
                )
                if not recovered:
                    self._publish_flow_mod_response(
                        command,
                        FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_METER_NOT_FOUND,
                        f"Meter {command.meter_id} not found on bridge "
                        f"{command.bridge_name} and recovery failed",
                        "METER_NOT_FOUND",
                    )
                    return
                logger.info(
                    f"Recovered meter {command.meter_id} during flow-add"
                )

        # Add the flow
        success, message, ovs_command = self._add_flow(command)

        if success:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_SUCCESS,
                message,
                ovs_command=ovs_command,
            )
        else:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
                ovs_command=ovs_command,
            )

    def _handle_flow_delete(self, command: FlowModCommand):
        """Handle flow DELETE action.

        Args:
            command: FlowModCommand with DELETE action
        """
        # Use cookie_mask if provided, otherwise use -1 (exact match)
        cookie_mask = command.cookie_mask if command.cookie_mask else 0xFFFFFFFFFFFFFFFF

        # Delete the flow by cookie
        success, message, ovs_command = self._delete_flow_by_cookie(
            command.bridge_name, command.openflow_cookie, cookie_mask
        )

        if success:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_SUCCESS,
                message,
                ovs_command=ovs_command,
            )
        else:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
                ovs_command=ovs_command,
            )

    def _handle_flow_modify(self, command: FlowModCommand):
        """Handle flow MODIFY action.

        Args:
            command: FlowModCommand with MODIFY action
        """
        # Check if meter exists if meter_id is specified AND this is not a DROP rule
        # DROP rules don't use meters, so skip meter validation for them
        is_drop_action = (
            command.output_action and command.output_action.upper() == "DROP"
        )
        if command.meter_id > 0 and not is_drop_action:
            if not self._meter_exists(command.bridge_name, command.meter_id):
                # Attempt meter recovery before rejecting
                recovered = self._recover_meter(
                    command.bridge_name, command.meter_id
                )
                if not recovered:
                    self._publish_flow_mod_response(
                        command,
                        FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_METER_NOT_FOUND,
                        f"Meter {command.meter_id} not found on bridge "
                        f"{command.bridge_name} and recovery failed",
                        "METER_NOT_FOUND",
                    )
                    return
                logger.info(
                    f"Recovered meter {command.meter_id} during flow-modify"
                )

        # Modify the flow
        success, message, ovs_command = self._modify_flow(command)

        if success:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_SUCCESS,
                message,
                ovs_command=ovs_command,
            )
        else:
            self._publish_flow_mod_response(
                command,
                FlowModResponseStatus.FLOW_MOD_RESPONSE_STATUS_ERROR,
                message,
                "OVS_ERROR",
                ovs_command=ovs_command,
            )

    def _subscribe_to_flow_mod_topics(self):
        """Subscribe to flow mod command topics."""
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(
            f"Subscribing to flow mod topic pattern: {self.flow_mod_topic_pattern}"
        )

        try:
            self.mqtt_client.subscribe_raw(
                self.flow_mod_topic_pattern, self._handle_flow_mod_command, qos=2
            )
            logger.info(
                f"Successfully subscribed to flow mod topics: {self.flow_mod_topic_pattern}"
            )
        except Exception as e:
            logger.error(f"Failed to subscribe to flow mod topics: {e}", exc_info=True)

    def _subscribe_to_policy_topics(self):
        """Subscribe to policy command topics."""
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        logger.info(f"Subscribing to policy topic pattern: {self.policy_topic_pattern}")

        try:
            self.mqtt_client.subscribe_raw(
                self.policy_topic_pattern, self._handle_policy_update, qos=2
            )
            logger.info(
                f"Successfully subscribed to policy topics: {self.policy_topic_pattern}"
            )
        except Exception as e:
            logger.error(f"Failed to subscribe to policy topics: {e}", exc_info=True)

    def _subscribe_to_classifier_config_topics(self):
        """Subscribe to classifier configuration topics."""
        if not self.mqtt_client:
            logger.error("MQTT client not initialized")
            return

        if not self.classifier_config_handler:
            # Initialize the classifier config handler
            self.classifier_config_handler = ClassifierConfigHandler(
                mqtt_client=self.mqtt_client,
                site_id=self.site_id,
                device_id=self.device_id,
            )

        logger.info("Subscribing to classifier configuration topics")

        try:
            self.classifier_config_handler.subscribe_to_topics()
            logger.info("Successfully subscribed to classifier configuration topics")
        except Exception as e:
            logger.error(
                f"Failed to subscribe to classifier config topics: {e}", exc_info=True
            )

    def _handle_policy_update(self, topic: str, payload: bytes):
        """Handle incoming policy update from MQTT.

        Supports both protobuf and JSON formats. Updates the local SQLite
        policy cache accordingly.

        Args:
            topic: MQTT topic (e.g., .../policy/block/add)
            payload: Raw message payload (protobuf or JSON)
        """
        logger.debug(f"Received policy update on topic: {topic}")

        # Ignore response topics - we only process command topics
        if "/response" in topic:
            logger.debug(f"Ignoring response topic: {topic}")
            return

        # Deduplication: check if we've seen this exact message recently
        # Use 16 hex chars (64 bits) for lower collision probability
        # Use usedforsecurity=False for FIPS compatibility (non-cryptographic use)
        try:
            payload_hash = int(
                hashlib.md5(payload, usedforsecurity=False).hexdigest()[:16], 16
            )
        except TypeError:
            # Fallback for older Python versions without usedforsecurity parameter
            payload_hash = int(hashlib.md5(payload).hexdigest()[:16], 16)
        message_key = (topic, payload_hash)
        current_time = time.time()

        # Increment counter and perform periodic cleanup (avoid O(n) on every message)
        self._dedup_message_count += 1
        if (
            self._dedup_message_count >= self._dedup_cleanup_interval
            or len(self._processed_messages) >= self._dedup_max_entries
        ):
            cutoff_time = current_time - self._dedup_window
            self._processed_messages = {
                k: v for k, v in self._processed_messages.items() if v > cutoff_time
            }
            self._dedup_message_count = 0

        # Check if we've seen this message recently
        if message_key in self._processed_messages:
            seen_time = self._processed_messages[message_key]
            age = current_time - seen_time
            logger.warning(
                f"Ignoring duplicate policy message: topic={topic}, "
                f"age={age:.2f}s (seen {age:.2f}s ago)"
            )
            return

        # Mark this message as processed
        self._processed_messages[message_key] = current_time

        if not self.policy_cache:
            logger.error("Policy cache not initialized")
            return

        try:
            # Parse topic to determine action type
            # Topics: .../policy/block/add, .../policy/block/remove,
            #         .../policy/ratelimit/add, .../policy/ratelimit/remove,
            #         .../policy/sync
            topic_parts = topic.split("/")
            if len(topic_parts) < 2:
                logger.warning(f"Invalid policy topic format: {topic}")
                return

            # Extract rule type and action from topic
            # Format: axon/control/{site_id}/{device_id}/policy/{type}/{action}
            if "policy" not in topic_parts:
                logger.warning(f"Policy topic missing 'policy' segment: {topic}")
                return

            policy_idx = topic_parts.index("policy")
            remaining = topic_parts[policy_idx + 1 :]

            if len(remaining) == 0:
                logger.warning(f"Incomplete policy topic: {topic}")
                return

            rule_type = remaining[
                0
            ]  # 'block', 'ratelimit', 'sync', 'ipblock', 'urlblock', 'blocklist'
            action = remaining[1] if len(remaining) > 1 else None

            # Try to decompress if compressed (sync and blocklist use zstd)
            if ZSTD_AVAILABLE:
                try:
                    decompressor = zstd.ZstdDecompressor()
                    decompressed = decompressor.decompress(
                        payload, max_output_size=MAX_ZSTD_DECOMPRESSED_SIZE
                    )
                except zstd.ZstdError as e:
                    logger.warning(f"Zstd decompression failed: {e}, using raw payload")
                    decompressed = payload
                except Exception:
                    decompressed = payload
            else:
                decompressed = payload

            if rule_type == "ipblock" and action in ("add", "remove"):
                self._handle_ipblock(action, decompressed)
                return
            if rule_type == "urlblock" and action in ("add", "remove"):
                self._handle_urlblock(action, decompressed)
                return
            if rule_type == "blocklist" and action == "entry" and len(remaining) >= 3:
                entry_action = remaining[2]  # "add" or "remove"
                if entry_action in ("add", "remove"):
                    self._handle_blocklist_entry(entry_action, decompressed)
                    return
            if rule_type == "blocklist" and action in ("add", "remove"):
                self._handle_blocklist(action, decompressed)
                return
            if rule_type == "sync":
                if POLICY_PROTOBUF_AVAILABLE:
                    try:
                        sync_msg = PolicySync()
                        sync_msg.ParseFromString(decompressed)
                        self._handle_policy_sync_protobuf(sync_msg)
                        return
                    except Exception as e:
                        logger.error(
                            f"Failed to parse PolicySync protobuf (rule_type={rule_type}, "
                            f"action={action}, size={len(decompressed)} bytes): {type(e).__name__}: {e}"
                        )
                self._handle_policy_json(rule_type, action, decompressed)
                return

            # block / ratelimit: protobuf (PolicyUpdate) or JSON
            if POLICY_PROTOBUF_AVAILABLE and rule_type != "sync":
                self._handle_policy_protobuf(rule_type, action, decompressed)
            else:
                self._handle_policy_json(rule_type, action, decompressed)

        except Exception as e:
            logger.error(f"Error handling policy update: {e}", exc_info=True)

    def _handle_ipblock(self, action: str, payload: bytes) -> None:
        """Handle ipblock add/remove (raw IPBlockRule protobuf)."""
        if not POLICY_PROTOBUF_AVAILABLE or not self.policy_cache:
            return
        statuses: List[PolicyRuleStatus] = []
        try:
            rule = IPBlockRule()
            rule.ParseFromString(payload)
        except Exception as e:
            logger.warning(f"Failed to parse IPBlockRule: {e}")
            statuses.append(
                self._create_policy_rule_status(0, "", False, f"Parse error: {e}")
            )
            self._publish_policy_response(
                "ipblock",
                action,
                "",
                ip_block_rule_statuses=statuses,
            )
            return

        rule_id = rule.rule_id or 0
        priority = rule.priority or 7000
        idle_timeout = rule.idle_timeout or 300
        direction = _direction_to_str(rule.direction)
        ip_addr = rule.ip_address or None
        cidr = rule.cidr_range or None
        desc = rule.description or ""

        try:
            if action == "add":
                if not ip_addr and not cidr:
                    statuses.append(
                        self._create_policy_rule_status(
                            rule_id,
                            f"ipblock-{rule_id}",
                            False,
                            "Missing ip_address and cidr_range",
                        )
                    )
                    self._publish_policy_response(
                        "ipblock", action, "", ip_block_rule_statuses=statuses
                    )
                    return
                if ip_addr:
                    ipaddress.ip_address(ip_addr)
                if cidr:
                    ipaddress.ip_network(cidr, strict=False)
                self.policy_cache.add_ip_block_rule(
                    rule_id=rule_id,
                    ip_address=ip_addr,
                    cidr_range=cidr,
                    direction=direction,
                    priority=priority,
                    idle_timeout=idle_timeout,
                    enabled=rule.enabled,
                    description=desc or None,
                )
                ok, err = self._install_ip_block_flows(
                    rule_id, ip_addr, cidr, direction, priority, idle_timeout
                )
                if not ok:
                    statuses.append(
                        self._create_policy_rule_status(
                            rule_id, f"ipblock-{rule_id}", False, err
                        )
                    )
                else:
                    statuses.append(
                        self._create_policy_rule_status(
                            rule_id, f"ipblock-{rule_id}", True
                        )
                    )
            else:
                success, err = self._delete_ip_block_flows(rule_id)
                if success:
                    self.policy_cache.remove_ip_block_rule(rule_id)
                    statuses.append(
                        self._create_policy_rule_status(
                            rule_id, f"ipblock-{rule_id}", True
                        )
                    )
                else:
                    logger.error(
                        f"Failed to delete IP block flows for rule_id {rule_id}: {err}"
                    )
                    statuses.append(
                        self._create_policy_rule_status(
                            rule_id, f"ipblock-{rule_id}", False, err
                        )
                    )
        except ValueError as e:
            statuses.append(
                self._create_policy_rule_status(
                    rule_id, f"ipblock-{rule_id}", False, f"Invalid IP/CIDR: {e}"
                )
            )
        except Exception as e:
            logger.exception(f"IP block {action} failed")
            statuses.append(
                self._create_policy_rule_status(
                    rule_id, f"ipblock-{rule_id}", False, str(e)
                )
            )

        self._publish_policy_response(
            "ipblock", action, "", ip_block_rule_statuses=statuses
        )

    def _handle_urlblock(self, action: str, payload: bytes) -> None:
        """Handle urlblock add/remove (raw URLBlockRule protobuf). DB only, no OVS."""
        if not POLICY_PROTOBUF_AVAILABLE or not self.policy_cache:
            return
        statuses: List[PolicyRuleStatus] = []
        try:
            rule = URLBlockRule()
            rule.ParseFromString(payload)
        except Exception as e:
            logger.warning(f"Failed to parse URLBlockRule: {e}")
            statuses.append(
                self._create_policy_rule_status(0, "", False, f"Parse error: {e}")
            )
            self._publish_policy_response(
                "urlblock", action, "", url_block_rule_statuses=statuses
            )
            return

        rule_id = rule.rule_id or 0
        try:
            if action == "add":
                self.policy_cache.add_url_block_rule(
                    rule_id=rule_id,
                    domain=rule.domain or None,
                    domain_pattern=rule.domain_pattern or None,
                    match_subdomains=rule.match_subdomains,
                    priority=rule.priority or 7000,
                    idle_timeout=rule.idle_timeout or 300,
                    enabled=rule.enabled,
                    description=rule.description or None,
                )
            else:
                self.policy_cache.remove_url_block_rule(rule_id)
            statuses.append(
                self._create_policy_rule_status(
                    rule_id,
                    rule.domain or rule.domain_pattern or f"url-{rule_id}",
                    True,
                )
            )
        except Exception as e:
            logger.exception(f"URL block {action} failed")
            statuses.append(
                self._create_policy_rule_status(
                    rule_id,
                    rule.domain or rule.domain_pattern or f"url-{rule_id}",
                    False,
                    str(e),
                )
            )

        self._publish_policy_response(
            "urlblock", action, "", url_block_rule_statuses=statuses
        )

    def _handle_blocklist(self, action: str, payload: bytes) -> None:
        """Handle blocklist add/remove (PolicyUpdate with block_list or raw BlockListSync protobuf)."""
        if not POLICY_PROTOBUF_AVAILABLE or not self.policy_cache:
            return
        statuses: List[PolicyRuleStatus] = []
        correlation_id = ""

        # Try parsing as PolicyUpdate first (new format)
        msg = None
        try:
            update = PolicyUpdate()
            update.ParseFromString(payload)
            if update.HasField("block_list"):
                msg = update.block_list
                correlation_id = update.correlation_id or ""
                logger.debug(
                    f"Parsed PolicyUpdate with block_list, correlation_id={correlation_id}"
                )
            else:
                # Not a PolicyUpdate with block_list, try raw BlockListSync
                msg = None
        except Exception:
            # Not a PolicyUpdate, try raw BlockListSync
            msg = None

        # If not PolicyUpdate, try parsing as raw BlockListSync (backward compatibility)
        if msg is None:
            try:
                msg = BlockListSync()
                msg.ParseFromString(payload)
                logger.debug("Parsed raw BlockListSync (backward compatibility)")
            except Exception as e:
                logger.warning(f"Failed to parse BlockListSync or PolicyUpdate: {e}")
                statuses.append(
                    self._create_policy_rule_status(0, "", False, f"Parse error: {e}")
                )
                self._publish_policy_response(
                    "blocklist", action, correlation_id, block_list_statuses=statuses
                )
                return

        list_id = msg.list_id or 0
        name = msg.name or f"list-{list_id}"
        priority = msg.priority or 7000
        ip_entries = list(msg.ip_entries) if msg.ip_entries else []
        domain_entries = list(msg.domain_entries) if msg.domain_entries else []

        logger.info(
            f"Processing block list {action}: list_id={list_id}, name={name}, "
            f"enabled={msg.enabled}, ip_entries={len(ip_entries)}, "
            f"domain_entries={len(domain_entries)}"
        )

        try:
            if action == "add":
                self.policy_cache.add_or_update_block_list(
                    list_id=list_id,
                    name=name,
                    enabled=msg.enabled,
                    priority=priority,
                    ip_entries=ip_entries,
                    domain_entries=domain_entries,
                )
                if msg.enabled and ip_entries:
                    ok, err = self._install_block_list_ip_flows(
                        list_id, priority, ip_entries
                    )
                    if not ok:
                        statuses.append(
                            self._create_policy_rule_status(list_id, name, False, err)
                        )
                        self._publish_policy_response(
                            "blocklist",
                            action,
                            correlation_id,
                            block_list_statuses=statuses,
                        )
                        return
                # Include enabled status in the response message
                enabled_status = msg.enabled
                status_msg = f"enabled={enabled_status}"
                if not enabled_status:
                    status_msg += " (list is disabled, no flows installed)"
                elif not ip_entries:
                    status_msg += " (no IP entries to install flows)"
                else:
                    status_msg += f" (flows installed for {len(ip_entries)} IPs)"

                statuses.append(
                    self._create_policy_rule_status(list_id, name, True, status_msg)
                )
            else:
                success, err = self._delete_block_list_ip_flows(list_id)
                if success:
                    self.policy_cache.remove_block_list(list_id)
                    statuses.append(
                        self._create_policy_rule_status(list_id, name, True)
                    )
                else:
                    logger.error(
                        f"Failed to delete block list IP flows for list_id {list_id}: {err}"
                    )
                    statuses.append(
                        self._create_policy_rule_status(list_id, name, False, err)
                    )
        except Exception as e:
            logger.exception(f"Block list {action} failed")
            statuses.append(
                self._create_policy_rule_status(list_id, name, False, str(e))
            )

        logger.info(
            f"Publishing block list {action} response: list_id={list_id}, "
            f"name={name}, enabled={msg.enabled if action == 'add' else 'N/A'}, "
            f"success={all(s.success for s in statuses)}"
        )
        self._publish_policy_response(
            "blocklist", action, correlation_id, block_list_statuses=statuses
        )

    def _handle_blocklist_entry(self, action: str, payload: bytes) -> None:
        """Handle incremental block list entry add/remove.

        Parses a PolicyUpdate with block_list_entry_update field and applies
        the delta (add or remove entries) to the local policy cache and OVS flows.
        """
        if not POLICY_PROTOBUF_AVAILABLE or not self.policy_cache:
            return
        statuses: List[PolicyRuleStatus] = []
        correlation_id = ""

        # Parse PolicyUpdate with block_list_entry_update
        msg = None
        try:
            update = PolicyUpdate()
            update.ParseFromString(payload)
            if update.HasField("block_list_entry_update"):
                msg = update.block_list_entry_update
                correlation_id = update.correlation_id or ""
                logger.debug(
                    f"Parsed PolicyUpdate with block_list_entry_update, "
                    f"correlation_id={correlation_id}"
                )
            else:
                logger.warning(
                    "PolicyUpdate does not contain block_list_entry_update field"
                )
                statuses.append(
                    self._create_policy_rule_status(
                        0, "", False, "Missing block_list_entry_update field"
                    )
                )
                self._publish_policy_response(
                    "blocklist", f"entry/{action}", correlation_id,
                    block_list_statuses=statuses,
                )
                return
        except Exception as e:
            logger.warning(f"Failed to parse BlockListEntryUpdate: {e}")
            statuses.append(
                self._create_policy_rule_status(0, "", False, f"Parse error: {e}")
            )
            self._publish_policy_response(
                "blocklist", f"entry/{action}", correlation_id,
                block_list_statuses=statuses,
            )
            return

        list_id = msg.list_id or 0
        name = msg.name or f"list-{list_id}"
        priority = msg.priority or 7000
        idle_timeout = msg.idle_timeout or 300
        ip_entries = list(msg.ip_entries) if msg.ip_entries else []
        domain_entries = list(msg.domain_entries) if msg.domain_entries else []

        logger.info(
            f"Processing block list entry {action}: list_id={list_id}, name={name}, "
            f"ip_entries={len(ip_entries)}, domain_entries={len(domain_entries)}"
        )

        # Verify block list exists on this agent
        if not self.policy_cache.block_list_exists(list_id):
            err_msg = (
                f"Block list {list_id} does not exist on this agent. "
                "A full block list sync may be required."
            )
            logger.warning(err_msg)
            statuses.append(
                self._create_policy_rule_status(list_id, name, False, err_msg)
            )
            self._publish_policy_response(
                "blocklist", f"entry/{action}", correlation_id,
                block_list_statuses=statuses,
            )
            return

        is_enabled = self.policy_cache.is_block_list_enabled(list_id)

        try:
            if action == "add":
                ok = self.policy_cache.add_block_list_entries(
                    list_id, ip_entries, domain_entries,
                )
                if not ok:
                    statuses.append(
                        self._create_policy_rule_status(
                            list_id, name, False, "Failed to add entries to cache"
                        )
                    )
                    self._publish_policy_response(
                        "blocklist", f"entry/{action}", correlation_id,
                        block_list_statuses=statuses,
                    )
                    return

                # Install OVS flows for new IP entries if list is enabled
                if is_enabled and ip_entries:
                    ok, err = self._install_block_list_ip_flows_incremental(
                        list_id, priority, ip_entries, idle_timeout,
                    )
                    if not ok:
                        statuses.append(
                            self._create_policy_rule_status(
                                list_id, name, False,
                                f"Entries cached but IP flow install failed: {err}",
                            )
                        )
                        self._publish_policy_response(
                            "blocklist", f"entry/{action}", correlation_id,
                            block_list_statuses=statuses,
                        )
                        return

                status_msg = (
                    f"Added {len(ip_entries)} IP, {len(domain_entries)} domain entries"
                )
                if is_enabled and ip_entries:
                    status_msg += f" (flows installed for {len(ip_entries)} IPs)"
                elif not is_enabled:
                    status_msg += " (list disabled, no flows installed)"
                statuses.append(
                    self._create_policy_rule_status(list_id, name, True, status_msg)
                )

            else:  # action == "remove"
                # Remove entries from cache only — existing OVS IP flows will
                # expire naturally via idle_timeout (default 300s). This avoids
                # the complexity of granular flow deletion and is safe because
                # the classifier checks the cache for domain entries, and IP
                # flows are short-lived.
                ok = self.policy_cache.remove_block_list_entries(
                    list_id, ip_entries, domain_entries,
                )
                if not ok:
                    statuses.append(
                        self._create_policy_rule_status(
                            list_id, name, False, "Failed to remove entries from cache"
                        )
                    )
                    self._publish_policy_response(
                        "blocklist", f"entry/{action}", correlation_id,
                        block_list_statuses=statuses,
                    )
                    return

                status_msg = (
                    f"Removed {len(ip_entries)} IP, {len(domain_entries)} domain entries"
                )
                if is_enabled and ip_entries:
                    status_msg += (
                        f" (IP flows will expire via idle_timeout for {len(ip_entries)} IPs)"
                    )
                statuses.append(
                    self._create_policy_rule_status(list_id, name, True, status_msg)
                )

        except Exception as e:
            logger.exception(f"Block list entry {action} failed")
            statuses.append(
                self._create_policy_rule_status(list_id, name, False, str(e))
            )

        logger.info(
            f"Publishing block list entry/{action} response: list_id={list_id}, "
            f"name={name}, success={all(s.success for s in statuses)}"
        )
        self._publish_policy_response(
            "blocklist", f"entry/{action}", correlation_id,
            block_list_statuses=statuses,
        )

    def _handle_policy_sync_protobuf(self, sync_msg: "PolicySync") -> None:
        """Handle full policy sync (PolicySync protobuf)."""
        if not self.policy_cache:
            return
        block_statuses: List[PolicyRuleStatus] = []
        ratelimit_statuses: List[PolicyRuleStatus] = []
        ip_block_statuses: List[PolicyRuleStatus] = []
        url_block_statuses: List[PolicyRuleStatus] = []
        block_list_statuses_list: List[PolicyRuleStatus] = []
        correlation_id = sync_msg.correlation_id or ""

        # Sync app block rules and rate limits (existing logic)
        block_rule_objs = []
        for r in sync_msg.block_rules:
            app_name = r.app_name
            rule_id = r.rule_id or 0
            if not app_name:
                block_statuses.append(
                    self._create_policy_rule_status(
                        rule_id, "", False, "Missing app_name"
                    )
                )
                continue

            # Parse time constraint if present
            tc_obj = self._parse_time_constraint(r)

            block_rule_objs.append(
                BlockRule(
                    app_name=app_name,
                    app_pattern=r.app_pattern or None,
                    priority=r.priority or 6000,
                    idle_timeout=r.idle_timeout or 300,
                    enabled=r.enabled,
                    target_mac=r.target_mac or None,
                    target_ip=r.target_ip or None,
                    target_network=r.target_network or None,
                    time_constraint=tc_obj,
                )
            )
            block_statuses.append(
                self._create_policy_rule_status(rule_id, app_name, True)
            )

        rate_limit_objs = []
        for r in sync_msg.rate_limit_rules:
            app_name = r.app_name
            rate_kbps = r.rate_kbps
            rule_id = r.rule_id or 0
            meter_id = 0
            if not app_name or not rate_kbps:
                ratelimit_statuses.append(
                    self._create_policy_rule_status(
                        rule_id, app_name or "", False, "Missing app_name or rate_kbps"
                    )
                )
                continue

            # Parse time constraint if present
            rl_tc_obj = self._parse_time_constraint(r)

            try:
                burst_kbps = r.burst_kbps or 0
                meter_id = self._ensure_meter_for_rate(rate_kbps, burst_kbps)
                if meter_id is None:
                    raise ValueError("Failed to ensure meter")
                rate_limit_objs.append(
                    RateLimitRule(
                        app_name=app_name,
                        meter_id=meter_id,
                        rate_kbps=rate_kbps,
                        burst_kbps=burst_kbps,
                        app_pattern=r.app_pattern or None,
                        priority=r.priority or 5000,
                        idle_timeout=r.idle_timeout or 300,
                        enabled=r.enabled,
                        target_mac=r.target_mac or None,
                        target_ip=r.target_ip or None,
                        target_network=r.target_network or None,
                        time_constraint=rl_tc_obj,
                    )
                )
                ratelimit_statuses.append(
                    self._create_policy_rule_status(
                        rule_id, app_name, True, "", meter_id
                    )
                )
            except Exception as e:
                ratelimit_statuses.append(
                    self._create_policy_rule_status(
                        rule_id, app_name, False, str(e), meter_id
                    )
                )

        self.policy_cache.sync_block_rules(block_rule_objs)
        self.policy_cache.sync_rate_limits(rate_limit_objs)

        # Sync IP block rules: clear existing OVS flows by rule_id, then sync DB and install new
        # NOTE: Non-atomic sync - there is a brief window where old flows are deleted before
        # new flows are installed. During this window (typically < 100ms), traffic that should
        # be blocked may pass through. For atomic updates, implement install-before-delete with
        # distinct cookies, but this adds complexity. Current trade-off favors simplicity.
        logger.debug(
            "IP block rule sync: deleting existing flows (non-atomic, brief unblocked window possible)"
        )
        for rule_id in self.policy_cache.get_all_ip_block_rule_ids():
            self._delete_ip_block_flows(rule_id)
        ip_block_rows = []
        for r in sync_msg.ip_block_rules:
            rule_id = r.rule_id or 0
            ip_addr = r.ip_address or None
            cidr = r.cidr_range or None
            direction = _direction_to_str(r.direction)
            priority = r.priority or 7000
            idle = r.idle_timeout or 300
            try:
                if ip_addr:
                    ipaddress.ip_address(ip_addr)
                if cidr:
                    ipaddress.ip_network(cidr, strict=False)
                ip_block_rows.append(
                    IPBlockRuleRow(
                        rule_id=rule_id,
                        ip_address=ip_addr,
                        cidr_range=cidr,
                        direction=direction,
                        priority=priority,
                        idle_timeout=idle,
                        enabled=r.enabled,
                        description=r.description or None,
                    )
                )
                ip_block_statuses.append(
                    self._create_policy_rule_status(rule_id, f"ipblock-{rule_id}", True)
                )
            except ValueError as e:
                ip_block_statuses.append(
                    self._create_policy_rule_status(
                        rule_id, f"ipblock-{rule_id}", False, f"Invalid IP/CIDR: {e}"
                    )
                )
        self.policy_cache.sync_ip_block_rules(ip_block_rows)
        for row in ip_block_rows:
            if row.enabled and (row.ip_address or row.cidr_range):
                ok, _ = self._install_ip_block_flows(
                    row.rule_id,
                    row.ip_address,
                    row.cidr_range,
                    row.direction,
                    row.priority,
                    row.idle_timeout,
                )
                if not ok:
                    for s in ip_block_statuses:
                        if s.rule_id == row.rule_id:
                            s.success = False
                            s.error_message = "OVS flow install failed"
                            break

        # Sync URL block rules (DB only)
        url_block_rows = []
        for r in sync_msg.url_block_rules:
            rule_id = r.rule_id or 0
            url_block_rows.append(
                URLBlockRuleRow(
                    rule_id=rule_id,
                    domain=r.domain or None,
                    domain_pattern=r.domain_pattern or None,
                    match_subdomains=r.match_subdomains,
                    priority=r.priority or 7000,
                    idle_timeout=r.idle_timeout or 300,
                    enabled=r.enabled,
                    description=r.description or None,
                )
            )
            url_block_statuses.append(
                self._create_policy_rule_status(
                    rule_id, r.domain or r.domain_pattern or f"url-{rule_id}", True
                )
            )
        self.policy_cache.sync_url_block_rules(url_block_rows)

        # Sync block lists: remove OVS flows for existing lists, sync DB, install for enabled
        for list_id in self.policy_cache.get_all_block_list_ids():
            self._delete_block_list_ip_flows(list_id)
        block_list_data: List[tuple] = []
        for bl in sync_msg.block_lists:
            list_id = bl.list_id or 0
            name = bl.name or f"list-{list_id}"
            priority = bl.priority or 7000
            ip_entries = list(bl.ip_entries) if bl.ip_entries else []
            domain_entries = list(bl.domain_entries) if bl.domain_entries else []
            block_list_data.append(
                (
                    BlockListRow(
                        list_id=list_id,
                        name=name,
                        enabled=bl.enabled,
                        priority=priority,
                    ),
                    ip_entries,
                    domain_entries,
                )
            )
            block_list_statuses_list.append(
                self._create_policy_rule_status(list_id, name, True)
            )
        self.policy_cache.sync_block_lists(block_list_data)
        for bl, ip_entries, domain_entries in block_list_data:
            if bl.enabled and ip_entries:
                ok, err = self._install_block_list_ip_flows(
                    bl.list_id, bl.priority, ip_entries
                )
                if not ok:
                    for s in block_list_statuses_list:
                        if s.rule_id == bl.list_id:
                            s.success = False
                            s.error_message = err
                            break

        self._sync_meter_registry()

        self._publish_policy_response(
            "sync",
            None,
            correlation_id,
            block_statuses=block_statuses,
            ratelimit_statuses=ratelimit_statuses,
            ip_block_rule_statuses=ip_block_statuses,
            url_block_rule_statuses=url_block_statuses,
            block_list_statuses=block_list_statuses_list,
        )

    def _parse_time_constraint(self, rule) -> Optional[TimeConstraint]:
        """Parse TimeConstraint from a protobuf rule if present.

        Args:
            rule: Protobuf rule message (BlockRule or RateLimitRule)

        Returns:
            TimeConstraint object if present, None otherwise
        """
        if not rule.HasField("time_constraint"):
            return None
        tc = rule.time_constraint
        return TimeConstraint(
            time_start=tc.time_start or None,
            time_end=tc.time_end or None,
            days_of_week=list(tc.days_of_week) if tc.days_of_week else None,
            timezone=tc.timezone or None,
        )

    def _handle_policy_protobuf(self, rule_type: str, action: str, payload: bytes):
        """Handle policy update using protobuf format."""
        block_statuses = []
        ratelimit_statuses = []
        correlation_id = ""

        try:
            update = PolicyUpdate()
            update.ParseFromString(payload)
            correlation_id = update.correlation_id

            if update.HasField("block_rule"):
                rule = update.block_rule
                rule_id = rule.rule_id if rule.rule_id else 0

                # Parse time constraint if present
                time_constraint = self._parse_time_constraint(rule)

                try:
                    if action == "add":
                        self.policy_cache.add_block_rule(
                            app_name=rule.app_name,
                            app_pattern=rule.app_pattern if rule.app_pattern else None,
                            priority=rule.priority if rule.priority else 6000,
                            idle_timeout=(
                                rule.idle_timeout if rule.idle_timeout else 300
                            ),
                            enabled=rule.enabled,
                            target_mac=rule.target_mac or None,
                            target_ip=rule.target_ip or None,
                            target_network=rule.target_network or None,
                            time_constraint=time_constraint,
                        )
                        logger.info(f"Added block rule: {rule.app_name}")
                        block_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, rule.app_name, True
                            )
                        )
                    elif action == "remove":
                        self.policy_cache.remove_block_rule(rule.app_name)
                        logger.info(f"Removed block rule: {rule.app_name}")
                        block_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, rule.app_name, True
                            )
                        )
                except Exception as e:
                    logger.error(f"Failed to apply block rule {rule.app_name}: {e}")
                    block_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, rule.app_name, False, str(e)
                        )
                    )

            elif update.HasField("rate_limit_rule"):
                rule = update.rate_limit_rule
                rule_id = rule.rule_id if rule.rule_id else 0
                meter_id = 0

                # Parse time constraint if present
                rate_limit_time_constraint = self._parse_time_constraint(rule)

                try:
                    if action == "add":
                        rate_kbps = rule.rate_kbps
                        burst_kbps = rule.burst_kbps if rule.burst_kbps else 0

                        # Determine meter_id: use provided one or find/create via meter reuse
                        if rule.meter_id > 0:
                            # Meter ID provided - use it (backward compatibility)
                            meter_id = rule.meter_id
                            # Verify meter exists in OVS before registering
                            if not self._verify_meter_exists_in_ovs(meter_id):
                                logger.warning(
                                    f"Provided meter_id {meter_id} does not exist in OVS "
                                    f"for rule {rule.app_name}, falling back to ensure"
                                )
                                # Fall back to finding/creating a meter
                                meter_id = self._ensure_meter_for_rate(
                                    rate_kbps, burst_kbps
                                )
                                if meter_id is None:
                                    raise ValueError(
                                        f"Meter {rule.meter_id} not found in OVS and "
                                        "failed to create replacement"
                                    )
                            else:
                                # Meter exists in OVS, register if not in cache
                                if self.policy_cache.get_meter_info(meter_id) is None:
                                    if self.bridge_name:
                                        self.policy_cache.register_meter(
                                            meter_id,
                                            self.bridge_name,
                                            rate_kbps,
                                            burst_kbps,
                                        )
                                else:
                                    self.policy_cache.increment_meter_refs(meter_id)
                        else:
                            # No meter_id provided - find or create one
                            meter_id = self._ensure_meter_for_rate(
                                rate_kbps, burst_kbps
                            )
                            if meter_id is None:
                                raise ValueError(
                                    "Failed to ensure meter for rate limit"
                                )

                        self.policy_cache.add_rate_limit(
                            app_name=rule.app_name,
                            meter_id=meter_id,
                            rate_kbps=rate_kbps,
                            burst_kbps=burst_kbps,
                            app_pattern=rule.app_pattern if rule.app_pattern else None,
                            priority=rule.priority if rule.priority > 0 else 5000,
                            idle_timeout=(
                                rule.idle_timeout if rule.idle_timeout > 0 else 300
                            ),
                            enabled=rule.enabled,
                            target_mac=rule.target_mac or None,
                            target_ip=rule.target_ip or None,
                            target_network=rule.target_network or None,
                            time_constraint=rate_limit_time_constraint,
                        )
                        logger.info(
                            f"Added rate limit: {rule.app_name} ({rate_kbps} kbps, meter={meter_id})"
                        )
                        ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, rule.app_name, True, "", meter_id
                            )
                        )
                    elif action == "remove":
                        # Get meter_id before removing to decrement refs
                        existing_rule = self.policy_cache.get_rate_limit(rule.app_name)
                        if existing_rule:
                            meter_id = existing_rule.meter_id
                        self.policy_cache.remove_rate_limit(rule.app_name)
                        if existing_rule:
                            can_delete = self.policy_cache.decrement_meter_refs(
                                existing_rule.meter_id
                            )
                            if can_delete and self.bridge_name:
                                # No more references, optionally delete the meter
                                self._delete_meter(
                                    self.bridge_name, existing_rule.meter_id
                                )
                                logger.info(
                                    f"Deleted unused meter {existing_rule.meter_id}"
                                )
                        logger.info(f"Removed rate limit: {rule.app_name}")
                        ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, rule.app_name, True, "", meter_id
                            )
                        )
                except Exception as e:
                    logger.error(
                        f"Failed to apply rate limit rule {rule.app_name}: {e}"
                    )
                    ratelimit_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, rule.app_name, False, str(e), meter_id
                        )
                    )

            # Send response
            self._publish_policy_response(
                rule_type, action, correlation_id, block_statuses, ratelimit_statuses
            )

        except Exception as e:
            # Protobuf parsing failed - this is expected when receiving JSON messages
            # or messages of a different protobuf type (e.g., MeterCommand)
            # Fall back to JSON silently (no error log since fallback is intentional)
            logger.debug(f"Protobuf parsing failed, falling back to JSON: {e}")
            self._handle_policy_json(rule_type, action, payload)

    def _handle_policy_json(self, rule_type: str, action: str, payload: bytes):
        """Handle policy update using JSON format."""
        import json

        block_statuses = []
        ratelimit_statuses = []
        correlation_id = ""

        try:
            data = json.loads(payload.decode("utf-8"))
            correlation_id = data.get("correlation_id", "")

            if rule_type == "block":
                app_name = data.get("app_name")
                rule_id = data.get("rule_id", 0)

                if not app_name:
                    logger.warning("Block rule missing app_name")
                    block_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, "", False, "Missing app_name"
                        )
                    )
                    self._publish_policy_response(
                        rule_type,
                        action,
                        correlation_id,
                        block_statuses,
                        ratelimit_statuses,
                    )
                    return

                try:
                    if action == "add":
                        self.policy_cache.add_block_rule(
                            app_name=app_name,
                            app_pattern=data.get("app_pattern"),
                            priority=data.get("priority", 6000),
                            idle_timeout=data.get("idle_timeout", 300),
                            enabled=data.get("enabled", True),
                        )
                        logger.info(f"Added block rule (JSON): {app_name}")
                        block_statuses.append(
                            self._create_policy_rule_status(rule_id, app_name, True)
                        )
                    elif action == "remove":
                        self.policy_cache.remove_block_rule(app_name)
                        logger.info(f"Removed block rule (JSON): {app_name}")
                        block_statuses.append(
                            self._create_policy_rule_status(rule_id, app_name, True)
                        )
                except Exception as e:
                    logger.error(f"Failed to apply block rule {app_name}: {e}")
                    block_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, app_name, False, str(e)
                        )
                    )

                # Send response for block rules
                self._publish_policy_response(
                    rule_type,
                    action,
                    correlation_id,
                    block_statuses,
                    ratelimit_statuses,
                )

            elif rule_type == "ratelimit":
                app_name = data.get("app_name")
                provided_meter_id = data.get("meter_id")
                rate_kbps = data.get("rate_kbps")
                burst_kbps = data.get("burst_kbps", 0)
                rule_id = data.get("rule_id", 0)
                meter_id = 0

                if not app_name:
                    logger.warning("Rate limit rule missing app_name")
                    ratelimit_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, "", False, "Missing app_name"
                        )
                    )
                    self._publish_policy_response(
                        rule_type,
                        action,
                        correlation_id,
                        block_statuses,
                        ratelimit_statuses,
                    )
                    return

                try:
                    if action == "add":
                        if not rate_kbps:
                            raise ValueError("Missing rate_kbps")

                        # Determine meter_id: use provided one or find/create via meter reuse
                        if provided_meter_id and provided_meter_id > 0:
                            # Meter ID provided - use it (backward compatibility)
                            meter_id = provided_meter_id
                            # Register in meter registry if not already there
                            if self.policy_cache.get_meter_info(meter_id) is None:
                                if self.bridge_name:
                                    self.policy_cache.register_meter(
                                        meter_id,
                                        self.bridge_name,
                                        rate_kbps,
                                        burst_kbps,
                                    )
                            else:
                                self.policy_cache.increment_meter_refs(meter_id)
                        else:
                            # No meter_id provided - find or create one
                            meter_id = self._ensure_meter_for_rate(
                                rate_kbps, burst_kbps
                            )
                            if meter_id is None:
                                raise ValueError(
                                    "Failed to ensure meter for rate limit"
                                )

                        self.policy_cache.add_rate_limit(
                            app_name=app_name,
                            meter_id=meter_id,
                            rate_kbps=rate_kbps,
                            burst_kbps=burst_kbps,
                            app_pattern=data.get("app_pattern"),
                            priority=data.get("priority", 5000),
                            idle_timeout=data.get("idle_timeout", 300),
                            enabled=data.get("enabled", True),
                        )
                        logger.info(
                            f"Added rate limit (JSON): {app_name} ({rate_kbps} kbps, meter={meter_id})"
                        )
                        ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, app_name, True, "", meter_id
                            )
                        )
                    elif action == "remove":
                        # Get meter_id before removing to decrement refs
                        existing_rule = self.policy_cache.get_rate_limit(app_name)
                        if existing_rule:
                            meter_id = existing_rule.meter_id
                        self.policy_cache.remove_rate_limit(app_name)
                        if existing_rule:
                            can_delete = self.policy_cache.decrement_meter_refs(
                                existing_rule.meter_id
                            )
                            if can_delete and self.bridge_name:
                                # No more references, optionally delete the meter
                                self._delete_meter(
                                    self.bridge_name, existing_rule.meter_id
                                )
                                logger.info(
                                    f"Deleted unused meter {existing_rule.meter_id}"
                                )
                        logger.info(f"Removed rate limit (JSON): {app_name}")
                        ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, app_name, True, "", meter_id
                            )
                        )
                except Exception as e:
                    logger.error(f"Failed to apply rate limit rule {app_name}: {e}")
                    ratelimit_statuses.append(
                        self._create_policy_rule_status(
                            rule_id, app_name, False, str(e), meter_id
                        )
                    )

                # Send response for rate limit rules
                self._publish_policy_response(
                    rule_type,
                    action,
                    correlation_id,
                    block_statuses,
                    ratelimit_statuses,
                )

            elif rule_type == "sync":
                # Full policy sync with response tracking
                block_rules = data.get("block_rules", [])
                rate_limit_rules = data.get("rate_limit_rules", [])
                sync_block_statuses = []
                sync_ratelimit_statuses = []

                # Convert to dataclass objects and track block rule statuses
                block_rule_objs = []
                for r in block_rules:
                    app_name = r.get("app_name")
                    rule_id = r.get("rule_id", 0)
                    if not app_name:
                        sync_block_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, "", False, "Missing app_name"
                            )
                        )
                        continue

                    block_rule_objs.append(
                        BlockRule(
                            app_name=app_name,
                            app_pattern=r.get("app_pattern"),
                            priority=r.get("priority", 6000),
                            idle_timeout=r.get("idle_timeout", 300),
                            enabled=r.get("enabled", True),
                        )
                    )
                    sync_block_statuses.append(
                        self._create_policy_rule_status(rule_id, app_name, True)
                    )

                # Process rate limit rules with meter reuse and track statuses
                rate_limit_objs = []
                for r in rate_limit_rules:
                    app_name = r.get("app_name")
                    rate_kbps = r.get("rate_kbps")
                    rule_id = r.get("rule_id", 0)
                    meter_id = 0

                    if not app_name or not rate_kbps:
                        sync_ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id,
                                app_name or "",
                                False,
                                "Missing app_name or rate_kbps",
                            )
                        )
                        continue

                    burst_kbps = r.get("burst_kbps", 0)
                    provided_meter_id = r.get("meter_id")

                    try:
                        # Determine meter_id using meter reuse
                        if provided_meter_id and provided_meter_id > 0:
                            # Verify provided meter exists in OVS
                            if self._verify_meter_exists_in_ovs(provided_meter_id):
                                meter_id = provided_meter_id
                            else:
                                logger.warning(
                                    f"Provided meter_id {provided_meter_id} does not "
                                    f"exist in OVS for {app_name}, falling back"
                                )
                                # Fall back to finding/creating a meter
                                meter_id = self._ensure_meter_for_rate(
                                    rate_kbps, burst_kbps
                                )
                                if meter_id is None:
                                    raise ValueError(
                                        f"Meter {provided_meter_id} not found in OVS "
                                        "and failed to create replacement"
                                    )
                        else:
                            # Find or create meter for this rate
                            meter_id = self._ensure_meter_for_rate(
                                rate_kbps, burst_kbps
                            )
                            if meter_id is None:
                                raise ValueError("Failed to ensure meter")

                        rate_limit_objs.append(
                            RateLimitRule(
                                app_name=app_name,
                                meter_id=meter_id,
                                rate_kbps=rate_kbps,
                                burst_kbps=burst_kbps,
                                app_pattern=r.get("app_pattern"),
                                priority=r.get("priority", 5000),
                                idle_timeout=r.get("idle_timeout", 300),
                                enabled=r.get("enabled", True),
                            )
                        )
                        sync_ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, app_name, True, "", meter_id
                            )
                        )
                    except Exception as e:
                        logger.warning(f"Skipping rate limit {app_name}: {e}")
                        sync_ratelimit_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, app_name, False, str(e), meter_id
                            )
                        )

                self.policy_cache.sync_block_rules(block_rule_objs)
                self.policy_cache.sync_rate_limits(rate_limit_objs)

                # IP block, URL block, block lists (JSON sync)
                sync_ip_block_statuses: List[PolicyRuleStatus] = []
                sync_url_block_statuses: List[PolicyRuleStatus] = []
                sync_block_list_statuses: List[PolicyRuleStatus] = []
                ip_block_rules = data.get("ip_block_rules", [])
                url_block_rules = data.get("url_block_rules", [])
                block_lists = data.get("block_lists", [])

                for rule_id in self.policy_cache.get_all_ip_block_rule_ids():
                    self._delete_ip_block_flows(rule_id)
                ip_block_rows = []
                for r in ip_block_rules:
                    try:
                        rule_id = int(r.get("rule_id", 0))
                        ip_addr = r.get("ip_address") or None
                        cidr = r.get("cidr_range") or None
                        direction = r.get("direction", "both")
                        priority = int(r.get("priority", 7000))
                        idle = int(r.get("idle_timeout", 300))
                        if ip_addr:
                            ipaddress.ip_address(ip_addr)
                        if cidr:
                            ipaddress.ip_network(cidr, strict=False)
                        ip_block_rows.append(
                            IPBlockRuleRow(
                                rule_id=rule_id,
                                ip_address=ip_addr,
                                cidr_range=cidr,
                                direction=direction,
                                priority=priority,
                                idle_timeout=idle,
                                enabled=bool(r.get("enabled", True)),
                                description=r.get("description"),
                            )
                        )
                        sync_ip_block_statuses.append(
                            self._create_policy_rule_status(
                                rule_id, f"ipblock-{rule_id}", True
                            )
                        )
                    except (ValueError, TypeError) as e:
                        # Try to get rule_id for error reporting, but handle failure gracefully
                        try:
                            rule_id = int(r.get("rule_id", 0))
                        except (ValueError, TypeError):
                            rule_id = 0
                        sync_ip_block_statuses.append(
                            self._create_policy_rule_status(
                                rule_id,
                                f"ipblock-{rule_id}",
                                False,
                                f"Invalid IP/CIDR or parsing error: {e}",
                            )
                        )
                self.policy_cache.sync_ip_block_rules(ip_block_rows)
                for row in ip_block_rows:
                    if row.enabled and (row.ip_address or row.cidr_range):
                        ok, _ = self._install_ip_block_flows(
                            row.rule_id,
                            row.ip_address,
                            row.cidr_range,
                            row.direction,
                            row.priority,
                            row.idle_timeout,
                        )
                        if not ok:
                            for s in sync_ip_block_statuses:
                                if s.rule_id == row.rule_id:
                                    s.success = False
                                    s.error_message = "OVS flow install failed"
                                    break

                url_block_rows = []
                for r in url_block_rules:
                    rule_id = int(r.get("rule_id", 0))
                    url_block_rows.append(
                        URLBlockRuleRow(
                            rule_id=rule_id,
                            domain=r.get("domain"),
                            domain_pattern=r.get("domain_pattern"),
                            match_subdomains=bool(r.get("match_subdomains", True)),
                            priority=int(r.get("priority", 7000)),
                            idle_timeout=int(r.get("idle_timeout", 300)),
                            enabled=bool(r.get("enabled", True)),
                            description=r.get("description"),
                        )
                    )
                    sync_url_block_statuses.append(
                        self._create_policy_rule_status(
                            rule_id,
                            r.get("domain")
                            or r.get("domain_pattern")
                            or f"url-{rule_id}",
                            True,
                        )
                    )
                self.policy_cache.sync_url_block_rules(url_block_rows)

                for list_id in self.policy_cache.get_all_block_list_ids():
                    self._delete_block_list_ip_flows(list_id)
                block_list_data: List[tuple] = []
                for bl in block_lists:
                    list_id = int(bl.get("list_id", 0))
                    name = bl.get("name") or f"list-{list_id}"
                    priority = int(bl.get("priority", 7000))
                    ip_entries = list(bl.get("ip_entries") or [])
                    domain_entries = list(bl.get("domain_entries") or [])
                    block_list_data.append(
                        (
                            BlockListRow(
                                list_id=list_id,
                                name=name,
                                enabled=bool(bl.get("enabled", False)),
                                priority=priority,
                            ),
                            ip_entries,
                            domain_entries,
                        )
                    )
                    sync_block_list_statuses.append(
                        self._create_policy_rule_status(list_id, name, True)
                    )
                self.policy_cache.sync_block_lists(block_list_data)
                for bl, ip_entries, domain_entries in block_list_data:
                    if bl.enabled and ip_entries:
                        ok, err = self._install_block_list_ip_flows(
                            bl.list_id, bl.priority, ip_entries
                        )
                        if not ok:
                            for s in sync_block_list_statuses:
                                if s.rule_id == bl.list_id:
                                    s.success = False
                                    s.error_message = err
                                    break

                # Re-sync meter registry to match the new rate limits
                self._sync_meter_registry()

                logger.info(
                    f"Policy sync complete: {len(block_rule_objs)} block rules, "
                    f"{len(rate_limit_objs)} rate limit rules, "
                    f"{len(ip_block_rows)} IP block, {len(url_block_rows)} URL block, "
                    f"{len(block_list_data)} block lists"
                )

                # Send sync response
                self._publish_policy_response(
                    rule_type,
                    None,
                    correlation_id,
                    block_statuses=sync_block_statuses,
                    ratelimit_statuses=sync_ratelimit_statuses,
                    ip_block_rule_statuses=sync_ip_block_statuses,
                    url_block_rule_statuses=sync_url_block_statuses,
                    block_list_statuses=sync_block_list_statuses,
                )

        except json.JSONDecodeError as e:
            # JSON parsing failed - this can happen with protobuf-only messages
            logger.debug(f"JSON parsing failed for policy update: {e}")
        except UnicodeDecodeError as e:
            # Binary data that can't be decoded as UTF-8 - likely a protobuf message
            # of a different type (e.g., MeterCommand) that we can safely ignore
            logger.debug(f"Binary data received on policy topic (not UTF-8): {e}")
        except Exception as e:
            # Only log as error for unexpected exceptions that indicate real problems
            logger.warning(f"Unexpected error handling policy update: {e}")

    def _on_reconnect(self):
        """Restore MQTT subscriptions after reconnection."""
        self._subscribe_to_all_topics()

    def _setup(self):
        """Subscribe to topics and start time constraint enforcer."""
        self._subscribe_to_all_topics()

        if self.bridge_name and self.policy_cache:
            self.time_enforcer = TimeConstraintEnforcer(
                self.policy_cache, self.bridge_name
            )
            self.time_enforcer.start()

        logger.info(
            f"OVS Agent running, listening on {self.meter_topic_pattern} "
            f"and {self.flow_mod_topic_pattern}"
        )

    def _run_loop(self):
        """Main agent loop - periodic meter integrity check."""
        last_meter_check = 0.0
        while self.running:
            now = time.time()
            if now - last_meter_check >= METER_WATCHDOG_INTERVAL:
                self._meter_watchdog()
                last_meter_check = now
            time.sleep(1)

    def _meter_watchdog(self) -> None:
        """Periodic check: verify all meters referenced by rate limits exist.

        Recreates any missing meters in OVS and notifies the backend.
        """
        if not self.bridge_name or not self.policy_cache:
            return

        rate_limits = self.policy_cache.get_all_rate_limits()
        if not rate_limits:
            return

        # Collect unique meter_ids referenced by rate limits
        expected_meter_ids = {rule.meter_id for rule in rate_limits}

        # Query OVS once for all meters
        ovs_meters, err = get_meters(self.bridge_name)
        if err:
            logger.warning(f"Meter watchdog: failed to query OVS meters: {err}")
            return

        ovs_meter_ids = {m.meter_id for m in ovs_meters}

        # Find missing meters
        missing = expected_meter_ids - ovs_meter_ids
        if not missing:
            return

        logger.warning(
            f"Meter watchdog: {len(missing)} meter(s) missing from OVS: {missing}"
        )

        recovered = []
        for meter_id in missing:
            rule_info = self._get_rate_info_for_meter(meter_id, rate_limits)
            if not rule_info:
                logger.warning(
                    f"Meter watchdog: no rate info for meter {meter_id}, skipping"
                )
                continue

            rate_kbps, burst_kbps = rule_info
            success, msg = self._add_meter(
                self.bridge_name, meter_id, rate_kbps, burst_kbps
            )
            if success or "METER_EXISTS" in msg:
                # Ensure registry is in sync
                existing = self.policy_cache.get_meter_info(meter_id)
                if not existing:
                    self.policy_cache.register_meter(
                        meter_id, self.bridge_name, rate_kbps, burst_kbps
                    )
                recovered.append(meter_id)
                logger.info(f"Meter watchdog: recovered meter {meter_id}")
            else:
                logger.error(
                    f"Meter watchdog: failed to recover meter {meter_id}: {msg}"
                )

        if recovered:
            self._notify_meter_recovery(recovered, rate_limits)

    def _cleanup(self):
        """Stop time constraint enforcer."""
        if self.time_enforcer:
            try:
                self.time_enforcer.stop()
            except Exception as e:
                logger.error(f"Error stopping time enforcer: {e}")


def start_ovs_agent_process() -> Optional[subprocess.Popen]:
    """Start the OVS Agent as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if already running
    if _is_ovs_agent_running():
        logger.info("OVS Agent is already running")
        return None

    try:
        python_executable = sys.executable
        module_path = "axon_agent.ovs.agent"

        logger.info("Starting OVS Agent process...")

        # Start process in background
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Give it a moment to start
        time.sleep(0.5)

        if process.poll() is None:
            logger.info(f"OVS Agent process started (PID: {process.pid})")
            return process
        else:
            logger.error("OVS Agent process exited immediately")
            return None

    except Exception as e:
        logger.error(f"Failed to start OVS Agent process: {e}")
        return None


def _is_ovs_agent_running() -> bool:
    """Check if OVS Agent is already running.

    Returns:
        True if running, False otherwise
    """
    try:
        # Check if running as systemd service
        try:
            result = subprocess.run(
                ["systemctl", "is-active", "--quiet", "axon-agent-ovs.service"],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            pass

        current_pid = os.getpid()

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.ovs.agent" in cmdline_str:
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error checking for OVS Agent process: {e}")
        return False


def stop_ovs_agent() -> bool:
    """Stop OVS Agent service/process.

    Returns:
        True if stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    ovs_service = "axon-agent-ovs.service"

    # Try to stop systemd service first
    try:
        if stop_systemd_service(ovs_service):
            logger.info("Stopped OVS Agent systemd service")
            if disable_systemd_service(ovs_service):
                logger.info("Disabled OVS Agent systemd service")
                return True
    except Exception as e:
        logger.warning(f"Failed to stop OVS Agent systemd service: {e}")

    # Fallback: stop subprocess
    try:
        current_pid = os.getpid()
        stopped_any = False

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "axon_agent.ovs.agent" in cmdline_str:
                        if proc.is_running():
                            logger.info(f"Stopping OVS Agent process (PID: {proc.pid})")
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                            except psutil.TimeoutExpired:
                                proc.kill()
                                proc.wait()
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return stopped_any
    except Exception as e:
        logger.error(f"Error stopping OVS Agent process: {e}")
        return False


def main():
    """Main entry point for OVS Agent."""
    agent = OVSAgent()
    agent.run()


if __name__ == "__main__":
    main()
