"""Open vSwitch bridge management."""

import logging
import subprocess
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class OVSBridgeManager:
    """Manages Open vSwitch bridge operations."""

    @staticmethod
    def create_bridge(
        bridge_name: str,
        ports: Optional[list] = None,
        openflow_version: str = "OpenFlow13",
    ) -> Tuple[bool, str, list]:
        """Create an OVS bridge with specified ports and OpenFlow version.

        Uses ovs-vsctl commands via subprocess to create bridges.

        Args:
            bridge_name: Name of the bridge to create
            ports: List of interface names to add to the bridge (optional)
            openflow_version: OpenFlow protocol version (default: "OpenFlow13")

        Returns:
            Tuple of (success: bool, message: str, active_ports: list)
        """
        if ports is None:
            ports = []

        try:
            # Check if bridge already exists
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "br-exists", bridge_name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    # Get current ports for the response
                    existing_ports = []
                    try:
                        ports_result = subprocess.run(
                            ["ovs-vsctl", "list-ports", bridge_name],
                            capture_output=True, text=True, timeout=10,
                        )
                        if ports_result.stdout.strip():
                            existing_ports = ports_result.stdout.strip().split("\n")
                    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                        pass
                    return False, f"Bridge {bridge_name} already exists", existing_ports
            except FileNotFoundError:
                return False, "ovs-vsctl command not found. Is Open vSwitch installed?", []
            except subprocess.TimeoutExpired:
                logger.warning("Timeout checking if bridge exists")

            # Create the bridge
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "add-br", bridge_name],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info(f"Created OVS bridge: {bridge_name}")
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to create bridge {bridge_name}: {e.stderr.strip() if e.stderr else str(e)}"
                logger.error(error_msg)
                return False, error_msg, []
            except FileNotFoundError:
                return False, "ovs-vsctl command not found. Is Open vSwitch installed?", []

            # Set OpenFlow protocol version
            try:
                result = subprocess.run(
                    [
                        "ovs-vsctl",
                        "set",
                        "bridge",
                        bridge_name,
                        f"protocols={openflow_version}",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info(f"Set bridge {bridge_name} protocols to {openflow_version}")
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to set bridge protocols: {e.stderr.strip() if e.stderr else str(e)}"
                logger.warning(error_msg)
                # Continue even if protocol setting fails

            # Add default meter (ID 999) for rate limiting
            # This meter is used by the default flow rule to ensure Layer 2 forwarding
            # with a baseline rate limit
            try:
                result = subprocess.run(
                    [
                        "ovs-ofctl",
                        "-O",
                        openflow_version,
                        "add-meter",
                        bridge_name,
                        "meter=999,kbps,bands=type=drop,rate=2000",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info(f"Created default meter (ID 999) on bridge {bridge_name}")
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to create default meter: {e.stderr.strip() if e.stderr else str(e)}"
                logger.warning(error_msg)
                # Continue even if meter creation fails
            except subprocess.TimeoutExpired:
                logger.warning(
                    f"Timeout creating default meter on bridge {bridge_name}"
                )

            # Install default flow rule with priority=0: meter:999,NORMAL
            # This ensures the bridge acts as a Layer 2 device with rate limiting
            try:
                result = subprocess.run(
                    [
                        "ovs-ofctl",
                        "-O",
                        openflow_version,
                        "add-flow",
                        bridge_name,
                        "priority=0,actions=meter:999,NORMAL",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info(
                    f"Installed default flow rule (priority=0, meter:999,NORMAL) on bridge {bridge_name}"
                )
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to install default flow rule: {e.stderr.strip() if e.stderr else str(e)}"
                logger.warning(error_msg)
                # Continue even if flow installation fails
            except subprocess.TimeoutExpired:
                logger.warning(
                    f"Timeout installing default flow rule on bridge {bridge_name}"
                )

            # Add ports to bridge
            added_ports = []
            failed_ports = []
            for port in ports:
                try:
                    result = subprocess.run(
                        ["ovs-vsctl", "add-port", bridge_name, port],
                        check=True,
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    added_ports.append(port)
                    logger.info(f"Added port {port} to bridge {bridge_name}")

                    # Bring interface up
                    try:
                        subprocess.run(
                            ["ip", "link", "set", port, "up"],
                            check=True,
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        logger.info(f"Brought interface {port} up")
                    except subprocess.CalledProcessError as e:
                        logger.warning(
                            f"Failed to bring interface {port} up: {e.stderr.strip() if e.stderr else str(e)}"
                        )
                        # Don't fail the whole operation if bringing interface up fails
                    except subprocess.TimeoutExpired:
                        logger.warning(f"Timeout bringing interface {port} up")
                except subprocess.CalledProcessError as e:
                    error_msg = e.stderr.strip() if e.stderr else str(e)
                    failed_ports.append((port, error_msg))
                    logger.error(f"Failed to add port {port} to bridge: {error_msg}")

            # Get active ports after creation
            active_ports = []
            try:
                ports_result = subprocess.run(
                    ["ovs-vsctl", "list-ports", bridge_name],
                    capture_output=True, text=True, timeout=10,
                )
                if ports_result.stdout.strip():
                    active_ports = ports_result.stdout.strip().split("\n")
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                logger.warning(f"Could not list ports for bridge {bridge_name}")

            # Build response message
            if failed_ports:
                failed_list = ", ".join([f"{p}: {err}" for p, err in failed_ports])
                if added_ports:
                    message = f"{bridge_name} created with {len(added_ports)} ports, but failed to add {failed_list}"
                    return False, message, active_ports
                else:
                    message = f"Bridge {bridge_name} created but failed to add ports: {failed_list}"
                    return False, message, active_ports
            else:
                if ports:
                    message = f"Bridge {bridge_name} created successfully with {len(ports)} ports"
                else:
                    message = f"Bridge {bridge_name} created successfully"
                return True, message, active_ports

        except Exception as e:
            error_msg = f"Unexpected error creating bridge {bridge_name}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg, []

    @staticmethod
    def delete_bridge(bridge_name: str) -> Tuple[bool, str]:
        """Delete an OVS bridge and remove all its ports.

        Uses ovs-vsctl commands via subprocess to delete bridges.
        The bridge deletion will automatically remove all ports.

        Args:
            bridge_name: Name of the bridge to delete

        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            # Check if bridge exists
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "br-exists", bridge_name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode != 0:
                    # Bridge doesn't exist, which is fine (idempotent operation)
                    return (
                        True,
                        f"Bridge {bridge_name} does not exist (already deleted)",
                    )
            except FileNotFoundError:
                return False, "ovs-vsctl command not found. Is Open vSwitch installed?"
            except subprocess.TimeoutExpired:
                logger.warning("Timeout checking if bridge exists")

            # Get list of ports before deletion (for logging)
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "list-ports", bridge_name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                ports = (
                    result.stdout.strip().split("\n") if result.stdout.strip() else []
                )
                if ports:
                    logger.info(f"Bridge {bridge_name} has {len(ports)} ports: {ports}")
            except subprocess.TimeoutExpired:
                # If we can't list ports, continue anyway
                logger.debug(f"Could not list ports for bridge {bridge_name}")

            # Delete the bridge (this automatically removes all ports)
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "del-br", bridge_name],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                logger.info(f"Deleted OVS bridge: {bridge_name}")
                return True, f"Bridge {bridge_name} deleted successfully"
            except subprocess.CalledProcessError as e:
                error_msg = f"Failed to delete bridge {bridge_name}: {e.stderr.strip() if e.stderr else str(e)}"
                logger.error(error_msg)
                return False, error_msg
            except FileNotFoundError:
                return False, "ovs-vsctl command not found. Is Open vSwitch installed?"

        except Exception as e:
            error_msg = f"Unexpected error deleting bridge {bridge_name}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg

    @staticmethod
    def update_ports(bridge_name: str, desired_ports: list) -> Tuple[bool, str, list]:
        """Declaratively set ports on a bridge.

        Computes the diff between current and desired ports, then adds/removes
        as needed to reach the desired state.

        Args:
            bridge_name: Name of the OVS bridge
            desired_ports: List of port names that should be on the bridge

        Returns:
            Tuple of (success: bool, message: str, active_ports: list)
        """
        try:
            # Check bridge exists
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "br-exists", bridge_name],
                    capture_output=True, text=True, timeout=10,
                )
                if result.returncode != 0:
                    return False, f"Bridge {bridge_name} does not exist", []
            except FileNotFoundError:
                return False, "ovs-vsctl command not found. Is Open vSwitch installed?", []
            except subprocess.TimeoutExpired:
                return False, f"Timeout checking if bridge {bridge_name} exists", []

            # Get current ports
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "list-ports", bridge_name],
                    capture_output=True, text=True, timeout=10,
                )
                current_ports = (
                    result.stdout.strip().split("\n") if result.stdout.strip() else []
                )
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError) as e:
                return False, f"Failed to list current ports: {e}", []

            desired_set = set(desired_ports)
            current_set = set(current_ports)
            ports_to_add = desired_set - current_set
            ports_to_remove = current_set - desired_set
            had_errors = False

            # Remove ports no longer desired
            for port in ports_to_remove:
                try:
                    subprocess.run(
                        ["ovs-vsctl", "del-port", bridge_name, port],
                        check=True, capture_output=True, text=True, timeout=10,
                    )
                    logger.info(f"Removed port {port} from bridge {bridge_name}")
                except subprocess.CalledProcessError as e:
                    error_msg = e.stderr.strip() if e.stderr else str(e)
                    logger.error(f"Failed to remove port {port}: {error_msg}")
                    had_errors = True
                except subprocess.TimeoutExpired:
                    logger.error(f"Timeout removing port {port} from {bridge_name}")
                    had_errors = True

            # Add new desired ports
            for port in ports_to_add:
                try:
                    subprocess.run(
                        ["ovs-vsctl", "add-port", bridge_name, port],
                        check=True, capture_output=True, text=True, timeout=10,
                    )
                    logger.info(f"Added port {port} to bridge {bridge_name}")

                    # Bring interface up (warning only — port is still added to OVS)
                    try:
                        subprocess.run(
                            ["ip", "link", "set", port, "up"],
                            check=True, capture_output=True, text=True, timeout=5,
                        )
                        logger.info(f"Brought interface {port} up")
                    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
                        logger.warning(f"Failed to bring interface {port} up: {e}")
                except subprocess.CalledProcessError as e:
                    error_msg = e.stderr.strip() if e.stderr else str(e)
                    logger.error(f"Failed to add port {port}: {error_msg}")
                    had_errors = True
                except subprocess.TimeoutExpired:
                    logger.error(f"Timeout adding port {port} to {bridge_name}")
                    had_errors = True

            # Get final port list
            final_ports = []
            try:
                result = subprocess.run(
                    ["ovs-vsctl", "list-ports", bridge_name],
                    capture_output=True, text=True, timeout=10,
                )
                if result.stdout.strip():
                    final_ports = result.stdout.strip().split("\n")
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                logger.warning(f"Could not list final ports for {bridge_name}")

            added_count = len(ports_to_add)
            removed_count = len(ports_to_remove)
            success = not had_errors
            message = (
                f"Updated ports on {bridge_name}: "
                f"{added_count} added, {removed_count} removed, "
                f"{len(final_ports)} active"
            )
            if had_errors:
                message += " (some operations failed)"
            logger.info(message)
            return success, message, final_ports

        except Exception as e:
            error_msg = f"Unexpected error updating ports on {bridge_name}: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg, []
