"""Main entry point for Axon Agent."""

import json
import logging
import os
import signal
import subprocess
import sys
import time
from typing import Optional

from .config import ConfigManager
from .discovery import DiscoveryManager
from .hardware import HardwareInfo
from .mqtt_client import MQTTClient
from .monitoring import start_flow_stats_monitoring_process
from .network import get_primary_mac
from .provisioning import ProvisioningManager
from axon_shared.proto.sniffer_messages_pb2 import (
    SnifferInstallCommand,
    SnifferInstallResponse,
    InstallStatus,
)
from axon_shared.mqtt.topics import control_topic, SNIFFER_INSTALL, SNIFFER_INSTALL_RESPONSE
from .traffic import start_sniffer_process
from .service_registry import get_registry, register_ce_services
from .utils import (
    setup_logging,
    start_agent_service,
)

# Sniffer config path
SNIFFER_CONFIG_PATH = "/etc/axon/sniffer_config.json"

logger = logging.getLogger(__name__)


class AxonAgent:
    """Main agent class that orchestrates discovery, provisioning, and runtime."""

    def __init__(self):
        """Initialize Axon Agent."""
        self.config_manager = ConfigManager()
        self.mqtt_client: Optional[MQTTClient] = None
        self.running = False
        self._pending_runtime_config = None  # Config to use for runtime phase setup

        # Register CE companion services
        register_ce_services()

        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
        if self.mqtt_client:
            try:
                self.mqtt_client.loop_stop()
                self.mqtt_client.disconnect()
            except Exception as e:
                logger.error(f"Error during shutdown: {e}")
        sys.exit(0)

    def run(self):
        """Run the agent main loop."""
        self.running = True

        try:
            # Load bootstrap configuration
            bootstrap = self.config_manager.load_bootstrap()
            controller_url = bootstrap.get("controller_url")
            controller_port = bootstrap.get("controller_port")
            mqtt_username = bootstrap.get("mqtt_username")
            mqtt_password = bootstrap.get("mqtt_password")
            primary_interface = bootstrap.get("primary_interface", "eth0")

            if not controller_url or not controller_port:
                logger.error(
                    "Bootstrap config missing controller_url or controller_port"
                )
                return

            # Check if device is already adopted
            config = self.config_manager.load_config()
            is_adopted = self.config_manager.is_adopted()
            logger.info(f"is_adopted: {is_adopted}")

            # Get primary MAC address
            try:
                mac_address = get_primary_mac(primary_interface)
            except ValueError as e:
                logger.error(f"Failed to get MAC address: {e}")
                return

            # Gather hardware information
            hardware_info = HardwareInfo.collect_all(
                primary_interface=primary_interface
            )

            # Initialize MQTT client
            if is_adopted and config:
                # Use device_id as client_id for adopted devices
                client_id = config.get("device_id")
                logger.info(
                    f"Device is adopted, using device_id as client_id: {client_id}"
                )
            else:
                # Use MAC address as client_id for discovery
                client_id = mac_address
                logger.info(
                    f"Device not adopted, using MAC address as client_id: {client_id}"
                )

            self.mqtt_client = MQTTClient(
                host=controller_url,
                port=controller_port,
                username=mqtt_username,
                password=mqtt_password,
                client_id=client_id,
            )

            # If device is already adopted, set up the runtime subscription callback
            # BEFORE connecting, so it's guaranteed to be called when connection completes
            if is_adopted and config:
                self._runtime_phase_started = False

                def setup_runtime_on_connect():
                    if self._runtime_phase_started:
                        logger.debug(
                            "on_connect callback triggered but runtime phase already started, skipping"
                        )
                        return
                    self._runtime_phase_started = True
                    logger.debug(
                        "on_connect callback triggered, setting up runtime phase..."
                    )
                    self._run_runtime_phase(config)

                self.mqtt_client.set_on_connect_callback(setup_runtime_on_connect)

            # Connect to MQTT broker
            self.mqtt_client.connect()
            self.mqtt_client.loop_start()

            # Wait for connection to establish (up to 5 seconds)
            max_wait = 5.0
            waited = 0.0
            while not self.mqtt_client.is_connected() and waited < max_wait:
                time.sleep(0.1)
                waited += 0.1

            if not self.mqtt_client.is_connected():
                logger.warning(
                    "MQTT connection not established within timeout, continuing anyway..."
                )
            else:
                logger.info("MQTT connection established")
                # If callback wasn't triggered (shouldn't happen, but safety check),
                # call it now as fallback
                if is_adopted and config and not self._runtime_phase_started:
                    # Check if callback was already called by checking if subscription exists
                    # If no subscriptions, callback might not have fired
                    if (
                        not hasattr(self.mqtt_client, "_topic_callbacks")
                        or len(self.mqtt_client._topic_callbacks) == 0
                    ):
                        logger.warning(
                            "Connection established but subscription not found, calling _run_runtime_phase as fallback"
                        )
                        self._runtime_phase_started = True
                        try:
                            self._run_runtime_phase(config)
                        except Exception as e:
                            logger.error(
                                f"Error calling _run_runtime_phase fallback: {e}",
                                exc_info=True,
                            )

            if not is_adopted:
                # Discovery Phase
                logger.info("Starting discovery phase...")
                axon_agent_version = bootstrap.get("axon_agent_version")
                is_switch = bootstrap.get("is_switch", False)
                enrollment_secret = bootstrap.get("enrollment_secret")
                self._run_discovery_phase(
                    mac_address,
                    hardware_info,
                    axon_agent_version,
                    is_switch,
                    enrollment_secret=enrollment_secret,
                )
            else:
                # Active Runtime Phase
                # Service startups are handled inside _run_runtime_phase() via
                # _start_companion_services(), which is called from the on_connect
                # callback set up above (line 136).
                logger.info("Device is adopted, entering active runtime phase...")

            # Keep running
            while self.running:
                time.sleep(1)

        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception as e:
            logger.error(f"Fatal error: {e}", exc_info=True)
        finally:
            if self.mqtt_client:
                try:
                    self.mqtt_client.loop_stop()
                    self.mqtt_client.disconnect()
                except Exception as e:
                    logger.error(f"Error during cleanup: {e}")

    def _run_discovery_phase(
        self,
        mac_address: str,
        hardware_info: dict,
        axon_agent_version: str = None,
        is_switch: bool = False,
        enrollment_secret: str = None,
    ):
        """Run discovery phase: publish discovery and wait for provisioning."""
        discovery_manager = DiscoveryManager(
            self.mqtt_client,
            mac_address,
            hardware_info,
            axon_agent_version=axon_agent_version,
            is_switch=is_switch,
            enrollment_secret=enrollment_secret,
        )

        # Publish discovery message
        if not discovery_manager.publish_discovery():
            logger.error("Failed to publish discovery message")
            return

        # Subscribe to provisioning topic
        def provisioning_callback(topic: str, payload: dict):
            """Handle provisioning message."""
            # Check if already adopted to prevent duplicate processing
            if self.config_manager.is_adopted():
                logger.debug(
                    "Device already adopted, ignoring duplicate provisioning message"
                )
                return

            logger.info("Received provisioning message, processing...")

            # Handle provisioning
            config = ProvisioningManager.handle_provisioning(
                payload, mac_address, self.config_manager
            )

            if config:
                # Set up runtime phase subscription callback BEFORE reconnecting
                # This ensures it's called when connection is established
                def setup_runtime_on_connect():
                    self._run_runtime_phase(config)

                # Reconnect with new identity
                self.mqtt_client = ProvisioningManager.reconnect_with_identity(
                    self.mqtt_client, config["device_id"], setup_runtime_on_connect
                )

                logger.info("Device successfully adopted and reconnected")
                logger.info("Transitioning to active runtime phase...")
            else:
                logger.error("Failed to process provisioning message")

        discovery_manager.subscribe_to_provisioning(provisioning_callback)

        # The callback will handle provisioning asynchronously when message arrives
        # Just keep the agent running - the callback will process provisioning and transition to runtime
        logger.info("Waiting for provisioning message from controller...")

    def _run_runtime_phase(self, config: dict):
        """Run active runtime phase: subscribe to control topics and handle commands."""
        device_id = config.get("device_id")
        network_id = config.get("network_id")

        if not device_id or not network_id:
            logger.error("Config missing device_id or network_id")
            return

        # Ensure we're connected before subscribing
        if not self.mqtt_client.is_connected():
            logger.warning("MQTT client not connected, waiting for connection...")
            # Wait up to 5 seconds for connection
            import time

            max_wait = 5.0
            waited = 0.0
            while not self.mqtt_client.is_connected() and waited < max_wait:
                time.sleep(0.1)
                waited += 0.1

            if not self.mqtt_client.is_connected():
                logger.error(
                    "MQTT client still not connected after waiting, cannot subscribe"
                )
                return

        # Additional small delay to ensure the MQTT client's message loop
        # is fully ready to handle subscriptions (especially important after reconnection)
        import time

        time.sleep(0.3)
        logger.debug("Waited for connection to stabilize before subscribing")

        # Subscribe to control topic with wildcard for all control messages
        control_topic_str = control_topic(network_id, device_id, "#")
        logger.debug(f"Setting up subscription to control topic: {control_topic_str}")
        logger.debug(f"Device ID: {device_id}, Network ID: {network_id}")

        def control_callback(topic: str, payload: dict):
            """Handle control commands by routing based on topic suffix."""
            logger.info(f"Received control command on {topic}: {payload}")

            # Extract the command type from the topic
            # Topic format: axon/control/{network_id}/{device_id}/{command}
            topic_parts = topic.split("/")
            if len(topic_parts) < 5:
                logger.warning(f"Invalid control topic format: {topic}")
                return

            command = "/".join(topic_parts[4:])  # Everything after device_id

            # Ignore protobuf topics handled by dedicated agent services
            # - Health check agent: health_check/*
            # - OVS agent: meter/*, flow_mod/*, policy/*
            # - Uptime monitoring agent: uptime_check/*
            if any(
                command.startswith(prefix)
                for prefix in [
                    "health_check/",
                    "meter/",
                    "flow_mod/",
                    "uptime_check/",
                    "policy/",
                    "bridge/",
                ]
            ):
                logger.debug(
                    f"Ignoring protobuf message on {topic} (handled by dedicated agent service)"
                )
                return

            # Ignore response topics (these are messages we sent, not commands for us)
            if command.endswith("/response"):
                logger.debug(f"Ignoring response message on {topic}")
                return

            logger.info(f"Unhandled command type: {command}")

        try:
            logger.debug(f"Subscribing to control topic: {control_topic_str}")
            self.mqtt_client.subscribe(control_topic_str, control_callback, qos=2)
            logger.debug(
                f"Subscription request sent for control topic: {control_topic_str}"
            )
            logger.debug("Waiting for SUBACK from broker...")

            # Wait a moment for SUBACK to arrive (subscriptions are async)
            import time

            time.sleep(0.5)

            logger.info(f"Successfully subscribed to control topic: {control_topic_str}")
            logger.info("Agent is ready and listening for commands")
        except Exception as e:
            logger.error(f"Failed to subscribe to control topic: {e}", exc_info=True)

        # Subscribe to sniffer install topic (protobuf, uses raw subscription)
        sniffer_install_topic = control_topic(network_id, device_id, SNIFFER_INSTALL)

        def sniffer_install_callback(topic: str, payload: bytes):
            """Handle sniffer install command (protobuf)."""
            self._handle_sniffer_install(topic, payload, network_id, device_id)

        try:
            logger.debug(
                f"Subscribing to sniffer install topic: {sniffer_install_topic}"
            )
            self.mqtt_client.subscribe_raw(
                sniffer_install_topic, sniffer_install_callback, qos=2
            )
            logger.info(
                f"Successfully subscribed to sniffer install topic: {sniffer_install_topic}"
            )
        except Exception as e:
            logger.error(
                f"Failed to subscribe to sniffer install topic: {e}", exc_info=True
            )

        # Start companion services (idempotent — safe to call on restart or fresh adoption)
        self._start_companion_services(config)

    def _start_companion_services(self, config: dict):
        """Start companion systemd services needed in the runtime phase.

        Called both when the device is already adopted at startup and when
        freshly adopted via provisioning. All start calls are idempotent.
        Uses the service registry so EE can add services without modifying
        this method.
        """
        registry = get_registry()
        config = config or {}
        for service in registry.get_services():
            if registry.should_start(service, config):
                start_agent_service(
                    service.service_name,
                    service.subprocess_starter,
                    service.display_name,
                )
            else:
                logger.debug(
                    f"Skipping {service.display_name} "
                    f"(condition: {service.condition.value} not met)"
                )

    def _handle_sniffer_install(
        self, topic: str, payload: bytes, network_id: str, device_id: str
    ):
        """Handle sniffer installation command (protobuf).

        Args:
            topic: MQTT topic the message was received on
            payload: Raw protobuf bytes
            network_id: Network ID for response topic
            device_id: Device ID for response topic
        """
        logger.info(f"Received sniffer install command on {topic}")

        try:
            # Deserialize protobuf message
            command = SnifferInstallCommand()
            command.ParseFromString(payload)

            logger.info(
                f"Sniffer install command: bridge={command.bridge_name}, "
                f"interface={command.monitor_interface}, "
                f"num_bytes={command.num_bytes}, num_packets={command.num_packets}"
            )

            # Validate configuration
            if not command.monitor_interface:
                self._publish_sniffer_response(
                    network_id,
                    device_id,
                    command.bridge_name,
                    "error",
                    "Missing monitor_interface in install command",
                )
                return

            # Validate interface exists
            if not self._validate_interface_exists(command.monitor_interface):
                self._publish_sniffer_response(
                    network_id,
                    device_id,
                    command.bridge_name,
                    "error",
                    f"Interface '{command.monitor_interface}' not found",
                )
                return

            # Save sniffer configuration
            # Note: port_to_client and port_to_router are deprecated and ignored
            sniffer_config = {
                "bridge_name": command.bridge_name,
                "monitor_interface": command.monitor_interface,
                "num_bytes": command.num_bytes if command.num_bytes > 0 else 225,
                "num_packets": command.num_packets if command.num_packets > 0 else 5,
                "site_id": network_id,
                "device_id": device_id,
            }

            try:
                os.makedirs(os.path.dirname(SNIFFER_CONFIG_PATH), exist_ok=True)
                with open(SNIFFER_CONFIG_PATH, "w") as f:
                    json.dump(sniffer_config, f, indent=2)
                logger.info(f"Saved sniffer config to {SNIFFER_CONFIG_PATH}")
            except Exception as e:
                logger.error(f"Failed to save sniffer config: {e}")
                self._publish_sniffer_response(
                    network_id,
                    device_id,
                    command.bridge_name,
                    "error",
                    f"Failed to save config: {str(e)}",
                )
                return

            # Start sniffer service
            success = self._start_sniffer()

            if success:
                self._publish_sniffer_response(
                    network_id,
                    device_id,
                    command.bridge_name,
                    "success",
                    "Sniffer installed and started successfully",
                )
            else:
                self._publish_sniffer_response(
                    network_id,
                    device_id,
                    command.bridge_name,
                    "error",
                    "Failed to start sniffer service",
                )

        except Exception as e:
            logger.error(f"Error handling sniffer install: {e}", exc_info=True)
            self._publish_sniffer_response(
                network_id,
                device_id,
                command.bridge_name,
                "error",
                f"Exception: {str(e)}",
            )

    def _validate_interface_exists(self, interface: str) -> bool:
        """Check if a network interface exists.

        Args:
            interface: Interface name to check

        Returns:
            True if interface exists, False otherwise
        """
        try:
            result = subprocess.run(
                ["ip", "link", "show", interface],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Error checking interface {interface}: {e}")
            return False

    def _start_sniffer(self) -> bool:
        """Start the traffic sniffer and flow stats monitoring services.

        Returns:
            True if sniffer started successfully, False otherwise
        """
        sniffer_started = False
        try:
            start_agent_service(
                "axon-agent-sniffer.service",
                start_sniffer_process,
                "traffic sniffer",
            )
            sniffer_started = True
        except Exception as e:
            logger.error(f"Failed to start traffic sniffer: {e}")

        # If sniffer started successfully, also start flow stats monitor
        if sniffer_started:
            start_agent_service(
                "axon-agent-flow-stats.service",
                start_flow_stats_monitoring_process,
                "flow statistics monitoring",
            )

        return sniffer_started

    def _publish_sniffer_response(
        self,
        network_id: str,
        device_id: str,
        bridge_name: str,
        status: str,
        message: str,
    ):
        """Publish sniffer install response (protobuf).

        Args:
            network_id: Network ID for response topic
            device_id: Device ID for response topic
            bridge_name: Name of the bridge
            status: "success" or "error"
            message: Response message
        """
        response_topic = control_topic(network_id, device_id, SNIFFER_INSTALL_RESPONSE)

        # Build protobuf response
        response = SnifferInstallResponse()
        response.status = (
            InstallStatus.INSTALL_STATUS_SUCCESS
            if status == "success"
            else InstallStatus.INSTALL_STATUS_ERROR
        )
        response.message = message
        response.bridge_name = bridge_name

        # Serialize and publish
        payload = response.SerializeToString()
        result = self.mqtt_client.publish_raw(response_topic, payload, qos=2)

        if result:
            logger.info(
                f"Published sniffer install response: status={status}, message={message}"
            )
        else:
            logger.error(
                f"Failed to publish sniffer install response to {response_topic}"
            )


def main():
    """Main entry point."""
    # Setup logging
    setup_logging()

    logger.info("Starting Axon Agent...")

    # Create and run agent
    agent = AxonAgent()
    agent.run()


if __name__ == "__main__":
    main()
