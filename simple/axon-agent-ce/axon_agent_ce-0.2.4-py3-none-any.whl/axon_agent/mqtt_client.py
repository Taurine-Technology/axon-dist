"""MQTT client wrapper for Axon Agent."""

import json
import logging
import uuid
from typing import Callable, Optional

import paho.mqtt.client as mqtt

logger = logging.getLogger(__name__)


class MQTTClient:
    """MQTT client wrapper with connection management."""

    def __init__(
        self,
        host: str,
        port: int,
        username: Optional[str] = None,
        password: Optional[str] = None,
        client_id: Optional[str] = None,
    ):
        """Initialize MQTT client.

        Args:
            host: MQTT broker hostname
            port: MQTT broker port
            username: Optional MQTT username
            password: Optional MQTT password
            client_id: Optional client ID (defaults to random UUID)
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password

        # Use provided client_id or generate one
        if client_id is None:
            client_id = f"axon-agent-{uuid.uuid4().hex[:8]}"

        self.client = mqtt.Client(
            client_id=client_id, protocol=mqtt.MQTTv311, clean_session=True
        )

        if username and password:
            self.client.username_pw_set(username, password)

        # Set callbacks
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.on_disconnect = self._on_disconnect
        self.client.on_subscribe = self._on_subscribe
        self.client.on_log = self._on_log

        # Store callbacks for topics
        self._topic_callbacks = {}  # JSON callbacks: topic -> callback(topic, dict)
        self._raw_topic_callbacks = {}  # Raw callbacks: topic -> callback(topic, bytes)
        self._connected = False  # Track connection state
        self._on_connect_callback = None  # Optional callback to call after connection

        logger.info(f"Initialized MQTT client with ID: {client_id}")

    def _on_connect(self, client, userdata, flags, rc):
        """Handle connection callback."""
        if rc == 0:
            self._connected = True
            # Log initial connection and reconnections
            # Check if this is a reconnection by seeing if we were previously connected
            if not hasattr(self, "_was_connected") or not self._was_connected:
                logger.info(f"Connected to MQTT broker at {self.host}:{self.port}")
            else:
                logger.info(f"Reconnected to MQTT broker at {self.host}:{self.port}")
            self._was_connected = True

            # Call custom on_connect callback if set
            # We call it directly here, but the callback should ensure subscriptions
            # happen after the connection is fully established
            if self._on_connect_callback:
                try:
                    logger.debug("Calling on_connect callback...")
                    self._on_connect_callback()
                    logger.debug("on_connect callback completed")
                except Exception as e:
                    logger.error(f"Error in on_connect callback: {e}", exc_info=True)
        else:
            self._connected = False
            logger.debug(f"Connection failed with code {rc}")

    def _on_message(self, client, userdata, msg):
        """Handle incoming message callback."""
        logger.debug(f"MQTT _on_message callback invoked for topic: {msg.topic}")
        logger.debug(
            f"Message QoS: {msg.qos}, Retain: {msg.retain}, Payload length: {len(msg.payload)} bytes"
        )
        topic = msg.topic

        # Check for raw callbacks first (no JSON parsing)
        raw_callback = self._find_raw_callback(topic)
        if raw_callback:
            try:
                logger.debug(f"Calling raw callback for topic {topic}")
                raw_callback(topic, msg.payload)
            except Exception as e:
                logger.error(f"Error in raw callback for {topic}: {e}", exc_info=True)
            return

        # Skip protobuf topics that are handled by dedicated agent services
        # These topics use protobuf, not JSON, and are handled by:
        # - OVS agent: meter/*, flow_mod/*, policy/*
        # - Health check agent: health_check/*
        # - Uptime monitoring agent: uptime_check/*
        # - Sniffer: plugin/sniffer/* (install command and response)
        if any(
            pattern in topic
            for pattern in [
                "/health_check/",
                "/meter/",
                "/flow_mod/",
                "/uptime_check/",
                "/plugin/sniffer/",
                "/policy/",
            ]
        ):
            logger.debug(
                f"Skipping protobuf topic {topic} (handled by dedicated agent service)"
            )
            return

        # Fall back to JSON callbacks
        try:
            payload_str = msg.payload.decode("utf-8")
            logger.debug(
                f"Decoded payload string (first 200 chars): {payload_str[:200]}"
            )
            payload = json.loads(payload_str)

            logger.info(f"Received message on {topic}: {payload}")
            logger.debug(f"Registered callbacks: {list(self._topic_callbacks.keys())}")

            # Call registered callback if exists
            if topic in self._topic_callbacks:
                callback = self._topic_callbacks[topic]
                logger.debug(f"Found exact match for topic {topic}")
                try:
                    callback(topic, payload)
                except Exception as e:
                    logger.error(
                        f"Error in topic callback for {topic}: {e}", exc_info=True
                    )
            else:
                # Try pattern matching for callbacks
                matched = False
                for pattern, callback in self._topic_callbacks.items():
                    logger.debug(f"Checking if topic {topic} matches pattern {pattern}")
                    if self._topic_matches(topic, pattern):
                        logger.debug(f"Topic {topic} matched pattern {pattern}")
                        matched = True
                        try:
                            callback(topic, payload)
                        except Exception as e:
                            logger.error(
                                f"Error in pattern callback for {pattern}: {e}",
                                exc_info=True,
                            )
                        break
                if not matched:
                    logger.warning(
                        f"No callback found for topic {topic}. "
                        f"Registered patterns: {list(self._topic_callbacks.keys())}"
                    )
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            # Check if there's a JSON handler registered for this topic
            has_json_handler = topic in self._topic_callbacks or any(
                self._topic_matches(topic, pattern) for pattern in self._topic_callbacks
            )

            # Build payload preview for debugging (safe for binary data)
            payload_len = len(msg.payload)
            try:
                # Attempt to show a text preview if decodable
                preview = msg.payload[:100].decode("utf-8", errors="replace")
                payload_info = f"size={payload_len} bytes, preview={preview!r}"
            except Exception:
                # Fallback to hex preview for binary data
                preview_hex = msg.payload[:50].hex()
                payload_info = f"size={payload_len} bytes, hex_preview={preview_hex}"

            if has_json_handler:
                # A JSON handler exists but parsing failed - this is a real error
                # (malformed JSON, misconfiguration, or non-UTF8 payload)
                logger.error(
                    f"Failed to parse JSON on topic {topic} which has a registered "
                    f"JSON handler. This may indicate malformed JSON, a misconfigured "
                    f"subscription, or a non-UTF8 payload. Error: {e}. "
                    f"Payload info: {payload_info}",
                    exc_info=True,
                )
            else:
                # No JSON handler for this topic - likely a binary/protobuf message
                # on a topic we subscribed to but didn't register a handler for
                # (e.g., agent receiving its own published protobuf response)
                logger.debug(
                    f"Non-JSON message on topic {topic} with no registered handler: {e}. "
                    f"Payload info: {payload_info}"
                )
        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)

    def _find_raw_callback(self, topic: str) -> Optional[Callable]:
        """Find a raw callback for the given topic.

        Args:
            topic: The MQTT topic to find a callback for

        Returns:
            The callback function if found, None otherwise
        """
        # Check for exact match first
        if topic in self._raw_topic_callbacks:
            return self._raw_topic_callbacks[topic]

        # Try pattern matching
        for pattern, callback in self._raw_topic_callbacks.items():
            if self._topic_matches(topic, pattern):
                return callback

        return None

    def _on_subscribe(self, client, userdata, mid, granted_qos):
        """Handle subscription acknowledgment callback."""
        # granted_qos is a tuple of QoS levels (one per topic in the subscription)
        if isinstance(granted_qos, tuple) and len(granted_qos) > 0:
            qos_level = granted_qos[0]
        else:
            qos_level = granted_qos

        logger.debug(
            f"Subscription acknowledged by broker (mid: {mid}, granted_qos: {granted_qos}, qos_level: {qos_level})"
        )

        # Check if granted QoS is less than requested (indicates subscription failure)
        if isinstance(qos_level, int) and qos_level == 128:
            logger.error(
                f"Subscription failed - broker returned QoS 128 (failure) for mid {mid}"
            )
        elif isinstance(qos_level, int) and qos_level > 2:
            logger.warning(
                f"Unexpected QoS level {qos_level} from broker for mid {mid}"
            )

    def _on_disconnect(self, client, userdata, rc):
        """Handle disconnection callback."""
        self._connected = False
        client_id = (
            self.client._client_id.decode()
            if hasattr(self.client._client_id, "decode")
            else self.client._client_id
        )
        if rc == 0:
            logger.info(f"Disconnected from MQTT broker (client_id: {client_id})")
        else:
            logger.warning(
                f"Unexpected disconnection (rc={rc}, client_id: {client_id})"
            )

    def _on_log(self, client, userdata, level, buf):
        """Handle log messages from paho-mqtt."""
        # Log all MQTT protocol messages for debugging
        # Check for PUBLISH messages specifically
        if "PUBLISH" in buf or "PUBREC" in buf or "PUBREL" in buf or "PUBCOMP" in buf:
            logger.debug(f"MQTT Protocol: {buf}")
        elif level >= mqtt.MQTT_LOG_WARNING:
            logger.debug(f"MQTT: {buf}")
        else:
            logger.debug(f"MQTT: {buf}")

    def _topic_matches(self, topic: str, pattern: str) -> bool:
        """Check if topic matches pattern (simple wildcard support).

        Args:
            topic: Actual topic
            pattern: Pattern with + and # wildcards

        Returns:
            True if topic matches pattern
        """
        # Handle # wildcard (matches zero or more topic levels)
        if pattern.endswith("/#"):
            # Remove trailing /# and check if topic starts with the prefix
            pattern_prefix = pattern[:-2]  # Remove "/#"
            matches = topic == pattern_prefix or topic.startswith(pattern_prefix + "/")
            logger.debug(
                f"Pattern {pattern} (prefix: {pattern_prefix}) matches {topic}: {matches}"
            )
            return matches
        elif pattern.endswith("#"):
            # Remove trailing # and check if topic starts with the prefix
            pattern_prefix = pattern[:-1]  # Remove "#"
            matches = topic == pattern_prefix or topic.startswith(pattern_prefix + "/")
            logger.debug(
                f"Pattern {pattern} (prefix: {pattern_prefix}) matches {topic}: {matches}"
            )
            return matches

        # Handle + wildcard (matches single topic level)
        # Convert pattern to regex: + becomes [^/]+, # becomes .*
        pattern_parts = pattern.split("/")
        topic_parts = topic.split("/")

        if len(pattern_parts) != len(topic_parts):
            # If pattern has #, it can match multiple levels, but we handle that above
            return False

        # Match each level
        for p, t in zip(pattern_parts, topic_parts):
            if p == "+":
                # + matches any single level
                continue
            elif p == "#":
                # Shouldn't happen here as we handle trailing # above
                return True
            elif p != t:
                return False

        return True

    def _patterns_overlap(self, pattern1: str, pattern2: str) -> bool:
        """Check if two topic patterns could match the same topic.

        This is a conservative check - it returns True if there's any possibility
        of overlap. It checks both directions (pattern1 matches pattern2 and vice versa).

        Args:
            pattern1: First topic pattern (may contain wildcards)
            pattern2: Second topic pattern (may contain wildcards)

        Returns:
            True if patterns could match the same topic
        """
        # Exact match
        if pattern1 == pattern2:
            return True

        # Check if either pattern would match the other as a concrete topic
        # (treating wildcards in the "topic" as literal characters)
        if self._topic_matches(pattern2, pattern1):
            return True
        if self._topic_matches(pattern1, pattern2):
            return True

        # Check for wildcard overlap scenarios
        # If both have # wildcards, check if prefixes overlap
        if "#" in pattern1 and "#" in pattern2:
            prefix1 = pattern1.split("#")[0].rstrip("/")
            prefix2 = pattern2.split("#")[0].rstrip("/")
            if prefix1.startswith(prefix2) or prefix2.startswith(prefix1):
                return True

        # If one has # and could match the other's structure
        if pattern1.endswith("/#") or pattern1.endswith("#"):
            prefix = pattern1.rstrip("/#")
            if pattern2.startswith(prefix):
                return True
        if pattern2.endswith("/#") or pattern2.endswith("#"):
            prefix = pattern2.rstrip("/#")
            if pattern1.startswith(prefix):
                return True

        return False

    def _get_callback_name(self, callback: Callable) -> str:
        """Get a human-readable name for a callback function.

        Args:
            callback: Callback function

        Returns:
            String representation of the callback
        """
        if hasattr(callback, "__name__"):
            name = callback.__name__
        elif hasattr(callback, "__class__"):
            name = callback.__class__.__name__
        else:
            name = str(callback)

        if hasattr(callback, "__module__"):
            return f"{callback.__module__}.{name}"
        return name

    def _check_subscription_overlap(
        self, new_topic: str, new_callback: Callable, is_raw: bool
    ) -> None:
        """Check for overlapping subscriptions and log warnings.

        Args:
            new_topic: The new topic pattern being subscribed
            new_callback: The callback for the new subscription
            is_raw: True if the new subscription is raw, False if JSON
        """
        new_callback_name = self._get_callback_name(new_callback)
        new_type = "raw" if is_raw else "JSON"
        other_type = "JSON" if is_raw else "raw"
        other_callbacks = self._topic_callbacks if is_raw else self._raw_topic_callbacks

        for existing_topic, existing_callback in other_callbacks.items():
            if self._patterns_overlap(new_topic, existing_topic):
                existing_callback_name = self._get_callback_name(existing_callback)
                logger.warning(
                    f"Subscription overlap detected! New {new_type} subscription "
                    f"'{new_topic}' (handler: {new_callback_name}) overlaps with existing "
                    f"{other_type} subscription '{existing_topic}' (handler: {existing_callback_name}). "
                    f"Raw callbacks take precedence - {other_type} handler may be skipped for "
                    f"matching messages."
                )

    def connect(self) -> None:
        """Connect to MQTT broker."""
        try:
            logger.info(f"Connecting to MQTT broker at {self.host}:{self.port}")
            self.client.connect(self.host, self.port, keepalive=60)
        except Exception as e:
            logger.error(f"Failed to connect to MQTT broker: {e}")
            raise

    def disconnect(self) -> None:
        """Disconnect from MQTT broker."""
        try:
            self.client.disconnect()
            logger.info("Disconnected from MQTT broker")
        except Exception as e:
            logger.error(f"Error disconnecting: {e}")

    def publish(self, topic: str, payload: dict, qos: int = 2) -> bool:
        """Publish JSON message to topic.

        Args:
            topic: MQTT topic
            payload: Dictionary to publish as JSON
            qos: Quality of Service level (0, 1, or 2)

        Returns:
            True if publish was successful, False otherwise
        """
        try:
            payload_json = json.dumps(payload)
            result = self.client.publish(topic, payload_json, qos=qos)

            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logger.debug(f"Published to {topic} (QoS {qos})")
                return True
            else:
                logger.error(f"Failed to publish to {topic}: rc={result.rc}")
                return False
        except Exception as e:
            logger.error(f"Error publishing to {topic}: {e}")
            return False

    def subscribe(self, topic: str, callback: Callable, qos: int = 2) -> None:
        """Subscribe to topic with callback.

        Args:
            topic: MQTT topic to subscribe to
            callback: Callback function(topic, payload) to call when message received
            qos: Quality of Service level (0, 1, or 2)
        """
        try:
            logger.debug(f"Attempting to subscribe to: {topic} with QoS {qos}")
            logger.debug(f"Client connected state: {self._connected}")
            client_id = (
                self.client._client_id.decode()
                if hasattr(self.client._client_id, "decode")
                else self.client._client_id
            )
            logger.debug(f"Client ID: {client_id}")

            # Check for overlapping raw subscriptions
            self._check_subscription_overlap(topic, callback, is_raw=False)

            if not self._connected:
                logger.warning(
                    f"Client not connected, subscription may fail. Connected state: {self._connected}"
                )

            result = self.client.subscribe(topic, qos)
            # result is (rc, mid) where rc is return code and mid is message ID
            logger.debug(f"Subscribe result: rc={result[0]}, mid={result[1]}")

            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                self._topic_callbacks[topic] = callback
                logger.debug(
                    f"Subscription request sent for {topic} (QoS {qos}, mid: {result[1]})"
                )
                logger.debug(f"Registered callback for pattern: {topic}")
                logger.debug(
                    f"Total registered callbacks: {len(self._topic_callbacks)}"
                )
                logger.debug(
                    f"All registered patterns: {list(self._topic_callbacks.keys())}"
                )
                logger.debug(f"Waiting for SUBACK from broker (mid: {result[1]})...")
            else:
                logger.error(f"Failed to subscribe to {topic}: rc={result[0]}")
        except Exception as e:
            logger.error(f"Error subscribing to {topic}: {e}", exc_info=True)
            raise

    def publish_raw(self, topic: str, payload: bytes, qos: int = 2) -> bool:
        """Publish raw bytes to topic (for protobuf/binary data).

        Args:
            topic: MQTT topic
            payload: Raw bytes to publish
            qos: Quality of Service level (0, 1, or 2)

        Returns:
            True if publish was successful, False otherwise
        """
        try:
            result = self.client.publish(topic, payload, qos=qos)

            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                logger.debug(
                    f"Published raw bytes to {topic} (QoS {qos}, {len(payload)} bytes)"
                )
                return True
            else:
                logger.error(f"Failed to publish raw to {topic}: rc={result.rc}")
                return False
        except Exception as e:
            logger.error(f"Error publishing raw to {topic}: {e}")
            return False

    def subscribe_raw(
        self, topic: str, callback: Callable[[str, bytes], None], qos: int = 2
    ) -> None:
        """Subscribe to topic with raw bytes callback (no JSON parsing).

        Use this for topics that receive binary data like protobuf messages.

        Args:
            topic: MQTT topic to subscribe to
            callback: Callback function(topic, payload_bytes) to call when message received
            qos: Quality of Service level (0, 1, or 2)
        """
        try:
            logger.debug(f"Attempting to subscribe (raw) to: {topic} with QoS {qos}")
            logger.debug(f"Client connected state: {self._connected}")

            # Check for overlapping JSON subscriptions
            self._check_subscription_overlap(topic, callback, is_raw=True)

            if not self._connected:
                logger.warning(
                    f"Client not connected, subscription may fail. Connected state: {self._connected}"
                )

            result = self.client.subscribe(topic, qos)
            logger.debug(f"Subscribe result: rc={result[0]}, mid={result[1]}")

            if result[0] == mqtt.MQTT_ERR_SUCCESS:
                self._raw_topic_callbacks[topic] = callback
                logger.debug(
                    f"Raw subscription request sent for {topic} (QoS {qos}, mid: {result[1]})"
                )
                logger.debug(f"Registered raw callback for pattern: {topic}")
                logger.debug(
                    f"Total registered raw callbacks: {len(self._raw_topic_callbacks)}"
                )
            else:
                logger.error(f"Failed to subscribe (raw) to {topic}: rc={result[0]}")
        except Exception as e:
            logger.error(f"Error subscribing (raw) to {topic}: {e}", exc_info=True)
            raise

    def set_on_connect_callback(self, callback: Callable) -> None:
        """Set a callback to be called after successful connection.

        Args:
            callback: Function to call after connection is established
        """
        self._on_connect_callback = callback

    def loop_forever(self) -> None:
        """Start blocking message loop."""
        logger.info("Starting MQTT message loop (blocking)")
        try:
            self.client.loop_forever()
        except KeyboardInterrupt:
            logger.info("Message loop interrupted")
            raise

    def loop_start(self) -> None:
        """Start non-blocking message loop."""
        logger.info("Starting MQTT message loop (non-blocking)")
        self.client.loop_start()

    def loop_stop(self) -> None:
        """Stop non-blocking message loop."""
        logger.info("Stopping MQTT message loop")
        self.client.loop_stop()

    def is_connected(self) -> bool:
        """Check if client is connected to the broker.

        Returns:
            True if connected, False otherwise
        """
        return self._connected
