"""Utility functions for Axon Agent."""

import hashlib
import logging
import logging.handlers
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

LOG_DIR = Path(os.environ.get("AXON_LOG_DIR", "/var/log/axon"))
LOG_MAX_BYTES = 5 * 1024 * 1024
LOG_BACKUP_COUNT = 3


def normalize_app_name(app_name: str) -> str:
    """Normalize application name to lowercase app-specific identifier.

    Extracts the application-specific part from protocol-prefixed names
    and converts to lowercase for consistent tracking.

    Examples:
        "QUIC.Instagram" -> "instagram"
        "TLS.YouTube" -> "youtube"
        "HTTP.Facebook" -> "facebook"
        "QUIC" -> "quic"
        "TLS" -> "tls"
        "Unknown" -> "unknown"

    Args:
        app_name: Application name from NFStream (e.g., "QUIC.Instagram")

    Returns:
        Lowercase app-specific identifier
    """
    if not app_name:
        return "unknown"
    if "." in app_name:
        return app_name.split(".", 1)[1].lower()
    return app_name.lower()


def compute_classification_id(app_name: str) -> int:
    """Compute the 32-bit classification ID from an application name.

    This function normalizes the app name (stripping protocol prefixes,
    lowercasing) and computes a consistent SHA-256 hash of the result.
    The lower 32 bits of this hash are used as the classification identifier.

    This is used to generate the lower 32 bits of OVS flow cookies and
    to match flows by classification when removing rules.

    Args:
        app_name: Application name (e.g., "Instagram", "QUIC.Facebook")

    Returns:
        32-bit classification ID (unsigned integer)
    """
    normalized = normalize_app_name(app_name)
    return int(hashlib.sha256(normalized.encode()).hexdigest()[:8], 16)


def _resolve_log_file_path(log_file: str = None) -> Path:
    """Resolve log file names into the shared Axon log directory.

    Bare names are written as /var/log/axon/<name>.log. Explicit paths are
    preserved, which keeps tests and ad-hoc local runs easy to control.
    """
    if log_file is None:
        log_file = "axon-agent"

    path = Path(log_file)
    if path.parent == Path("."):
        if path.suffix != ".log":
            path = path.with_suffix(".log")
        return LOG_DIR / path
    return path


def setup_logging(log_file: str = None) -> None:
    """Configure logging to both file and stdout with INFO level.

    Args:
        log_file: Optional path or bare log name. If None, uses
            /var/log/axon/axon-agent.log.
    """
    log_path = _resolve_log_file_path(log_file)

    # Create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    # Remove existing handlers
    root_logger.handlers.clear()

    # File handler with rotation (5MB max, 3 backup files)
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            log_path,
            maxBytes=LOG_MAX_BYTES,
            backupCount=LOG_BACKUP_COUNT,
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    except (PermissionError, OSError) as e:
        # If we can't write to file, just use stdout
        logging.warning(f"Could not create log file {log_path}: {e}")

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)


def normalize_mac(mac: str) -> str:
    """Normalize MAC address format to lowercase with colons.

    Args:
        mac: MAC address in any format

    Returns:
        Normalized MAC address (e.g., 'aa:bb:cc:dd:ee:ff')
    """
    # Remove common separators and convert to lowercase
    mac = mac.replace("-", "").replace(":", "").replace(".", "").lower()

    # Reformat with colons
    if len(mac) == 12:
        return ":".join(mac[i : i + 2] for i in range(0, 12, 2))

    return mac


def get_timestamp() -> str:
    """Get ISO 8601 timestamp with timezone.

    Returns:
        ISO 8601 formatted timestamp (e.g., '2025-01-01T12:00:00Z')
    """
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def enable_systemd_service(service_name: str) -> bool:
    """Enable a systemd service to start on boot.

    Args:
        service_name: Name of the systemd service (e.g., 'axon-agent-monitor.service')

    Returns:
        True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    try:
        result = subprocess.run(
            ["systemctl", "enable", service_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            logger.info(f"Enabled systemd service: {service_name}")
            return True
        else:
            logger.warning(
                f"Failed to enable systemd service {service_name}: {result.stderr}"
            )
            return False
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        subprocess.SubprocessError,
        PermissionError,
    ) as e:
        logger.warning(f"Error enabling systemd service {service_name}: {e}")
        return False


def start_systemd_service(service_name: str) -> bool:
    """Start a systemd service.

    Args:
        service_name: Name of the systemd service (e.g., 'axon-agent-monitor.service')

    Returns:
        True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    try:
        result = subprocess.run(
            ["systemctl", "start", service_name],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            logger.info(f"Started systemd service: {service_name}")
            return True
        else:
            logger.warning(
                f"Failed to start systemd service {service_name}: {result.stderr}"
            )
            return False
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        subprocess.SubprocessError,
        PermissionError,
    ) as e:
        logger.warning(f"Error starting systemd service {service_name}: {e}")
        return False


def restart_systemd_service(service_name: str) -> bool:
    """Restart a systemd service.

    Args:
        service_name: Name of the systemd service (e.g., 'axon-agent-monitor.service')

    Returns:
        True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    try:
        result = subprocess.run(
            ["systemctl", "restart", service_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            logger.info(f"Restarted systemd service: {service_name}")
            return True
        else:
            logger.warning(
                f"Failed to restart systemd service {service_name}: {result.stderr}"
            )
            return False
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        subprocess.SubprocessError,
        PermissionError,
    ) as e:
        logger.warning(f"Error restarting systemd service {service_name}: {e}")
        return False


def stop_systemd_service(service_name: str) -> bool:
    """Stop a systemd service.

    Args:
        service_name: Name of the systemd service (e.g., 'axon-agent-monitor.service')

    Returns:
        True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    try:
        result = subprocess.run(
            ["systemctl", "stop", service_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            logger.info(f"Stopped systemd service: {service_name}")
            return True
        else:
            logger.warning(
                f"Failed to stop systemd service {service_name}: {result.stderr}"
            )
            return False
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        subprocess.SubprocessError,
        PermissionError,
    ) as e:
        logger.warning(f"Error stopping systemd service {service_name}: {e}")
        return False


def disable_systemd_service(service_name: str) -> bool:
    """Disable a systemd service from starting on boot.

    Args:
        service_name: Name of the systemd service (e.g., 'axon-agent-monitor.service')

    Returns:
        True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    try:
        result = subprocess.run(
            ["systemctl", "disable", service_name],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            logger.info(f"Disabled systemd service: {service_name}")
            return True
        else:
            logger.warning(
                f"Failed to disable systemd service {service_name}: {result.stderr}"
            )
            return False
    except (
        subprocess.TimeoutExpired,
        FileNotFoundError,
        subprocess.SubprocessError,
        PermissionError,
    ) as e:
        logger.warning(f"Error disabling systemd service {service_name}: {e}")
        return False


def start_agent_service(
    service_name: str, subprocess_starter: Callable[[], None], agent_type: str
) -> None:
    """Enable and start an agent service with subprocess fallback.

    Args:
        service_name: The systemd service name (e.g., 'axon-agent-monitor.service')
        subprocess_starter: Callable to start the agent as a subprocess fallback
        agent_type: Human-readable agent type for logging (e.g., 'device monitoring')
    """
    logger = logging.getLogger(__name__)
    try:
        if enable_systemd_service(service_name):
            logger.info(f"Enabled {agent_type} systemd service")
            if start_systemd_service(service_name):
                logger.info(f"Started {agent_type} systemd service")
            else:
                logger.warning(
                    f"Failed to start {agent_type} service, falling back to subprocess"
                )
                subprocess_starter()
                logger.info(f"Started {agent_type} as subprocess (fallback)")
        else:
            logger.warning(
                f"Failed to enable {agent_type} service, trying to start process directly"
            )
            subprocess_starter()
            logger.info(f"Started {agent_type} as subprocess (fallback)")
    except Exception as e:
        logger.warning(f"Failed to enable/start {agent_type} service: {e}")
        try:
            subprocess_starter()
            logger.info(f"Started {agent_type} as subprocess (fallback)")
        except Exception as e2:
            logger.warning(f"Failed to start {agent_type} process: {e2}")
