"""Base agent class for all Axon Agent companion services.

Provides common lifecycle management: config loading, MQTT connection with
retry/backoff, signal handling, graceful shutdown, and optional publish buffering
for agents that collect data while MQTT is disconnected.

Subclasses must implement:
    - _load_service_config(config: dict) -> bool
    - _run_loop()

Subclasses may override:
    - _setup()       — called after connection, before _run_loop()
    - _cleanup()     — called in finally block after _run_loop()
    - _on_reconnect() — auto-registered as on_connect callback if overridden
    - _load_config()  — for agents that load config from non-standard sources
"""

import collections
import logging
import signal
import sys
import time
from abc import ABC, abstractmethod
from typing import Optional

from .config import ConfigManager
from .mqtt_client import MQTTClient
from .utils import setup_logging

logger = logging.getLogger(__name__)

# MQTT connection retry configuration
MQTT_MAX_RETRIES = 5
MQTT_INITIAL_BACKOFF = 2  # seconds
MQTT_MAX_BACKOFF = 60  # seconds

# MQTT connection result codes (from paho-mqtt)
MQTT_AUTH_ERROR_CODES = {4, 5}  # 4=bad username/password, 5=not authorized


class BaseAgent(ABC):
    """Abstract base class for Axon Agent companion services.

    Class attributes (override in subclasses):
        agent_name: Human-readable name for logging (e.g., "Health Check Agent")
        mqtt_client_id_suffix: Suffix for MQTT client ID (e.g., "health-check")
        config_fail_exit_code: Exit code on config failure (0=no restart, 1=restart)
        log_name: Argument to setup_logging() (None uses default)
        connection_wait_timeout: Seconds to wait for MQTT connection
        use_counted_retries: True=counted retries, False=infinite non-blocking
        publish_buffer_size: Max buffered publishes during disconnect
    """

    agent_name: str = "Base Agent"
    mqtt_client_id_suffix: str = "base"
    config_fail_exit_code: int = 0
    log_name: Optional[str] = None
    connection_wait_timeout: float = 10.0
    use_counted_retries: bool = True
    publish_buffer_size: int = 300

    def __init__(self):
        """Initialize base agent with common state."""
        self.config_manager = ConfigManager()
        self.mqtt_client: Optional[MQTTClient] = None
        self.running = False

        # Device identity
        self.device_id: Optional[str] = None
        self.site_id: Optional[str] = None

        # MQTT error tracking
        self._last_mqtt_error: Optional[str] = None
        self._last_mqtt_rc: Optional[int] = None

        # Publish buffer for offline buffering (used by infinite-retry agents)
        self._publish_buffer = collections.deque(maxlen=self.publish_buffer_size)

        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        logger.info(
            f"Received signal {signum}, shutting down {self.agent_name}..."
        )
        self.running = False

    # ------------------------------------------------------------------
    # Config loading
    # ------------------------------------------------------------------

    def _load_config(self) -> bool:
        """Load configuration from config.json.

        Default implementation loads config.json, extracts device_id and
        site_id (network_id), then delegates to _load_service_config().

        Override entirely for agents that load config from non-standard
        sources (e.g., sniffer_config.json, classifier_config.json).

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            config = self.config_manager.load_config()
            if not config:
                logger.error("Device not adopted - config.json not found")
                return False

            self.device_id = config.get("device_id")
            self.site_id = config.get("network_id")

            if not self.device_id or not self.site_id:
                logger.error("Config missing device_id or network_id")
                return False

            logger.info(
                f"Loaded config: device_id={self.device_id}, "
                f"site_id={self.site_id}"
            )
            return self._load_service_config(config)

        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            return False

    @abstractmethod
    def _load_service_config(self, config: dict) -> bool:
        """Load service-specific configuration from the device config dict.

        Called by the default _load_config() after device_id and site_id
        are extracted. Override to set up topics, load bridge configs, etc.

        Args:
            config: Full config.json dictionary

        Returns:
            True if service config loaded successfully, False otherwise
        """

    # ------------------------------------------------------------------
    # MQTT connection
    # ------------------------------------------------------------------

    def _cleanup_mqtt_client(self):
        """Stop the MQTT network loop, disconnect, and clear the client."""
        if self.mqtt_client:
            try:
                self.mqtt_client.loop_stop()
                self.mqtt_client.disconnect()
            except Exception as e:
                logger.error(f"Error during MQTT cleanup: {e}")
            self.mqtt_client = None

    def _connect_mqtt(self) -> bool:
        """Connect to MQTT broker.

        Full variant with auth error tracking and cleanup on failure.

        Returns:
            True if connection successful, False otherwise
        """
        # Reset error state
        self._last_mqtt_error = None
        self._last_mqtt_rc = None

        # If client already exists, check connection and cleanup if not connected
        if self.mqtt_client:
            if self.mqtt_client.is_connected():
                return True
            self._cleanup_mqtt_client()

        try:
            bootstrap = self.config_manager.load_bootstrap()
            controller_url = bootstrap.get("controller_url")
            controller_port = bootstrap.get("controller_port")
            mqtt_username = bootstrap.get("mqtt_username")
            mqtt_password = bootstrap.get("mqtt_password")

            if not controller_url or not controller_port:
                self._last_mqtt_error = "config"
                logger.error(
                    "Bootstrap config missing controller_url or controller_port"
                )
                return False

            self.mqtt_client = MQTTClient(
                host=controller_url,
                port=controller_port,
                username=mqtt_username,
                password=mqtt_password,
                client_id=f"{self.device_id}-{self.mqtt_client_id_suffix}",
            )

            self.mqtt_client.connect()
            self.mqtt_client.loop_start()

            # Wait for connection to establish
            max_wait = self.connection_wait_timeout
            waited = 0.0
            while not self.mqtt_client.is_connected() and waited < max_wait:
                time.sleep(0.1)
                waited += 0.1

            if not self.mqtt_client.is_connected():
                try:
                    rc = self.mqtt_client.client._connect_rc
                    self._last_mqtt_rc = rc
                    if rc in MQTT_AUTH_ERROR_CODES:
                        self._last_mqtt_error = "auth"
                        logger.error(
                            f"MQTT authentication failed (rc={rc}). "
                            "Check username/password in bootstrap.json."
                        )
                    else:
                        self._last_mqtt_error = "connection"
                        logger.warning(
                            f"Failed to connect to MQTT broker within "
                            f"timeout (rc={rc})"
                        )
                except AttributeError:
                    self._last_mqtt_error = "connection"
                    logger.warning(
                        "Failed to connect to MQTT broker within timeout"
                    )
                self._cleanup_mqtt_client()
                return False

            logger.info(
                f"Connected to MQTT broker at "
                f"{controller_url}:{controller_port}"
            )
            return True

        except ConnectionRefusedError as e:
            self._last_mqtt_error = "connection"
            logger.warning(f"Connection refused by MQTT broker: {e}")
        except OSError as e:
            self._last_mqtt_error = "connection"
            logger.warning(f"Network error connecting to MQTT: {e}")
        except Exception as e:
            self._last_mqtt_error = "unknown"
            logger.error(f"Failed to connect to MQTT: {e}")

        self._cleanup_mqtt_client()
        return False

    def _connect_with_counted_retries(self) -> bool:
        """Try MQTT_MAX_RETRIES times with exponential backoff.

        Exits immediately on auth or config errors.

        Returns:
            True if connected, False otherwise (caller should sys.exit(1))
        """
        backoff = MQTT_INITIAL_BACKOFF

        for attempt in range(1, MQTT_MAX_RETRIES + 1):
            if self._connect_mqtt():
                return True

            if self._last_mqtt_error == "auth":
                logger.error(
                    "MQTT authentication failed. Check bootstrap.json "
                    "for correct username/password. Exiting with code 1."
                )
                sys.exit(1)

            if self._last_mqtt_error == "config":
                logger.error(
                    "MQTT configuration error. Check bootstrap.json for "
                    "missing or invalid settings. Exiting with code 1."
                )
                sys.exit(1)

            if attempt < MQTT_MAX_RETRIES:
                logger.warning(
                    f"MQTT connection failed "
                    f"(attempt {attempt}/{MQTT_MAX_RETRIES}). "
                    f"Retrying in {backoff} seconds..."
                )
                time.sleep(backoff)
                backoff = min(backoff * 2, MQTT_MAX_BACKOFF)

        logger.error(
            f"Failed to connect to MQTT broker after {MQTT_MAX_RETRIES} "
            "attempts. Exiting with code 1 to allow systemd to restart "
            "the service."
        )
        return False

    def _connect_with_infinite_retries(self) -> bool:
        """Non-blocking infinite retry: connect + loop_start, then proceed.

        Enters main loop regardless of connection state. paho-mqtt's
        background thread handles reconnection automatically.

        Returns:
            True if initial connection succeeded, False if entering
            main loop without connection (will reconnect in background)
        """
        backoff = 2.0
        max_backoff = 60.0

        while self.running and not self._connect_mqtt():
            logger.warning(
                f"Failed to connect to MQTT broker, retrying in "
                f"{backoff:.0f}s..."
            )
            time.sleep(backoff)
            backoff = min(backoff * 2, max_backoff)

        if not self.running:
            logger.info(
                "Shutdown requested during MQTT connection retry, stopping."
            )
            self._cleanup_mqtt_client()
            return False

        return True

    # ------------------------------------------------------------------
    # Publish buffering
    # ------------------------------------------------------------------

    def _buffered_publish(self, topic, payload, qos=2, raw=False):
        """Publish with offline buffering.

        When connected, flushes any buffered messages first then publishes
        the current message. When disconnected, buffers the message (oldest
        dropped when buffer is full).

        Args:
            topic: MQTT topic
            payload: Message payload (dict for publish, bytes for publish_raw)
            qos: MQTT QoS level
            raw: If True, use publish_raw (binary), else publish (JSON)

        Returns:
            True if published successfully, False if buffered or failed
        """
        if self.mqtt_client and self.mqtt_client.is_connected():
            self._flush_publish_buffer()
            if raw:
                return self.mqtt_client.publish_raw(topic, payload, qos=qos)
            else:
                return self.mqtt_client.publish(topic, payload, qos=qos)
        else:
            self._publish_buffer.append((topic, payload, qos, raw))
            return False

    def _flush_publish_buffer(self):
        """Publish all buffered messages. Returns count flushed."""
        count = 0
        while self._publish_buffer:
            topic, payload, qos, raw = self._publish_buffer.popleft()
            try:
                if raw:
                    self.mqtt_client.publish_raw(topic, payload, qos=qos)
                else:
                    self.mqtt_client.publish(topic, payload, qos=qos)
                count += 1
            except Exception as e:
                logger.warning(f"Failed to flush buffered message: {e}")
                break
        if count:
            logger.info(f"Flushed {count} buffered messages")
        return count

    # ------------------------------------------------------------------
    # Lifecycle hooks (override as needed)
    # ------------------------------------------------------------------

    def _setup(self):
        """Called after MQTT connection, before entering _run_loop().

        Override to perform one-time setup like subscribing to topics,
        initializing state, etc.
        """

    def _cleanup(self):
        """Called in finally block after _run_loop() exits.

        Override to perform cleanup like stopping background threads,
        saving state, etc.
        """

    def _on_reconnect(self):
        """Called on MQTT reconnection to restore subscriptions.

        Override in agents that subscribe to topics. This is automatically
        registered as an on_connect callback if the subclass overrides it.
        """

    def _get_log_name(self) -> str:
        """Return a stable per-service log name for file logging."""
        if self.log_name:
            return self.log_name

        suffix = self.mqtt_client_id_suffix or "base"
        return f"axon-agent-{suffix}"

    # ------------------------------------------------------------------
    # Abstract methods
    # ------------------------------------------------------------------

    @abstractmethod
    def _run_loop(self):
        """Main agent loop. Called after connection and setup.

        Should loop while self.running is True. Example:
            while self.running:
                time.sleep(1)
        """

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self):
        """Full lifecycle orchestrator.

        1. Setup logging
        2. Load config -> exit on failure
        3. Connect to MQTT (counted or infinite retries)
        4. Register _on_reconnect if overridden
        5. _setup()
        6. _run_loop()
        7. _cleanup() + MQTT disconnect
        """
        setup_logging(self._get_log_name())
        logger.info(f"Starting {self.agent_name}...")

        # Load configuration
        if not self._load_config():
            logger.error(
                f"Failed to load configuration, exiting with code "
                f"{self.config_fail_exit_code}"
            )
            sys.exit(self.config_fail_exit_code)

        # Connect to MQTT
        if self.use_counted_retries:
            if not self._connect_with_counted_retries():
                sys.exit(1)
        else:
            self.running = True
            if not self._connect_with_infinite_retries():
                return

        # Register reconnect callback if subclass overrides _on_reconnect
        if type(self)._on_reconnect is not BaseAgent._on_reconnect:
            self.mqtt_client.set_on_connect_callback(self._on_reconnect)
            logger.info(
                "Configured MQTT reconnection callback to restore "
                "subscriptions"
            )

        # Setup
        self._setup()

        # Main loop
        if self.use_counted_retries:
            self.running = True
        logger.info(f"{self.agent_name} running")

        try:
            self._run_loop()
        except KeyboardInterrupt:
            logger.info(f"{self.agent_name} interrupted by user")
        except Exception as e:
            logger.error(
                f"Fatal error in {self.agent_name} loop: {e}",
                exc_info=True,
            )
        finally:
            self._cleanup()
            self._cleanup_mqtt_client()
            logger.info(f"{self.agent_name} stopped")
