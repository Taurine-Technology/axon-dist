"""Classifier flow statistics monitoring script that publishes flow stats to MQTT.

This module polls OVS flow tables every 5 seconds, extracts statistics for flows
installed by the NFStream classifier (both DROP and METER actions), and publishes
them to the Axon controller via MQTT using protobuf + zstd compression.

Only flows installed by the classifier (indicated by having a non-zero 64-bit cookie
with the specific structure: flow_hash << 32 | classification_id) are collected.

Cookie Structure:
    Upper 32 bits: Hash of 5-tuple + timestamp (unique flow identifier)
    Lower 32 bits: Hash of normalized app name (classification_id)

MQTT Topic: axon/data/{site_id}/{device_id}/classifier-flow-stats
"""

import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from typing import Dict, List, Optional

import psutil
import zstandard as zstd

from ..base_agent import BaseAgent
from ..hostname_resolver import HostnameCache
from ..utils import setup_logging, stop_systemd_service, disable_systemd_service
from axon_shared.mqtt.topics import data_topic, CLASSIFIER_FLOW_STATS
try:
    from axon_shared.proto.classifier_flow_stats_messages_pb2 import (
        ClassifierFlowStatsBatch,
        ClassifierFlowStatsEntry,
    )
    CLASSIFIER_FLOW_STATS_PROTOBUF_AVAILABLE = True
except ImportError:
    CLASSIFIER_FLOW_STATS_PROTOBUF_AVAILABLE = False
    ClassifierFlowStatsBatch = None
    ClassifierFlowStatsEntry = None

logger = logging.getLogger(__name__)

# Configuration constants
DEFAULT_POLL_INTERVAL = 5  # seconds - send stats every 5 seconds
CLASSIFIER_CONFIG_PATH = "/etc/axon/classifier_config.json"
SNIFFER_CONFIG_PATH = "/etc/axon/sniffer_config.json"
DEFAULT_OPENFLOW_VERSION = "OpenFlow13"

# Classification registry file path (shared with classifier)
CLASSIFICATION_REGISTRY_PATH = "/var/lib/axon/classification_registry.json"


@dataclass
class ParsedClassifierFlowStats:
    """Parsed flow statistics for a classifier-installed flow from OVS."""

    openflow_cookie: int
    classification_id: int  # Lower 32 bits of cookie
    flow_hash: int  # Upper 32 bits of cookie
    app_name: str  # Normalized app name from registry
    byte_count: int
    packet_count: int
    duration_sec: float
    action_type: str  # "DROP", "METER", "CLASSIFY", or "NORMAL"
    meter_id: int  # 0 if action is DROP
    priority: int
    protocol: str
    src_mac: str
    dst_mac: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    src_hostname: str = ""  # Client device hostname from DHCP/mDNS
    requested_server_name: str = ""  # SNI (destination server name)


class ClassificationRegistry:
    """Thread-safe registry mapping classification_id to app name and SNI.

    This registry is populated from classifier flow installations and persisted
    to disk for recovery across restarts.

    Registry format (backwards compatible):
        New format: {"12345": {"app_name": "instagram", "sni": "www.instagram.com"}}
        Legacy format: {"12345": "instagram"}
        Both formats are supported when reading; new entries always use new format.
    """

    def __init__(self, registry_path: str = CLASSIFICATION_REGISTRY_PATH):
        self._registry: Dict[int, dict] = {}
        self._lock = threading.Lock()
        self._registry_path = registry_path
        self._load_from_disk()

    def _load_from_disk(self):
        """Load registry from disk if available."""
        try:
            if os.path.exists(self._registry_path):
                with open(self._registry_path, "r") as f:
                    data = json.load(f)
                    with self._lock:
                        for k, v in data.items():
                            cid = int(k)
                            if isinstance(v, str):
                                # Legacy format: value is just app_name string
                                self._registry[cid] = {
                                    "app_name": v, "sni": ""
                                }
                            elif isinstance(v, dict):
                                self._registry[cid] = {
                                    "app_name": v.get("app_name", "unknown"),
                                    "sni": v.get("sni", ""),
                                }
                    logger.info(
                        f"Loaded {len(self._registry)} entries "
                        f"from classification registry"
                    )
        except Exception as e:
            logger.warning(f"Failed to load classification registry: {e}")

    def _save_to_disk(self):
        """Save registry to disk."""
        try:
            os.makedirs(os.path.dirname(self._registry_path), exist_ok=True)
            with open(self._registry_path, "w") as f:
                json.dump(
                    {str(k): v for k, v in self._registry.items()},
                    f, indent=2,
                )
        except Exception as e:
            logger.warning(f"Failed to save classification registry: {e}")

    def register(self, classification_id: int, app_name: str, sni: str = ""):
        """Register a classification_id -> app_name/sni mapping."""
        with self._lock:
            existing = self._registry.get(classification_id)
            if existing is None:
                self._registry[classification_id] = {
                    "app_name": app_name, "sni": sni,
                }
                self._save_to_disk()
                logger.debug(
                    f"Registered classification: {classification_id} "
                    f"-> {app_name} (sni={sni})"
                )
            elif sni and not existing.get("sni"):
                # Update SNI if we didn't have one before
                existing["sni"] = sni
                self._save_to_disk()

    def get(self, classification_id: int) -> str:
        """Get app name for a classification_id."""
        with self._lock:
            entry = self._registry.get(classification_id)
            if entry is None:
                return "unknown"
            return entry.get("app_name", "unknown")

    def get_sni(self, classification_id: int) -> str:
        """Get SNI for a classification_id."""
        with self._lock:
            entry = self._registry.get(classification_id)
            if entry is None:
                return ""
            return entry.get("sni", "")

    def get_all(self) -> Dict[int, str]:
        """Get a copy of the entire registry (app_name only, for compat)."""
        with self._lock:
            return {
                k: v.get("app_name", "unknown")
                for k, v in self._registry.items()
            }


class ClassifierFlowStatsMonitor(BaseAgent):
    """Monitors OVS flow statistics for classifier-installed flows and publishes to MQTT."""

    agent_name = "Classifier Flow Stats Monitor"
    mqtt_client_id_suffix = "classifier-flow-stats"
    config_fail_exit_code = 0
    log_name = None
    connection_wait_timeout = 5.0
    use_counted_retries = False
    publish_buffer_size = 60

    def __init__(self):
        """Initialize classifier flow stats monitor."""
        super().__init__()

        # Configuration values
        self.bridge_name: Optional[str] = None
        self.openflow_version: str = DEFAULT_OPENFLOW_VERSION
        self.poll_interval: int = DEFAULT_POLL_INTERVAL
        self.flow_stats_topic: Optional[str] = None

        # Zstd compressor for message compression
        self.compressor = zstd.ZstdCompressor(level=3)

        # Classification registry for app name and SNI lookups
        self.classification_registry = ClassificationRegistry()

        # Hostname cache for client device name lookups (read-only)
        self.hostname_cache: Optional[HostnameCache] = None

    def _load_config(self) -> bool:
        """Load configuration from classifier_config.json or sniffer_config.json.

        Overrides BaseAgent._load_config() entirely because this agent loads
        from classifier_config.json or sniffer_config.json rather than the
        standard config.json.

        Returns:
            True if configuration loaded successfully, False otherwise
        """
        try:
            # Try classifier config first
            config_path = None
            config = None

            if os.path.exists(CLASSIFIER_CONFIG_PATH):
                config_path = CLASSIFIER_CONFIG_PATH
                with open(CLASSIFIER_CONFIG_PATH, "r") as f:
                    config = json.load(f)
                self.site_id = config.get("site_id")
                self.device_id = config.get("device_id")
                self.bridge_name = config.get("bridge_name")
            elif os.path.exists(SNIFFER_CONFIG_PATH):
                # Fall back to sniffer config
                config_path = SNIFFER_CONFIG_PATH
                with open(SNIFFER_CONFIG_PATH, "r") as f:
                    config = json.load(f)
                self.site_id = config.get("site_id")
                self.device_id = config.get("device_id")
                self.bridge_name = config.get("bridge_name")
            else:
                logger.error(
                    f"Neither classifier config ({CLASSIFIER_CONFIG_PATH}) "
                    f"nor sniffer config ({SNIFFER_CONFIG_PATH}) found"
                )
                return False

            if not self.site_id or not self.device_id:
                logger.error(f"Config {config_path} missing site_id or device_id")
                return False

            # Load device config for additional settings
            device_config = self.config_manager.load_config()
            if device_config:
                bridge_configs = device_config.get("bridge_configs", {})
                if bridge_configs:
                    first_bridge = next(iter(bridge_configs.values()))
                    if isinstance(first_bridge, dict):
                        openflow_version = first_bridge.get("openflow_version")
                        if openflow_version:
                            self.openflow_version = openflow_version
                        if not self.bridge_name:
                            self.bridge_name = first_bridge.get("bridge_name")

            if not self.bridge_name:
                logger.error("Bridge name not found in config")
                return False

            # Build flow stats topic (different from regular flow-stats)
            self.flow_stats_topic = data_topic(self.site_id, self.device_id, CLASSIFIER_FLOW_STATS)

            logger.info(
                f"Loaded config: site_id={self.site_id}, device_id={self.device_id}, "
                f"bridge={self.bridge_name}, poll_interval={self.poll_interval}s"
            )
            return True

        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in config: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            return False

    def _load_service_config(self, config: dict) -> bool:
        """Not used - _load_config is overridden entirely.

        This method satisfies the abstract interface from BaseAgent but is
        never called because _load_config() is fully overridden.
        """
        return True

    def run(self):
        """Run the classifier flow statistics monitor.

        Overrides BaseAgent.run() to add protobuf availability check
        before proceeding with normal lifecycle.
        """
        if not CLASSIFIER_FLOW_STATS_PROTOBUF_AVAILABLE:
            setup_logging(self._get_log_name())
            logger.error(
                "Classifier flow stats protobuf not available. "
                "Run: protoc --python_out=. classifier_flow_stats_messages.proto"
            )
            sys.exit(1)
        super().run()

    def _run_loop(self):
        """Main monitoring loop: collect, build batch, compress & publish, sleep."""
        logger.info(
            f"Publishing to {self.flow_stats_topic} "
            f"every {self.poll_interval} seconds"
        )

        while self.running:
            # Collect flow stats
            flow_stats = self._collect_flow_stats()

            if flow_stats:
                # Build protobuf batch
                batch = self._build_protobuf_batch(flow_stats)

                # Compress and publish
                self._compress_and_publish(batch)

                # Log summary
                drop_count = sum(1 for fs in flow_stats if fs.action_type == "DROP")
                meter_count = sum(
                    1 for fs in flow_stats if fs.action_type == "METER"
                )
                total_bytes = sum(fs.byte_count for fs in flow_stats)
                total_packets = sum(fs.packet_count for fs in flow_stats)
                logger.debug(
                    f"Collected {len(flow_stats)} flows "
                    f"(DROP: {drop_count}, METER: {meter_count}), "
                    f"total: {total_packets} packets, {total_bytes} bytes"
                )
            else:
                logger.debug("No classifier flows found")

            # Wait for next poll
            time.sleep(self.poll_interval)

    def _get_flows_from_ovs(self) -> str:
        """Retrieve flow statistics from OVS bridge.

        Returns:
            Output from ovs-ofctl dump-flows command, or empty string on error
        """
        try:
            cmd = [
                "ovs-ofctl",
                "dump-flows",
                self.bridge_name,
                "-O",
                self.openflow_version,
            ]
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                logger.error(f"Error retrieving flows: {result.stderr}")
                return ""

            return result.stdout

        except subprocess.TimeoutExpired:
            logger.error("Timeout retrieving flows from OVS")
            return ""
        except Exception as e:
            logger.error(f"Exception retrieving flows: {e}")
            return ""

    def _parse_flow_line(self, line: str) -> Optional[ParsedClassifierFlowStats]:
        """Parse an OVS flow dump line to extract stats for classifier flows.

        Only returns stats for flows that:
        1. Have a non-zero cookie (installed by classifier)
        2. Have priority >= 4500 (classifier-installed flows)

        Action type is determined from the actions string:
        - "DROP"     -- actions contain 'drop'
        - "METER"    -- actions contain 'meter:N'
        - "CLASSIFY" -- actions contain 'set_field' with 'ip_dscp' (DSCP marking)
        - "NORMAL"   -- all other classifier flows (plain forwarding)

        Args:
            line: Single line from ovs-ofctl dump-flows output

        Returns:
            ParsedClassifierFlowStats if flow meets criteria, None otherwise
        """
        # Skip if no cookie or no actions
        if "cookie=" not in line or "actions=" not in line:
            return None

        # Extract cookie (required)
        cookie_match = re.search(r"cookie=0x([0-9a-fA-F]+)", line)
        if not cookie_match:
            return None

        try:
            cookie = int(cookie_match.group(1), 16)
        except ValueError:
            return None

        # Skip zero cookies (unclassified flows)
        if cookie == 0:
            return None

        # Extract priority and filter for classifier-installed flows (>= 5000)
        priority_match = re.search(r"priority=(\d+)", line)
        priority = int(priority_match.group(1)) if priority_match else 0

        if priority < 4500:
            return None

        # Extract actions and determine action type
        actions_match = re.search(r"actions=(.*)", line)
        if not actions_match:
            return None

        actions_str = actions_match.group(1).lower()

        # Skip controller flows
        if "controller" in actions_str:
            return None

        # Determine action type
        action_type = "NORMAL"
        meter_id = 0

        if "drop" in actions_str:
            action_type = "DROP"
        elif "meter:" in actions_str:
            action_type = "METER"
            meter_match = re.search(r"meter:(\d+)", actions_str)
            if meter_match:
                meter_id = int(meter_match.group(1))
        elif "set_field" in actions_str and "ip_dscp" in actions_str:
            action_type = "CLASSIFY"
        # else: action_type stays "NORMAL" — plain forwarding flows

        # Parse cookie structure
        classification_id = cookie & 0xFFFFFFFF  # Lower 32 bits
        flow_hash = (cookie >> 32) & 0xFFFFFFFF  # Upper 32 bits

        # Look up app name from registry
        app_name = self.classification_registry.get(classification_id)

        # Extract other fields
        duration_match = re.search(r"duration=([\d\.]+)s", line)
        duration_sec = float(duration_match.group(1)) if duration_match else 0.0

        packets_match = re.search(r"n_packets=(\d+)", line)
        packet_count = int(packets_match.group(1)) if packets_match else 0

        bytes_match = re.search(r"n_bytes=(\d+)", line)
        byte_count = int(bytes_match.group(1)) if bytes_match else 0

        # Determine protocol from match fields
        protocol = "OTHER"
        line_lower = line.lower()
        if (
            ",tcp," in line_lower
            or ",tcp " in line_lower
            or line_lower.endswith(",tcp")
        ):
            protocol = "TCP"
        elif (
            ",udp," in line_lower
            or ",udp " in line_lower
            or line_lower.endswith(",udp")
        ):
            protocol = "UDP"
        elif (
            ",icmp," in line_lower
            or ",icmp " in line_lower
            or line_lower.endswith(",icmp")
        ):
            protocol = "ICMP"
        elif (
            ",arp," in line_lower
            or ",arp " in line_lower
            or line_lower.endswith(",arp")
        ):
            protocol = "ARP"

        # Extract source MAC
        src_mac_match = re.search(r"dl_src=([0-9a-fA-F:]+)", line)
        src_mac = src_mac_match.group(1).lower() if src_mac_match else ""

        # Extract destination MAC
        dst_mac_match = re.search(r"dl_dst=([0-9a-fA-F:]+)", line)
        dst_mac = dst_mac_match.group(1).lower() if dst_mac_match else ""

        # Extract source IP
        src_ip_match = re.search(r"nw_src=([0-9\.]+)", line)
        src_ip = src_ip_match.group(1) if src_ip_match else ""

        # Extract destination IP
        dst_ip_match = re.search(r"nw_dst=([0-9\.]+)", line)
        dst_ip = dst_ip_match.group(1) if dst_ip_match else ""

        # Extract source port
        src_port_match = re.search(r"tp_src=(\d+)", line)
        src_port = int(src_port_match.group(1)) if src_port_match else 0

        # Extract destination port
        dst_port_match = re.search(r"tp_dst=(\d+)", line)
        dst_port = int(dst_port_match.group(1)) if dst_port_match else 0

        return ParsedClassifierFlowStats(
            openflow_cookie=cookie,
            classification_id=classification_id,
            flow_hash=flow_hash,
            app_name=app_name,
            byte_count=byte_count,
            packet_count=packet_count,
            duration_sec=duration_sec,
            action_type=action_type,
            meter_id=meter_id,
            priority=priority,
            protocol=protocol,
            src_mac=src_mac,
            dst_mac=dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
        )

    def _collect_flow_stats(self) -> List[ParsedClassifierFlowStats]:
        """Collect all classifier flow statistics from OVS.

        Reloads the hostname cache on each poll cycle to pick up new
        hostname discoveries from the resolver.

        Returns:
            List of ParsedClassifierFlowStats for flows that meet criteria
        """
        output = self._get_flows_from_ovs()
        if not output:
            return []

        # Reload hostname cache from disk on each poll cycle
        try:
            self.hostname_cache = HostnameCache.load_from_file()
        except Exception as e:
            logger.debug(f"Failed to load hostname cache: {e}")

        stats = []
        for line in output.strip().splitlines():
            flow_stats = self._parse_flow_line(line)
            if flow_stats:
                # Enrich with hostname from cache
                if self.hostname_cache and flow_stats.src_mac:
                    flow_stats.src_hostname = self.hostname_cache.get(
                        flow_stats.src_mac
                    )
                # Enrich with SNI from classification registry
                if flow_stats.classification_id:
                    flow_stats.requested_server_name = (
                        self.classification_registry.get_sni(
                            flow_stats.classification_id
                        )
                    )
                stats.append(flow_stats)

        return stats

    def _build_protobuf_batch(
        self, flow_stats: List[ParsedClassifierFlowStats]
    ) -> ClassifierFlowStatsBatch:
        """Build a ClassifierFlowStatsBatch protobuf message.

        Args:
            flow_stats: List of parsed flow statistics

        Returns:
            ClassifierFlowStatsBatch protobuf message
        """
        batch = ClassifierFlowStatsBatch()
        batch.site_id = self.site_id
        batch.device_id = self.device_id
        batch.bridge_name = self.bridge_name
        batch.timestamp_ms = int(time.time() * 1000)
        batch.poll_interval_sec = self.poll_interval

        for fs in flow_stats:
            entry = batch.stats.add()
            entry.openflow_cookie = fs.openflow_cookie
            entry.classification_id = fs.classification_id
            entry.flow_hash = fs.flow_hash
            entry.app_name = fs.app_name
            entry.byte_count = fs.byte_count
            entry.packet_count = fs.packet_count
            entry.duration_sec = fs.duration_sec
            entry.action_type = fs.action_type
            entry.meter_id = fs.meter_id
            entry.priority = fs.priority
            entry.protocol = fs.protocol
            entry.src_mac = fs.src_mac
            entry.dst_mac = fs.dst_mac
            entry.src_ip = fs.src_ip
            entry.dst_ip = fs.dst_ip
            entry.src_port = fs.src_port
            entry.dst_port = fs.dst_port
            if fs.src_hostname:
                entry.src_hostname = fs.src_hostname
            if fs.requested_server_name:
                entry.requested_server_name = fs.requested_server_name

        return batch

    def _compress_and_publish(self, batch: ClassifierFlowStatsBatch) -> bool:
        """Serialize, compress, and publish the batch.

        Args:
            batch: ClassifierFlowStatsBatch protobuf message

        Returns:
            True if publish successful, False otherwise
        """
        if not self.mqtt_client or not self.mqtt_client.is_connected():
            return False

        try:
            # Serialize to protobuf
            protobuf_bytes = batch.SerializeToString()

            # Compress with zstd
            compressed = self.compressor.compress(protobuf_bytes)

            # Publish to MQTT with QoS 0 (fire-and-forget)
            result = self.mqtt_client.publish_raw(
                self.flow_stats_topic, compressed, qos=0
            )

            if result:
                logger.debug(
                    f"Published {len(batch.stats)} classifier flow stats "
                    f"({len(protobuf_bytes)} bytes -> {len(compressed)} bytes compressed)"
                )
                return True
            else:
                logger.warning(
                    f"Failed to publish classifier flow stats to {self.flow_stats_topic}"
                )
                return False

        except Exception as e:
            logger.error(f"Error publishing classifier flow stats: {e}")
            return False

    def register_classification(self, classification_id: int, app_name: str):
        """Register a classification_id -> app_name mapping.

        This should be called when the classifier installs a flow.

        Args:
            classification_id: The 32-bit classification hash
            app_name: The normalized application name
        """
        self.classification_registry.register(classification_id, app_name)


def start_classifier_flow_stats_monitoring_process() -> Optional[subprocess.Popen]:
    """Start the classifier flow statistics monitoring script as a separate process.

    Returns:
        Popen process object if started successfully, None otherwise
    """
    logger = logging.getLogger(__name__)

    # Check if process is already running
    if _is_classifier_flow_stats_monitoring_running():
        logger.info("Classifier flow statistics monitoring process is already running")
        return None

    try:
        # Use Python to run the module
        python_executable = sys.executable
        module_path = "axon_agent.monitoring.classifier_flow_stats_monitor"

        logger.info("Starting classifier flow statistics monitoring process...")

        # Start process in background (daemon-like)
        process = subprocess.Popen(
            [python_executable, "-m", module_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Give it a moment to start
        time.sleep(0.5)

        # Check if process is still running
        if process.poll() is None:
            logger.info(
                f"Classifier flow statistics monitoring process started (PID: {process.pid})"
            )
            return process
        else:
            logger.error(
                "Classifier flow statistics monitoring process exited immediately"
            )
            return None

    except Exception as e:
        logger.error(
            f"Failed to start classifier flow statistics monitoring process: {e}"
        )
        return None


def _is_classifier_flow_stats_monitoring_running() -> bool:
    """Check if classifier flow statistics monitoring process is already running.

    Returns:
        True if monitoring process is running, False otherwise
    """
    try:
        # First check if running as systemd service
        try:
            result = subprocess.run(
                [
                    "systemctl",
                    "is-active",
                    "--quiet",
                    "axon-agent-classifier-flow-stats.service",
                ],
                capture_output=True,
                timeout=2,
            )
            if result.returncode == 0:
                logger = logging.getLogger(__name__)
                logger.info(
                    "Classifier flow statistics monitoring is running as systemd service"
                )
                return True
        except (
            subprocess.TimeoutExpired,
            FileNotFoundError,
            subprocess.SubprocessError,
        ):
            pass

        current_pid = os.getpid()

        # Check for processes matching our module name
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "classifier_flow_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.classifier_flow_stats_monitor"
                        in cmdline_str
                    ):
                        if proc.is_running():
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(
            f"Error checking for classifier flow stats monitoring process: {e}"
        )
        return False


def stop_classifier_flow_stats_monitoring() -> bool:
    """Stop classifier flow statistics monitoring service/process.

    Returns:
        True if monitoring was stopped successfully, False otherwise
    """
    logger = logging.getLogger(__name__)
    service_name = "axon-agent-classifier-flow-stats.service"

    # Try to stop systemd service first
    try:
        if stop_systemd_service(service_name):
            logger.info("Stopped classifier flow statistics monitoring systemd service")
            if disable_systemd_service(service_name):
                logger.info(
                    "Disabled classifier flow statistics monitoring systemd service"
                )
                return True
            else:
                logger.error(
                    f"Failed to disable {service_name} after stopping it. "
                    "Service may restart on next boot."
                )
                return False
    except Exception as e:
        logger.warning(
            f"Failed to stop classifier flow stats systemd service: {e}, "
            "trying to stop subprocess"
        )

    # Fallback: try to stop subprocess
    try:
        current_pid = os.getpid()
        stopped_any = False

        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                if proc.pid == current_pid:
                    continue

                cmdline = proc.info.get("cmdline", [])
                if cmdline:
                    cmdline_str = " ".join(cmdline)
                    if "classifier_flow_stats_monitor" in cmdline_str or (
                        "axon_agent.monitoring.classifier_flow_stats_monitor"
                        in cmdline_str
                    ):
                        if proc.is_running():
                            logger.info(
                                f"Stopping classifier flow statistics monitoring "
                                f"process (PID: {proc.pid})"
                            )
                            proc.terminate()
                            try:
                                proc.wait(timeout=5)
                                logger.info(
                                    f"Classifier flow statistics monitoring process "
                                    f"{proc.pid} stopped gracefully"
                                )
                            except psutil.TimeoutExpired:
                                logger.warning(
                                    f"Process {proc.pid} did not terminate, forcing kill"
                                )
                                proc.kill()
                                proc.wait()
                                logger.info(
                                    f"Classifier flow statistics monitoring process "
                                    f"{proc.pid} killed"
                                )
                            stopped_any = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if stopped_any:
            logger.info("Stopped classifier flow statistics monitoring process(es)")
            return True
        else:
            logger.info(
                "No classifier flow statistics monitoring process found to stop"
            )
            return True
    except Exception as e:
        logger.error(
            f"Error stopping classifier flow statistics monitoring process: {e}"
        )
        return False


def main():
    """Main entry point for classifier flow stats monitor."""
    monitor = ClassifierFlowStatsMonitor()
    monitor.run()


if __name__ == "__main__":
    main()
