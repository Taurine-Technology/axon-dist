"""Core classifier module using NFStream for traffic classification.

This module provides the core functionality for capturing and classifying
network traffic using NFStream's nDPI engine. It is designed to be used
by both the test script (console output) and production agent (MQTT).

Features:
    - Traffic classification using NFStream/nDPI
    - Policy-based blocking (DROP action via OVS)
    - Policy-based rate limiting (METER action via OVS)
    - Cached block registry for subsequent flows
    - IP-to-SNI mapping for flows without SNI

Classes:
    ClassifierPlugin: NFPlugin that collects payloads and triggers early expiration
    FlowCollector: Manages flow data collection, batching, and IP-to-SNI cache
"""

import hashlib
import ipaddress
import logging
from multiprocessing import Queue as MPQueue
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from queue import Empty as QueueEmpty
from typing import TYPE_CHECKING, Callable, Optional

try:
    from nfstream import NFPlugin
except ImportError:
    raise ImportError("nfstream not installed. Run: pip install nfstream")

if TYPE_CHECKING:
    from ..policy_cache import PolicyCache

from .ovs_actions import (
    OVSActionWorker,
    find_meter_by_rate_in_ovs,
    generate_flow_cookie,
    install_bidirectional_drop,
    install_bidirectional_meter,
    install_bidirectional_normal,
    is_generic_protocol,
    is_private_ip,
    normalize_app_name,
)

logger = logging.getLogger(__name__)

# Default configuration values
DEFAULT_NUM_BYTES = 225
DEFAULT_NUM_PACKETS = 5
DEFAULT_BATCH_INTERVAL = 1.0  # seconds
DEFAULT_IDLE_TIMEOUT = 30  # seconds
DEFAULT_MIN_CLASSIFICATION_PACKETS = 3  # minimum packets before forcing classification
DEFAULT_BLOCK_CACHE_TTL = 300  # seconds (5 minutes)

# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class ClassifiedFlowData:
    """Data class representing a classified flow."""

    # Basic 5-tuple
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    src_mac: str
    dst_mac: str
    is_tcp: bool

    # Payload samples
    payload_sample: bytes  # Flattened payload (num_packets * num_bytes)
    payload_packet_count: int

    # Flow identifier
    flow_id: int

    # NFStream classification
    application_name: str
    application_category: str
    application_confidence: int
    requested_server_name: str  # SNI
    client_fingerprint: str
    server_fingerprint: str

    # Traffic statistics
    bidirectional_packets: int
    bidirectional_bytes: int
    bidirectional_duration_ms: int
    src2dst_packets: int
    dst2src_packets: int
    src2dst_bytes: int
    dst2src_bytes: int

    # Metadata
    sni_source: str  # "direct", "cached", "ip"
    timestamp_ms: int = field(default_factory=lambda: int(time.time() * 1000))
    flow_first_seen_ms: int = (
        0  # NFStream's bidirectional_first_seen_ms (stable per-flow)
    )
    vlan_id: int = 0
    vlan_source: str = ""

    # Cookie and classification tracking (for OVS flow stats monitoring)
    # Cookie structure: (flow_hash << 32) | classification_id
    openflow_cookie: int = 0
    classification_id: int = 0  # Lower 32 bits - hash of normalized app name
    normalized_app_name: str = ""  # Lowercase app-specific name (e.g., "instagram")

    # Client device hostname (from DHCP/mDNS discovery)
    src_hostname: str = ""

    # Policy tracking (to avoid duplicate policy application)
    policy_applied: bool = False  # True if early policy was already applied
    early_action: Optional[str] = None  # "block", "rate_limit", or None


VLAN_ATTR_NAMES = (
    "vlan_id",
    "src_vlan_id",
    "dst_vlan_id",
    "bidirectional_vlan_id",
)


def _vlan_extra_keys(owner_name: str, owner) -> list[str]:
    """Return additional VLAN-looking attributes for debug diagnostics."""
    try:
        keys = vars(owner).keys()
    except TypeError:
        return []
    return [
        f"{owner_name}.{key}={getattr(owner, key, None)!r}"
        for key in sorted(keys)
        if "vlan" in key.lower() and key not in VLAN_ATTR_NAMES
    ]


def inspect_vlan_info(flow) -> tuple[int, str]:
    """Extract a VLAN ID and a debug description of where it came from."""
    candidates = []
    for attr_name in VLAN_ATTR_NAMES:
        value = getattr(flow, attr_name, None)
        candidates.append(f"{attr_name}={value!r}")
        try:
            vlan_id = int(value)
        except (TypeError, ValueError):
            continue
        if vlan_id > 0:
            return vlan_id, f"{attr_name} ({', '.join(candidates)})"

    extras = _vlan_extra_keys("flow", flow)
    udps = getattr(flow, "udps", None)
    if udps is not None:
        extras.extend(_vlan_extra_keys("udps", udps))
    extra_text = f"; extras={', '.join(extras)}" if extras else ""
    return 0, f"none ({', '.join(candidates)}{extra_text})"


def extract_vlan_id(flow) -> int:
    """Extract a VLAN ID from an NFStream flow object when available."""
    vlan_id, _ = inspect_vlan_info(flow)
    return vlan_id


def _log_vlan_debug(
    context: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    vlan_id: int,
    vlan_source: str,
    label: str = "",
) -> None:
    """Log the VLAN state at a classifier decision/install boundary."""
    logger.debug(
        "VLAN DEBUG %s: %s:%s -> %s:%s proto=%s vlan_id=%s vlan_source=%s label=%s",
        context,
        src_ip,
        src_port,
        dst_ip,
        dst_port,
        "tcp" if is_tcp else "udp",
        vlan_id,
        vlan_source,
        label,
    )


def _is_global_public_ip(ip: str) -> bool:
    """Check if an IP is globally routable unicast."""
    try:
        ip_addr = ipaddress.ip_address(ip)
        return ip_addr.is_global and not ip_addr.is_multicast
    except ValueError:
        return False


class ClassifierPlugin(NFPlugin):
    """NFPlugin that collects payloads and triggers early expiration.

    This plugin:
    1. Collects the first NUM_BYTES of each of the first NUM_PACKETS packets
    2. Monitors NFStream's classification progress
    3. Triggers early flow expiration when both conditions are met:
       - Required number of payload packets collected
       - Application has been classified (not Unknown)
    4. Performs EARLY SNI-based blocking as soon as SNI is detected (before full classification)
    5. Performs EARLY app-based policy check as soon as app is identified (before 5 packets)

    Args:
        num_bytes: Number of bytes to capture per packet (default: 225)
        num_packets: Number of packets to capture (default: 5)
        min_classification_packets: Minimum packets before allowing classification (default: 3)
        on_flow_ready: Callback function when a flow is ready for output (legacy)
        flow_queue: multiprocessing.Queue for inter-process communication (preferred)
        flow_converter: Function to convert NFStream flow to ClassifiedFlowData
        policy_cache: Optional PolicyCache for early SNI-based blocking
        bridge: Optional OVS bridge name for installing DROP rules
        ovs_worker: Optional OVSActionWorker for async policy enforcement
        use_async_ovs: If True, use async worker for OVS operations (default: True if worker provided)
    """

    def __init__(
        self,
        num_bytes: int = DEFAULT_NUM_BYTES,
        num_packets: int = DEFAULT_NUM_PACKETS,
        min_classification_packets: int = DEFAULT_MIN_CLASSIFICATION_PACKETS,
        on_flow_ready: Optional[Callable[[object], None]] = None,
        flow_queue: Optional[MPQueue] = None,
        flow_converter: Optional[
            Callable[[object], Optional["ClassifiedFlowData"]]
        ] = None,
        processed_flow_ttl: int = 300,  # How long to remember processed flows (seconds)
        policy_cache: Optional["PolicyCache"] = None,
        bridge: Optional[str] = None,
        ovs_worker: Optional["OVSActionWorker"] = None,
        use_async_ovs: Optional[bool] = None,
        allow_public_to_public: bool = False,
    ):
        self.num_bytes = num_bytes
        self.num_packets = num_packets
        self.min_classification_packets = min_classification_packets
        self.on_flow_ready = on_flow_ready
        self.flow_queue = flow_queue
        self.flow_converter = flow_converter
        self.processed_flow_ttl = processed_flow_ttl

        # Early blocking support
        self.policy_cache = policy_cache
        self.bridge = bridge
        self.ovs_worker = ovs_worker
        self.early_blocking_enabled = policy_cache is not None and bridge is not None

        # Use async OVS by default if worker is provided
        self.use_async_ovs = (
            use_async_ovs if use_async_ovs is not None else (ovs_worker is not None)
        )
        self.allow_public_to_public = allow_public_to_public

        # Statistics
        self.flow_count = 0
        self.packet_count = 0
        self.bytes_count = 0
        self.early_blocked_flows = 0
        self.early_rate_limited_flows = 0
        self.early_app_policy_checks = 0

        # Cache of processed flow tuples to skip re-processing after early expiration
        # Key: (src_ip, dst_ip, src_port, dst_port, protocol, vlan_id)
        # Value: expiration timestamp
        self._processed_flows: dict[tuple, float] = {}
        # Cleanup scheduling: run every 100 flows or 60 seconds
        self._processed_flows_cleanup_interval = 100  # flows
        self._processed_flows_cleanup_time_interval = 60.0  # seconds
        self._last_processed_flows_cleanup_ts = time.time()

    def _get_flow_key(self, flow) -> tuple:
        """Get a unique key for a flow based on its 5-tuple."""
        return (
            getattr(flow, "src_ip", ""),
            getattr(flow, "dst_ip", ""),
            getattr(flow, "src_port", 0),
            getattr(flow, "dst_port", 0),
            getattr(flow, "protocol", 0),
            extract_vlan_id(flow),
        )

    def _check_early_sni_block(self, flow) -> bool:
        """Check if flow should be blocked based on SNI, immediately on detection.

        This is called as soon as SNI is available (typically packet 1-2) to block
        blocklisted domains BEFORE the TLS handshake completes.

        Args:
            flow: NFStream flow object

        Returns:
            True if flow was blocked (DROP rules installed), False otherwise
        """
        if not self.early_blocking_enabled:
            logger.debug("Early blocking disabled, skipping SNI check")
            return False

        # Already checked this flow
        if getattr(flow.udps, "early_sni_checked", False):
            return getattr(flow.udps, "early_blocked", False)

        # Get SNI
        sni = getattr(flow, "requested_server_name", "") or ""
        if not sni:
            return False

        # Mark as checked so we don't re-check on every packet
        flow.udps.early_sni_checked = True
        flow.udps.early_blocked = False

        # Get flow details
        src_ip = getattr(flow, "src_ip", "")
        dst_ip = getattr(flow, "dst_ip", "")
        src_port = getattr(flow, "src_port", 0)
        dst_port = getattr(flow, "dst_port", 0)
        protocol = getattr(flow, "protocol", 0)
        is_tcp = protocol == 6
        vlan_id, vlan_source = inspect_vlan_info(flow)

        # Determine which is LAN (private) IP
        src_is_private = is_private_ip(src_ip)
        dst_is_private = is_private_ip(dst_ip)

        public_to_public = (
            self.allow_public_to_public
            and not src_is_private
            and _is_global_public_ip(src_ip)
            and _is_global_public_ip(dst_ip)
        )

        # Skip LAN-to-LAN or WAN-to-WAN unless EE explicitly opts into
        # globally-routable public-to-public monitoring and policy.
        if src_is_private == dst_is_private:
            if public_to_public:
                logger.debug(
                    f"Accepting public-to-public early SNI policy: {src_ip} -> {dst_ip}"
                )
            else:
                logger.debug(f"Skipping LAN-LAN/WAN-WAN: {src_ip} -> {dst_ip}")
                return False

        # Check domain blocklist
        logger.debug(
            f"CHECK BLOCKLIST: sni={sni}, {src_ip}:{src_port} -> {dst_ip}:{dst_port}, "
            f"bridge={self.bridge}, policy_cache={self.policy_cache is not None}"
        )
        blocked, info = self.policy_cache.check_block_list_domain(sni)
        logger.debug(f"BLOCKLIST RESULT: sni={sni}, blocked={blocked}, info={info}")
        if blocked:
            rule_label = f"blocklist:{info.get('name', 'unknown')}"
            priority = info.get("priority", 7000)

            logger.info(
                f"EARLY BLOCK: {rule_label} - {sni} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            _log_vlan_debug(
                "early_sni_domain_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                vlan_id,
                vlan_source,
                rule_label,
            )

            if self.use_async_ovs and self.ovs_worker:
                # Async path: queue for background execution
                self.ovs_worker.enqueue_drop(
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    src_port=src_port,
                    dst_port=dst_port,
                    is_tcp=is_tcp,
                    app_name=rule_label,
                    priority=priority,
                    idle_timeout=DEFAULT_BLOCK_CACHE_TTL,
                    rule_label=sni,
                    vlan_id=vlan_id,
                )
                flow.udps.early_blocked = True
                self.early_blocked_flows += 1
                return True
            else:
                # Sync path: immediate execution
                success_fwd, success_rev, _ = install_bidirectional_drop(
                    self.bridge,
                    src_ip,
                    src_port,
                    dst_ip,
                    dst_port,
                    is_tcp,
                    rule_label,
                    priority,
                    DEFAULT_BLOCK_CACHE_TTL,
                    vlan_id=vlan_id,
                )

                logger.info(
                    f"DROP INSTALL RESULT: sni={sni}, success_fwd={success_fwd}, "
                    f"success_rev={success_rev}"
                )
                if success_fwd and success_rev:
                    flow.udps.early_blocked = True
                    self.early_blocked_flows += 1
                    logger.info(f"EARLY BLOCKED SET: sni={sni}, early_blocked=True")

                    # Register in cached block registry for both IPs
                    if src_is_private:
                        self.policy_cache.register_cached_block(
                            src_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                        )
                    if dst_is_private:
                        self.policy_cache.register_cached_block(
                            dst_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                        )
                    return True
                else:
                    logger.warning(f"Failed to install early DROP flows for {sni}")

        # Check URL blocklist
        blocked, info = self.policy_cache.check_url_block(sni)
        logger.debug(f"URL BLOCKLIST RESULT: sni={sni}, blocked={blocked}")
        if blocked:
            rule_label = f"urlblock:{info.get('rule_id', '')}"
            priority = info.get("priority", 7000)

            logger.info(
                f"EARLY BLOCK (URL): {rule_label} - {sni} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            _log_vlan_debug(
                "early_sni_url_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                vlan_id,
                vlan_source,
                rule_label,
            )

            if self.use_async_ovs and self.ovs_worker:
                # Async path: queue for background execution
                self.ovs_worker.enqueue_drop(
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    src_port=src_port,
                    dst_port=dst_port,
                    is_tcp=is_tcp,
                    app_name=rule_label,
                    priority=priority,
                    idle_timeout=DEFAULT_BLOCK_CACHE_TTL,
                    rule_label=sni,
                    vlan_id=vlan_id,
                )
                flow.udps.early_blocked = True
                self.early_blocked_flows += 1
                return True
            else:
                # Sync path: immediate execution
                success_fwd, success_rev, _ = install_bidirectional_drop(
                    self.bridge,
                    src_ip,
                    src_port,
                    dst_ip,
                    dst_port,
                    is_tcp,
                    rule_label,
                    priority,
                    DEFAULT_BLOCK_CACHE_TTL,
                    vlan_id=vlan_id,
                )

                if success_fwd and success_rev:
                    flow.udps.early_blocked = True
                    self.early_blocked_flows += 1

                    # Register in cached block registry
                    if src_is_private:
                        self.policy_cache.register_cached_block(
                            src_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                        )
                    if dst_is_private:
                        self.policy_cache.register_cached_block(
                            dst_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                        )
                    return True
                else:
                    logger.warning(f"Failed to install early DROP flows for URL {sni}")

        return False

    def _check_early_app_policy(self, flow) -> Optional[str]:
        """Check app-based policy as soon as app is identified.

        This is called when NFStream identifies the application (e.g., QUIC.Instagram),
        typically at packet 2-3, BEFORE waiting for full classification (5 packets).
        This enables near-instant policy enforcement for app-based rules.

        Args:
            flow: NFStream flow object

        Returns:
            Action taken: "block", "rate_limit", or None if no policy matched
        """
        if not self.early_blocking_enabled:
            return None

        # Already checked app policy for this flow
        if getattr(flow.udps, "early_app_checked", False):
            return getattr(flow.udps, "early_app_action", None)

        # Get app name
        app_name = getattr(flow, "application_name", "") or ""
        if not app_name or app_name == "Unknown":
            return None

        # Skip generic protocols - need specific app identification
        if is_generic_protocol(app_name):
            return None

        # Mark as checked
        flow.udps.early_app_checked = True
        flow.udps.early_app_action = None
        self.early_app_policy_checks += 1

        # Get flow details
        src_ip = getattr(flow, "src_ip", "")
        dst_ip = getattr(flow, "dst_ip", "")
        src_port = getattr(flow, "src_port", 0)
        dst_port = getattr(flow, "dst_port", 0)
        protocol = getattr(flow, "protocol", 0)
        is_tcp = protocol == 6
        src_mac = getattr(flow, "src_mac", "")
        dst_mac = getattr(flow, "dst_mac", "")
        sni = getattr(flow, "requested_server_name", "") or ""
        vlan_id, vlan_source = inspect_vlan_info(flow)

        # Determine which is LAN (private) IP
        src_is_private = is_private_ip(src_ip)
        dst_is_private = is_private_ip(dst_ip)

        public_to_public = (
            self.allow_public_to_public
            and not src_is_private
            and _is_global_public_ip(src_ip)
            and _is_global_public_ip(dst_ip)
        )

        # Skip LAN-to-LAN or WAN-to-WAN unless EE explicitly opts into
        # globally-routable public-to-public monitoring and policy.
        if src_is_private == dst_is_private:
            if public_to_public:
                logger.debug(
                    f"Accepting public-to-public early app policy: {src_ip} -> {dst_ip}"
                )
            else:
                logger.debug(f"Skipping LAN-LAN/WAN-WAN: {src_ip} -> {dst_ip}")
                return None

        # Get timestamp for cookie generation
        timestamp_ms = getattr(flow, "bidirectional_first_seen_ms", 0) or None

        # Check app blocklist
        block_rule = self.policy_cache.is_blocked(
            app_name,
            src_mac=src_mac,
            dst_mac=dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
        )
        if block_rule:
            rule_label = f"app:{app_name}"
            priority = block_rule.priority
            idle_timeout = block_rule.idle_timeout

            logger.info(
                f"EARLY APP BLOCK: {rule_label} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port} (sni={sni or 'none'})"
            )
            _log_vlan_debug(
                "early_app_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                vlan_id,
                vlan_source,
                rule_label,
            )

            if self.use_async_ovs and self.ovs_worker:
                # Async path: queue for background execution
                self.ovs_worker.enqueue_drop(
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    src_port=src_port,
                    dst_port=dst_port,
                    is_tcp=is_tcp,
                    app_name=app_name,
                    priority=priority,
                    idle_timeout=idle_timeout,
                    rule_label=rule_label,
                    timestamp_ms=timestamp_ms,
                    vlan_id=vlan_id,
                )
                flow.udps.early_blocked = True
                flow.udps.early_app_action = "block"
                self.early_blocked_flows += 1
            else:
                # Sync path: immediate execution
                success_fwd, success_rev, _ = install_bidirectional_drop(
                    self.bridge,
                    src_ip,
                    src_port,
                    dst_ip,
                    dst_port,
                    is_tcp,
                    rule_label,
                    priority,
                    idle_timeout,
                    timestamp_ms=timestamp_ms,
                    vlan_id=vlan_id,
                )
                if success_fwd and success_rev:
                    flow.udps.early_blocked = True
                    flow.udps.early_app_action = "block"
                    self.early_blocked_flows += 1

                    # Register in cached block registry
                    if src_is_private:
                        self.policy_cache.register_cached_block(
                            src_ip, sni or dst_ip, rule_label, idle_timeout
                        )
                    if dst_is_private:
                        self.policy_cache.register_cached_block(
                            dst_ip, sni or src_ip, rule_label, idle_timeout
                        )
                else:
                    logger.warning(f"Failed to install early DROP flows for {app_name}")

            return flow.udps.early_app_action

        # Check app rate limits
        # CRITICAL: For TLS/QUIC/HTTPS flows, delay rate limiting until SNI is checked.
        # This prevents installing METER rules before we know if the flow will be blocked.
        # SNI-based blocking (priority 7000) must be evaluated BEFORE rate limiting (priority 5000).
        sni_bearing_apps = {"TLS", "QUIC", "HTTP.S", "HTTPS", "TLS.DoH", "TLS.DoT"}
        app_may_have_sni = (
            app_name in sni_bearing_apps or "TLS" in app_name or "QUIC" in app_name
        )
        if app_may_have_sni and not getattr(flow.udps, "early_sni_checked", False):
            # SNI not yet checked for this TLS/QUIC flow - delay rate limiting
            # The flow will be re-evaluated once SNI is available
            logger.debug(
                f"DELAY RATE LIMIT: Waiting for SNI check - {app_name} "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            # Don't mark as checked - let it be rechecked after SNI
            flow.udps.early_app_checked = False
            return None

        # Skip rate limiting if already blocked via SNI
        if getattr(flow.udps, "early_blocked", False):
            logger.info(
                f"SKIP RATE LIMIT: Flow already blocked via SNI - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            return "block"

        rate_rule = self.policy_cache.get_rate_limit(
            app_name,
            src_mac=src_mac,
            dst_mac=dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
        )
        if rate_rule and rate_rule.meter_id > 0:
            rule_label = f"rate:{app_name}"
            priority = rate_rule.priority
            idle_timeout = rate_rule.idle_timeout
            meter_id = rate_rule.meter_id

            logger.debug(
                f"EARLY APP RATE LIMIT: {rule_label} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port} (meter={meter_id})"
            )
            _log_vlan_debug(
                "early_app_meter",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                vlan_id,
                vlan_source,
                rule_label,
            )

            if self.use_async_ovs and self.ovs_worker:
                # Async path: queue for background execution
                self.ovs_worker.enqueue_meter(
                    src_ip=src_ip,
                    dst_ip=dst_ip,
                    src_port=src_port,
                    dst_port=dst_port,
                    is_tcp=is_tcp,
                    meter_id=meter_id,
                    app_name=app_name,
                    priority=priority,
                    idle_timeout=idle_timeout,
                    rule_label=rule_label,
                    timestamp_ms=timestamp_ms,
                    vlan_id=vlan_id,
                )
                flow.udps.early_app_action = "rate_limit"
                self.early_rate_limited_flows += 1
            else:
                # Sync path: immediate execution
                success_fwd, success_rev, _ = install_bidirectional_meter(
                    self.bridge,
                    src_ip,
                    src_port,
                    dst_ip,
                    dst_port,
                    is_tcp,
                    meter_id,
                    rule_label,
                    priority,
                    idle_timeout,
                    timestamp_ms=timestamp_ms,
                    vlan_id=vlan_id,
                )
                if success_fwd and success_rev:
                    flow.udps.early_app_action = "rate_limit"
                    self.early_rate_limited_flows += 1
                else:
                    logger.warning(
                        f"Failed to install early METER flows for {app_name}"
                    )

            return flow.udps.early_app_action

        return None

    def _is_flow_already_processed(self, flow) -> bool:
        """Check if this 5-tuple was recently processed."""
        flow_key = self._get_flow_key(flow)
        if flow_key in self._processed_flows:
            expiry = self._processed_flows[flow_key]
            if time.time() < expiry:
                return True
            else:
                # Expired, remove from cache
                del self._processed_flows[flow_key]
        return False

    def _mark_flow_processed(self, flow) -> None:
        """Mark a flow as processed so we skip it if re-created."""
        flow_key = self._get_flow_key(flow)
        self._processed_flows[flow_key] = time.time() + self.processed_flow_ttl

        # Also mark the reverse direction
        reverse_key = (
            flow_key[1],  # dst_ip -> src_ip
            flow_key[0],  # src_ip -> dst_ip
            flow_key[3],  # dst_port -> src_port
            flow_key[2],  # src_port -> dst_port
            flow_key[4],  # protocol
            flow_key[5],  # vlan_id
        )
        self._processed_flows[reverse_key] = time.time() + self.processed_flow_ttl

    def _cleanup_processed_flows(self) -> None:
        """Remove expired entries from _processed_flows to prevent unbounded growth.

        Called periodically from on_expire based on flow count or time interval.
        """
        now = time.time()
        expired_keys = [
            key for key, expiry in self._processed_flows.items() if expiry <= now
        ]
        for key in expired_keys:
            del self._processed_flows[key]

        if expired_keys:
            logger.debug(
                f"Cleaned up {len(expired_keys)} expired processed flow entries"
            )

    def _maybe_cleanup_processed_flows(self) -> None:
        """Conditionally run cleanup based on flow count or time interval."""
        now = time.time()
        time_since_cleanup = now - self._last_processed_flows_cleanup_ts
        flows_since_cleanup = self.flow_count % self._processed_flows_cleanup_interval

        # Run cleanup if enough time passed or enough flows processed
        if (
            time_since_cleanup >= self._processed_flows_cleanup_time_interval
            or flows_since_cleanup == 0
        ):
            self._cleanup_processed_flows()
            self._last_processed_flows_cleanup_ts = now

    def on_init(self, packet, flow):
        """Called when a new flow is created (first packet seen)."""
        self.flow_count += 1
        self.packet_count += 1
        self.bytes_count += packet.ip_size

        # Initialize flow tracking
        flow.udps.payload_samples = []
        flow.udps.payload_packet_count = 0
        flow.udps.classified = False
        flow.udps.ready = False
        flow.udps.skip = False  # Will be set True if already processed
        flow.udps.sent = False  # Will be set True after flow data is sent
        flow.udps.flow_number = self.flow_count
        flow.udps.early_sni_checked = False  # For early SNI blocking
        flow.udps.early_blocked = False  # True if early blocked
        flow.udps.early_app_checked = False  # For early app-based blocking
        flow.udps.early_app_action = None  # "block", "rate_limit", or None
        flow.udps.sni_logged = False  # For logging SNI detection once

        # Check if this 5-tuple was already processed recently
        # This handles re-created flows after early expiration
        if self._is_flow_already_processed(flow):
            flow.udps.skip = True
            logger.debug(
                f"Skipping already-processed flow: "
                f"{getattr(flow, 'src_ip', '?')}:{getattr(flow, 'src_port', '?')} -> "
                f"{getattr(flow, 'dst_ip', '?')}:{getattr(flow, 'dst_port', '?')}"
            )
            return

        # Log new flow detection periodically (every 100 flows or first 10)
        if self.flow_count <= 10 or self.flow_count % 100 == 0:
            src_ip = getattr(flow, "src_ip", "?")
            dst_ip = getattr(flow, "dst_ip", "?")
            logger.debug(
                f"New flow #{self.flow_count}: {src_ip} -> {dst_ip}, "
                f"total_packets={self.packet_count}"
            )

        # Collect first payload
        self._collect_payload(packet, flow)

        # Check for early SNI-based blocking (may be available in first packet for some protocols)
        self._check_early_sni_block(flow)

    def on_update(self, packet, flow):
        """Called for each packet in the flow."""
        self.packet_count += 1
        self.bytes_count += packet.ip_size

        # Skip if this flow was already processed (re-created after early expiration)
        if getattr(flow.udps, "skip", False):
            return

        # Periodically clean up expired entries from _processed_flows
        # This ensures cleanup runs even when no flows expire (long-lived connections)
        self._maybe_cleanup_processed_flows()

        # If already classified and sent, just let packets flow through
        # This keeps the flow alive in NFStream (and OVS) without re-processing
        if flow.udps.ready:
            return

        # CRITICAL: Check for early SNI-based blocking IMMEDIATELY when SNI is detected
        # This happens BEFORE payload collection and full classification to ensure
        # blocked content is stopped as soon as the TLS ClientHello is parsed.
        # The SNI is typically available in packet 1-2.
        sni = getattr(flow, "requested_server_name", "") or ""
        if sni and not getattr(flow.udps, "sni_logged", False):
            # Log when SNI is first detected
            flow.udps.sni_logged = True
            logger.debug(
                f"SNI detected: {sni} for {getattr(flow, 'src_ip', '?')} -> "
                f"{getattr(flow, 'dst_ip', '?')} at packet {flow.bidirectional_packets}"
            )

        if not getattr(flow.udps, "early_sni_checked", False):
            self._check_early_sni_block(flow)

        # CRITICAL: Check for early app-based policy as soon as app is identified
        # This happens at packet 2-3 typically, BEFORE waiting for 5 packets.
        # Enables near-instant policy enforcement for app-based rules (block/rate-limit).
        if not getattr(flow.udps, "early_app_checked", False):
            self._check_early_app_policy(flow)

        # Collect payload sample
        self._collect_payload(packet, flow)

        # Check if classification is complete
        if not flow.udps.classified:
            app_name = getattr(flow, "application_name", "") or ""
            has_sni = bool(getattr(flow, "requested_server_name", ""))
            has_enough_packets = (
                flow.bidirectional_packets >= self.min_classification_packets
            )
            has_all_payloads = flow.udps.payload_packet_count >= self.num_packets

            # CRITICAL: For TLS/QUIC flows, we MUST wait for SNI before sending to
            # FlowCollector. Otherwise, FlowCollector can't check domain blocklist
            # and might apply rate limiting before blocking is evaluated.
            # We wait up to max_sni_wait_packets for SNI before giving up.
            sni_bearing_apps = {"TLS", "QUIC", "HTTP.S", "HTTPS", "TLS.DoH", "TLS.DoT"}
            app_may_have_sni = (
                app_name in sni_bearing_apps or "TLS" in app_name or "QUIC" in app_name
            )
            max_sni_wait_packets = 10  # Wait up to 10 packets for SNI

            # For TLS/QUIC: require SNI OR wait longer before classifying
            if app_may_have_sni and not has_sni:
                # Still waiting for SNI - don't classify yet unless we've waited long enough
                if flow.bidirectional_packets < max_sni_wait_packets:
                    # Keep waiting for SNI
                    return

            # Classification complete when:
            # 1. Application identified (not empty or Unknown) AND
            # 2. Either has SNI OR seen enough packets
            if app_name and app_name != "Unknown":
                if (has_sni or has_enough_packets) and has_all_payloads:
                    # Log if TLS/QUIC without SNI (unusual - possibly TLS resumption)
                    if app_may_have_sni and not has_sni:
                        logger.debug(
                            f"TLS/QUIC flow classified without SNI after {flow.bidirectional_packets} packets: "
                            f"{getattr(flow, 'src_ip', '?')} -> {getattr(flow, 'dst_ip', '?')}, app={app_name}"
                        )

                    flow.udps.classified = True
                    flow.udps.ready = True
                    # Don't force expiration - let the flow live naturally
                    # This prevents NFStream from creating new flows for the same 5-tuple
                    # Send the flow data now for policy application
                    self._send_classified_flow(flow)

    def _send_classified_flow(self, flow):
        """Send a classified flow for processing (policy application, batching).

        Called when classification is complete, before the flow naturally expires.
        This allows early policy application while keeping the flow alive in NFStream.
        """
        app_name = getattr(flow, "application_name", "Unknown") or "Unknown"
        src_ip = getattr(flow, "src_ip", "?")
        dst_ip = getattr(flow, "dst_ip", "?")
        sni = getattr(flow, "requested_server_name", "") or ""
        early_blocked = getattr(flow.udps, "early_blocked", False)
        early_app_action = getattr(flow.udps, "early_app_action", None)

        logger.debug(
            f"SEND TO COLLECTOR: {src_ip} -> {dst_ip}, app={app_name}, "
            f"sni={sni or 'none'}, early_blocked={early_blocked}, "
            f"early_app_action={early_app_action}, packets={flow.bidirectional_packets}"
        )

        # Preferred path: use multiprocessing queue (process-safe)
        if self.flow_queue is not None and self.flow_converter is not None:
            try:
                flow_data = self.flow_converter(flow)
                if flow_data:
                    self.flow_queue.put(flow_data)
                    # Mark flow as sent so on_expire doesn't resend
                    flow.udps.sent = True
                    logger.debug(
                        f"Flow put on mp queue: {src_ip} -> {dst_ip}, app={app_name}"
                    )
            except Exception as e:
                logger.error(f"Error converting/queuing flow: {e}", exc_info=True)
        # Legacy path: use callback (for backward compatibility)
        elif self.on_flow_ready:
            self.on_flow_ready(flow)
            flow.udps.sent = True

    def on_expire(self, flow):
        """Called when flow expires (idle or active timeout)."""
        # Periodically clean up expired entries from _processed_flows
        self._maybe_cleanup_processed_flows()

        # Skip if this flow was already processed (re-created after early expiration)
        if getattr(flow.udps, "skip", False):
            return

        app_name = getattr(flow, "application_name", "Unknown") or "Unknown"
        src_ip = getattr(flow, "src_ip", "?")
        dst_ip = getattr(flow, "dst_ip", "?")
        sni = getattr(flow, "requested_server_name", "") or ""

        # Mark this flow as processed so we skip re-created flows
        # (in case a new connection starts quickly after this one ends)
        self._mark_flow_processed(flow)

        # If already sent during on_update, don't resend
        if getattr(flow.udps, "sent", False):
            logger.debug(
                f"Flow expired (already sent): {src_ip} -> {dst_ip}, app={app_name}, "
                f"packets={flow.bidirectional_packets}"
            )
            return

        logger.debug(
            f"Flow expired: {src_ip} -> {dst_ip}, app={app_name}, "
            f"sni={sni or 'none'}, packets={flow.bidirectional_packets}"
        )

        # Preferred path: use multiprocessing queue (process-safe)
        if self.flow_queue is not None and self.flow_converter is not None:
            try:
                flow_data = self.flow_converter(flow)
                if flow_data:
                    self.flow_queue.put(flow_data)
                    logger.debug(
                        f"Flow put on mp queue: {src_ip} -> {dst_ip}, app={app_name}"
                    )
            except Exception as e:
                logger.error(f"Error converting/queuing flow: {e}", exc_info=True)
        # Legacy path: use callback (for backward compatibility)
        elif self.on_flow_ready:
            self.on_flow_ready(flow)

    def _collect_payload(self, packet, flow):
        """Collect payload sample from packet."""
        if flow.udps.payload_packet_count >= self.num_packets:
            return

        # Get payload bytes
        payload = b""
        if hasattr(packet, "ip_packet") and packet.ip_packet:
            payload = bytes(packet.ip_packet)

        # Skip empty payloads
        if len(payload) == 0:
            return

        # Extract first num_bytes, pad if needed
        sample = payload[: self.num_bytes]
        if len(sample) < self.num_bytes:
            sample = sample + b"\x00" * (self.num_bytes - len(sample))

        flow.udps.payload_samples.append(sample)
        flow.udps.payload_packet_count += 1


@dataclass
class FlowAction:
    """Result of policy enforcement for a flow."""

    action: str  # "allow", "block", "rate_limit"
    blocked: bool = False
    blocked_via_cache: bool = False
    rate_limited_via_cache: bool = False
    meter_id: Optional[int] = None
    rule_app_name: Optional[str] = None


class FlowCollector:
    """Manages flow data collection, batching, policy enforcement, and IP-to-SNI cache.

    This class:
    1. Receives classified flows from the ClassifierPlugin (via mp queue)
    2. Converts them to ClassifiedFlowData
    3. Checks policy cache for blocklist/rate-limit rules
    4. Installs OVS flow rules (DROP or METER) based on policy
    5. Maintains cached block registry for subsequent flows
    6. Batches flows and sends them at regular intervals

    The flow queue is a multiprocessing.Queue for process-safe IPC between
    NFStream's metering processes and the main sender thread.

    Args:
        on_batch_ready: Callback function when a batch is ready
        batch_interval: Interval in seconds between batch sends (default: 1.0)
        num_bytes: Number of bytes per packet sample (default: 225)
        num_packets: Number of packets per flow (default: 5)
        bridge: OVS bridge name for policy enforcement (optional)
        policy_cache: PolicyCache instance for blocklist/rate-limit lookup (optional)
        ovs_worker: Optional OVSActionWorker for async policy enforcement
        use_async_ovs: If True, create and use OVSActionWorker for async operations
    """

    def __init__(
        self,
        on_batch_ready: Callable[[list[ClassifiedFlowData]], None],
        batch_interval: float = DEFAULT_BATCH_INTERVAL,
        num_bytes: int = DEFAULT_NUM_BYTES,
        num_packets: int = DEFAULT_NUM_PACKETS,
        bridge: Optional[str] = None,
        policy_cache: Optional["PolicyCache"] = None,
        ovs_worker: Optional["OVSActionWorker"] = None,
        use_async_ovs: bool = True,
        install_normal_flows: bool = True,
        hostname_resolver=None,
        allow_public_to_public: bool = False,
    ):
        self.on_batch_ready = on_batch_ready
        self.batch_interval = batch_interval
        self.num_bytes = num_bytes
        self.num_packets = num_packets
        self.bridge = bridge
        self.policy_cache = policy_cache
        self.use_async_ovs = use_async_ovs
        self.install_normal_flows = install_normal_flows
        self.hostname_resolver = hostname_resolver
        self.allow_public_to_public = allow_public_to_public
        self.classification_registry = None

        # OVS Action Worker for async policy enforcement
        # Create one if not provided and async is enabled
        if ovs_worker is not None:
            self.ovs_worker = ovs_worker
            self._owns_worker = False  # Don't manage lifecycle
        elif use_async_ovs and bridge is not None:
            self.ovs_worker = OVSActionWorker(
                bridge=bridge,
                batch_size=50,
                max_wait_ms=10,
                policy_cache=policy_cache,
            )
            self._owns_worker = True  # We created it, we manage lifecycle
        else:
            self.ovs_worker = None
            self._owns_worker = False

        # Flow queue for batch processing (multiprocessing.Queue for process-safe IPC)
        self._flow_queue: MPQueue = MPQueue()

        # IP-to-SNI cache: maps (vlan_id, destination IP) -> (sni, last_seen_timestamp)
        # Expires after DEFAULT_BLOCK_CACHE_TTL (300 seconds) of inactivity
        self._ip_to_sni_cache: dict[tuple[int, str], tuple[str, float]] = {}
        # IP-to-app cache: maps (vlan_id, destination IP) -> (app_name, last_seen)
        # Used to apply policy when a generic protocol flow goes to a known app IP
        # Expires after DEFAULT_BLOCK_CACHE_TTL (300 seconds) of inactivity
        self._ip_to_app_cache: dict[tuple[int, str], tuple[str, float]] = {}
        self._cache_lock = threading.Lock()

        # Classification cache: maps server endpoint -> classification info
        # Used to reuse classification and cookies for subsequent flows to the same server
        # when NFStream can't classify (e.g., TLS resumption, cached DNS)
        # Key: (dst_ip, dst_port, vlan_id)
        # Value: (app_name, cookie, classification_id, last_seen_sec, idle_timeout_sec)
        # Expires when now - last_seen >= idle_timeout
        self._classification_cache: dict[tuple, tuple[str, int, int, float, int]] = {}

        # Classification cache cleanup scheduling
        self._cleanup_interval = 60.0  # seconds between cleanup runs
        self._last_cleanup = time.time()

        # Batch sender thread
        self._running = False
        self._sender_thread: Optional[threading.Thread] = None

        # Statistics
        self.total_flows = 0
        self.total_packets = 0
        self.total_bytes = 0
        self.blocked_flows = 0
        self.rate_limited_flows = 0
        self.normal_flows = 0
        self.cached_blocked_flows = 0
        self.cached_rate_limited_flows = 0

    @property
    def policy_enabled(self) -> bool:
        """Check if policy enforcement is enabled."""
        return self.bridge is not None and self.policy_cache is not None

    def get_queue(self) -> MPQueue:
        """Get the multiprocessing queue for plugin to write to.

        This queue is process-safe and can be shared with NFStream's
        metering processes.

        Returns:
            The multiprocessing.Queue instance
        """
        return self._flow_queue

    def get_flow_converter(self) -> Callable[[object], Optional[ClassifiedFlowData]]:
        """Get the flow conversion function for plugin to use.

        This function converts NFStream flow objects to ClassifiedFlowData,
        handling IP orientation, SNI caching, and payload extraction.

        Returns:
            The _convert_flow method bound to this instance
        """
        return self._convert_flow

    def get_ovs_worker(self) -> Optional["OVSActionWorker"]:
        """Get the OVS action worker for use by ClassifierPlugin.

        Returns:
            The OVSActionWorker instance, or None if async OVS is not enabled
        """
        return self.ovs_worker

    def start(self):
        """Start the batch sender thread and OVS worker if enabled."""
        # Start OVS worker first (if we own it)
        if self._owns_worker and self.ovs_worker:
            self.ovs_worker.start()
            logger.info("OVS action worker started (async mode)")

        self._running = True
        self._sender_thread = threading.Thread(target=self._batch_sender, daemon=True)
        self._sender_thread.start()
        logger.info("FlowCollector batch sender started")
        if self.policy_enabled:
            logger.info(f"Policy enforcement enabled on bridge: {self.bridge}")
            if self.ovs_worker:
                logger.info("Using async OVS worker for early policy enforcement")

    def stop(self):
        """Stop the batch sender thread and OVS worker."""
        self._running = False
        if self._sender_thread:
            self._sender_thread.join(timeout=2.0)
        logger.info("FlowCollector batch sender stopped")

        # Stop OVS worker (if we own it)
        if self._owns_worker and self.ovs_worker:
            self.ovs_worker.stop()
            logger.info("OVS action worker stopped")

        if self.policy_enabled:
            logger.info(
                f"Blocked flows: {self.blocked_flows}, Rate limited: {self.rate_limited_flows}"
            )

    def add_flow(self, flow) -> Optional[ClassifiedFlowData]:
        """Add a flow to the collection queue (legacy method).

        NOTE: This method is for backward compatibility with the callback-based
        flow processing model. The preferred approach is to use the multiprocessing
        queue directly via get_queue() and get_flow_converter().

        Args:
            flow: NFStream flow object

        Returns:
            ClassifiedFlowData if conversion successful, None otherwise
        """
        try:
            flow_data = self._convert_flow(flow)
            if flow_data:
                # Add to batch queue (policy is applied in _batch_sender)
                self._flow_queue.put(flow_data)
                logger.debug(
                    f"Flow added to queue (legacy): {flow_data.src_ip}:{flow_data.src_port} -> "
                    f"{flow_data.dst_ip}:{flow_data.dst_port}"
                )
                return flow_data
            else:
                logger.debug(
                    "Flow conversion returned None (no payloads or not private IP)"
                )
        except Exception as e:
            logger.error(f"Error converting flow: {e}", exc_info=True)
        return None

    @staticmethod
    def _vlan_ip_cache_key(vlan_id: int, dst_ip: str) -> tuple[int, str]:
        """Build a VLAN-aware cache key for destination-IP caches."""
        return (vlan_id or 0, dst_ip)

    def get_ip_to_sni_cache(self) -> dict[tuple[int, str], str]:
        """Get a copy of the IP-to-SNI cache ((vlan_id, IP) -> SNI string)."""
        with self._cache_lock:
            return {
                cache_key: sni
                for cache_key, (sni, _) in self._ip_to_sni_cache.items()
            }

    def _convert_flow(self, flow) -> Optional[ClassifiedFlowData]:
        """Convert an NFStream flow to ClassifiedFlowData."""
        # Skip flows without payloads
        if not hasattr(flow, "udps") or not hasattr(flow.udps, "payload_samples"):
            logger.debug(
                f"Skipping flow {flow.src_ip} -> {flow.dst_ip}: no udps/payload_samples attr"
            )
            return None

        payload_samples = flow.udps.payload_samples
        if not payload_samples:
            logger.debug(
                f"Skipping flow {flow.src_ip} -> {flow.dst_ip}: empty payload_samples"
            )
            return None

        # Determine client (private IP) orientation
        src_is_client = self._is_private_ip(flow.src_ip)
        dst_is_client = self._is_private_ip(flow.dst_ip)

        public_to_public = False

        # Skip LAN-to-LAN or WAN-to-WAN traffic unless EE explicitly
        # opts into globally-routable public-to-public monitoring.
        if src_is_client == dst_is_client:
            public_to_public = (
                self.allow_public_to_public
                and not src_is_client
                and _is_global_public_ip(flow.src_ip)
                and _is_global_public_ip(flow.dst_ip)
            )
            if public_to_public:
                logger.debug(
                    f"Accepting public-to-public flow: "
                    f"{flow.src_ip} -> {flow.dst_ip}"
                )
            else:
                logger.debug(
                    f"Skipping flow {flow.src_ip} -> {flow.dst_ip}: "
                    f"both {'private' if src_is_client else 'public'} IPs"
                )
                return None

        # Orient flow: client is always src. For EE public-to-public
        # monitoring, preserve NFStream source orientation as client identity.
        if public_to_public:
            src_ip = flow.src_ip
            dst_ip = flow.dst_ip
            src_port = flow.src_port
            dst_port = flow.dst_port
            src_mac = flow.src_mac
            dst_mac = flow.dst_mac
            src2dst_packets = flow.src2dst_packets
            dst2src_packets = flow.dst2src_packets
            src2dst_bytes = flow.src2dst_bytes
            dst2src_bytes = flow.dst2src_bytes
        elif src_is_client:
            src_ip = flow.src_ip
            dst_ip = flow.dst_ip
            src_port = flow.src_port
            dst_port = flow.dst_port
            src_mac = flow.src_mac
            dst_mac = flow.dst_mac
            src2dst_packets = flow.src2dst_packets
            dst2src_packets = flow.dst2src_packets
            src2dst_bytes = flow.src2dst_bytes
            dst2src_bytes = flow.dst2src_bytes
        else:
            # Swap orientation
            src_ip = flow.dst_ip
            dst_ip = flow.src_ip
            src_port = flow.dst_port
            dst_port = flow.src_port
            src_mac = flow.dst_mac
            dst_mac = flow.src_mac
            src2dst_packets = flow.dst2src_packets
            dst2src_packets = flow.src2dst_packets
            src2dst_bytes = flow.dst2src_bytes
            dst2src_bytes = flow.src2dst_bytes

        vlan_id, vlan_source = inspect_vlan_info(flow)

        # Get SNI and update cache
        sni = getattr(flow, "requested_server_name", "") or ""
        sni_source = "direct"
        sni_cache_key = self._vlan_ip_cache_key(vlan_id, dst_ip)

        with self._cache_lock:
            if sni:
                # Update cache with new SNI and timestamp
                self._ip_to_sni_cache[sni_cache_key] = (sni, time.time())
            else:
                # Try to get from cache
                cached_entry = self._ip_to_sni_cache.get(sni_cache_key)
                if cached_entry:
                    sni = cached_entry[0]
                    sni_source = "cached"
                else:
                    sni = dst_ip
                    sni_source = "ip"

        # Generate flow ID
        flow_key = (
            src_ip,
            dst_ip,
            str(src_port),
            str(dst_port),
            "TCP" if flow.protocol == 6 else "UDP",
            src_mac,
        )
        flow_id = self._generate_flow_id(flow_key)

        # Flatten payload samples
        payload_sample = b"".join(payload_samples)

        # Get application name and generate cookie with classification tracking
        app_name = getattr(flow, "application_name", "Unknown") or "Unknown"
        flow_tuple = (src_ip, dst_ip, src_port, dst_port)

        # Use NFStream's first-seen timestamp for stable cookie generation
        # This ensures the same flow gets the same cookie throughout its lifetime
        flow_first_seen_ms = getattr(flow, "bidirectional_first_seen_ms", 0) or 0
        if vlan_id > 0:
            flow_tuple = (*flow_tuple, vlan_id)
        _log_vlan_debug(
            "convert_flow",
            src_ip,
            src_port,
            dst_ip,
            dst_port,
            flow.protocol == 6,
            vlan_id,
            vlan_source,
            app_name,
        )

        openflow_cookie, classification_id, normalized_app_name = generate_flow_cookie(
            app_name,
            flow_tuple,
            timestamp_ms=flow_first_seen_ms if flow_first_seen_ms else None,
        )

        # Check if early policy was applied in ClassifierPlugin
        early_blocked = getattr(flow.udps, "early_blocked", False)
        early_app_action = getattr(flow.udps, "early_app_action", None)
        policy_applied = early_blocked or early_app_action is not None

        # Look up client device hostname
        src_hostname = ""
        if self.hostname_resolver is not None:
            try:
                src_hostname = self.hostname_resolver.lookup(src_mac)
            except Exception:
                pass

        return ClassifiedFlowData(
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            src_mac=src_mac,
            dst_mac=dst_mac,
            is_tcp=(flow.protocol == 6),
            payload_sample=payload_sample,
            payload_packet_count=flow.udps.payload_packet_count,
            flow_id=flow_id,
            application_name=app_name,
            application_category=getattr(flow, "application_category_name", "Unknown")
            or "Unknown",
            application_confidence=getattr(flow, "application_confidence", 0) or 0,
            requested_server_name=sni,
            client_fingerprint=getattr(flow, "client_fingerprint", "") or "",
            server_fingerprint=getattr(flow, "server_fingerprint", "") or "",
            bidirectional_packets=flow.bidirectional_packets,
            bidirectional_bytes=flow.bidirectional_bytes,
            bidirectional_duration_ms=flow.bidirectional_duration_ms,
            src2dst_packets=src2dst_packets,
            dst2src_packets=dst2src_packets,
            src2dst_bytes=src2dst_bytes,
            dst2src_bytes=dst2src_bytes,
            sni_source=sni_source,
            flow_first_seen_ms=flow_first_seen_ms,
            vlan_id=vlan_id,
            vlan_source=vlan_source,
            openflow_cookie=openflow_cookie,
            classification_id=classification_id,
            normalized_app_name=normalized_app_name,
            src_hostname=src_hostname,
            policy_applied=policy_applied,
            early_action=(
                early_app_action
                if early_app_action
                else ("block" if early_blocked else None)
            ),
        )

    def _extract_app_name(self, app_name: str) -> str:
        """Extract the base application name from a protocol-prefixed name.

        E.g., "QUIC.Instagram" -> "Instagram", "TLS.Facebook" -> "Facebook"

        Args:
            app_name: Full application name from NFStream

        Returns:
            Base application name (part after the dot, or original if no dot)
        """
        if "." in app_name:
            _, sub_proto = app_name.split(".", 1)
            return sub_proto
        return app_name

    def _cache_app_for_ip(
        self, dst_ip: str, app_name: str, vlan_id: int = 0
    ) -> None:
        """Cache the application name for a destination IP.

        Only caches non-generic applications (e.g., Instagram, YouTube).
        Entry expires after DEFAULT_BLOCK_CACHE_TTL (300s) of inactivity.

        Args:
            dst_ip: Destination IP address
            app_name: Application name from NFStream
            vlan_id: 802.1Q VLAN ID, or 0 for untagged/unknown
        """
        if not is_generic_protocol(app_name):
            base_app = self._extract_app_name(app_name)
            cache_key = self._vlan_ip_cache_key(vlan_id, dst_ip)
            with self._cache_lock:
                self._ip_to_app_cache[cache_key] = (base_app, time.time())
                logger.debug(
                    f"Cached app for IP: vlan={vlan_id} {dst_ip} -> {base_app}"
                )

    def _get_cached_app_for_ip(
        self, dst_ip: str, vlan_id: int = 0
    ) -> Optional[str]:
        """Get the cached application name for a destination IP.

        Returns None if expired (older than DEFAULT_BLOCK_CACHE_TTL).
        Updates last_seen on successful lookup.

        Args:
            dst_ip: Destination IP address
            vlan_id: 802.1Q VLAN ID, or 0 for untagged/unknown

        Returns:
            Cached application name, or None if not cached or expired
        """
        cache_key = self._vlan_ip_cache_key(vlan_id, dst_ip)
        with self._cache_lock:
            entry = self._ip_to_app_cache.get(cache_key)
            if entry is None:
                return None

            app_name, last_seen = entry
            elapsed = time.time() - last_seen

            # Check if expired
            if elapsed >= DEFAULT_BLOCK_CACHE_TTL:
                del self._ip_to_app_cache[cache_key]
                return None

            # Update last_seen to keep entry alive
            self._ip_to_app_cache[cache_key] = (app_name, time.time())
            return app_name

    def _get_cached_classification(
        self, dst_ip: str, dst_port: int, vlan_id: int = 0
    ) -> Optional[tuple[str, int, int]]:
        """Get cached classification for a server endpoint if one exists and hasn't expired.

        Used to reuse classification and cookie when NFStream can't classify
        a subsequent flow to the same server (e.g., TLS resumption).

        Args:
            dst_ip: Destination IP address
            dst_port: Destination port
            vlan_id: 802.1Q VLAN ID, or 0 for untagged/unknown

        Returns:
            Tuple of (app_name, cookie, classification_id) if valid, None otherwise
        """
        cache_key = (dst_ip, dst_port, vlan_id)
        with self._cache_lock:
            if cache_key not in self._classification_cache:
                return None

            app_name, cookie, classification_id, last_seen, idle_timeout = (
                self._classification_cache[cache_key]
            )
            elapsed = time.time() - last_seen

            # If expired, remove from cache
            if elapsed >= idle_timeout:
                del self._classification_cache[cache_key]
                return None

            # Update last_seen to keep the cache entry alive
            self._classification_cache[cache_key] = (
                app_name,
                cookie,
                classification_id,
                time.time(),
                idle_timeout,
            )

            logger.debug(
                f"Reusing cached classification for {dst_ip}:{dst_port} "
                f"vlan={vlan_id}: app={app_name}, cookie=0x{cookie:016x}"
            )
            return (app_name, cookie, classification_id)

    def _cache_classification(
        self,
        dst_ip: str,
        dst_port: int,
        app_name: str,
        cookie: int,
        classification_id: int,
        idle_timeout: int,
        vlan_id: int = 0,
    ) -> None:
        """Cache classification info for a server endpoint.

        Only caches non-generic classifications (e.g., TLS.Instagram, not TLS).
        Generic protocols provide no useful info for future lookups.

        Sets last_seen to current time. Entry expires when idle for idle_timeout.

        Args:
            dst_ip: Destination IP address
            dst_port: Destination port
            app_name: Classified application name
            cookie: The 64-bit OpenFlow cookie
            classification_id: The 32-bit classification hash
            idle_timeout: How long to cache (typically OVS idle timeout)
            vlan_id: 802.1Q VLAN ID, or 0 for untagged/unknown
        """
        if is_generic_protocol(app_name):
            logger.debug(
                f"Skipping cache for generic protocol {app_name} "
                f"at {dst_ip}:{dst_port}"
            )
            return

        cache_key = (dst_ip, dst_port, vlan_id)
        with self._cache_lock:
            self._classification_cache[cache_key] = (
                app_name,
                cookie,
                classification_id,
                time.time(),
                idle_timeout,
            )
            logger.debug(
                f"Cached classification for {dst_ip}:{dst_port} vlan={vlan_id}: "
                f"app={app_name}, cookie=0x{cookie:016x}"
            )

    def _refresh_flow_classification_metadata(
        self, flow_data: ClassifiedFlowData, app_name: str
    ) -> None:
        """Update flow metadata after resolving a generic protocol to an app."""
        flow_tuple = (
            flow_data.src_ip,
            flow_data.dst_ip,
            flow_data.src_port,
            flow_data.dst_port,
        )
        if flow_data.vlan_id > 0:
            flow_tuple = (*flow_tuple, flow_data.vlan_id)

        cookie, classification_id, normalized_app_name = generate_flow_cookie(
            app_name,
            flow_tuple,
            timestamp_ms=flow_data.flow_first_seen_ms or None,
        )
        flow_data.application_name = app_name
        flow_data.openflow_cookie = cookie
        flow_data.classification_id = classification_id
        flow_data.normalized_app_name = normalized_app_name

    def _cleanup_expired_classifications(self) -> None:
        """Remove expired entries from the classification cache.

        Entries expire when now - last_seen >= idle_timeout.
        """
        now = time.time()
        with self._cache_lock:
            expired_keys = [
                key
                for key, (
                    _,
                    _,
                    _,
                    last_seen,
                    idle_timeout,
                ) in self._classification_cache.items()
                if now - last_seen >= idle_timeout
            ]
            for key in expired_keys:
                del self._classification_cache[key]

    def _cleanup_expired_ip_to_app_cache(self) -> None:
        """Remove expired entries from the IP-to-app cache.

        Entries expire after DEFAULT_BLOCK_CACHE_TTL seconds of inactivity.
        """
        now = time.time()
        with self._cache_lock:
            expired_keys = [
                cache_key
                for cache_key, (_, last_seen) in self._ip_to_app_cache.items()
                if now - last_seen >= DEFAULT_BLOCK_CACHE_TTL
            ]
            for cache_key in expired_keys:
                del self._ip_to_app_cache[cache_key]

    def _cleanup_expired_ip_to_sni_cache(self) -> None:
        """Remove expired entries from the IP-to-SNI cache.

        Entries expire after DEFAULT_BLOCK_CACHE_TTL seconds of inactivity.
        """
        now = time.time()
        with self._cache_lock:
            expired_keys = [
                cache_key
                for cache_key, (_, last_seen) in self._ip_to_sni_cache.items()
                if now - last_seen >= DEFAULT_BLOCK_CACHE_TTL
            ]
            for cache_key in expired_keys:
                del self._ip_to_sni_cache[cache_key]

    def _check_domain_blocklist(
        self, flow_data: ClassifiedFlowData
    ) -> Optional[FlowAction]:
        """Check if flow matches domain blocklist or URL block rules.

        Checks block_list_domain and url_block rules against the flow's SNI.
        Installs DROP flows and registers cached blocks if matched.

        Args:
            flow_data: Classified flow data

        Returns:
            FlowAction if blocked, None otherwise
        """
        sni = flow_data.requested_server_name
        if not sni:
            # Log TLS/QUIC flows without SNI - these can't be checked against blocklist
            app_name = flow_data.application_name
            if app_name and ("TLS" in app_name or "QUIC" in app_name):
                logger.info(
                    f"COLLECTOR NO SNI: {flow_data.src_ip} -> {flow_data.dst_ip}, "
                    f"app={app_name} - cannot check domain blocklist"
                )
            return None

        src_ip = flow_data.src_ip
        dst_ip = flow_data.dst_ip
        src_port = flow_data.src_port
        dst_port = flow_data.dst_port
        is_tcp = flow_data.is_tcp

        # Check block list (domain)
        blocked, info = self.policy_cache.check_block_list_domain(sni)
        if blocked:
            priority = info.get("priority", 7000)
            rule_label = f"blocklist:{info.get('name', 'unknown')}"
            _log_vlan_debug(
                "collector_domain_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                flow_data.vlan_id,
                flow_data.vlan_source,
                rule_label,
            )
            success_fwd, success_rev, _ = install_bidirectional_drop(
                self.bridge,
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                rule_label,
                priority,
                DEFAULT_BLOCK_CACHE_TTL,
                timestamp_ms=flow_data.flow_first_seen_ms or None,
                cookie=None,
                vlan_id=flow_data.vlan_id,
            )
            if not success_fwd or not success_rev:
                logger.warning(f"Failed to install DROP flows for {rule_label}")
            if is_private_ip(src_ip):
                self.policy_cache.register_cached_block(
                    src_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                )
            if is_private_ip(dst_ip):
                self.policy_cache.register_cached_block(
                    dst_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                )
            logger.info(
                f"BLOCKED: {rule_label} - {sni} - {src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            return FlowAction(
                action="block",
                blocked=True,
                blocked_via_cache=False,
                rule_app_name=info.get("name", "unknown"),
            )

        # Check URL block rules
        blocked, info = self.policy_cache.check_url_block(sni)
        if blocked:
            priority = info.get("priority", 7000)
            rule_label = f"urlblock:{info.get('rule_id', '')}"
            _log_vlan_debug(
                "collector_url_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                flow_data.vlan_id,
                flow_data.vlan_source,
                rule_label,
            )
            success_fwd, success_rev, _ = install_bidirectional_drop(
                self.bridge,
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                rule_label,
                priority,
                DEFAULT_BLOCK_CACHE_TTL,
                timestamp_ms=flow_data.flow_first_seen_ms or None,
                cookie=None,
                vlan_id=flow_data.vlan_id,
            )
            if not success_fwd or not success_rev:
                logger.warning(f"Failed to install DROP flows for {rule_label}")
            if is_private_ip(src_ip):
                self.policy_cache.register_cached_block(
                    src_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                )
            if is_private_ip(dst_ip):
                self.policy_cache.register_cached_block(
                    dst_ip, sni, rule_label, DEFAULT_BLOCK_CACHE_TTL
                )
            logger.info(
                f"BLOCKED: {rule_label} - {sni} - {src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            return FlowAction(
                action="block",
                blocked=True,
                blocked_via_cache=False,
                rule_app_name=rule_label,
            )

        return None

    def _check_app_blocklist(
        self,
        flow_data: ClassifiedFlowData,
        effective_app_name: str,
    ) -> Optional[FlowAction]:
        """Check if flow matches app blocklist rules.

        Installs DROP flows, caches classification, and registers cached blocks.

        Args:
            flow_data: Classified flow data
            effective_app_name: App name to check (may be from cache)

        Returns:
            FlowAction if blocked, None otherwise
        """
        src_ip = flow_data.src_ip
        dst_ip = flow_data.dst_ip
        src_port = flow_data.src_port
        dst_port = flow_data.dst_port
        is_tcp = flow_data.is_tcp
        sni = flow_data.requested_server_name
        sni_source = flow_data.sni_source
        cache_destination = sni if sni and sni_source == "direct" else dst_ip

        block_rule = self.policy_cache.is_blocked(
            effective_app_name,
            src_mac=flow_data.src_mac,
            dst_mac=flow_data.dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
        )
        if not block_rule:
            return None

        # Cache the app name for this VLAN/IP for future generic protocol flows
        self._cache_app_for_ip(dst_ip, effective_app_name, flow_data.vlan_id)

        # Install bidirectional DROP flows (use cached cookie if available)
        _log_vlan_debug(
            "collector_app_drop",
            src_ip,
            src_port,
            dst_ip,
            dst_port,
            is_tcp,
            flow_data.vlan_id,
            flow_data.vlan_source,
            effective_app_name,
        )
        success_fwd, success_rev, cookie_used = install_bidirectional_drop(
            self.bridge,
            src_ip,
            src_port,
            dst_ip,
            dst_port,
            is_tcp,
            effective_app_name,
            block_rule.priority,
            block_rule.idle_timeout,
            timestamp_ms=flow_data.flow_first_seen_ms or None,
            vlan_id=flow_data.vlan_id,
        )

        if not success_fwd or not success_rev:
            logger.warning(f"Failed to install DROP flows for {effective_app_name}")
        else:
            # Cache classification for future flows to same server
            classification_id = flow_data.classification_id or (
                cookie_used & 0xFFFFFFFF
            )
            self._cache_classification(
                dst_ip,
                dst_port,
                effective_app_name,
                cookie_used,
                classification_id,
                block_rule.idle_timeout,
                flow_data.vlan_id,
            )

        # Register in cached block registry
        if is_private_ip(src_ip):
            self.policy_cache.register_cached_block(
                src_ip,
                cache_destination,
                effective_app_name,
                DEFAULT_BLOCK_CACHE_TTL,
            )
        if is_private_ip(dst_ip):
            external_dest = sni if sni else src_ip
            self.policy_cache.register_cached_block(
                dst_ip, external_dest, effective_app_name, DEFAULT_BLOCK_CACHE_TTL
            )

        logger.info(
            f"BLOCKED: {effective_app_name} - {src_ip}:{src_port} -> {dst_ip}:{dst_port}"
        )
        return FlowAction(
            action="block",
            blocked=True,
            blocked_via_cache=False,
            rule_app_name=block_rule.app_name,
        )

    def _check_rate_limit(
        self,
        flow_data: ClassifiedFlowData,
        effective_app_name: str,
    ) -> Optional[FlowAction]:
        """Check if flow matches rate limit rules.

        Resolves meter_id, installs METER flows, caches classification,
        and registers cached meters.

        Args:
            flow_data: Classified flow data
            effective_app_name: App name to check (may be from cache)

        Returns:
            FlowAction if rate limited, None otherwise
        """
        src_ip = flow_data.src_ip
        dst_ip = flow_data.dst_ip
        src_port = flow_data.src_port
        dst_port = flow_data.dst_port
        is_tcp = flow_data.is_tcp
        sni = flow_data.requested_server_name
        sni_source = flow_data.sni_source
        cache_destination = sni if sni and sni_source == "direct" else dst_ip

        rate_rule = self.policy_cache.get_rate_limit(
            effective_app_name,
            src_mac=flow_data.src_mac,
            dst_mac=flow_data.dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
        )
        if not rate_rule:
            return None

        # Log when FlowCollector is about to apply rate limiting
        logger.debug(
            f"COLLECTOR RATE LIMIT: {effective_app_name} {src_ip}:{src_port} -> "
            f"{dst_ip}:{dst_port}, sni={sni or 'none'}, meter_id={rate_rule.meter_id}"
        )

        # Cache the app name for this VLAN/IP for future generic protocol flows
        self._cache_app_for_ip(dst_ip, effective_app_name, flow_data.vlan_id)

        # Resolve meter_id - if 0, look up by rate in OVS
        meter_id = rate_rule.meter_id
        if meter_id == 0:
            logger.info(
                f"Rate limit rule has meter_id=0, looking up meter by rate "
                f"({rate_rule.rate_kbps} kbps) in OVS"
            )
            found_meter = find_meter_by_rate_in_ovs(self.bridge, rate_rule.rate_kbps)
            if found_meter:
                meter_id = found_meter
                logger.info(f"Found meter {meter_id} with rate {rate_rule.rate_kbps}")
                # Update the database with the correct meter_id
                self.policy_cache.update_rate_limit_meter_id(
                    rate_rule.app_name, meter_id
                )
            else:
                logger.warning(
                    f"No meter found with rate {rate_rule.rate_kbps} kbps, "
                    f"cannot apply rate limit for {effective_app_name}"
                )
                return None  # Return None to allow _apply_policy to continue

        # Install bidirectional METER flows (use cached cookie if available)
        _log_vlan_debug(
            "collector_app_meter",
            src_ip,
            src_port,
            dst_ip,
            dst_port,
            is_tcp,
            flow_data.vlan_id,
            flow_data.vlan_source,
            effective_app_name,
        )
        success_fwd, success_rev, cookie_used = install_bidirectional_meter(
            self.bridge,
            src_ip,
            src_port,
            dst_ip,
            dst_port,
            is_tcp,
            meter_id,
            effective_app_name,
            rate_rule.priority,
            rate_rule.idle_timeout,
            timestamp_ms=flow_data.flow_first_seen_ms or None,
            vlan_id=flow_data.vlan_id,
        )

        if not success_fwd or not success_rev:
            logger.warning(f"Failed to install METER flows for {effective_app_name}")
        else:
            # Cache classification for future flows to same server
            classification_id = flow_data.classification_id or (
                cookie_used & 0xFFFFFFFF
            )
            self._cache_classification(
                dst_ip,
                dst_port,
                effective_app_name,
                cookie_used,
                classification_id,
                rate_rule.idle_timeout,
                flow_data.vlan_id,
            )

        # Register in cached meter registry (use resolved meter_id)
        # Skip caching for generic protocols - only cache meters with
        # specific app identification to keep the cache meaningful
        if not is_generic_protocol(effective_app_name):
            if is_private_ip(src_ip):
                self.policy_cache.register_cached_meter(
                    src_ip,
                    cache_destination,
                    meter_id,
                    rate_rule.rate_kbps,
                    effective_app_name,
                    DEFAULT_BLOCK_CACHE_TTL,
                )
            if is_private_ip(dst_ip):
                external_dest = sni if sni else src_ip
                self.policy_cache.register_cached_meter(
                    dst_ip,
                    external_dest,
                    meter_id,
                    rate_rule.rate_kbps,
                    effective_app_name,
                    DEFAULT_BLOCK_CACHE_TTL,
                )

        logger.debug(
            f"RATE LIMITED: {effective_app_name} - {src_ip}:{src_port} -> "
            f"{dst_ip}:{dst_port} (meter={meter_id})"
        )
        return FlowAction(
            action="rate_limit",
            meter_id=meter_id,
            rule_app_name=rate_rule.app_name,
        )

    def _check_cached_policies(
        self,
        flow_data: ClassifiedFlowData,
        app_name: str,
    ) -> Optional[FlowAction]:
        """Check cached blocks and meters for generic protocol flows.

        Only applies when sni_source is "cached" and app is generic protocol.
        This prevents blocking/limiting the wrong service on shared CDN IPs.

        Args:
            flow_data: Classified flow data
            app_name: Original app name (not effective)

        Returns:
            FlowAction if cached policy matched, None otherwise
        """
        sni_source = flow_data.sni_source
        if sni_source != "cached" or not is_generic_protocol(app_name):
            return None

        src_ip = flow_data.src_ip
        dst_ip = flow_data.dst_ip
        src_port = flow_data.src_port
        dst_port = flow_data.dst_port
        is_tcp = flow_data.is_tcp
        sni = flow_data.requested_server_name
        cache_destination = sni if sni and sni_source == "direct" else dst_ip

        src_is_private = is_private_ip(src_ip)
        dst_is_private = is_private_ip(dst_ip)

        # Check cached blocks
        should_block = False
        if src_is_private:
            block_check, _ = self.policy_cache.check_cached_block(
                src_ip, cache_destination
            )
            if block_check:
                should_block = True

        if not should_block and dst_is_private:
            external_dest = sni if sni else src_ip
            block_check, _ = self.policy_cache.check_cached_block(dst_ip, external_dest)
            if block_check:
                should_block = True

        if should_block:
            # Use resolved app name from flow_data (may have been enriched
            # from cache in _apply_policy) instead of the raw generic protocol
            resolved_name = flow_data.application_name

            # Install DROP flows based on cached block
            _log_vlan_debug(
                "collector_cached_drop",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                flow_data.vlan_id,
                flow_data.vlan_source,
                resolved_name,
            )
            success_fwd, success_rev, _ = install_bidirectional_drop(
                self.bridge,
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                resolved_name,
                6000,
                DEFAULT_BLOCK_CACHE_TTL,
                timestamp_ms=flow_data.flow_first_seen_ms or None,
                vlan_id=flow_data.vlan_id,
            )

            if not success_fwd or not success_rev:
                logger.warning(
                    f"Failed to install cached DROP flows for {resolved_name}"
                )

            logger.info(
                f"BLOCKED (cached): {resolved_name} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            return FlowAction(
                action="block",
                blocked=True,
                blocked_via_cache=True,
                rule_app_name=resolved_name,
            )

        # Check cached meters
        meter_id = None

        if src_is_private:
            _, meter_id, _ = self.policy_cache.check_cached_meter(
                src_ip, cache_destination
            )

        if not meter_id and dst_is_private:
            external_dest = sni if sni else src_ip
            _, meter_id, _ = self.policy_cache.check_cached_meter(dst_ip, external_dest)

        if meter_id is not None:
            resolved_name = flow_data.application_name

            # Install METER flows based on cached meter
            _log_vlan_debug(
                "collector_cached_meter",
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                flow_data.vlan_id,
                flow_data.vlan_source,
                resolved_name,
            )
            success_fwd, success_rev, _ = install_bidirectional_meter(
                self.bridge,
                src_ip,
                src_port,
                dst_ip,
                dst_port,
                is_tcp,
                meter_id,
                resolved_name,
                5000,
                DEFAULT_BLOCK_CACHE_TTL,
                timestamp_ms=flow_data.flow_first_seen_ms or None,
                vlan_id=flow_data.vlan_id,
            )

            if not success_fwd or not success_rev:
                logger.warning(
                    f"Failed to install cached METER flows for {resolved_name}"
                )

            logger.debug(
                f"RATE LIMITED (cached): {resolved_name} - "
                f"{src_ip}:{src_port} -> {dst_ip}:{dst_port} (meter={meter_id})"
            )
            return FlowAction(
                action="rate_limit",
                rate_limited_via_cache=True,
                meter_id=meter_id,
                rule_app_name=resolved_name,
            )

        return None

    def _apply_policy(self, flow_data: ClassifiedFlowData) -> FlowAction:
        """Apply policy rules to a flow and install OVS flow rules if needed.

        Dispatcher that sequentially checks policy rules in priority order:
        1. Domain blocklist and URL block rules (SNI-based)
        2. App blocklist rules
        3. Rate limit rules
        4. Cached blocks/meters (for generic protocols only)

        Args:
            flow_data: Classified flow data

        Returns:
            FlowAction indicating what action was taken
        """
        if not self.policy_enabled:
            logger.debug("Policy enforcement not enabled, allowing flow")
            return FlowAction(action="allow")

        app_name = flow_data.application_name
        dst_ip = flow_data.dst_ip
        dst_port = flow_data.dst_port

        # Step 1: Check domain blocklist and URL block rules (requires SNI)
        action = self._check_domain_blocklist(flow_data)
        if action:
            return action

        # Resolve effective app name for generic protocols
        # This handles TLS resumption, cached DNS, etc.
        effective_app_name = app_name

        if is_generic_protocol(app_name):
            # First try the classification cache. Reuse only the app identity;
            # each concrete OpenFlow rule still needs its own per-tuple cookie.
            cached = self._get_cached_classification(
                dst_ip, dst_port, flow_data.vlan_id
            )
            if cached:
                effective_app_name, _, _ = cached
                logger.debug(
                    f"Using cached classification for {dst_ip}:{dst_port}: "
                    f"{effective_app_name} (original: {app_name})"
                )
            else:
                # Fall back to VLAN/IP app cache (legacy, no cookie)
                cached_app = self._get_cached_app_for_ip(
                    dst_ip, flow_data.vlan_id
                )
                if cached_app:
                    effective_app_name = cached_app
                    logger.debug(
                        f"Using cached app name for {dst_ip} "
                        f"vlan={flow_data.vlan_id}: {cached_app} "
                        f"(original: {app_name})"
                    )

            # Write resolved name back to flow_data so the controller/UI
            # shows the specific app (e.g., "TLS.Instagram") not just "TLS"
            if not is_generic_protocol(effective_app_name):
                self._refresh_flow_classification_metadata(
                    flow_data, effective_app_name
                )

        # Step 2: Check app blocklist
        action = self._check_app_blocklist(flow_data, effective_app_name)
        if action:
            return action

        # Step 3: Check rate limits
        action = self._check_rate_limit(flow_data, effective_app_name)
        if action:
            return action

        # Step 4: Check cached policies (for generic protocols only)
        action = self._check_cached_policies(flow_data, app_name)
        if action:
            return action

        return FlowAction(action="allow")

    def _install_normal_flow(self, flow_data: ClassifiedFlowData) -> bool:
        """Install a NORMAL flow rule for a classified flow without a policy match.

        This enables flow stats monitoring for all classified traffic,
        even when no block or rate-limit policy applies.

        Args:
            flow_data: Classified flow data

        Returns:
            True if the flow was installed successfully
        """
        if not self.install_normal_flows or not self.bridge:
            return False

        app_name = flow_data.application_name
        _log_vlan_debug(
            "collector_normal",
            flow_data.src_ip,
            flow_data.src_port,
            flow_data.dst_ip,
            flow_data.dst_port,
            flow_data.is_tcp,
            flow_data.vlan_id,
            flow_data.vlan_source,
            app_name,
        )
        success_fwd, success_rev, cookie = install_bidirectional_normal(
            bridge=self.bridge,
            src_ip=flow_data.src_ip,
            src_port=flow_data.src_port,
            dst_ip=flow_data.dst_ip,
            dst_port=flow_data.dst_port,
            is_tcp=flow_data.is_tcp,
            app_name=app_name,
            priority=4500,
            idle_timeout=300,
            timestamp_ms=flow_data.flow_first_seen_ms or None,
            vlan_id=flow_data.vlan_id,
        )

        if success_fwd and success_rev:
            flow_data.openflow_cookie = cookie
            flow_data.classification_id = cookie & 0xFFFFFFFF
            flow_data.normalized_app_name = normalize_app_name(app_name)
            self.normal_flows += 1
            logger.debug(
                f"NORMAL flow installed: {flow_data.src_ip} -> "
                f"{flow_data.dst_ip}, app={app_name}"
            )
            return True

        return False

    def _batch_sender(self):
        """Background thread that sends batched flows.

        Reads flows from the multiprocessing queue, applies policy enforcement,
        and sends them to the callback in batches.

        OPTIMIZED: Processes queue FIRST then sleeps, with adaptive sleep time.
        This ensures minimal latency for policy enforcement while still batching.
        """
        logger.info("Batch sender thread started")
        cycle_count = 0
        status_interval = 5  # Log status every 5 cycles
        min_sleep = 0.01  # 10ms minimum sleep when busy
        max_sleep = self.batch_interval  # Full interval when idle

        while self._running:
            # PROCESS FIRST, then sleep (inverted from original)
            # This ensures flows are processed as soon as they arrive

            # Periodic cleanup of expired classification cache entries
            now = time.time()
            if now - self._last_cleanup >= self._cleanup_interval:
                self._cleanup_expired_classifications()
                self._cleanup_expired_ip_to_app_cache()
                self._cleanup_expired_ip_to_sni_cache()
                self._last_cleanup = now

            # Collect all flows from queue and apply policy
            # Limit per-cycle processing to prevent starvation when queue is
            # continuously fed by multiple worker processes
            max_per_cycle = 50
            batch: list[ClassifiedFlowData] = []
            flows_processed = 0
            early_policy_skipped = 0

            while flows_processed < max_per_cycle:
                try:
                    flow_data = self._flow_queue.get_nowait()
                    flows_processed += 1

                    # Skip policy application if early policy was already applied
                    # This avoids duplicate OVS rule installation
                    if flow_data.policy_applied:
                        early_policy_skipped += 1
                        logger.debug(
                            f"Skipping policy (early applied): {flow_data.src_ip} -> "
                            f"{flow_data.dst_ip}, action={flow_data.early_action}"
                        )
                        # Still update stats based on early action
                        if flow_data.early_action == "block":
                            self.blocked_flows += 1
                        elif flow_data.early_action == "rate_limit":
                            self.rate_limited_flows += 1
                    else:
                        # Apply policy enforcement for flows not handled early
                        action = self._apply_policy(flow_data)

                        # Update statistics
                        if action.blocked:
                            self.blocked_flows += 1
                            if action.blocked_via_cache:
                                self.cached_blocked_flows += 1
                            logger.info(
                                f"BLOCKED flow: {flow_data.src_ip} -> {flow_data.dst_ip}, "
                                f"app={flow_data.application_name}"
                            )
                        elif action.action == "rate_limit":
                            self.rate_limited_flows += 1
                            if action.rate_limited_via_cache:
                                self.cached_rate_limited_flows += 1
                            logger.debug(
                                f"RATE LIMITED flow: {flow_data.src_ip} -> {flow_data.dst_ip}, "
                                f"app={flow_data.application_name}, meter={action.meter_id}"
                            )
                        elif action.action == "allow":
                            self._install_normal_flow(flow_data)

                    # Register final classification with SNI for flow stats monitor
                    if (
                        self.classification_registry is not None
                        and flow_data.classification_id
                    ):
                        self.classification_registry.register(
                            flow_data.classification_id,
                            flow_data.normalized_app_name,
                            sni=flow_data.requested_server_name,
                        )

                    # Update global stats
                    self.total_flows += 1
                    self.total_packets += flow_data.bidirectional_packets
                    self.total_bytes += flow_data.bidirectional_bytes

                    batch.append(flow_data)
                except QueueEmpty:
                    break

            # Send batch if not empty
            if batch:
                logger.debug(
                    f"Sending batch of {len(batch)} flows "
                    f"({early_policy_skipped} early-processed)"
                )
                try:
                    self.on_batch_ready(batch)
                except Exception as e:
                    logger.error(f"Error in batch callback: {e}", exc_info=True)

            # Adaptive sleep: short when busy (had items), longer when idle
            # This balances latency vs CPU usage
            if batch:
                sleep_time = min_sleep  # Quick turnaround when busy
            else:
                sleep_time = max_sleep  # Longer wait when idle

            time.sleep(sleep_time)
            cycle_count += 1

            # Periodic status log (only when idle cycles accumulate)
            if cycle_count % status_interval == 0:
                try:
                    queue_size = self._flow_queue.qsize()
                except NotImplementedError:
                    queue_size = -1  # qsize() not reliable on all platforms
                logger.debug(
                    f"Classifier stats: total_flows={self.total_flows}, "
                    f"blocked={self.blocked_flows}, rate_limited={self.rate_limited_flows}, "
                    f"normal={self.normal_flows}, queue_size={queue_size}"
                )

        logger.info("Batch sender thread stopped")

    @staticmethod
    def _is_private_ip(ip: str) -> bool:
        """Check if an IP address is private."""
        try:
            return ipaddress.ip_address(ip).is_private
        except ValueError:
            return False

    @staticmethod
    def _is_global_public_ip(ip: str) -> bool:
        """Check if an IP is globally routable unicast."""
        return _is_global_public_ip(ip)

    @staticmethod
    def _generate_flow_id(flow_key: tuple) -> int:
        """Generate a deterministic 32-bit flow ID from the flow tuple."""
        key_str = "|".join(str(x) for x in flow_key)
        hash_bytes = hashlib.sha256(key_str.encode()).digest()
        return int.from_bytes(hash_bytes[:4], byteorder="big")


def format_bytes(num_bytes: int) -> str:
    """Format bytes to human readable string."""
    for unit in ["B", "KB", "MB", "GB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f}{unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f}TB"


def format_flow_console(flow: ClassifiedFlowData) -> str:
    """Format a flow for console output.

    Args:
        flow: ClassifiedFlowData object

    Returns:
        Formatted string for console output
    """
    proto = "TCP" if flow.is_tcp else "UDP"
    src = f"{flow.src_ip}:{flow.src_port}"
    dst = f"{flow.dst_ip}:{flow.dst_port}"
    timestamp = datetime.now().strftime("%H:%M:%S")

    # Format SNI with source indicator
    sni_display = flow.requested_server_name
    if flow.sni_source == "cached":
        sni_display += " (cached)"
    elif flow.sni_source == "ip":
        sni_display = f"{sni_display} (IP)"

    return (
        f"[{timestamp}] {src:>21} -> {dst:<21} | {proto:3} | "
        f"{flow.application_name:<20} | {sni_display} | "
        f"{flow.bidirectional_packets:>5} pkts | {format_bytes(flow.bidirectional_bytes):>8}"
    )


def format_flow_log(flow: ClassifiedFlowData) -> str:
    """Format a flow for log file output.

    Args:
        flow: ClassifiedFlowData object

    Returns:
        Formatted string for log file (pipe-delimited)
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    proto = "TCP" if flow.is_tcp else "UDP"

    return (
        f"{timestamp} | {flow.src_ip}:{flow.src_port} | {flow.dst_ip}:{flow.dst_port} | "
        f"{proto} | {flow.application_name} | {flow.application_category} | "
        f"{flow.requested_server_name} | {flow.sni_source} | "
        f"{flow.bidirectional_packets} | {flow.bidirectional_bytes} | "
        f"{flow.client_fingerprint[:16] if flow.client_fingerprint else ''}"
    )
