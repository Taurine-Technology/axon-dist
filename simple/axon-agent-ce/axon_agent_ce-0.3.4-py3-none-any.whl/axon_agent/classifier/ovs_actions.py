"""OVS flow installation and async action worker for the classifier.

This module provides functions for installing OpenFlow rules (DROP, METER)
in Open vSwitch, as well as an async batching worker that reduces subprocess
overhead by grouping multiple flow-mod operations into single ovs-ofctl calls.

Functions:
    is_private_ip: Check if IP is in private ranges
    is_ipv6: Check if IP is IPv6
    is_generic_protocol: Check if app name is a generic protocol
    normalize_app_name: Extract and lowercase the app-specific identifier
    generate_flow_cookie: Generate a unique 64-bit cookie for OVS flow tracking
    add_drop_flow: Install a DROP flow rule
    add_meter_flow: Install a METER flow rule
    find_meter_by_rate_in_ovs: Find a meter by rate in OVS
    install_bidirectional_drop: Install bidirectional DROP rules
    install_bidirectional_meter: Install bidirectional METER rules

Classes:
    OVSAction: Dataclass representing an async OVS action
    OVSActionWorker: Background worker that batches and executes OVS actions
"""

import hashlib
import ipaddress
import logging
import queue
import subprocess
import threading
import time
from dataclasses import dataclass
from queue import Empty as QueueEmpty
from typing import TYPE_CHECKING, Optional, Tuple

from ..utils import (
    compute_classification_id,
)

if TYPE_CHECKING:
    from ..policy_cache import PolicyCache

logger = logging.getLogger(__name__)

# Generic protocols without specific application identification
# Used to determine if a cached block warning should be logged
GENERIC_PROTOCOLS = {
    "HTTP",
    "TCP",
    "UDP",
    "TLS",
    "QUIC",
    "DNS",
    "ICMP",
    "Unknown",
    "HTTP_Proxy",
    "HTTPS",
    "SSL",
    "DTLS",
    "MDNS",
    "SSDP",
    "LLMNR",
    "IGMP",
    "NTP",
    "DHCP",
    "DHCPv6",
    "ARP",
    "STUN",
}


# =============================================================================
# Utility Functions
# =============================================================================


def is_private_ip(ip: str) -> bool:
    """Check if IP is in private ranges (10.x, 172.16-31.x, 192.168.x).

    Args:
        ip: IP address string (IPv4 or IPv6)

    Returns:
        True if the IP is a private/local address
    """
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return False


def is_ipv6(ip: str) -> bool:
    """Check if an IP address is IPv6.

    Args:
        ip: IP address string

    Returns:
        True if the IP is an IPv6 address
    """
    try:
        return ipaddress.ip_address(ip).version == 6
    except ValueError:
        return False


def is_generic_protocol(app_name: str) -> bool:
    """Check if app_name is a generic protocol without sub-protocol.

    Generic protocols are those that don't identify a specific application,
    such as HTTP, TCP, UDP without a service-specific suffix.

    Args:
        app_name: Application name from NFStream (e.g., "HTTP", "TLS.Instagram")

    Returns:
        True if the protocol is generic (no specific app identified)
    """
    if not app_name:
        return True
    # If contains dot, check if the part after is also generic
    if "." in app_name:
        base, sub = app_name.split(".", 1)
        return sub in GENERIC_PROTOCOLS
    return app_name in GENERIC_PROTOCOLS


def normalize_app_name(app_name: str) -> str:
    """Normalize application name to lowercase app-specific identifier.

    Extracts the application-specific part from protocol-prefixed names
    and converts to lowercase for consistent tracking.

    Examples:
        "QUIC.Instagram" -> "instagram"
        "TLS.YouTube" -> "youtube"
        "HTTP.Facebook" -> "facebook"
        "QUIC" -> "quic"
        "TLS" -> "tls"
        "Unknown" -> "unknown"

    Args:
        app_name: Application name from NFStream (e.g., "QUIC.Instagram")

    Returns:
        Lowercase app-specific identifier
    """
    if not app_name:
        return "unknown"
    if "." in app_name:
        return app_name.split(".", 1)[1].lower()
    return app_name.lower()


def generate_flow_cookie(
    app_name: str, flow_tuple: tuple, timestamp_ms: Optional[int] = None
) -> Tuple[int, int, str]:
    """Generate a unique 64-bit cookie for OVS flow tracking.

    Cookie structure:
    - Upper 32 bits: Hash of 5-tuple + timestamp (flow identifier with uniqueness)
    - Lower 32 bits: Hash of normalized application name (classification identifier)

    Args:
        app_name: Application name (e.g., "Instagram", "QUIC.Facebook")
        flow_tuple: Tuple of (src_ip, dst_ip, src_port, dst_port)
        timestamp_ms: Optional timestamp in milliseconds (defaults to current time)

    Returns:
        Tuple of (cookie, classification_id, normalized_app_name)
        - cookie: 64-bit integer for OVS flow tracking
        - classification_id: 32-bit hash of normalized app name (lower 32 bits)
        - normalized_app_name: Lowercase app-specific name (e.g., "instagram")
    """
    if timestamp_ms is None:
        timestamp_ms = int(time.time() * 1000)

    # Normalize app name first
    normalized_name = normalize_app_name(app_name)

    # Upper 32 bits: flow tuple + timestamp for uniqueness (second granularity)
    flow_key = str(flow_tuple) + str(timestamp_ms // 1000)
    flow_hash = int(hashlib.sha256(flow_key.encode()).hexdigest()[:8], 16)

    # Lower 32 bits: classification hash (from normalized name)
    # Uses shared compute_classification_id for consistency with time_enforcer
    classification_id = compute_classification_id(app_name)

    cookie = (flow_hash << 32) | classification_id
    return cookie, classification_id, normalized_name


# =============================================================================
# OVS Flow Installation Functions
# =============================================================================


def _build_port_spec(src_port: int, dst_port: int) -> str:
    """Build OpenFlow port spec, omitting ports that are zero.

    In OpenFlow, tp_src=0 means "match exactly on port 0", not "match any port".
    To match any port, we must omit the port fields entirely.

    Args:
        src_port: Source port (0 means any)
        dst_port: Destination port (0 means any)

    Returns:
        OpenFlow port spec string (may be empty, always ends with comma if non-empty)
    """
    port_spec = ""
    if src_port > 0:
        port_spec += f"tp_src={src_port},"
    if dst_port > 0:
        port_spec += f"tp_dst={dst_port},"
    return port_spec


def _build_vlan_spec(vlan_id: Optional[int]) -> str:
    """Build OpenFlow VLAN spec, omitting untagged/unknown VLANs."""
    if vlan_id is not None and vlan_id > 0:
        return f"dl_vlan={vlan_id},"
    return ""


def _build_cookie_flow_tuple(
    src_ip: str,
    dst_ip: str,
    src_port: int,
    dst_port: int,
    vlan_id: Optional[int],
) -> tuple:
    """Build the flow identity used for cookie generation."""
    flow_tuple = (src_ip, dst_ip, src_port, dst_port)
    if vlan_id is not None and vlan_id > 0:
        return (*flow_tuple, vlan_id)
    return flow_tuple


def add_drop_flow(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    cookie: int,
    priority: int = 6000,
    idle_timeout: int = 300,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, str]:
    """Install a DROP flow rule in OVS.

    Args:
        bridge: OVS bridge name (e.g., "br0")
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        cookie: 64-bit flow cookie for tracking
        priority: OpenFlow priority (default: 6000, higher than normal traffic)
        idle_timeout: Flow idle timeout in seconds (default: 300)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (success, message)
    """
    # Skip IPv6 flows - nw_src/nw_dst only work with IPv4
    if is_ipv6(src_ip) or is_ipv6(dst_ip):
        logger.debug(f"Skipping IPv6 flow: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
        return False, "IPv6 flows not supported"

    proto = "tcp" if is_tcp else "udp"
    vlan_spec = _build_vlan_spec(vlan_id)
    port_spec = _build_port_spec(src_port, dst_port)

    flow_spec = (
        f"cookie=0x{cookie:016x},"
        f"priority={priority},"
        f"idle_timeout={idle_timeout},"
        f"{vlan_spec}"
        f"{proto},"
        f"nw_src={src_ip},"
        f"nw_dst={dst_ip},"
        f"{port_spec}"
        f"actions=drop"
    )
    cmd = ["ovs-ofctl", "add-flow", bridge, flow_spec, "-OOpenflow13"]
    logger.debug(
        "OVS DROP add-flow request: bridge=%s vlan_id=%s flow_spec=%s",
        bridge,
        vlan_id,
        flow_spec,
    )

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            logger.debug(f"DROP flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
            return True, f"Flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port}"
        else:
            error = result.stderr.strip() or "Unknown error"
            logger.error(f"Failed to add DROP flow: {error}")
            return False, f"Failed to add flow: {error}"
    except subprocess.TimeoutExpired:
        logger.error("Timeout executing ovs-ofctl for DROP flow")
        return False, "Timeout executing ovs-ofctl"
    except FileNotFoundError:
        logger.error("ovs-ofctl not found")
        return False, "ovs-ofctl not found - is Open vSwitch installed?"
    except Exception as e:
        logger.error(f"Error adding DROP flow: {e}")
        return False, f"Error: {str(e)}"


def find_meter_by_rate_in_ovs(bridge: str, rate_kbps: int) -> Optional[int]:
    """Query OVS to find a meter with the specified rate.

    Args:
        bridge: OVS bridge name
        rate_kbps: Rate limit in kbps to search for

    Returns:
        meter_id if found, None otherwise
    """
    try:
        result = subprocess.run(
            ["ovs-ofctl", "dump-meters", bridge, "-OOpenflow13"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            logger.warning(f"Failed to dump meters: {result.stderr}")
            return None

        # Parse meter output
        # Example:
        # meter=10 kbps bands=
        # type=drop rate=900
        current_meter_id = None
        for line in result.stdout.split("\n"):
            line = line.strip()
            if line.startswith("meter="):
                # Extract meter ID: "meter=10 kbps ..." -> 10
                parts = line.split()
                if parts:
                    meter_part = parts[0]  # "meter=10"
                    try:
                        current_meter_id = int(meter_part.split("=")[1])
                    except (IndexError, ValueError):
                        current_meter_id = None
            elif line.startswith("type=drop") and current_meter_id is not None:
                # Extract rate: "type=drop rate=900 ..." -> 900
                # Use exact token match to avoid false positives
                # (e.g., rate=900 matching rate=9000 or burst_rate=900)
                tokens = line.split()
                rate_token = f"rate={rate_kbps}"
                if rate_token in tokens:
                    logger.debug(
                        f"Found meter {current_meter_id} with rate {rate_kbps} in OVS"
                    )
                    return current_meter_id
                current_meter_id = None  # Reset for next meter

        return None
    except subprocess.TimeoutExpired:
        logger.error("Timeout querying OVS meters")
        return None
    except Exception as e:
        logger.error(f"Error querying OVS meters: {e}")
        return None


def add_meter_flow(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    meter_id: int,
    cookie: int,
    priority: int = 5000,
    idle_timeout: int = 300,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, str]:
    """Install a flow rule with METER action in OVS.

    Args:
        bridge: OVS bridge name (e.g., "br0")
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        meter_id: OVS meter ID to apply
        cookie: 64-bit flow cookie for tracking
        priority: OpenFlow priority (default: 5000, lower than block)
        idle_timeout: Flow idle timeout in seconds (default: 300)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (success, message)
    """
    # Skip IPv6 flows - nw_src/nw_dst only work with IPv4
    if is_ipv6(src_ip) or is_ipv6(dst_ip):
        logger.debug(f"Skipping IPv6 flow: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
        return False, "IPv6 flows not supported"

    proto = "tcp" if is_tcp else "udp"
    vlan_spec = _build_vlan_spec(vlan_id)
    port_spec = _build_port_spec(src_port, dst_port)

    flow_spec = (
        f"cookie=0x{cookie:016x},"
        f"priority={priority},"
        f"idle_timeout={idle_timeout},"
        f"{vlan_spec}"
        f"{proto},"
        f"nw_src={src_ip},"
        f"nw_dst={dst_ip},"
        f"{port_spec}"
        f"actions=meter:{meter_id},NORMAL"
    )
    cmd = ["ovs-ofctl", "add-flow", bridge, flow_spec, "-OOpenflow13"]
    logger.debug(
        "OVS METER add-flow request: bridge=%s vlan_id=%s meter_id=%s flow_spec=%s",
        bridge,
        vlan_id,
        meter_id,
        flow_spec,
    )

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            logger.debug(
                f"METER flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port} (meter={meter_id})"
            )
            return (
                True,
                f"Flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port} (meter={meter_id})",
            )
        else:
            error = result.stderr.strip() or "Unknown error"
            logger.error(f"Failed to add METER flow: {error}")
            return False, f"Failed to add flow: {error}"
    except subprocess.TimeoutExpired:
        logger.error("Timeout executing ovs-ofctl for METER flow")
        return False, "Timeout executing ovs-ofctl"
    except FileNotFoundError:
        logger.error("ovs-ofctl not found")
        return False, "ovs-ofctl not found - is Open vSwitch installed?"
    except Exception as e:
        logger.error(f"Error adding METER flow: {e}")
        return False, f"Error: {str(e)}"


def install_bidirectional_drop(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    app_name: str,
    priority: int = 6000,
    idle_timeout: int = 300,
    timestamp_ms: Optional[int] = None,
    cookie: Optional[int] = None,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, bool, int]:
    """Install bidirectional DROP flow rules in OVS.

    Args:
        bridge: OVS bridge name
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        app_name: Application name for cookie generation
        priority: OpenFlow priority
        idle_timeout: Flow idle timeout in seconds
        timestamp_ms: Flow first-seen timestamp for stable cookie generation
        cookie: Optional pre-computed cookie (if provided, reuses this cookie)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (forward_success, reverse_success, cookie_used)
    """
    # Use provided cookie or generate a new one
    if cookie is not None:
        cookie_fwd = cookie
        # For reverse, we use the same cookie since it identifies the same flow
        cookie_rev = cookie
    else:
        flow_tuple_fwd = _build_cookie_flow_tuple(
            src_ip, dst_ip, src_port, dst_port, vlan_id
        )
        flow_tuple_rev = _build_cookie_flow_tuple(
            dst_ip, src_ip, dst_port, src_port, vlan_id
        )
        cookie_fwd, _, _ = generate_flow_cookie(
            app_name, flow_tuple_fwd, timestamp_ms=timestamp_ms
        )
        cookie_rev, _, _ = generate_flow_cookie(
            app_name, flow_tuple_rev, timestamp_ms=timestamp_ms
        )

    # Forward direction: src -> dst
    success_fwd, _ = add_drop_flow(
        bridge,
        src_ip,
        src_port,
        dst_ip,
        dst_port,
        is_tcp,
        cookie_fwd,
        priority,
        idle_timeout,
        vlan_id,
    )

    # Reverse direction: dst -> src
    success_rev, _ = add_drop_flow(
        bridge,
        dst_ip,
        dst_port,
        src_ip,
        src_port,
        is_tcp,
        cookie_rev,
        priority,
        idle_timeout,
        vlan_id,
    )

    return success_fwd, success_rev, cookie_fwd


def install_bidirectional_meter(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    meter_id: int,
    app_name: str,
    priority: int = 5000,
    idle_timeout: int = 300,
    timestamp_ms: Optional[int] = None,
    cookie: Optional[int] = None,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, bool, int]:
    """Install bidirectional METER flow rules in OVS.

    Args:
        bridge: OVS bridge name
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        meter_id: OVS meter ID to apply
        app_name: Application name for cookie generation
        priority: OpenFlow priority
        idle_timeout: Flow idle timeout in seconds
        timestamp_ms: Flow first-seen timestamp for stable cookie generation
        cookie: Optional pre-computed cookie (if provided, reuses this cookie)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (forward_success, reverse_success, cookie_used)
    """
    # Use provided cookie or generate a new one
    if cookie is not None:
        cookie_fwd = cookie
        cookie_rev = cookie
    else:
        flow_tuple_fwd = _build_cookie_flow_tuple(
            src_ip, dst_ip, src_port, dst_port, vlan_id
        )
        flow_tuple_rev = _build_cookie_flow_tuple(
            dst_ip, src_ip, dst_port, src_port, vlan_id
        )
        cookie_fwd, _, _ = generate_flow_cookie(
            app_name, flow_tuple_fwd, timestamp_ms=timestamp_ms
        )
        cookie_rev, _, _ = generate_flow_cookie(
            app_name, flow_tuple_rev, timestamp_ms=timestamp_ms
        )

    # Forward direction: src -> dst
    success_fwd, _ = add_meter_flow(
        bridge,
        src_ip,
        src_port,
        dst_ip,
        dst_port,
        is_tcp,
        meter_id,
        cookie_fwd,
        priority,
        idle_timeout,
        vlan_id,
    )

    # Reverse direction: dst -> src
    success_rev, _ = add_meter_flow(
        bridge,
        dst_ip,
        dst_port,
        src_ip,
        src_port,
        is_tcp,
        meter_id,
        cookie_rev,
        priority,
        idle_timeout,
        vlan_id,
    )

    return success_fwd, success_rev, cookie_fwd


def add_normal_flow(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    cookie: int,
    priority: int = 4500,
    idle_timeout: int = 300,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, str]:
    """Install a NORMAL flow rule in OVS for traffic visibility.

    Args:
        bridge: OVS bridge name (e.g., "br0")
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        cookie: 64-bit flow cookie for tracking
        priority: OpenFlow priority (default: 4500, below policy flows)
        idle_timeout: Flow idle timeout in seconds (default: 300)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (success, message)
    """
    if is_ipv6(src_ip) or is_ipv6(dst_ip):
        logger.debug(f"Skipping IPv6 flow: {src_ip}:{src_port} -> {dst_ip}:{dst_port}")
        return False, "IPv6 flows not supported"

    proto = "tcp" if is_tcp else "udp"
    vlan_spec = _build_vlan_spec(vlan_id)
    port_spec = _build_port_spec(src_port, dst_port)

    flow_spec = (
        f"cookie=0x{cookie:016x},"
        f"priority={priority},"
        f"idle_timeout={idle_timeout},"
        f"{vlan_spec}"
        f"{proto},"
        f"nw_src={src_ip},"
        f"nw_dst={dst_ip},"
        f"{port_spec}"
        f"actions=NORMAL"
    )
    cmd = ["ovs-ofctl", "add-flow", bridge, flow_spec, "-OOpenflow13"]
    logger.debug(
        "OVS NORMAL add-flow request: bridge=%s vlan_id=%s flow_spec=%s",
        bridge,
        vlan_id,
        flow_spec,
    )

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            logger.debug(
                f"NORMAL flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port}"
            )
            return (
                True,
                f"Flow added: {src_ip}:{src_port} -> {dst_ip}:{dst_port}",
            )
        else:
            error = result.stderr.strip() or "Unknown error"
            logger.error(f"Failed to add NORMAL flow: {error}")
            return False, f"Failed to add flow: {error}"
    except subprocess.TimeoutExpired:
        logger.error("Timeout executing ovs-ofctl for NORMAL flow")
        return False, "Timeout executing ovs-ofctl"
    except FileNotFoundError:
        logger.error("ovs-ofctl not found")
        return False, "ovs-ofctl not found - is Open vSwitch installed?"
    except Exception as e:
        logger.error(f"Error adding NORMAL flow: {e}")
        return False, f"Error: {str(e)}"


def install_bidirectional_normal(
    bridge: str,
    src_ip: str,
    src_port: int,
    dst_ip: str,
    dst_port: int,
    is_tcp: bool,
    app_name: str,
    priority: int = 4500,
    idle_timeout: int = 300,
    timestamp_ms: Optional[int] = None,
    cookie: Optional[int] = None,
    vlan_id: Optional[int] = None,
) -> Tuple[bool, bool, int]:
    """Install bidirectional NORMAL flow rules in OVS for traffic visibility.

    Args:
        bridge: OVS bridge name
        src_ip: Source IP address
        src_port: Source port
        dst_ip: Destination IP address
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        app_name: Application name for cookie generation
        priority: OpenFlow priority (default: 4500)
        idle_timeout: Flow idle timeout in seconds (default: 300)
        timestamp_ms: Flow first-seen timestamp for stable cookie generation
        cookie: Optional pre-computed cookie (if provided, reuses this cookie)
        vlan_id: Optional 802.1Q VLAN ID to match

    Returns:
        Tuple of (forward_success, reverse_success, cookie_used)
    """
    if cookie is not None:
        cookie_fwd = cookie
        cookie_rev = cookie
    else:
        flow_tuple_fwd = _build_cookie_flow_tuple(
            src_ip, dst_ip, src_port, dst_port, vlan_id
        )
        flow_tuple_rev = _build_cookie_flow_tuple(
            dst_ip, src_ip, dst_port, src_port, vlan_id
        )
        cookie_fwd, _, _ = generate_flow_cookie(
            app_name, flow_tuple_fwd,
            timestamp_ms=timestamp_ms
        )
        cookie_rev, _, _ = generate_flow_cookie(
            app_name, flow_tuple_rev,
            timestamp_ms=timestamp_ms
        )

    success_fwd, _ = add_normal_flow(
        bridge,
        src_ip,
        src_port,
        dst_ip,
        dst_port,
        is_tcp,
        cookie_fwd,
        priority,
        idle_timeout,
        vlan_id,
    )

    success_rev, _ = add_normal_flow(
        bridge,
        dst_ip,
        dst_port,
        src_ip,
        src_port,
        is_tcp,
        cookie_rev,
        priority,
        idle_timeout,
        vlan_id,
    )

    return success_fwd, success_rev, cookie_fwd


# =============================================================================
# Async OVS Action Worker
# =============================================================================


@dataclass
class OVSAction:
    """Represents an OVS flow action to be executed asynchronously.

    Attributes:
        action_type: "drop" or "meter"
        bridge: OVS bridge name
        src_ip: Source IP address
        dst_ip: Destination IP address
        src_port: Source port
        dst_port: Destination port
        is_tcp: True for TCP, False for UDP
        priority: OpenFlow priority
        idle_timeout: Flow idle timeout in seconds
        app_name: Application name (for logging and cookie generation)
        meter_id: Meter ID (only for "meter" action)
        cookie: Pre-computed cookie (optional)
        timestamp_ms: Flow first-seen timestamp for cookie generation
        rule_label: Human-readable label for logging
    """

    action_type: str  # "drop" or "meter"
    bridge: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    is_tcp: bool
    priority: int
    idle_timeout: int
    app_name: str
    meter_id: Optional[int] = None
    cookie: Optional[int] = None
    timestamp_ms: Optional[int] = None
    rule_label: Optional[str] = None
    vlan_id: Optional[int] = None


class OVSActionWorker:
    """Background worker that batches and executes OVS flow rules asynchronously.

    This worker:
    1. Receives OVS actions via a thread-safe queue
    2. Batches multiple actions together (up to batch_size or max_wait_ms)
    3. Executes batched flow-mods in a single ovs-ofctl subprocess call
    4. Handles errors gracefully without blocking the caller

    For high-throughput scenarios (thousands of flows/sec), this provides:
    - Non-blocking action submission from packet processing path
    - Reduced subprocess overhead via batching
    - Configurable latency vs throughput tradeoff

    Args:
        bridge: Default OVS bridge name (can be overridden per-action)
        batch_size: Maximum actions to batch before executing (default: 50)
        max_wait_ms: Maximum time to wait for batch to fill (default: 10ms)
        policy_cache: Optional PolicyCache for registering cached blocks
    """

    def __init__(
        self,
        bridge: str,
        batch_size: int = 50,
        max_wait_ms: int = 10,
        policy_cache: Optional["PolicyCache"] = None,
    ):
        self.bridge = bridge
        self.batch_size = batch_size
        self.max_wait_ms = max_wait_ms
        self.policy_cache = policy_cache

        self._queue: "queue.Queue[OVSAction]" = queue.Queue()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

        # Statistics (protected by _stats_lock for thread-safety)
        self._stats_lock = threading.Lock()
        self._actions_queued = 0
        self._actions_executed = 0
        self._batches_executed = 0
        self._errors = 0

    @property
    def actions_queued(self) -> int:
        """Thread-safe read of actions_queued counter."""
        with self._stats_lock:
            return self._actions_queued

    @property
    def actions_executed(self) -> int:
        """Thread-safe read of actions_executed counter."""
        with self._stats_lock:
            return self._actions_executed

    @property
    def batches_executed(self) -> int:
        """Thread-safe read of batches_executed counter."""
        with self._stats_lock:
            return self._batches_executed

    @property
    def errors(self) -> int:
        """Thread-safe read of errors counter."""
        with self._stats_lock:
            return self._errors

    def start(self) -> None:
        """Start the background worker thread."""
        if self._thread is not None and self._thread.is_alive():
            logger.warning("OVSActionWorker already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._thread.start()
        logger.info(
            f"OVSActionWorker started (batch_size={self.batch_size}, "
            f"max_wait_ms={self.max_wait_ms})"
        )

    def stop(self) -> None:
        """Stop the background worker thread."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            if self._thread.is_alive():
                logger.warning("OVSActionWorker thread did not stop within timeout")
            else:
                self._thread = None
        logger.info(
            f"OVSActionWorker stopped: queued={self.actions_queued}, "
            f"executed={self.actions_executed}, batches={self.batches_executed}, "
            f"errors={self.errors}"
        )

    def enqueue(self, action: OVSAction) -> None:
        """Enqueue an OVS action for async execution.

        This method is non-blocking and safe to call from any thread.

        Args:
            action: OVSAction to execute
        """
        self._queue.put(action)
        with self._stats_lock:
            self._actions_queued += 1
        logger.debug(
            f"Queued OVS action: {action.action_type} for "
            f"{action.src_ip}:{action.src_port} -> {action.dst_ip}:{action.dst_port}"
        )

    def enqueue_drop(
        self,
        src_ip: str,
        dst_ip: str,
        src_port: int,
        dst_port: int,
        is_tcp: bool,
        app_name: str,
        priority: int,
        idle_timeout: int,
        rule_label: Optional[str] = None,
        cookie: Optional[int] = None,
        timestamp_ms: Optional[int] = None,
        bridge: Optional[str] = None,
        vlan_id: Optional[int] = None,
    ) -> None:
        """Convenience method to enqueue a DROP action.

        Args:
            src_ip: Source IP address
            dst_ip: Destination IP address
            src_port: Source port
            dst_port: Destination port
            is_tcp: True for TCP, False for UDP
            app_name: Application name for cookie generation
            priority: OpenFlow priority
            idle_timeout: Flow idle timeout in seconds
            rule_label: Human-readable label for logging
            cookie: Pre-computed cookie (optional)
            timestamp_ms: Flow first-seen timestamp
            bridge: OVS bridge (defaults to worker's bridge)
            vlan_id: Optional 802.1Q VLAN ID to match
        """
        action = OVSAction(
            action_type="drop",
            bridge=bridge or self.bridge,
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            is_tcp=is_tcp,
            priority=priority,
            idle_timeout=idle_timeout,
            app_name=app_name,
            rule_label=rule_label,
            cookie=cookie,
            timestamp_ms=timestamp_ms,
            vlan_id=vlan_id,
        )
        self.enqueue(action)

    def enqueue_meter(
        self,
        src_ip: str,
        dst_ip: str,
        src_port: int,
        dst_port: int,
        is_tcp: bool,
        meter_id: int,
        app_name: str,
        priority: int,
        idle_timeout: int,
        rule_label: Optional[str] = None,
        cookie: Optional[int] = None,
        timestamp_ms: Optional[int] = None,
        bridge: Optional[str] = None,
        vlan_id: Optional[int] = None,
    ) -> None:
        """Convenience method to enqueue a METER action.

        Args:
            src_ip: Source IP address
            dst_ip: Destination IP address
            src_port: Source port
            dst_port: Destination port
            is_tcp: True for TCP, False for UDP
            meter_id: OVS meter ID to apply
            app_name: Application name for cookie generation
            priority: OpenFlow priority
            idle_timeout: Flow idle timeout in seconds
            rule_label: Human-readable label for logging
            cookie: Pre-computed cookie (optional)
            timestamp_ms: Flow first-seen timestamp
            bridge: OVS bridge (defaults to worker's bridge)
            vlan_id: Optional 802.1Q VLAN ID to match
        """
        action = OVSAction(
            action_type="meter",
            bridge=bridge or self.bridge,
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            is_tcp=is_tcp,
            meter_id=meter_id,
            priority=priority,
            idle_timeout=idle_timeout,
            app_name=app_name,
            rule_label=rule_label,
            cookie=cookie,
            timestamp_ms=timestamp_ms,
            vlan_id=vlan_id,
        )
        self.enqueue(action)

    def _worker_loop(self) -> None:
        """Background worker loop that processes the action queue."""
        logger.debug("OVSActionWorker loop started")

        while not self._stop_event.is_set():
            batch: list[OVSAction] = []
            deadline = time.time() + (self.max_wait_ms / 1000)

            # Collect batch (up to batch_size or max_wait_ms)
            while len(batch) < self.batch_size:
                remaining_ms = max(0, (deadline - time.time()) * 1000)
                if remaining_ms <= 0 and batch:
                    # Deadline reached and we have items
                    break

                try:
                    # Wait up to remaining time or 1ms minimum
                    timeout = max(0.001, remaining_ms / 1000)
                    action = self._queue.get(timeout=timeout)
                    batch.append(action)
                except QueueEmpty:
                    if batch:
                        # Have items and queue is empty, process now
                        break
                    # No items, check stop event and continue
                    continue

            if batch:
                self._execute_batch(batch)

        # Drain remaining items on shutdown
        remaining: list[OVSAction] = []
        while True:
            try:
                remaining.append(self._queue.get_nowait())
            except QueueEmpty:
                break

        if remaining:
            logger.info(f"Executing {len(remaining)} remaining actions on shutdown")
            self._execute_batch(remaining)

        logger.debug("OVSActionWorker loop stopped")

    def _execute_batch(self, batch: list[OVSAction]) -> None:
        """Execute a batch of OVS actions.

        Groups actions by bridge and action type for optimal batching.

        Args:
            batch: List of OVSAction objects to execute
        """
        if not batch:
            return

        # Group by bridge for batching
        by_bridge: dict[str, list[OVSAction]] = {}
        for action in batch:
            bridge = action.bridge or self.bridge
            if bridge not in by_bridge:
                by_bridge[bridge] = []
            by_bridge[bridge].append(action)

        # Execute each bridge's actions
        for bridge, actions in by_bridge.items():
            flow_mods: list[str] = []

            for action in actions:
                # Skip IPv6 flows - nw_src/nw_dst only work with IPv4
                if is_ipv6(action.src_ip) or is_ipv6(action.dst_ip):
                    logger.debug(
                        f"Skipping IPv6 flow: {action.src_ip}:{action.src_port} -> "
                        f"{action.dst_ip}:{action.dst_port}"
                    )
                    continue

                # Generate cookie if not provided
                if action.cookie is not None:
                    cookie_fwd = action.cookie
                    cookie_rev = action.cookie
                else:
                    flow_tuple_fwd = _build_cookie_flow_tuple(
                        action.src_ip,
                        action.dst_ip,
                        action.src_port,
                        action.dst_port,
                        action.vlan_id,
                    )
                    flow_tuple_rev = _build_cookie_flow_tuple(
                        action.dst_ip,
                        action.src_ip,
                        action.dst_port,
                        action.src_port,
                        action.vlan_id,
                    )
                    cookie_fwd, _, _ = generate_flow_cookie(
                        action.app_name,
                        flow_tuple_fwd,
                        timestamp_ms=action.timestamp_ms,
                    )
                    cookie_rev, _, _ = generate_flow_cookie(
                        action.app_name,
                        flow_tuple_rev,
                        timestamp_ms=action.timestamp_ms,
                    )

                proto = "tcp" if action.is_tcp else "udp"
                vlan_spec = _build_vlan_spec(action.vlan_id)
                port_spec_fwd = _build_port_spec(action.src_port, action.dst_port)
                port_spec_rev = _build_port_spec(action.dst_port, action.src_port)

                if action.action_type == "drop":
                    # Forward direction
                    flow_mods.append(
                        f"cookie=0x{cookie_fwd:016x},"
                        f"priority={action.priority},"
                        f"idle_timeout={action.idle_timeout},"
                        f"{vlan_spec}"
                        f"{proto},"
                        f"nw_src={action.src_ip},"
                        f"nw_dst={action.dst_ip},"
                        f"{port_spec_fwd}"
                        f"actions=drop"
                    )
                    # Reverse direction
                    flow_mods.append(
                        f"cookie=0x{cookie_rev:016x},"
                        f"priority={action.priority},"
                        f"idle_timeout={action.idle_timeout},"
                        f"{vlan_spec}"
                        f"{proto},"
                        f"nw_src={action.dst_ip},"
                        f"nw_dst={action.src_ip},"
                        f"{port_spec_rev}"
                        f"actions=drop"
                    )
                    logger.debug(
                        "OVS ASYNC DROP flow-mods: bridge=%s vlan_id=%s fwd=%s rev=%s",
                        bridge,
                        action.vlan_id,
                        flow_mods[-2],
                        flow_mods[-1],
                    )

                    logger.info(
                        f"ASYNC DROP: {action.rule_label or action.app_name} - "
                        f"{action.src_ip}:{action.src_port} -> "
                        f"{action.dst_ip}:{action.dst_port}"
                    )

                elif action.action_type == "meter" and action.meter_id is not None:
                    # Forward direction
                    flow_mods.append(
                        f"cookie=0x{cookie_fwd:016x},"
                        f"priority={action.priority},"
                        f"idle_timeout={action.idle_timeout},"
                        f"{vlan_spec}"
                        f"{proto},"
                        f"nw_src={action.src_ip},"
                        f"nw_dst={action.dst_ip},"
                        f"{port_spec_fwd}"
                        f"actions=meter:{action.meter_id},NORMAL"
                    )
                    # Reverse direction
                    flow_mods.append(
                        f"cookie=0x{cookie_rev:016x},"
                        f"priority={action.priority},"
                        f"idle_timeout={action.idle_timeout},"
                        f"{vlan_spec}"
                        f"{proto},"
                        f"nw_src={action.dst_ip},"
                        f"nw_dst={action.src_ip},"
                        f"{port_spec_rev}"
                        f"actions=meter:{action.meter_id},NORMAL"
                    )
                    logger.debug(
                        "OVS ASYNC METER flow-mods: bridge=%s vlan_id=%s meter_id=%s fwd=%s rev=%s",
                        bridge,
                        action.vlan_id,
                        action.meter_id,
                        flow_mods[-2],
                        flow_mods[-1],
                    )

                    logger.info(
                        f"ASYNC METER: {action.rule_label or action.app_name} - "
                        f"{action.src_ip}:{action.src_port} -> "
                        f"{action.dst_ip}:{action.dst_port} (meter={action.meter_id})"
                    )

                # Register in cached block registry if policy_cache available
                if self.policy_cache and action.action_type == "drop":
                    sni = action.rule_label or action.app_name
                    if is_private_ip(action.src_ip):
                        self.policy_cache.register_cached_block(
                            action.src_ip, sni, action.app_name, action.idle_timeout
                        )
                    if is_private_ip(action.dst_ip):
                        self.policy_cache.register_cached_block(
                            action.dst_ip, sni, action.app_name, action.idle_timeout
                        )

            # Execute batch via stdin
            if flow_mods:
                self._execute_flow_mods(bridge, flow_mods)

        with self._stats_lock:
            self._batches_executed += 1
            self._actions_executed += len(batch)

    def _execute_flow_mods(self, bridge: str, flow_mods: list[str]) -> bool:
        """Execute multiple flow-mods in a single ovs-ofctl call.

        Uses stdin to pass multiple flow specifications, which is much more
        efficient than spawning a subprocess for each flow.

        Args:
            bridge: OVS bridge name
            flow_mods: List of flow specification strings

        Returns:
            True if all flows were added successfully
        """
        if not flow_mods:
            return True

        # Join flow mods with newlines for stdin input
        flow_input = "\n".join(flow_mods)

        cmd = ["ovs-ofctl", "add-flows", bridge, "-", "-OOpenflow13"]

        try:
            result = subprocess.run(
                cmd,
                input=flow_input,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0:
                logger.debug(
                    f"Batch of {len(flow_mods)} flow-mods executed on {bridge}"
                )
                return True
            else:
                error = result.stderr.strip() or "Unknown error"
                logger.error(f"Failed to execute batch flow-mods: {error}")
                with self._stats_lock:
                    self._errors += 1
                return False
        except subprocess.TimeoutExpired:
            logger.error("Timeout executing batched ovs-ofctl")
            with self._stats_lock:
                self._errors += 1
            return False
        except FileNotFoundError:
            logger.error("ovs-ofctl not found")
            with self._stats_lock:
                self._errors += 1
            return False
        except Exception as e:
            logger.error(f"Error executing batch flow-mods: {e}")
            with self._stats_lock:
                self._errors += 1
            return False
