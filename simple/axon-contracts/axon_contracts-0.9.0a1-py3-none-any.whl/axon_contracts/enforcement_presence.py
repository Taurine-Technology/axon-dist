"""Source-scoped, time-bound presence IDs. See docs/enforcement-presence.md."""

import hashlib
import ipaddress
import struct

from axon_contracts.proto import enforcement_messages_pb2 as pb


def presence_digest(site: str, device: str, bridge: str, p: pb.EnforcementPresence) -> bytes:
    """Validate the v1 shape and hash its explicit canonical encoding.

    Admission must additionally verify the supplied ID, source authorization,
    policy revision ownership, clock skew and replay age. No database access.
    """
    maximum = (1 << 63) - 1
    clean = pb.EnforcementPresence()
    clean.CopyFrom(p)
    clean.DiscardUnknownFields()
    if clean != p:
        raise ValueError("unknown presence fields")
    if (not p.HasField("rule") or len(p.parent_admission_id) != 32
            or len(p.source_mac) != 6 or len(p.destination_mac) != 6
            or len(p.vlan_ids) > 2 or any(v > 4095 for v in p.vlan_ids)
            or p.rule.kind not in (pb.RULE_KIND_IP_BLOCK, pb.RULE_KIND_BLOCK_LIST)
            or p.rule.rule_id == 0 or p.rule.revision > maximum
            or not 0 < p.execution_not_before_ms <= p.first_received_at_ms <= p.last_received_at_ms <= maximum - 5000
            or p.first_received_at_ms // 5000 != p.last_received_at_ms // 5000
            or p.client_side not in (0, 1, 2)):
        raise ValueError("invalid enforcement presence")
    data = bytearray(b"axon-enforcement-presence-v1\x00")
    for value in (site, device, bridge):
        encoded = value.encode("utf-8")
        if not 1 <= len(encoded) <= 64 or any(c in value for c in "\x00\r\n/+#"):
            raise ValueError("invalid presence source")
        data.extend(bytes((len(encoded),)))
        data.extend(encoded)
    data.extend(p.parent_admission_id)
    data.extend(struct.pack("!IIQQQQ", p.rule.kind, p.rule.rule_id, p.rule.revision,
                            p.first_received_at_ms, p.last_received_at_ms,
                            p.execution_not_before_ms))
    source, destination = ipaddress.ip_address(p.source_ip), ipaddress.ip_address(p.destination_ip)
    if (source.version != destination.version or str(source) != p.source_ip
            or str(destination) != p.destination_ip or "%" in p.source_ip or "%" in p.destination_ip
            or getattr(source, "ipv4_mapped", None) or getattr(destination, "ipv4_mapped", None)):
        raise ValueError("invalid presence IP")
    for address in (source, destination):
        data.extend(bytes((len(address.packed),)))
        data.extend(address.packed)
    data.extend(p.source_mac)
    data.extend(p.destination_mac)
    data.extend(bytes((len(p.vlan_ids),)))
    for vlan in p.vlan_ids:
        data.extend(struct.pack("!H", vlan))
    data.extend(bytes((p.client_side,)))
    return hashlib.sha256(data).digest()
