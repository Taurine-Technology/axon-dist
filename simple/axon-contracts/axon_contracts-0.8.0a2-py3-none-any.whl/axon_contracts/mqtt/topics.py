"""
MQTT topic patterns for Axon controller <-> agent communication.

Single source of truth (Python side) — kept byte-for-byte in sync with the Go
side, gen/go/topics/topics.go. The cross-language parity test enforces that the
suffix constants and builder outputs match. Change both files together.

Topic planes:
  - Control (QoS 2): Controller -> Agent commands. Guaranteed delivery.
  - Data (QoS 0): Agent -> Controller telemetry. Fire-and-forget.
  - Status (QoS 1): Agent -> Controller state changes.
  - Discovery: Agent -> Controller during onboarding.
"""

# =====================================================================
# QoS constants
# =====================================================================
QOS_CONTROL = 2
QOS_DATA = 0
QOS_STATUS = 1

# =====================================================================
# Prefixes (format-string templates)
# =====================================================================
CONTROL_PREFIX = "axon/control/{site_id}/{device_id}"
DATA_PREFIX = "axon/data/{site_id}/{device_id}"
STATUS_PREFIX = "axon/status/{site_id}/{device_id}"

# =====================================================================
# Global / Discovery topics
# =====================================================================
DISCOVERY = "axon/discovery"
PROVISION = "axon/provision/{mac}"

# =====================================================================
# Discovery message fields (JSON payload on DISCOVERY topic)
# =====================================================================
DISCOVERY_FIELD_UNIQUE_ID = "unique_id"
DISCOVERY_FIELD_STATUS = "status"
DISCOVERY_FIELD_IS_SWITCH = "is_switch"
DISCOVERY_FIELD_AGENT_VERSION = "axon_agent_version"
DISCOVERY_FIELD_HARDWARE_INFO = "hardware_info"
DISCOVERY_FIELD_ENROLLMENT_SECRET = "enrollment_secret"  # EE: optional

# =====================================================================
# Provision message fields (JSON payload on PROVISION topic)
# =====================================================================
PROVISION_FIELD_STATUS = "status"
PROVISION_FIELD_DEVICE_ID = "device_id"
PROVISION_FIELD_NETWORK_ID = "network_id"
PROVISION_FIELD_BRIDGE_CONFIG = "bridge_config"
PROVISION_STATUS_CLAIMED = "claimed"

# =====================================================================
# Control Plane topic suffixes (QoS 2) — Controller -> Agent
# =====================================================================

# Agent update / version
AGENT_UPDATE = "agent/update"
AGENT_UPDATE_RESPONSE = "agent/update/response"
AGENT_VERSION_REQUEST = "agent/version"
AGENT_VERSION_RESPONSE = "agent/version/response"

# OVS Bridge lifecycle
BRIDGE_CREATE = "bridge/create"
BRIDGE_DELETE = "bridge/delete"
BRIDGE_UPDATE_PORTS = "bridge/update_ports"

# OVS Meter management
METER_CREATE = "meter/create"
METER_DELETE = "meter/delete"
METER_MODIFY = "meter/modify"

# Health check
HEALTH_CHECK_REQUEST = "health_check/request"
HEALTH_CHECK_RESPONSE = "health_check/response"

# Uptime monitoring
UPTIME_CHECK_HEARTBEAT = "uptime_check/heartbeat"
UPTIME_CHECK_REQUEST = "uptime_check/request"
UPTIME_CHECK_RESPONSE = "uptime_check/response"

# Policy management
POLICY_SYNC = "policy/sync"
POLICY_BLOCK_ADD = "policy/block/add"
POLICY_BLOCK_REMOVE = "policy/block/remove"
POLICY_RATELIMIT_ADD = "policy/ratelimit/add"
POLICY_RATELIMIT_REMOVE = "policy/ratelimit/remove"
POLICY_IPBLOCK_ADD = "policy/ipblock/add"
POLICY_IPBLOCK_REMOVE = "policy/ipblock/remove"
POLICY_URLBLOCK_ADD = "policy/urlblock/add"
POLICY_URLBLOCK_REMOVE = "policy/urlblock/remove"
POLICY_BLOCKLIST_ADD = "policy/blocklist/add"
POLICY_BLOCKLIST_REMOVE = "policy/blocklist/remove"
POLICY_BLOCKLIST_ENTRY_ADD = "policy/blocklist/entry/add"
POLICY_BLOCKLIST_ENTRY_REMOVE = "policy/blocklist/entry/remove"

# Smart Uplink queue management.
#
# Delivery contract:
#   apply/remove requests and responses -> QoS 2 (state mutations)
#   capability request/status           -> QoS 1 (re-triggerable/snapshot)
#   qos-stats                           -> QoS 0 (bounded periodic telemetry)
# NOTE: these QOS_* names refer to Smart Queue Management, NOT the MQTT QoS
# levels (QOS_CONTROL/QOS_DATA/QOS_STATUS) above. Naming collision is part of the
# contract; do not "fix" it.
QOS_APPLY = "qos/apply"
QOS_APPLY_RESPONSE = "qos/apply/response"
QOS_REMOVE = "qos/remove"
QOS_REMOVE_RESPONSE = "qos/remove/response"
QOS_CAPABILITY_REQUEST = "qos/capability/request"

QOS_APPLY_MQTT_QOS = QOS_CONTROL
QOS_APPLY_RESPONSE_MQTT_QOS = QOS_CONTROL
QOS_REMOVE_MQTT_QOS = QOS_CONTROL
QOS_REMOVE_RESPONSE_MQTT_QOS = QOS_CONTROL
QOS_CAPABILITY_REQUEST_MQTT_QOS = QOS_STATUS

# Smart Uplink live view (post-shaper per-host rates, v0.7.0): qos/live/request
# carries QoSLiveViewRequest (start / keepalive / stop; QoS 1, re-triggerable),
# answered on qos/live/response with QoSLiveViewResponse. The qos-live data-plane
# suffix lives in the data-plane section below.
QOS_LIVE_REQUEST = "qos/live/request"
QOS_LIVE_RESPONSE = "qos/live/response"
QOS_LIVE_REQUEST_MQTT_QOS = QOS_STATUS
QOS_LIVE_RESPONSE_MQTT_QOS = QOS_STATUS

# Ask the agent to publish its DeviceProfile now (DeviceProfileRequest; the
# profile echoes correlation_id). QoS 1.
# Full pattern: axon/control/{site_id}/{device_id}/device/profile/request
DEVICE_PROFILE_REQUEST = "device/profile/request"
DEVICE_PROFILE_REQUEST_MQTT_QOS = QOS_STATUS

# Plugin / Sniffer
SNIFFER_INSTALL = "plugin/sniffer/install"

# Classifier management
CLASSIFIER_INSTALL = "classifier/install"
CLASSIFIER_CONFIGURE = "classifier/configure"
CLASSIFIER_ENABLE = "classifier/enable"
CLASSIFIER_DISABLE = "classifier/disable"
CLASSIFIER_STATUS_REQUEST = "classifier/status"

# Flow modification (v1 ML classification)
FLOW_MOD_ADD = "flow_mod/add"

# Device lifecycle (graceful uninstall / decommission)
DEVICE_UNINSTALL = "device/uninstall"
DEVICE_UNINSTALL_RESPONSE = "device/uninstall/response"

# Network diagnostics (on-demand troubleshooting probes; QoS 1 — these
# are re-triggerable probes deduped by correlation_id, like the agent
# version probe, not must-not-lose state mutations)
DIAGNOSTIC_DNS_CHECK = "diagnostic/dns_check"
DIAGNOSTIC_DNS_CHECK_RESPONSE = "diagnostic/dns_check/response"
DIAGNOSTIC_SPEED_TEST = "diagnostic/speed_test"
DIAGNOSTIC_SPEED_TEST_RESPONSE = "diagnostic/speed_test/response"
DIAGNOSTIC_PATH_TRACE = "diagnostic/path_trace"
DIAGNOSTIC_PATH_TRACE_RESPONSE = "diagnostic/path_trace/response"
DIAGNOSTIC_HTTP_CHECK = "diagnostic/http_check"
DIAGNOSTIC_HTTP_CHECK_RESPONSE = "diagnostic/http_check/response"
DIAGNOSTIC_LINK_HEALTH = "diagnostic/link_health"
DIAGNOSTIC_LINK_HEALTH_RESPONSE = "diagnostic/link_health/response"
DIAGNOSTIC_REACHABILITY_MATRIX = "diagnostic/reachability_matrix"
DIAGNOSTIC_REACHABILITY_MATRIX_RESPONSE = "diagnostic/reachability_matrix/response"

# SNMP agent-transport monitoring.
#   configure (+response) -> QoS 2 (per-switch config push; must-not-lose,
#                            matches agent/update)
#   probe (+response)     -> QoS 1 (re-triggerable test-connection probe,
#                            deduped by correlation_id)
#   unifi/fetch (+resp)   -> QoS 1 (re-triggerable scoped HTTP relay call,
#                            deduped by correlation_id)
# The snmp-walk data-plane suffix lives in the data-plane section below.
SNMP_CONFIGURE = "snmp/configure"
SNMP_CONFIGURE_RESPONSE = "snmp/configure/response"
SNMP_PROBE = "snmp/probe"
SNMP_PROBE_RESPONSE = "snmp/probe/response"
UNIFI_FETCH = "unifi/fetch"
UNIFI_FETCH_RESPONSE = "unifi/fetch/response"

# Client status (LWT / Last Will and Testament)
# Note: uses site-level scope, not device-level
CLIENT_STATUS = "client/status"
CLIENT_STATUS_TOPIC = "axon/control/{site_id}/client/status"

# =====================================================================
# Data Plane topic suffixes (QoS 0 unless noted) — Agent -> Controller
# =====================================================================

# Device statistics
DEVICE_STATS = "stats"
PORT_STATS = "port-stats"
PORT_STATUS = "port-status"

# Interface changes (QoS 1)
INTERFACES = "interfaces"

# Traffic flows (v1 sniffer)
FLOWS = "flows"
FLOWS_RAW = "flows/raw"

# Flow statistics
FLOW_STATS = "flow-stats"
FLOW_STATS_RAW = "flow-stats-raw"

# Classified flows (v2 NFStream)
CLASSIFIED_FLOWS = "classified_flows"
CLASSIFIER_FLOW_STATS = "classifier-flow-stats"

# Classifier health (ClassifierHealthSample telemetry; QoS 0, raw protobuf)
CLASSIFIER_HEALTH = "classifier-health"

# Mirror-mode per-flow accounting (MirrorFlowStatsBatch; QoS 0, zstd protobuf)
MIRROR_FLOW_STATS = "mirror-flow-stats"

# Switching-mode classifier/capture-owned per-flow accounting
# (MirrorFlowStatsBatch; QoS 0, zstd protobuf), distinct from OVS-derived
# classifier-flow-stats
CLASSIFIER_FLOW_ACCOUNTING = "classifier-flow-accounting"

# Smart Uplink aggregate queue stats (one bounded batch per direction).
QOS_STATS = "qos-stats"
QOS_STATS_MQTT_QOS = QOS_DATA

# QOS_LIVE carries Smart Uplink live-view batches (QoSLiveBatch: one message per
# interval per device, every shaped interface's per-host post-shaper byte/packet
# deltas), published only while a live-view session is active. QoS 0,
# zstd-compressed protobuf, never retained.
QOS_LIVE = "qos-live"
QOS_LIVE_MQTT_QOS = QOS_DATA

# SNMP agent-transport walk results (SnmpWalkResult; QoS 0, raw protobuf).
# Data-plane identity is the switch; the monitored device is identified by
# target_id in the payload.
SNMP_WALK = "snmp-walk"

# Classifier status response (QoS 1)
CLASSIFIER_STATUS_RESPONSE = "classifier/status"
CLASSIFIER_INSTALL_RESPONSE = "classifier/install/response"

# Sniffer install response
SNIFFER_INSTALL_RESPONSE = "plugin/sniffer/install/response"

# =====================================================================
# Status Plane topic suffixes (QoS 1) — Agent -> Controller state changes
# =====================================================================

# Production-deployment lifecycle progress stream (LifecycleProgress; QoS 1).
# Full pattern: axon/status/{site_id}/{device_id}/lifecycle/progress
LIFECYCLE_PROGRESS = "lifecycle/progress"

# Smart Uplink capability snapshot, published on connect and on request.
# Full pattern: axon/status/{site_id}/{device_id}/qos/capability
QOS_CAPABILITY_STATUS = "qos/capability"
QOS_CAPABILITY_STATUS_MQTT_QOS = QOS_STATUS

# Agent DeviceProfile (hardware, kernel, queueing and capture capabilities):
# published after adoption, on profile-hash change, as a slow heartbeat and on
# request. QoS 1.
# Full pattern: axon/status/{site_id}/{device_id}/device/profile
DEVICE_PROFILE_STATUS = "device/profile"
DEVICE_PROFILE_STATUS_MQTT_QOS = QOS_STATUS

# =====================================================================
# Subscription wildcard patterns (used by controller listener)
# =====================================================================
SUB_DISCOVERY = "axon/discovery"
SUB_CONTROL_SITE = "axon/control/{site_id}/#"
SUB_DATA_SITE = "axon/data/{site_id}/#"
SUB_STATUS_SITE = "axon/status/{site_id}/#"
SUB_CONTROL_GLOBAL = "axon/control/+/#"
# Narrow retained-status discovery. A broad global status subscription would
# route unrelated lifecycle/status traffic through the discovery client.
SUB_QOS_CAPABILITY_GLOBAL = "axon/status/+/+/qos/capability"


# =====================================================================
# Topic builder helpers
# =====================================================================


def control_topic(site_id: str, device_id: str, suffix: str) -> str:
    """Build a concrete control plane topic for publishing."""
    return f"axon/control/{site_id}/{device_id}/{suffix}"


def data_topic(site_id: str, device_id: str, suffix: str) -> str:
    """Build a concrete data plane topic for publishing."""
    return f"axon/data/{site_id}/{device_id}/{suffix}"


def status_topic(site_id: str, device_id: str, suffix: str) -> str:
    """Build a concrete status topic for publishing."""
    return f"axon/status/{site_id}/{device_id}/{suffix}"


def provision_topic(mac: str) -> str:
    """Build a provision topic for a specific device MAC address."""
    return f"axon/provision/{mac}"


def client_status_topic(site_id: str) -> str:
    """Build the LWT client status topic for a site."""
    return f"axon/control/{site_id}/client/status"


# =====================================================================
# Handler pattern builders (regex patterns for MQTTHandler.topic_pattern)
# =====================================================================


def control_pattern(topic_suffix: str) -> str:
    """Build a regex pattern for a control plane topic handler."""
    return rf"^axon/control/([^/]+)/([^/]+)/{topic_suffix}$"


def data_pattern(topic_suffix: str) -> str:
    """Build a regex pattern for a data plane topic handler."""
    return rf"^axon/data/([^/]+)/([^/]+)/{topic_suffix}$"


def status_pattern(topic_suffix: str) -> str:
    """Build a regex pattern for a status topic handler."""
    return rf"^axon/status/([^/]+)/([^/]+)/{topic_suffix}$"


# Bounded passive DNS interval aggregates (no domains or packets).
DNS_QUALITY = "dns-quality"
DNS_QUALITY_MQTT_QOS = QOS_DATA
