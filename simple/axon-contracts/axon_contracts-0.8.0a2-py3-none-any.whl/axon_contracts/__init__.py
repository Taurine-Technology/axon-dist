"""Axon contracts: protobuf messages, MQTT topics, and gRPC endpoints shared by
the Axon controller, the Python API, and the Go agent. Single source of truth."""

__version__ = "0.8.0a2"
