"""Step name constants for the update orchestrator.

Centralised so ``completed_steps`` / ``failed_steps`` in
``AgentUpdateResponse`` can never drift between the orchestrator and
the tests that assert on them.
"""

# Forward path
STEP_PROBE_VERSIONS = "probe_current_versions"
STEP_ACQUIRE_LOCK = "acquire_update_lock"
STEP_RESOLVE_TARGET = "resolve_target_version"
STEP_SNAPSHOT_SERVICES = "snapshot_running_services"
STEP_DISK_CHECK = "disk_space_check"
STEP_MIGRATE_LEGACY_VENV = "migrate_legacy_venv"
STEP_PICK_SLOT = "pick_inactive_slot"
STEP_RM_INACTIVE = "rm_inactive_slot"
STEP_CREATE_VENV = "create_venv"
STEP_PIP_INSTALL = "pip_install"
STEP_VERIFY_IMPORTS = "verify_new_venv_imports"
STEP_BACKUP_UNITS = "backup_unit_files"
STEP_INSTALL_UNITS = "install_new_unit_files"
STEP_DAEMON_RELOAD = "daemon_reload"
STEP_STOP_S0 = "stop_old_services"
STEP_SWAP_SYMLINK = "swap_venv_symlink"
STEP_START_S0 = "start_new_services"
STEP_WAIT_HEALTH = "wait_for_health"
STEP_RESTART_SELF = "restart_self_scheduled"

# Rollback path
ROLLBACK_STOP_S0 = "rollback_stop_failing_services"
ROLLBACK_SWAP_BACK = "rollback_swap_venv_symlink"
ROLLBACK_RESTORE_UNITS = "rollback_restore_unit_files"
ROLLBACK_DAEMON_RELOAD = "rollback_daemon_reload"
ROLLBACK_START_S0 = "rollback_start_old_services"
ROLLBACK_WAIT_HEALTH = "rollback_wait_for_health"

# Sentinel: included in completed_steps when a fast-path early return
# fires. Lets the controller distinguish a no-op from a real install.
SENTINEL_DRY_RUN = "dry_run_skipped_install"
