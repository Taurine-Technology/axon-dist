"""Version probe — read installed package versions from a venv slot.

Used both at update time (snapshot before/after) and to service the
``AgentVersionRequest`` MQTT command from the controller.
"""

import logging
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from axon_agent_ee.updater import slots

logger = logging.getLogger(__name__)


INSTALLER_VERSION_FILE = slots.INSTALL_DIR / "INSTALLER_VERSION"

_PROBE_SCRIPT = (
    "import axon_agent, axon_agent_ee, axon_shared;"
    "print(axon_agent.__version__);"
    "print(axon_agent_ee.__version__);"
    "print(axon_shared.__version__)"
)


@dataclass
class VersionSnapshot:
    """Version triple from a single venv slot."""

    ee: str
    ce: str
    shared: str


def probe_versions_in_slot(slot: Path, timeout_s: float = 15.0) -> VersionSnapshot:
    """Subprocess into ``{slot}/bin/python`` and import all three packages.

    Raises ``FileNotFoundError`` if the slot's python is missing,
    ``RuntimeError`` if the import fails for any reason.
    """
    python = slot / "bin" / "python"
    if not python.exists():
        raise FileNotFoundError(f"slot python missing: {python}")
    try:
        out = subprocess.run(
            [str(python), "-c", _PROBE_SCRIPT],
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except subprocess.SubprocessError as e:
        raise RuntimeError(f"probe subprocess raised: {e}") from e
    if out.returncode != 0:
        raise RuntimeError(
            f"probe failed rc={out.returncode}: {out.stderr.strip()!r}"
        )
    lines = [ln.strip() for ln in out.stdout.splitlines() if ln.strip()]
    if len(lines) != 3:
        raise RuntimeError(f"probe produced {len(lines)} lines, expected 3")
    ce, ee, shared = lines
    return VersionSnapshot(ee=ee, ce=ce, shared=shared)


def probe_current_versions(timeout_s: float = 15.0) -> VersionSnapshot:
    """Probe via the symlink — i.e. whatever venv systemd services run on."""
    return probe_versions_in_slot(slots.VENV_LINK, timeout_s=timeout_s)


def read_installer_version() -> str:
    """Return the contents of /opt/axon-agent/INSTALLER_VERSION, or ''.

    Empty string means the installer didn't write the sentinel (pre-0.3.0
    installer) or the file is unreadable.
    """
    try:
        return INSTALLER_VERSION_FILE.read_text().strip()
    except OSError:
        return ""


def is_update_in_progress() -> bool:
    """True if /opt/axon-agent/update.lock is currently held.

    Uses a non-blocking acquire: if we get the lock, nobody else has it
    (release immediately). If we can't, someone holds it.
    """
    if not slots.LOCK_PATH.exists():
        return False
    try:
        from filelock import FileLock, Timeout
    except ImportError:
        # filelock not yet a dep on legacy installs — fall back to
        # "lock file exists → assume held".
        return True
    fl = FileLock(str(slots.LOCK_PATH))
    try:
        fl.acquire(timeout=0)
    except Timeout:
        return True
    try:
        return False
    finally:
        try:
            fl.release()
        except Exception:
            pass


def perform_version_probe(correlation_id: str):
    """Build an AgentVersionResponse for the controller.

    Synchronous, sub-second — safe to call from the MQTT callback thread.
    Returns the proto message; caller serialises and publishes.
    """
    # Imported lazily so that a missing axon-shared proto doesn't break
    # module import (decommission.py uses the same defensive pattern).
    from axon_shared.proto.agent_update_messages_pb2 import (
        AgentVersionResponse,
    )
    from axon_agent_ee.updater import health

    snapshot: Optional[VersionSnapshot] = None
    try:
        snapshot = probe_current_versions()
    except Exception:
        logger.exception("probe_current_versions failed; reporting empty versions")

    response = AgentVersionResponse(
        correlation_id=correlation_id,
        ee_version=snapshot.ee if snapshot else "",
        ce_version=snapshot.ce if snapshot else "",
        shared_version=snapshot.shared if snapshot else "",
        installer_version=read_installer_version(),
        update_in_progress=is_update_in_progress(),
        timestamp_ms=int(time.time() * 1000),
    )
    response.running_services.extend(health.snapshot_running_services(exclude=()))
    return response
