"""Update orchestrator — the 21-step sequence with rollback.

Mirrors the partial-failure / step-recorder pattern from
``axon_agent_ee.decommission.perform_uninstall``.

CRITICAL INVARIANTS
-------------------
1. ``axon-agent-ee.service`` is excluded from S0 — the agent IS the
   process running this orchestrator and must not stop itself mid-flight.
   The caller schedules ``systemctl restart axon-agent-ee.service``
   AFTER the response is published (see ``_run_update_worker`` in
   ``main.py``).
2. The venv symlink swap (step 17) is the only mutation that flips
   which code is live. Every other step is reversible.
3. S0 is captured BEFORE any destructive action — that is the ground
   truth for "what should be running after."
4. Unit-file backup is byte-for-byte (``cp -p``), restored verbatim on
   rollback.
5. The agent NEVER deletes the previously-active slot. The next
   successful update replaces it.
"""

import json
import logging
import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from axon_agent_ee.updater import health, index, probe, slots, steps
from axon_agent_ee.updater.probe import VersionSnapshot

logger = logging.getLogger(__name__)


# Pre-flight thresholds.
MIN_FREE_BYTES = 500 * 1024 * 1024
DEFAULT_HEALTH_TIMEOUT_S = 90
ROLLBACK_HEALTH_TIMEOUT_S = 60
PIP_TIMEOUT_S = 15 * 60  # 15 minutes — nfstream compile can be slow on ARM
VENV_CREATE_TIMEOUT_S = 60
VERIFY_IMPORTS_TIMEOUT_S = 30
SYSTEMD_DIR = Path("/etc/systemd/system")


class UpdateError(Exception):
    """Raised by helpers when a step fails fatally (no rollback possible)."""


@dataclass
class _Context:
    """Mutable state passed through the orchestration."""

    cmd: object  # AgentUpdateCommand
    started_at: float
    completed: List[str] = field(default_factory=list)
    failed: List[str] = field(default_factory=list)
    error_messages: List[str] = field(default_factory=list)
    previous: Optional[VersionSnapshot] = None
    current: Optional[VersionSnapshot] = None
    s0: List[str] = field(default_factory=list)
    previous_active_slot: Optional[Path] = None
    inactive_slot: Optional[Path] = None
    lock = None  # filelock.FileLock | None

    def add_error(self, step: str, exc: BaseException) -> None:
        self.failed.append(step)
        self.error_messages.append(f"{step}: {exc}")
        logger.exception("step %s failed", step)


def _build_response(
    ctx: _Context,
    status,
    error_message: str = "",
):
    """Materialise an AgentUpdateResponse from the orchestration state."""
    from axon_shared.proto.agent_update_messages_pb2 import (
        AgentUpdateResponse,
    )
    prev = ctx.previous or VersionSnapshot(ee="", ce="", shared="")
    curr = ctx.current or prev
    response = AgentUpdateResponse(
        correlation_id=getattr(ctx.cmd, "correlation_id", ""),
        status=status,
        previous_version=prev.ee,
        current_version=curr.ee,
        previous_ce_version=prev.ce,
        current_ce_version=curr.ce,
        previous_shared_version=prev.shared,
        current_shared_version=curr.shared,
        error_message=error_message
        or (ctx.error_messages[0] if ctx.error_messages else ""),
        duration_ms=int((time.time() - ctx.started_at) * 1000),
    )
    response.completed_steps.extend(ctx.completed)
    response.failed_steps.extend(ctx.failed)
    return response


def _append_log_entry(entry: dict) -> None:
    """Append a JSON line to ``update.log`` (best-effort, never raises)."""
    try:
        slots.INSTALL_DIR.mkdir(parents=True, exist_ok=True)
        with slots.LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        logger.exception("failed to append %s", slots.LOG_PATH)


def _release_lock(ctx: _Context) -> None:
    if ctx.lock is None:
        return
    try:
        ctx.lock.release()
    except Exception:
        logger.exception("FileLock.release raised")
    try:
        slots.LOCK_PATH.unlink(missing_ok=True)
    except OSError:
        logger.exception("failed to unlink %s", slots.LOCK_PATH)
    ctx.lock = None


def _resolve_index_url(cmd) -> str:
    return getattr(cmd, "index_url", "") or index.DEFAULT_INDEX_URL


def _resolve_systemd_src_dirs(slot: Path) -> List[Path]:
    """Resolve site-packages systemd dirs for axon_agent and axon_agent_ee."""
    python = slot / "bin" / "python"
    out = subprocess.run(
        [
            str(python),
            "-c",
            (
                "import axon_agent, axon_agent_ee, pathlib;"
                "print(pathlib.Path(axon_agent.__file__).parent / 'systemd');"
                "print(pathlib.Path(axon_agent_ee.__file__).parent / 'systemd')"
            ),
        ],
        check=False,
        capture_output=True,
        text=True,
        timeout=15,
    )
    if out.returncode != 0:
        raise UpdateError(
            f"could not resolve systemd dirs: {out.stderr.strip()!r}"
        )
    dirs = [Path(line.strip()) for line in out.stdout.splitlines() if line.strip()]
    for d in dirs:
        if not d.is_dir():
            raise UpdateError(f"systemd dir missing: {d}")
    return dirs


def _backup_unit_files() -> List[Path]:
    """cp -p /etc/systemd/system/axon-agent-*.service → units.prev/."""
    if slots.UNITS_PREV.exists():
        shutil.rmtree(slots.UNITS_PREV)
    slots.UNITS_PREV.mkdir(parents=True, exist_ok=True)
    backed_up: List[Path] = []
    for src in sorted(SYSTEMD_DIR.glob("axon-agent-*.service")):
        # cp -p preserves mode + timestamps. shutil.copy2 mirrors that.
        dst = slots.UNITS_PREV / src.name
        shutil.copy2(src, dst)
        backed_up.append(dst)
    return backed_up


def _install_new_unit_files(slot: Path) -> List[Path]:
    """Copy unit files from the new venv's site-packages into /etc/systemd/system/."""
    src_dirs = _resolve_systemd_src_dirs(slot)
    venv_python = str(slots.VENV_LINK / "bin" / "python")
    install_dir = str(slots.INSTALL_DIR)
    installed: List[Path] = []
    for src_dir in src_dirs:
        for src in sorted(src_dir.glob("*.service")):
            dst = SYSTEMD_DIR / src.name
            content = src.read_text(encoding="utf-8")
            content = content.replace(
                "ExecStart=/usr/bin/python3", f"ExecStart={venv_python}"
            )
            content = content.replace(
                "WorkingDirectory=/opt/axon-agent",
                f"WorkingDirectory={install_dir}",
            )
            dst.write_text(content, encoding="utf-8")
            os.chmod(dst, 0o644)
            installed.append(dst)
    return installed


def _restore_unit_files() -> None:
    """Restore unit files from units.prev/ on rollback."""
    if not slots.UNITS_PREV.exists():
        return
    for src in sorted(slots.UNITS_PREV.glob("axon-agent-*.service")):
        dst = SYSTEMD_DIR / src.name
        shutil.copy2(src, dst)


def _execute_rollback(ctx: _Context) -> bool:
    """Run the R1–R6 rollback path. Returns True if rollback succeeded.

    A False return means the rollback itself failed — caller raises a
    STATUS_FAILED with manual-intervention error message.
    """
    logger.warning("Executing rollback to slot %s", ctx.previous_active_slot)

    # R1 — stop failing-new-services
    _, fail_stop = health.stop_units(ctx.s0)
    if fail_stop:
        ctx.failed.append(f"{steps.ROLLBACK_STOP_S0}:{','.join(fail_stop)}")
    else:
        ctx.completed.append(steps.ROLLBACK_STOP_S0)

    # R2 — swap symlink back
    try:
        slots.swap_venv_symlink(ctx.previous_active_slot)
        ctx.completed.append(steps.ROLLBACK_SWAP_BACK)
    except Exception as e:
        ctx.add_error(steps.ROLLBACK_SWAP_BACK, e)
        return False

    # R3 — restore unit files
    try:
        _restore_unit_files()
        ctx.completed.append(steps.ROLLBACK_RESTORE_UNITS)
    except Exception as e:
        ctx.add_error(steps.ROLLBACK_RESTORE_UNITS, e)

    # daemon-reload
    if health.daemon_reload():
        ctx.completed.append(steps.ROLLBACK_DAEMON_RELOAD)
    else:
        ctx.failed.append(steps.ROLLBACK_DAEMON_RELOAD)

    # R4 — start old services
    _, fail_start = health.start_units(ctx.s0)
    if fail_start:
        ctx.failed.append(f"{steps.ROLLBACK_START_S0}:{','.join(fail_start)}")
    else:
        ctx.completed.append(steps.ROLLBACK_START_S0)

    # R5 — verify health
    ok, still_inactive = health.verify_running(
        ctx.s0, timeout_s=ROLLBACK_HEALTH_TIMEOUT_S
    )
    if ok:
        ctx.completed.append(steps.ROLLBACK_WAIT_HEALTH)
        return True
    ctx.failed.append(
        f"{steps.ROLLBACK_WAIT_HEALTH}:{','.join(still_inactive)}"
    )
    return False


def perform_update(cmd, site_id: str, device_id: str):
    """Execute the update plan, return AgentUpdateResponse. Never raises."""
    from axon_shared.proto.agent_update_messages_pb2 import (
        AgentUpdateResponse,
    )

    ctx = _Context(cmd=cmd, started_at=time.time())

    # ── Step 2 — acquire the filelock first; nothing else races us. ──
    try:
        from filelock import FileLock, Timeout
    except ImportError as e:
        ctx.add_error(steps.STEP_ACQUIRE_LOCK, e)
        return _build_response(
            ctx,
            AgentUpdateResponse.STATUS_FAILED,
            error_message="filelock library missing",
        )

    try:
        slots.INSTALL_DIR.mkdir(parents=True, exist_ok=True)
        ctx.lock = FileLock(str(slots.LOCK_PATH))
        try:
            ctx.lock.acquire(timeout=0)
        except Timeout:
            ctx.lock = None
            ctx.failed.append(steps.STEP_ACQUIRE_LOCK)
            return _build_response(
                ctx,
                AgentUpdateResponse.STATUS_FAILED,
                error_message="another update in progress",
            )
        ctx.completed.append(steps.STEP_ACQUIRE_LOCK)
        return _perform_update_locked(ctx, site_id, device_id)
    finally:
        _release_lock(ctx)


def _perform_update_locked(ctx: _Context, site_id: str, device_id: str):
    """Inner orchestration body — called with the update lock held."""
    from axon_shared.proto.agent_update_messages_pb2 import (
        AgentUpdateResponse,
    )

    # ── Step 1 — probe current versions. ──
    try:
        ctx.previous = probe.probe_current_versions()
        ctx.current = ctx.previous  # default; updated on success
        ctx.completed.append(steps.STEP_PROBE_VERSIONS)
    except Exception as e:
        ctx.add_error(steps.STEP_PROBE_VERSIONS, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 3 — resolve target / fast-path ALREADY_AT_VERSION. ──
    target_version = (getattr(ctx.cmd, "target_version", "") or "").strip()
    if not target_version or target_version == ctx.previous.ee:
        ctx.completed.append(steps.STEP_RESOLVE_TARGET)
        return _build_response(ctx, AgentUpdateResponse.STATUS_ALREADY_AT_VERSION)

    index_url = _resolve_index_url(ctx.cmd)
    try:
        if not index.head_check_wheel(index_url, "axon-agent-ee", target_version):
            ctx.failed.append(steps.STEP_RESOLVE_TARGET)
            ctx.error_messages.append(
                f"resolve_target: axon-agent-ee=={target_version} not in {index_url}"
            )
            return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)
    except Exception as e:
        ctx.add_error(steps.STEP_RESOLVE_TARGET, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)
    ctx.completed.append(steps.STEP_RESOLVE_TARGET)

    # ── Step 4 — disk-space pre-flight. ──
    try:
        free = shutil.disk_usage(slots.INSTALL_DIR).free
    except OSError as e:
        ctx.add_error(steps.STEP_DISK_CHECK, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)
    if free < MIN_FREE_BYTES:
        ctx.failed.append(steps.STEP_DISK_CHECK)
        ctx.error_messages.append(
            f"disk_space_check: {free} bytes free < {MIN_FREE_BYTES}"
        )
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)
    ctx.completed.append(steps.STEP_DISK_CHECK)

    # ── Step 5 — legacy-venv migration (first update only). ──
    if slots.is_legacy_layout():
        try:
            slots.migrate_legacy_layout()
            ctx.completed.append(steps.STEP_MIGRATE_LEGACY_VENV)
        except Exception as e:
            ctx.add_error(steps.STEP_MIGRATE_LEGACY_VENV, e)
            return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 6 — snapshot S0 + persist intent for crash recovery. ──
    try:
        ctx.previous_active_slot = slots.current_active_slot()
        ctx.s0 = health.snapshot_running_services()
        ctx.completed.append(steps.STEP_SNAPSHOT_SERVICES)
    except Exception as e:
        ctx.add_error(steps.STEP_SNAPSHOT_SERVICES, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    _append_log_entry(
        {
            "ts": int(ctx.started_at * 1000),
            "event": "update_start",
            "correlation_id": getattr(ctx.cmd, "correlation_id", ""),
            "target_version": target_version,
            "previous_version": ctx.previous.ee,
            "active_slot_at_start": ctx.previous_active_slot.name,
            "s0": ctx.s0,
        }
    )

    # ── Step 7 — pick the inactive slot. ──
    try:
        ctx.inactive_slot = slots.pick_inactive_slot()
        ctx.completed.append(steps.STEP_PICK_SLOT)
    except Exception as e:
        ctx.add_error(steps.STEP_PICK_SLOT, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 8 — dry-run early return. ──
    if getattr(ctx.cmd, "dry_run", False):
        ctx.completed.append(steps.SENTINEL_DRY_RUN)
        return _build_response(ctx, AgentUpdateResponse.STATUS_OK)

    # ── Step 9 — wipe inactive slot. ──
    try:
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        ctx.completed.append(steps.STEP_RM_INACTIVE)
    except Exception as e:
        ctx.add_error(steps.STEP_RM_INACTIVE, e)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 10 — create the venv. ──
    try:
        rc = subprocess.run(
            ["python3", "-m", "venv", str(ctx.inactive_slot)],
            check=False,
            capture_output=True,
            text=True,
            timeout=VENV_CREATE_TIMEOUT_S,
        )
        if rc.returncode != 0:
            raise UpdateError(f"venv creation failed: {rc.stderr.strip()!r}")
        ctx.completed.append(steps.STEP_CREATE_VENV)
    except Exception as e:
        ctx.add_error(steps.STEP_CREATE_VENV, e)
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 11 — pip install. ──
    pip = ctx.inactive_slot / "bin" / "pip"
    try:
        rc = subprocess.run(
            [
                str(pip),
                "install",
                "--quiet",
                "--index-url",
                index_url,
                "--extra-index-url",
                "https://pypi.org/simple/",
                f"axon-agent-ee[classifier]=={target_version}",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=PIP_TIMEOUT_S,
        )
        if rc.returncode != 0:
            raise UpdateError(
                f"pip install failed rc={rc.returncode}: "
                f"{(rc.stderr or rc.stdout).strip()[-400:]!r}"
            )
        ctx.completed.append(steps.STEP_PIP_INSTALL)
    except Exception as e:
        ctx.add_error(steps.STEP_PIP_INSTALL, e)
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 12 — verify imports + version pins. ──
    try:
        new_versions = probe.probe_versions_in_slot(
            ctx.inactive_slot, timeout_s=VERIFY_IMPORTS_TIMEOUT_S
        )
        if new_versions.ee != target_version:
            raise UpdateError(
                f"verify_imports: ee version {new_versions.ee} != "
                f"target {target_version}"
            )
        ctx.completed.append(steps.STEP_VERIFY_IMPORTS)
    except Exception as e:
        ctx.add_error(steps.STEP_VERIFY_IMPORTS, e)
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 13 — backup unit files. ──
    try:
        _backup_unit_files()
        ctx.completed.append(steps.STEP_BACKUP_UNITS)
    except Exception as e:
        ctx.add_error(steps.STEP_BACKUP_UNITS, e)
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 14 — install new unit files. ──
    try:
        _install_new_unit_files(ctx.inactive_slot)
        ctx.completed.append(steps.STEP_INSTALL_UNITS)
    except Exception as e:
        ctx.add_error(steps.STEP_INSTALL_UNITS, e)
        # Restore unit files we just clobbered.
        try:
            _restore_unit_files()
            health.daemon_reload()
        except Exception:
            logger.exception("partial unit-file restore failed")
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ── Step 15 — daemon-reload. ──
    if health.daemon_reload():
        ctx.completed.append(steps.STEP_DAEMON_RELOAD)
    else:
        ctx.failed.append(steps.STEP_DAEMON_RELOAD)
        # daemon-reload failure is rare and recoverable — but treat it as
        # a hard failure to avoid bringing services up against a stale
        # generator state.
        _restore_unit_files()
        shutil.rmtree(ctx.inactive_slot, ignore_errors=True)
        return _build_response(ctx, AgentUpdateResponse.STATUS_FAILED)

    # ─────────────────────────────────────────────────────────────────
    # Steps 16–19 are the rollback-bracketed window.
    # ─────────────────────────────────────────────────────────────────

    # ── Step 16 — stop S0 (excludes axon-agent-ee.service). ──
    _, fail_stop = health.stop_units(ctx.s0)
    if fail_stop:
        ctx.failed.append(f"{steps.STEP_STOP_S0}:{','.join(fail_stop)}")
        ctx.error_messages.append(f"stop_units failed for {fail_stop}")
        if _execute_rollback(ctx):
            return _build_response(ctx, AgentUpdateResponse.STATUS_ROLLED_BACK)
        return _build_response(
            ctx,
            AgentUpdateResponse.STATUS_FAILED,
            error_message="rollback failed; manual intervention required",
        )
    ctx.completed.append(steps.STEP_STOP_S0)

    # ── Step 17 — atomic symlink swap. ──
    try:
        slots.swap_venv_symlink(ctx.inactive_slot)
        ctx.completed.append(steps.STEP_SWAP_SYMLINK)
    except Exception as e:
        ctx.add_error(steps.STEP_SWAP_SYMLINK, e)
        if _execute_rollback(ctx):
            return _build_response(ctx, AgentUpdateResponse.STATUS_ROLLED_BACK)
        return _build_response(
            ctx,
            AgentUpdateResponse.STATUS_FAILED,
            error_message="rollback failed; manual intervention required",
        )

    # ── Step 18 — start S0. ──
    _, fail_start = health.start_units(ctx.s0)
    if fail_start:
        ctx.failed.append(f"{steps.STEP_START_S0}:{','.join(fail_start)}")
        if _execute_rollback(ctx):
            return _build_response(ctx, AgentUpdateResponse.STATUS_ROLLED_BACK)
        return _build_response(
            ctx,
            AgentUpdateResponse.STATUS_FAILED,
            error_message="rollback failed; manual intervention required",
        )
    ctx.completed.append(steps.STEP_START_S0)

    # ── Step 19 — wait for health. ──
    raw_timeout = getattr(ctx.cmd, "timeout_seconds", 0)
    try:
        timeout_s = float(raw_timeout)
    except (TypeError, ValueError):
        timeout_s = 0.0
    if timeout_s <= 0:
        # 0 (proto3 default), negative, or unparseable → use built-in default.
        timeout_s = DEFAULT_HEALTH_TIMEOUT_S
    ok, still_inactive = health.verify_running(ctx.s0, timeout_s=timeout_s)
    if not ok:
        ctx.failed.append(
            f"{steps.STEP_WAIT_HEALTH}:{','.join(still_inactive)}"
        )
        ctx.error_messages.append(
            f"wait_for_health: still inactive: {still_inactive}"
        )
        if _execute_rollback(ctx):
            return _build_response(ctx, AgentUpdateResponse.STATUS_ROLLED_BACK)
        return _build_response(
            ctx,
            AgentUpdateResponse.STATUS_FAILED,
            error_message="rollback failed; manual intervention required",
        )
    ctx.completed.append(steps.STEP_WAIT_HEALTH)

    # ── Step 20 — restart-self (caller schedules; we just record the step). ──
    ctx.completed.append(steps.STEP_RESTART_SELF)

    # Refresh current versions from the new active slot.
    try:
        ctx.current = probe.probe_versions_in_slot(ctx.inactive_slot)
    except Exception:
        logger.exception("post-swap version probe failed; using target_version")
        ctx.current = VersionSnapshot(
            ee=target_version,
            ce=ctx.previous.ce,
            shared=ctx.previous.shared,
        )

    _append_log_entry(
        {
            "ts": int(time.time() * 1000),
            "event": "update_ok",
            "correlation_id": getattr(ctx.cmd, "correlation_id", ""),
            "from_version": ctx.previous.ee,
            "to_version": ctx.current.ee,
            "active_slot_now": ctx.inactive_slot.name,
        }
    )

    return _build_response(ctx, AgentUpdateResponse.STATUS_OK)
