"""Self-update orchestrator for Axon Agent EE.

The agent installs new wheels into a fresh venv slot, atomically swaps
the live symlink, restarts companion services, and either confirms
healthy or rolls back to the previous slot.

Public surface:

* ``perform_update`` — orchestrate a full update cycle.
* ``perform_version_probe`` — synchronous version snapshot for the
  ``AgentVersionRequest`` MQTT handler.
* ``recover_from_partial_update`` — boot-time recovery probe; called
  once during ``EEAxonAgent.__init__``.

"""

from axon_agent_ee.updater.apply import perform_update
from axon_agent_ee.updater.probe import perform_version_probe
from axon_agent_ee.updater.recovery import recover_from_partial_update

__all__ = [
    "perform_update",
    "perform_version_probe",
    "recover_from_partial_update",
]
