"""PEP 503 simple index helpers.

Used to verify a target version actually has a wheel published before
we tear down the existing install. The controller is the authoritative
source of "latest" for production rollouts; ``resolve_latest`` is for
self-tests only.
"""

import logging
import re
import urllib.error
import urllib.request
from html.parser import HTMLParser
from typing import List, Optional

logger = logging.getLogger(__name__)


DEFAULT_INDEX_URL = "https://taurine-technology.github.io/axon-dist/simple/"

# Wheel filename pattern: axon_agent_ee-0.3.0-py3-none-any.whl
# Note distributions normalise hyphens to underscores in wheel names.
_WHEEL_RE = re.compile(
    r"^(?P<dist>[A-Za-z0-9_]+)-(?P<version>[0-9][0-9A-Za-z.\-+!]*?)-"
    r"py3-none-any\.whl$"
)


class _HrefCollector(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.hrefs: List[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.lower() != "a":
            return
        for k, v in attrs:
            if k.lower() == "href" and v:
                self.hrefs.append(v)
                break


def _normalise_index_url(index_url: str) -> str:
    return index_url if index_url.endswith("/") else index_url + "/"


def _normalise_dist_name(name: str) -> str:
    """PEP 503 normalisation."""
    return re.sub(r"[-_.]+", "-", name).lower()


def _fetch_index_page(index_url: str, package: str, timeout_s: float = 15.0) -> str:
    """GET ``{index_url}/{package}/`` and return the HTML body."""
    url = _normalise_index_url(index_url) + _normalise_dist_name(package) + "/"
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"index GET {url} failed HTTP {e.code}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"index GET {url} failed: {e}") from e


def _list_versions(html: str, package: str) -> List[str]:
    """Parse all wheel filenames in ``html``, return matching versions."""
    collector = _HrefCollector()
    collector.feed(html)
    target_dist = _normalise_dist_name(package).replace("-", "_")
    versions: List[str] = []
    for href in collector.hrefs:
        # href may be a relative URL with query/fragment; strip everything
        # after the filename.
        filename = href.rsplit("/", 1)[-1]
        filename = filename.split("#", 1)[0].split("?", 1)[0]
        m = _WHEEL_RE.match(filename)
        if not m:
            continue
        if _normalise_dist_name(m.group("dist")) != _normalise_dist_name(target_dist):
            continue
        versions.append(m.group("version"))
    return versions


def head_check_wheel(
    index_url: str,
    package: str,
    version: str,
    timeout_s: float = 15.0,
) -> bool:
    """Confirm a wheel for ``package``==``version`` is listed in the index."""
    try:
        html = _fetch_index_page(index_url, package, timeout_s=timeout_s)
    except Exception:
        logger.exception("head_check_wheel: index fetch failed")
        return False
    return version in _list_versions(html, package)


def resolve_latest(
    index_url: str = DEFAULT_INDEX_URL,
    package: str = "axon-agent-ee",
    timeout_s: float = 15.0,
) -> Optional[str]:
    """Return the highest version listed for ``package``, or None.

    Uses ``packaging.version.Version`` ordering when available, falling
    back to lexicographic sort if ``packaging`` isn't importable.
    """
    try:
        html = _fetch_index_page(index_url, package, timeout_s=timeout_s)
    except Exception:
        logger.exception("resolve_latest: index fetch failed")
        return None
    versions = _list_versions(html, package)
    if not versions:
        return None
    try:
        from packaging.version import Version

        return str(max(versions, key=Version))
    except ImportError:
        # Fallback when `packaging` isn't importable. Lexicographic sort
        # would be wrong ("0.10.0" < "0.2.0" as strings), so split each
        # version on '.' and compare as a tuple of ints. Non-numeric
        # suffixes (e.g. PEP 440 pre-releases) are coerced to their
        # leading-digit prefix; if no digits, the segment is 0.
        def _key(v: str):
            parts = []
            for seg in v.split("."):
                digits = ""
                for ch in seg:
                    if ch.isdigit():
                        digits += ch
                    else:
                        break
                parts.append(int(digits) if digits else 0)
            return tuple(parts)

        return max(versions, key=_key)
