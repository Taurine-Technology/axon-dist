"""Boot-time recovery probe.

Called once during ``EEAxonAgent.__init__`` (wrapped in try/except —
recovery must never block agent startup). Three tiers:

* **Tier 1 — Lock present, symlink unchanged:** crashed before step 17.
  Just clear the lock; nothing else to undo.
* **Tier 2 — Lock present, symlink at NEW slot, S0 healthy:** crashed
  after step 17 but services are up. Clear lock and continue.
* **Tier 3 — Lock present, symlink at NEW slot, S0 unhealthy:** crashed
  mid-rollout-window. Execute rollback inline, then ``systemctl
  restart axon-agent-ee.service`` so we re-enter on the rolled-back
  venv.
"""

import json
import logging
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import List, Optional

from axon_agent_ee.updater import health, slots

logger = logging.getLogger(__name__)


SYSTEMD_DIR = Path("/etc/systemd/system")
TIER2_HEALTH_TIMEOUT_S = 10
TIER3_HEALTH_TIMEOUT_S = 30


def _read_last_log_entry(path: Optional[Path] = None) -> Optional[dict]:
    """Return the last newline-delimited-JSON entry or None."""
    if path is None:
        path = slots.LOG_PATH
    if not path.exists():
        return None
    try:
        # Tail-ish: read the last ~16 KiB and split on newlines.
        with path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 16384))
            tail = f.read().decode("utf-8", errors="replace")
        for line in reversed([ln for ln in tail.splitlines() if ln.strip()]):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                continue
    except OSError:
        logger.exception("could not read %s", path)
    return None


def _write_recovery_marker(label: str, detail: dict) -> None:
    entry = {"ts": int(time.time() * 1000), "event": label, **detail}
    try:
        slots.INSTALL_DIR.mkdir(parents=True, exist_ok=True)
        with slots.LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        logger.exception("could not write recovery marker")


def _clear_lock() -> None:
    try:
        slots.LOCK_PATH.unlink(missing_ok=True)
    except OSError:
        logger.exception("could not unlink %s", slots.LOCK_PATH)


def _restore_unit_files() -> None:
    if not slots.UNITS_PREV.exists():
        return
    for src in sorted(slots.UNITS_PREV.glob("axon-agent-*.service")):
        dst = SYSTEMD_DIR / src.name
        try:
            shutil.copy2(src, dst)
        except OSError:
            logger.exception("could not restore %s", dst)


def _execute_recovery_rollback(
    pre_update_slot_name: str,
    s0: List[str],
) -> None:
    """Tier 3 — swap symlink back, restart everything, restart self.

    This function should not return on success: it ends in
    ``os._exit(0)`` so systemd respawns us on the rolled-back venv.

    Wrapped in try/finally so :func:`_clear_lock` ALWAYS runs — leaving
    a stale lock here would loop the device into recovery on every boot.
    """
    pre_update_slot = slots.INSTALL_DIR / pre_update_slot_name
    swap_attempted = False
    rollback_post_swap_ok = False

    try:
        if not pre_update_slot.exists():
            logger.error(
                "Tier 3 rollback aborted: pre-update slot %s missing",
                pre_update_slot,
            )
            _write_recovery_marker(
                "recovery_rollback_aborted_missing_slot",
                {"pre_update_slot": pre_update_slot_name},
            )
            return

        # Stop S0 (currently running on the new code).
        try:
            health.stop_units(s0)
        except Exception:
            logger.exception("Tier 3: stop_units raised; continuing to swap anyway")

        try:
            slots.swap_venv_symlink(pre_update_slot)
            swap_attempted = True
        except Exception:
            logger.exception(
                "Tier 3: swap_venv_symlink back to %s failed", pre_update_slot
            )
            _write_recovery_marker(
                "recovery_rollback_swap_failed",
                {"target": pre_update_slot_name},
            )
            return

        # Post-swap operations restore the previous unit files and bring S0
        # back up. If any of these blow up we still need to clear the lock
        # (handled by the outer finally) and tell ops what happened.
        try:
            _restore_unit_files()
            health.daemon_reload()
            health.start_units(s0)
            rollback_post_swap_ok = True
        except Exception:
            logger.exception("Tier 3: post-swap recovery operations raised")
    finally:
        # Always clear the lock — a stale lock would loop recovery forever.
        _clear_lock()
        if swap_attempted:
            if rollback_post_swap_ok:
                _write_recovery_marker(
                    "recovery_rollback_complete",
                    {"reverted_to": pre_update_slot_name, "s0": s0},
                )
            else:
                _write_recovery_marker(
                    "recovery_rollback_post_swap_failed",
                    {"reverted_to": pre_update_slot_name, "s0": s0},
                )

    # systemd will respawn us on the rolled-back venv via Restart=always.
    try:
        subprocess.Popen(
            ["systemctl", "restart", "axon-agent-ee.service"]
        )
    except Exception:
        logger.exception("systemctl restart self failed; falling through to os._exit")
    time.sleep(5.0)
    logger.warning(
        "Tier 3 rollback issued restart; os._exit(0) as fallback"
    )
    os._exit(0)


def recover_from_partial_update() -> None:
    """Run the boot-time recovery probe. Never raises."""
    try:
        _recover_inner()
    except Exception:
        logger.exception("recovery probe raised — continuing startup")


def _recover_inner() -> None:
    if not slots.LOCK_PATH.exists():
        return  # clean

    log_entry = _read_last_log_entry()
    pre_update_slot_name = (
        log_entry.get("active_slot_at_start", "") if log_entry else ""
    )
    if (
        log_entry is None
        or log_entry.get("event") != "update_start"
        or not pre_update_slot_name
        or pre_update_slot_name not in {"venv-A", "venv-B"}
    ):
        # No usable record. Treat as Tier 1 — just clear the lock. Cover:
        # missing log, wrong event type, missing/empty active_slot_at_start,
        # and any unrecognised slot name (would fail downstream anyway).
        _write_recovery_marker(
            "recovery_lock_without_intent",
            {
                "detail": "missing or invalid update_start log entry",
                "pre_update_slot_name": pre_update_slot_name,
            },
        )
        _clear_lock()
        return

    s0: List[str] = list(log_entry.get("s0", []))

    try:
        active = slots.current_active_slot()
    except slots.SlotError:
        logger.exception("recovery: layout corrupt; clearing lock and bailing")
        _write_recovery_marker(
            "recovery_layout_corrupt",
            {"pre_update_slot": pre_update_slot_name},
        )
        _clear_lock()
        return

    if active.name == pre_update_slot_name:
        # Tier 1 — died before swap.
        _write_recovery_marker(
            "recovery_tier1_pre_swap",
            {"active_slot": active.name},
        )
        _clear_lock()
        return

    # Symlink at the NEW slot.
    ok, still_inactive = health.verify_running(s0, timeout_s=TIER2_HEALTH_TIMEOUT_S)
    if ok:
        # Tier 2 — services healthy on new code. Lucky.
        _write_recovery_marker(
            "recovery_tier2_post_swap_healthy",
            {"active_slot": active.name, "s0": s0},
        )
        _clear_lock()
        return

    # Tier 3 — must rollback.
    _write_recovery_marker(
        "recovery_tier3_post_swap_unhealthy",
        {
            "active_slot": active.name,
            "still_inactive": still_inactive,
            "rollback_target": pre_update_slot_name,
        },
    )
    _execute_recovery_rollback(pre_update_slot_name, s0)
