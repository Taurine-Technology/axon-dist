"""Venv slot management — venv-A / venv-B with atomic symlink swap.

Filesystem layout (post-migration):

    /opt/axon-agent/
    ├── venv  ─►  venv-A         # symlink, what systemd ExecStart uses
    ├── venv-A/                  # one of A/B is active, the other idle
    ├── venv-B/
    ├── units.prev/              # systemd unit-file backups
    ├── update.lock              # filelock; held during apply()
    └── update.log               # newline-delimited json, last 100 ops

Legacy installs (pre-0.3.0) have ``venv`` as a real directory; the
first update migrates it via :func:`migrate_legacy_layout`.
"""

import logging
import os
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


INSTALL_DIR = Path("/opt/axon-agent")
VENV_LINK = INSTALL_DIR / "venv"
SLOT_A = INSTALL_DIR / "venv-A"
SLOT_B = INSTALL_DIR / "venv-B"
UNITS_PREV = INSTALL_DIR / "units.prev"
LOCK_PATH = INSTALL_DIR / "update.lock"
LOG_PATH = INSTALL_DIR / "update.log"


class SlotError(Exception):
    """Raised when slot state is inconsistent with what we expect."""


def _resolve_install_dir(install_dir):
    """Use ``install_dir`` if given, else read the (test-patchable) module global.

    Looking up the module attribute lazily lets tests monkeypatch
    ``INSTALL_DIR`` without having to pass an explicit kwarg through
    every helper.
    """
    if install_dir is not None:
        return install_dir
    return INSTALL_DIR


def _remove_swap_path(path: Path) -> None:
    """Remove ``venv.swap`` regardless of whether it's a symlink, file, or dir.

    We're the only writer of this path, so under normal operation it's
    either a dangling symlink left over from a previous swap or absent.
    Defending against a real directory (or regular file) costs almost
    nothing and keeps the next swap from raising IsADirectoryError if
    something on the device manually populated the path.
    """
    if path.is_symlink():
        # Symlinks must be unlinked, not rmtree'd — rmtree would follow
        # the link and delete the target slot.
        path.unlink()
        return
    if not path.exists():
        return
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()


def is_legacy_layout(install_dir=None) -> bool:
    """Return True if /opt/axon-agent/venv is a real directory (pre-0.3.0)."""
    install_dir = _resolve_install_dir(install_dir)
    venv = install_dir / "venv"
    return venv.is_dir() and not venv.is_symlink()


def current_active_slot(install_dir=None) -> Path:
    """Resolve the venv symlink to its slot directory.

    Raises SlotError if the layout is legacy (real dir) or the symlink
    target is unrecognised.
    """
    install_dir = _resolve_install_dir(install_dir)
    venv = install_dir / "venv"
    if not venv.is_symlink():
        raise SlotError(
            f"{venv} is not a symlink (legacy layout?); migrate first"
        )
    target = os.readlink(venv)
    # Symlink should be relative ("venv-A" / "venv-B"). Accept absolute too.
    if os.path.isabs(target):
        resolved = Path(target)
    else:
        resolved = (install_dir / target).resolve()
    name = resolved.name
    if name not in {"venv-A", "venv-B"}:
        raise SlotError(
            f"venv symlink points at unknown target: {target!r} "
            f"(expected venv-A or venv-B)"
        )
    return install_dir / name


def pick_inactive_slot(install_dir=None) -> Path:
    """Return whichever of venv-A/venv-B is NOT the current active slot."""
    install_dir = _resolve_install_dir(install_dir)
    active = current_active_slot(install_dir)
    if active.name == "venv-A":
        return install_dir / "venv-B"
    return install_dir / "venv-A"


def swap_venv_symlink(target_slot: Path, install_dir=None) -> None:
    """Atomically point /opt/axon-agent/venv at ``target_slot``.

    Uses a temporary symlink + os.replace so the rename is atomic across
    a concurrent reader. Refuses to operate when ``venv`` is a real
    directory — caller must run :func:`migrate_legacy_layout` first.
    """
    install_dir = _resolve_install_dir(install_dir)
    venv = install_dir / "venv"
    if venv.is_dir() and not venv.is_symlink():
        raise SlotError(
            f"{venv} is a real directory; run migrate_legacy_layout() first"
        )

    if target_slot.parent != install_dir:
        raise SlotError(
            f"target_slot {target_slot} is not inside {install_dir}"
        )
    if target_slot.name not in {"venv-A", "venv-B"}:
        raise SlotError(
            f"target_slot {target_slot} is not a recognised slot name"
        )

    tmp = install_dir / "venv.swap"
    _remove_swap_path(tmp)
    # Relative symlink so the layout is movable.
    tmp.symlink_to(target_slot.name)
    os.replace(tmp, venv)
    logger.info("Swapped venv symlink → %s", target_slot.name)


def migrate_legacy_layout(install_dir=None) -> None:
    """Bring the install dir into the venv → venv-A symlink layout.

    Idempotent and tolerant of interrupted prior migrations. Three cases:

    1. ``venv`` is a symlink already → no-op.
    2. ``venv`` is a real directory and ``venv-A`` doesn't exist → rename
       venv → venv-A, then create the relative symlink.
    3. ``venv`` is missing or is a dangling symlink AND ``venv-A`` exists →
       a prior migration crashed between rename and symlink creation.
       Just (re)create the symlink to recover.

    Refuses (raises SlotError) if both the legacy ``venv`` directory AND
    ``venv-A`` already exist — ambiguous, requires manual cleanup.
    """
    install_dir = _resolve_install_dir(install_dir)
    venv = install_dir / "venv"
    slot_a = install_dir / "venv-A"
    tmp = install_dir / "venv.swap"

    # Case 1: already migrated.
    if venv.is_symlink():
        return

    # Case 3: interrupted prior migration — venv is missing or broken,
    # but venv-A is on disk. Recreate the symlink.
    venv_missing = not venv.exists() and not venv.is_symlink()
    if venv_missing and slot_a.is_dir():
        _remove_swap_path(tmp)
        tmp.symlink_to("venv-A")
        os.replace(tmp, venv)
        logger.warning(
            "Recovered interrupted legacy migration: "
            "recreated venv symlink → venv-A"
        )
        return

    # Case 2 (and the only remaining valid state): venv is a real dir.
    if not is_legacy_layout(install_dir):
        # Some other unexpected state (e.g. venv is a regular file).
        # Not legacy, not symlink, not the recoverable case above.
        return
    if slot_a.exists():
        raise SlotError(
            f"legacy {venv} exists alongside {slot_a}; "
            f"manual cleanup required"
        )
    venv.rename(slot_a)
    _remove_swap_path(tmp)
    tmp.symlink_to("venv-A")
    os.replace(tmp, venv)
    logger.info("Migrated legacy venv → venv-A")
