"""Systemd health helpers for the update orchestrator.

Shells out to ``systemctl`` rather than depending on a DBus binding so
this module works in CI containers and on minimal device images.
"""

import logging
import subprocess
import time
from typing import Iterable, List, Tuple

logger = logging.getLogger(__name__)

# axon-agent-ee.service is the agent itself — the process running the
# updater. It must be excluded from the stop/start cycle and restarted
# explicitly at the end.
DEFAULT_EXCLUDES = ("axon-agent-ee.service",)


def snapshot_running_services(
    exclude: Iterable[str] = DEFAULT_EXCLUDES,
) -> List[str]:
    """Return sorted list of active axon-agent-* units, minus ``exclude``."""
    excluded = set(exclude)
    try:
        result = subprocess.run(
            [
                "systemctl",
                "list-units",
                "--type=service",
                "--state=active",
                "--no-pager",
                "--no-legend",
                "--plain",
                "axon-agent-*.service",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except subprocess.SubprocessError:
        logger.exception("systemctl list-units failed")
        return []

    units: List[str] = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        # First column is the unit name.
        unit = line.split()[0]
        if unit in excluded:
            continue
        units.append(unit)
    return sorted(units)


def _is_active(unit: str) -> bool:
    try:
        rc = subprocess.run(
            ["systemctl", "is-active", "--quiet", unit],
            check=False,
            timeout=10,
        ).returncode
    except subprocess.SubprocessError:
        return False
    return rc == 0


def verify_running(
    units: List[str],
    timeout_s: float,
    poll_s: float = 2.0,
) -> Tuple[bool, List[str]]:
    """Poll ``is-active --quiet`` for each unit until all active or timeout.

    Returns ``(all_ok, still_inactive)``. An empty unit list is treated
    as trivially OK.
    """
    if not units:
        return True, []
    deadline = time.monotonic() + max(timeout_s, 0.0)
    still_inactive: List[str] = list(units)
    while True:
        still_inactive = [u for u in units if not _is_active(u)]
        if not still_inactive:
            return True, []
        if time.monotonic() >= deadline:
            return False, still_inactive
        time.sleep(poll_s)


def stop_units(units: List[str]) -> Tuple[List[str], List[str]]:
    """systemctl stop each unit. Returns ``(stopped, failed)``."""
    stopped: List[str] = []
    failed: List[str] = []
    for unit in units:
        try:
            rc = subprocess.run(
                ["systemctl", "stop", unit],
                check=False,
                capture_output=True,
                timeout=30,
            ).returncode
        except subprocess.SubprocessError:
            logger.exception("systemctl stop %s raised", unit)
            failed.append(unit)
            continue
        if rc == 0:
            stopped.append(unit)
        else:
            failed.append(unit)
    return stopped, failed


def start_units(units: List[str]) -> Tuple[List[str], List[str]]:
    """systemctl start each unit. Returns ``(started, failed)``."""
    started: List[str] = []
    failed: List[str] = []
    for unit in units:
        try:
            rc = subprocess.run(
                ["systemctl", "start", unit],
                check=False,
                capture_output=True,
                timeout=30,
            ).returncode
        except subprocess.SubprocessError:
            logger.exception("systemctl start %s raised", unit)
            failed.append(unit)
            continue
        if rc == 0:
            started.append(unit)
        else:
            failed.append(unit)
    return started, failed


def daemon_reload() -> bool:
    try:
        rc = subprocess.run(
            ["systemctl", "daemon-reload"],
            check=False,
            capture_output=True,
            timeout=30,
        ).returncode
    except subprocess.SubprocessError:
        logger.exception("systemctl daemon-reload raised")
        return False
    return rc == 0
