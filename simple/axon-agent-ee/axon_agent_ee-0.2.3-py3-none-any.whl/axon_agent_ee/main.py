"""EE Agent main entry point.

EEAxonAgent extends AxonAgent, adding EE companion services
(EE classifier) to the service registry. All CE behavior
(discovery, provisioning, MQTT, CE companion services) is
inherited unchanged.
"""

import logging

from axon_agent.main import AxonAgent

from axon_agent_ee.service_registry_ee import register_ee_services

logger = logging.getLogger(__name__)


class EEAxonAgent(AxonAgent):
    """Enterprise Edition agent.

    Extends AxonAgent by registering EE companion services
    alongside the CE services. super().__init__() calls
    register_ce_services(); we then add EE services.
    """

    def __init__(self):
        super().__init__()
        register_ee_services()


def main():
    """Entry point for axon-agent-ee."""
    from axon_agent.base_agent import setup_logging

    setup_logging("axon-agent-ee")
    agent = EEAxonAgent()
    agent.run()


if __name__ == "__main__":
    main()
