"""Axon Agent EE - Enterprise Edition agent for the Axon platform."""

__version__ = "0.3.6"
