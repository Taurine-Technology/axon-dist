"""EE service registration.

Registers EE-specific companion services. Called AFTER
register_ce_services() — adds only EE services to avoid
double-registration of CE services.
"""

import logging
import os
import subprocess

from axon_agent.service_registry import (
    CompanionService,
    register_service,
)

logger = logging.getLogger(__name__)

# Mirror of CE's SNIFFER_CONFIG_PATH gating: the classifier-install MQTT
# handler in ClassifierConfigHandler writes this file and then enables +
# starts the unit itself. Without the file, the unit exits immediately
# with "Classifier config not found" — there's nothing useful for the
# agent's companion-service driver to do until the controller has
# provisioned us.
CLASSIFIER_CONFIG_PATH = "/etc/axon/classifier_config.json"


def _start_ee_classifier():
    """Start the EE classifier systemd service."""
    try:
        subprocess.Popen(
            ["systemctl", "start", "axon-agent-ee-classifier.service"]
        )
    except Exception as e:
        logger.error(f"Failed to start EE classifier service: {e}")


def register_ee_services():
    """Register EE-specific companion services.

    Should be called after register_ce_services() has already
    registered all CE services. Only adds EE services.
    """
    from axon_agent.service_registry import StartCondition

    if not os.path.exists(CLASSIFIER_CONFIG_PATH):
        logger.info(
            "Skipping EE classifier registration: %s not present. "
            "The controller's classifier-install handler will provision "
            "the unit; subsequent agent restarts will pick it up.",
            CLASSIFIER_CONFIG_PATH,
        )
        return

    register_service(
        CompanionService(
            service_name="axon-agent-ee-classifier.service",
            subprocess_starter=_start_ee_classifier,
            display_name="EE Classifier",
            condition=StartCondition.ALWAYS,
        )
    )
    logger.debug("Registered EE companion services")
