"""EE-specific configuration loaded from /etc/axon/ee_config.json."""

import json
import logging
import os
from dataclasses import dataclass, fields

logger = logging.getLogger(__name__)

EE_CONFIG_PATHS = ["/etc/axon/ee_config.json", "./ee_config.json"]


@dataclass
class EEConfig:
    """Enterprise Edition configuration.

    Loaded from /etc/axon/ee_config.json (production) or
    ./ee_config.json (development). Falls back to defaults
    if no config file is found.

    Note: collector_token is NOT stored here. It is read from
    the CE config (/etc/axon/config.json) since it is a per-site
    secret shared with the main agent.
    """

    collector_endpoint: str = "data.taurinetech.xyz:443"
    collector_tls: bool = True
    ee_num_packets: int = 10
    ee_max_packet_bytes: int = 1500
    batch_size: int = 100
    batch_timeout_seconds: float = 10.0
    geo_cache_path: str = "/var/lib/axon/geo_cache.json"
    geo_cache_ttl_hours: int = 24

    @classmethod
    def load(cls) -> "EEConfig":
        """Load EE config from standard paths, falling back to defaults."""
        for path in EE_CONFIG_PATHS:
            if os.path.exists(path):
                try:
                    with open(path) as f:
                        data = json.load(f)
                    valid_fields = {field.name for field in fields(cls)}
                    filtered = {
                        k: v for k, v in data.items() if k in valid_fields
                    }
                    logger.info(f"Loaded EE config from {path}")
                    return cls(**filtered)
                except Exception as e:
                    logger.error(f"Failed to load EE config from {path}: {e}")
        logger.info("No EE config found, using defaults")
        return cls()
