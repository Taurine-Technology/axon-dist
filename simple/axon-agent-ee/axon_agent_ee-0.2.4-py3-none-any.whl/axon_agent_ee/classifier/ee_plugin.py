"""EE Classifier Plugin — extends CE with raw packet capture.

Collects up to ee_num_packets full IP packets per flow in
flow.udps.ee_raw_packets (parallel to CE's flow.udps.payload_samples).
On flow expire, builds an EEFlowRecord and puts it on ee_flow_queue
for the gRPC data client to send to the central collector.

CE behavior (payload collection, classification, policy enforcement)
is completely unchanged.
"""

import logging
import queue
import time

from axon_agent.classifier.classifier import ClassifierPlugin

from axon_agent_ee.data_client.grpc_client import EEFlowRecord

logger = logging.getLogger(__name__)


class EEClassifierPlugin(ClassifierPlugin):
    """Extends CE ClassifierPlugin with raw packet capture for EE.

    Captures up to ee_num_packets raw IP packets (up to ee_max_bytes
    each) per flow. Sends all captured packets to ee_flow_queue when
    the flow expires. This is separate from CE's payload_samples path.

    Key design points:
    - CE uses flow.udps.payload_samples (5 x 225B). EE uses
      flow.udps.ee_raw_packets (10 x 1500B). No overlap.
    - CE sends at classification time (~5 pkts) via flow_queue.
      EE sends at expire time via ee_flow_queue.
    - After CE sets ready=True, super().on_update() returns early,
      but _collect_raw_packet still runs (Python doesn't propagate
      the parent's return).
    """

    def __init__(
        self, ee_flow_queue=None, ee_num_packets=10,
        ee_max_bytes=1500, **kwargs
    ):
        super().__init__(**kwargs)
        self.ee_flow_queue = ee_flow_queue
        self.ee_num_packets = ee_num_packets
        self.ee_max_bytes = ee_max_bytes

    def on_init(self, packet, flow):
        """Initialize CE state + EE raw packet tracking."""
        super().on_init(packet, flow)
        flow.udps.ee_raw_packets = []
        flow.udps.ee_packet_count = 0
        self._collect_raw_packet(packet, flow)

    def on_update(self, packet, flow):
        """CE processing + EE raw packet collection.

        After CE sets ready=True, super().on_update() returns early
        but this method still executes _collect_raw_packet, allowing
        collection of packets 6-10 after CE has finished at ~5.
        """
        super().on_update(packet, flow)
        self._collect_raw_packet(packet, flow)

    def on_expire(self, flow):
        """Send EE data before CE expire logic."""
        self._send_ee_flow(flow)
        super().on_expire(flow)

    def _collect_raw_packet(self, packet, flow):
        """Capture raw IP packet bytes for EE data pipeline.

        Stores (raw_bytes, timestamp_us) tuples in
        flow.udps.ee_raw_packets. Stops after ee_num_packets
        are collected. Skips flows marked as already-processed.
        """
        if getattr(flow.udps, "skip", False):
            return
        if flow.udps.ee_packet_count >= self.ee_num_packets:
            return
        raw = getattr(packet, "ip_packet", None)
        if raw:
            raw_bytes = bytes(raw)
            if raw_bytes:
                flow.udps.ee_raw_packets.append(
                    (
                        raw_bytes[: self.ee_max_bytes],
                        int(time.time() * 1_000_000),
                    )
                )
                flow.udps.ee_packet_count += 1

    def _send_ee_flow(self, flow):
        """Build EEFlowRecord and put on ee_flow_queue.

        Called during on_expire. Skips flows that are marked as
        already-processed or have no captured packets.
        """
        if getattr(flow.udps, "skip", False):
            return
        if not getattr(flow.udps, "ee_raw_packets", None):
            return
        if self.ee_flow_queue is None:
            return

        record = EEFlowRecord(
            src_ip=getattr(flow, "src_ip", ""),
            dst_ip=getattr(flow, "dst_ip", ""),
            src_port=getattr(flow, "src_port", 0),
            dst_port=getattr(flow, "dst_port", 0),
            src_mac=getattr(flow, "src_mac", ""),
            dst_mac=getattr(flow, "dst_mac", ""),
            is_tcp=getattr(flow, "protocol", 6) == 6,
            application_name=getattr(flow, "application_name", "") or "",
            requested_server_name=(
                getattr(flow, "requested_server_name", "") or ""
            ),
            bidirectional_packets=getattr(
                flow, "bidirectional_packets", 0
            ),
            bidirectional_bytes=getattr(flow, "bidirectional_bytes", 0),
            flow_duration_ms=getattr(
                flow, "bidirectional_duration_ms", 0
            ),
            timestamp_ms=int(
                getattr(flow, "bidirectional_first_seen_ms", 0)
            ),
            ndpi_confidence=float(
                getattr(flow, "application_confidence", 0)
            ),
            raw_packets=flow.udps.ee_raw_packets,
        )

        try:
            self.ee_flow_queue.put(record, timeout=1.0)
        except queue.Full:
            logger.debug("EE flow queue full, dropping flow")
        except Exception as e:
            logger.debug(f"Failed to queue EE flow: {e}")
