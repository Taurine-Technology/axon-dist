"""EE Classifier Agent — extends CE with gRPC data pipeline.

Overrides ClassifierAgent's _create_plugin() factory method to use
EEClassifierPlugin instead of ClassifierPlugin. Sets up the gRPC
data client and geolocation resolver in _setup().

Lifecycle (inherited from BaseAgent.run()):
  1. _load_config() — CE config + EE config + collector_token
  2. _connect_mqtt() — MQTT connection [inherited]
  3. _setup() — geo resolve + create queue + start gRPC client
  4. _run_loop() — calls _create_collector() [inherited] then
     _create_plugin() [overridden] then runs NFStreamer
  5. _cleanup() — stop gRPC client + CE cleanup
"""

import logging
import multiprocessing

from axon_agent.classifier.agent import ClassifierAgent
from axon_agent.config import ConfigManager

from axon_agent_ee import __version__
from axon_agent_ee.classifier.ee_plugin import EEClassifierPlugin
from axon_agent_ee.data_client.grpc_client import EEFlowDataClient
from axon_agent_ee.ee_config import EEConfig
from axon_agent_ee.geolocation.geo_resolver import GeoResolver

logger = logging.getLogger(__name__)


class EEClassifierAgent(ClassifierAgent):
    """Extends CE ClassifierAgent with EE data pipeline.

    Uses factory method override (_create_plugin) to swap in
    EEClassifierPlugin. Sets up gRPC client and geolocation
    in _setup(), which runs before _run_loop().
    """

    def __init__(self):
        super().__init__()
        self.ee_config = None
        self.ee_data_client = None
        self.ee_flow_queue = None
        self.geo_info = None
        self.collector_token = ""

    def _load_config(self) -> bool:
        """Load CE config, then EE config and collector_token."""
        if not super()._load_config():
            return False

        self.ee_config = EEConfig.load()

        # Read collector_token from CE's /etc/axon/config.json
        ce_config = ConfigManager().load_config()
        self.collector_token = (
            ce_config.get("collector_token", "") if ce_config else ""
        )
        if not self.collector_token:
            logger.warning(
                "No collector_token in config.json — "
                "EE data will not authenticate"
            )
        return True

    def _setup(self):
        """Resolve geolocation and start gRPC client before _run_loop."""
        super()._setup()
        logger.info(f"EE Classifier version: {__version__}")

        # Resolve geolocation (cached to disk)
        self.geo_info = GeoResolver(
            cache_path=self.ee_config.geo_cache_path,
            cache_ttl_hours=self.ee_config.geo_cache_ttl_hours,
        ).resolve()
        logger.info(
            f"Geolocation: {self.geo_info.country_code} "
            f"({self.geo_info.region})"
        )

        # Create EE flow queue (plugin writes, gRPC client reads)
        self.ee_flow_queue = multiprocessing.Queue(maxsize=500)

        # Start gRPC data client (background batch sender thread)
        self.ee_data_client = EEFlowDataClient(
            ee_config=self.ee_config,
            device_id=self.device_id,
            site_id=self.site_id,
            switch_id=self.bridge_name or "",
            collector_token=self.collector_token,
            geo_info=self.geo_info,
            ee_flow_queue=self.ee_flow_queue,
        )
        self.ee_data_client.start()

    def _create_plugin(self):
        """Override factory: use EEClassifierPlugin.

        Returns an EEClassifierPlugin with the same CE params plus
        the EE flow queue and packet capture settings.
        """
        return EEClassifierPlugin(
            num_bytes=self.num_bytes,
            num_packets=self.num_packets,
            flow_queue=self.collector.get_queue(),
            flow_converter=self.collector.get_flow_converter(),
            policy_cache=(
                self.policy_cache if self.policy_enabled else None
            ),
            bridge=(
                self.bridge_name if self.policy_enabled else None
            ),
            ee_flow_queue=self.ee_flow_queue,
            ee_num_packets=self.ee_config.ee_num_packets,
            ee_max_bytes=self.ee_config.ee_max_packet_bytes,
        )

    def _cleanup(self):
        """Stop gRPC client, then CE cleanup."""
        if self.ee_data_client:
            self.ee_data_client.stop()
        super()._cleanup()


def main():
    """Entry point for axon-agent-ee-classifier."""
    agent = EEClassifierAgent()
    agent.run()


if __name__ == "__main__":
    main()
