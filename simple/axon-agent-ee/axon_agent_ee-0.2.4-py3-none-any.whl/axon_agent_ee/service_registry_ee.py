"""EE service registration.

Registers EE-specific companion services. Called AFTER
register_ce_services() — adds only EE services to avoid
double-registration of CE services.
"""

import logging
import subprocess

from axon_agent.service_registry import (
    CompanionService,
    register_service,
)

logger = logging.getLogger(__name__)


def _start_ee_classifier():
    """Start the EE classifier systemd service."""
    try:
        subprocess.Popen(
            ["systemctl", "start", "axon-agent-ee-classifier.service"]
        )
    except Exception as e:
        logger.error(f"Failed to start EE classifier service: {e}")


def register_ee_services():
    """Register EE-specific companion services.

    Should be called after register_ce_services() has already
    registered all CE services. Only adds EE services.
    """
    from axon_agent.service_registry import StartCondition
    register_service(
        CompanionService(
            service_name="axon-agent-ee-classifier.service",
            subprocess_starter=_start_ee_classifier,
            display_name="EE Classifier",
            condition=StartCondition.ALWAYS,
        )
    )
    logger.debug("Registered EE companion services")
