"""Axon Agent EE - Enterprise Edition agent for the Axon platform."""

__version__ = "0.2.4"
