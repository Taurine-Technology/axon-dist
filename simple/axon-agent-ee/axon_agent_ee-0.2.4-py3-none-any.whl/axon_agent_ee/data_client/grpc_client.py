"""gRPC client for streaming flow data to the central data collector.

Manages a persistent gRPC channel and a background thread that drains
flows from a multiprocessing.Queue, batches them, compresses with zstd,
and streams them to the collector via the IngestFlows RPC.
"""

import logging
import queue
import threading
import time
from dataclasses import dataclass

import grpc
import zstandard as zstd

from axon_shared.proto import ee_data_service_pb2, ee_data_service_pb2_grpc

from axon_agent_ee.ee_config import EEConfig
from axon_agent_ee.geolocation.geo_resolver import GeoInfo

logger = logging.getLogger(__name__)


@dataclass
class EEFlowRecord:
    """Pickle-friendly flow record passed through multiprocessing.Queue.

    Constructed by EEClassifierPlugin._send_ee_flow() in the NFStream
    subprocess, consumed by EEFlowDataClient._batch_sender_loop() in
    the main process.
    """

    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    src_mac: str
    dst_mac: str
    is_tcp: bool
    application_name: str
    requested_server_name: str
    bidirectional_packets: int
    bidirectional_bytes: int
    flow_duration_ms: int
    timestamp_ms: int
    ndpi_confidence: float
    raw_packets: list  # list of (bytes, int) tuples: (data, timestamp_us)


class EEFlowDataClient:
    """Manages gRPC connection and background batch sender thread.

    Drains EEFlowRecords from a multiprocessing.Queue, batches them
    (up to batch_size or batch_timeout_seconds), compresses with zstd,
    and sends via the FlowDataService.IngestFlows client-streaming RPC.
    """

    def __init__(
        self,
        ee_config: EEConfig,
        device_id: str,
        site_id: str,
        switch_id: str,
        collector_token: str,
        geo_info: GeoInfo,
        ee_flow_queue,
    ):
        self._config = ee_config
        self._device_id = device_id
        self._site_id = site_id
        self._switch_id = switch_id
        self._collector_token = collector_token
        self._geo_info = geo_info
        self._queue = ee_flow_queue
        self._running = False
        self._thread = None
        self._compressor = zstd.ZstdCompressor(level=3)
        self._channel = None
        self._stub = None

    def start(self):
        """Start the gRPC channel and batch sender thread."""
        self._running = True
        self._channel = self._create_channel()
        self._stub = ee_data_service_pb2_grpc.FlowDataServiceStub(
            self._channel
        )
        self._thread = threading.Thread(
            target=self._batch_sender_loop, daemon=True, name="ee-grpc-sender"
        )
        self._thread.start()
        logger.info(
            f"EE data client started, endpoint={self._config.collector_endpoint}"
        )

    def stop(self):
        """Signal shutdown, flush remaining flows, and close channel."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=15)
        if self._channel:
            try:
                self._channel.close()
            except Exception:
                pass
        logger.info("EE data client stopped")

    def _create_channel(self):
        """Create gRPC channel with TLS or insecure based on config."""
        if self._config.collector_tls:
            return grpc.secure_channel(
                self._config.collector_endpoint,
                grpc.ssl_channel_credentials(),
            )
        return grpc.insecure_channel(self._config.collector_endpoint)

    def _batch_sender_loop(self):
        """Background thread: drain queue, batch flows, send via gRPC.

        Batches up to batch_size flows or flushes after
        batch_timeout_seconds of waiting. On gRPC errors, applies
        exponential backoff (2s -> 60s). Flushes remaining flows
        on shutdown.
        """
        backoff = 2
        max_backoff = 60
        batch = []

        while self._running:
            # Block for first record (with timeout for shutdown check)
            try:
                record = self._queue.get(
                    timeout=self._config.batch_timeout_seconds
                )
                batch.append(record)
            except queue.Empty:
                pass

            # Drain remaining without blocking (up to batch_size)
            while len(batch) < self._config.batch_size:
                try:
                    batch.append(self._queue.get_nowait())
                except queue.Empty:
                    break

            if not batch:
                continue

            # Send batch via gRPC
            try:
                grpc_batch = self._build_batch(batch)
                response = self._stub.IngestFlows(iter([grpc_batch]))
                if response.success:
                    logger.debug(
                        f"Sent {len(batch)} EE flows, "
                        f"accepted={response.flows_accepted}"
                    )
                else:
                    logger.warning(
                        f"Server rejected batch: {response.error_message}"
                    )
                batch = []
                backoff = 2
            except grpc.RpcError as e:
                logger.warning(
                    f"gRPC send failed ({e.code()}): {e.details()}, "
                    f"retrying in {backoff}s "
                    f"({len(batch)} flows buffered)"
                )
                time.sleep(backoff)
                backoff = min(backoff * 2, max_backoff)
            except Exception as e:
                logger.error(
                    f"Unexpected error sending EE batch: {e}",
                    exc_info=True,
                )
                batch = []

        # Flush remaining on shutdown
        # Drain anything left in the queue
        while True:
            try:
                batch.append(self._queue.get_nowait())
            except queue.Empty:
                break

        if batch:
            try:
                grpc_batch = self._build_batch(batch)
                self._stub.IngestFlows(iter([grpc_batch]))
                logger.info(f"Flushed {len(batch)} EE flows on shutdown")
            except Exception:
                logger.warning(
                    f"Failed to flush {len(batch)} EE flows on shutdown"
                )

    def _build_batch(self, records):
        """Convert list of EEFlowRecords to a compressed EEFlowBatch.

        Serializes records into an EEFlows protobuf, compresses with
        zstd, and wraps in an EEFlowBatch with device metadata,
        geolocation, and auth token.
        """
        ee_flows = ee_data_service_pb2.EEFlows()

        for rec in records:
            flow = ee_flows.flows.add()
            flow.timestamp_ms = rec.timestamp_ms
            flow.src_ip = rec.src_ip
            flow.dst_ip = rec.dst_ip
            flow.src_port = rec.src_port
            flow.dst_port = rec.dst_port
            flow.src_mac = rec.src_mac
            flow.dst_mac = rec.dst_mac
            flow.is_tcp = rec.is_tcp
            flow.application_name = rec.application_name
            flow.requested_server_name = rec.requested_server_name
            flow.bidirectional_packets = rec.bidirectional_packets
            flow.bidirectional_bytes = rec.bidirectional_bytes
            flow.flow_duration_ms = rec.flow_duration_ms
            flow.ndpi_confidence = rec.ndpi_confidence

            for raw_data, ts_us in rec.raw_packets:
                pkt = flow.raw_packets.add()
                pkt.data = raw_data
                pkt.timestamp_us = ts_us

        compressed = self._compressor.compress(
            ee_flows.SerializeToString()
        )

        return ee_data_service_pb2.EEFlowBatch(
            device_id=self._device_id,
            site_id=self._site_id,
            switch_id=self._switch_id,
            timestamp_ms=int(time.time() * 1000),
            region=self._geo_info.region,
            country_code=self._geo_info.country_code,
            latitude=self._geo_info.latitude,
            longitude=self._geo_info.longitude,
            compressed_flows=compressed,
            flow_count=len(records),
            auth_token=self._collector_token,
        )
