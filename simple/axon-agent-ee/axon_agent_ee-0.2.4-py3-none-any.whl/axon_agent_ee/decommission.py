"""Graceful uninstall orchestrator for Axon Agent EE.

Invoked by EEAxonAgent when the controller publishes a
DeviceUninstallCommand on axon/control/{site_id}/{device_id}/device/uninstall.

Two modes keyed off cmd.remove_agent_code:

* Terminal mode (remove_agent_code=true): stop everything, wipe code +
  venv, and let the caller run ``systemctl stop axon-agent-ee.service``.
  The switch returns to a pre-adoption state.

* Re-enrollment mode (remove_agent_code=false): stop data-plane services
  and optionally wipe credentials, then let the caller ``os._exit(0)`` so
  systemd's Restart=always resurrects us into discovery phase.

CRITICAL ORDERING INVARIANTS
----------------------------
1. Data-plane services stop BEFORE bridge teardown (no new flow-mods).
2. Bridge teardown runs BEFORE axon-agent-ovs stops (ovs owns the ops).
3. axon-agent-ee.service unit file is NEVER removed — the orphaned file
   is harmless (ExecStart points at a deleted venv, so manual starts
   fail cleanly) and ``systemctl stop`` on a not-found unit is
   systemd-version-dependent.
4. /opt/axon-agent/ removal is the LAST filesystem op before response
   publish — after shutil.rmtree returns, no Python imports can resolve.
5. CE classifier unmask runs unconditionally — insurance for the
   re-enrollment path (a masked unit blocks the next adoption).
"""

import logging
import os
import shutil
import subprocess
from typing import List, Optional

from axon_agent.bridge_utils import delete_bridge_and_cleanup
from axon_agent.config import ConfigManager
from axon_agent.mqtt_client import MQTTClient
from axon_shared.mqtt.topics import status_topic
from axon_shared.proto.device_lifecycle_messages_pb2 import (
    DeviceUninstallCommand,
    DeviceUninstallResponse,
)

logger = logging.getLogger(__name__)


# Services stopped in step 2 (ordered — data plane first, control
# services last).
DATA_PLANE_SERVICES = [
    "axon-agent-ee-classifier-flow-stats.service",
    "axon-agent-ee-classifier.service",
    "axon-agent-sniffer.service",
    "axon-agent-flow-stats.service",
    "axon-agent-port-stats.service",
    "axon-agent-port-link.service",
    "axon-agent-monitor.service",
    "axon-agent-uptime.service",
    "axon-agent-healthcheck.service",
]

# Adjunct units disabled in step 5, regardless of remove_agent_code.
# These are safe to leave disabled because the controller re-installs /
# re-enables them via the classifier-install MQTT flow on next adoption.
ADJUNCT_DISABLE_UNITS = [
    "axon-agent-classifier.service",
    "axon-agent-classifier-flow-stats.service",
    "axon-agent-ee-classifier.service",
    "axon-agent-ee-classifier-flow-stats.service",
]

# Unit files removed ONLY when remove_agent_code=true (terminal mode).
# Note: axon-agent-ee.service is deliberately NOT in this list.
TERMINAL_UNIT_FILES = [
    "/etc/systemd/system/axon-agent-ee-classifier.service",
    "/etc/systemd/system/axon-agent-ee-classifier-flow-stats.service",
    "/etc/systemd/system/axon-agent.service",
    "/etc/systemd/system/axon-agent-monitor.service",
    "/etc/systemd/system/axon-agent-ovs.service",
    "/etc/systemd/system/axon-agent-uptime.service",
    "/etc/systemd/system/axon-agent-port-stats.service",
    "/etc/systemd/system/axon-agent-port-link.service",
    "/etc/systemd/system/axon-agent-flow-stats.service",
    "/etc/systemd/system/axon-agent-sniffer.service",
    "/etc/systemd/system/axon-agent-healthcheck.service",
    "/etc/systemd/system/axon-agent-classifier.service",
    "/etc/systemd/system/axon-agent-classifier-flow-stats.service",
]

# Units disabled alongside the terminal-mode unit-file rm's.
TERMINAL_DISABLE_UNITS = [
    "axon-agent-ee.service",
    "axon-agent-ee-classifier.service",
    "axon-agent-ee-classifier-flow-stats.service",
    "axon-agent.service",
    "axon-agent-monitor.service",
    "axon-agent-ovs.service",
    "axon-agent-uptime.service",
    "axon-agent-port-stats.service",
    "axon-agent-port-link.service",
    "axon-agent-flow-stats.service",
    "axon-agent-sniffer.service",
    "axon-agent-healthcheck.service",
]

# Credential + cache paths wiped when remove_credentials=true.
CREDENTIAL_FILES = [
    "/etc/axon/config.json",
    "/etc/axon/bootstrap.json",
    "/etc/axon/classifier_config.json",
    "/etc/axon/sniffer_config.json",
    "/etc/axon/ee_config.json",
    # /opt/axon-agent/ fallback copies that install.sh recognizes.
    "/opt/axon-agent/config.json",
    "/opt/axon-agent/bootstrap.json",
    "/opt/axon-agent/classifier_config.json",
    "/opt/axon-agent/sniffer_config.json",
    "/opt/axon-agent/ee_config.json",
]

OVS_DROPIN_FILE = (
    "/etc/systemd/system/axon-agent-ovs.service.d/10-ee-classifier-override.conf"
)
OVS_DROPIN_DIR = "/etc/systemd/system/axon-agent-ovs.service.d"

ETC_AXON_DIR = "/etc/axon"
VAR_LIB_AXON_DIR = "/var/lib/axon"
OPT_AXON_AGENT_DIR = "/opt/axon-agent"


def _systemctl(*args: str, timeout: float = 30.0) -> int:
    """Run systemctl with check=False and return the returncode.

    We never raise on systemctl failure — the caller records it and
    moves on.
    """
    try:
        result = subprocess.run(
            ["systemctl", *args],
            check=False,
            capture_output=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            stderr = (result.stderr or b"").decode("utf-8", errors="replace").strip()
            logger.debug(
                f"systemctl {' '.join(args)} rc={result.returncode} stderr={stderr!r}"
            )
        return result.returncode
    except subprocess.TimeoutExpired:
        logger.warning(f"systemctl {' '.join(args)} timed out after {timeout}s")
        return -1
    except Exception as e:
        logger.warning(f"systemctl {' '.join(args)} raised: {e}")
        return -1


class _StepRecorder:
    """Tracks completed and failed steps across the orchestrator.

    Each ``run(step_name, fn)`` call wraps a single step: if ``fn`` raises
    or returns False-ish on its own terms, the step is recorded as failed
    and the orchestrator continues.
    """

    def __init__(self) -> None:
        self.completed: List[str] = []
        self.failed: List[str] = []
        self.error_messages: List[str] = []

    def run(self, step_name: str, fn, *args, **kwargs) -> bool:
        """Run ``fn`` under the step name.

        ``fn`` may either return a bool (False == failure) or raise. Any
        other truthy return (or None) counts as success.
        """
        try:
            result = fn(*args, **kwargs)
            if result is False:
                self.failed.append(step_name)
                logger.warning(f"Step failed: {step_name}")
                return False
            self.completed.append(step_name)
            logger.info(f"Step completed: {step_name}")
            return True
        except Exception as e:
            self.failed.append(step_name)
            self.error_messages.append(f"{step_name}: {e}")
            logger.exception(f"Step raised: {step_name}")
            return False


def _stop_service(service: str) -> bool:
    rc = _systemctl("stop", service)
    # systemctl stop on a not-installed unit returns non-zero but we
    # treat it as "nothing to do" — the outcome matches success.
    # Distinguishing is version-dependent, so we check load state.
    if rc == 0:
        return True
    # Inactive or not-found → still a success for our purposes.
    load_state = _systemctl_show_property(service, "LoadState")
    active_state = _systemctl_show_property(service, "ActiveState")
    if load_state in {"not-found", "masked"}:
        logger.debug(f"{service}: {load_state}, treating stop as no-op")
        return True
    if active_state in {"inactive", "failed"}:
        logger.debug(f"{service}: already {active_state}, treating stop as no-op")
        return True
    return False


def _systemctl_show_property(unit: str, prop: str) -> Optional[str]:
    try:
        out = subprocess.run(
            ["systemctl", "show", "--property", prop, "--value", unit],
            check=False,
            capture_output=True,
            timeout=10,
        )
        return out.stdout.decode("utf-8", errors="replace").strip()
    except Exception:
        return None


def _disable_service(service: str) -> bool:
    rc = _systemctl("disable", service)
    # disable returns non-zero when the unit is already disabled or
    # doesn't exist. That's fine for an uninstall path.
    return rc == 0 or _systemctl_show_property(service, "LoadState") in {
        "not-found",
        "masked",
    }


def _unmask_service(service: str) -> bool:
    rc = _systemctl("unmask", service)
    # unmask on an already-unmasked or absent unit returns non-zero.
    # Either way, the end state is "not masked" → success.
    if rc == 0:
        return True
    load_state = _systemctl_show_property(service, "LoadState")
    return load_state != "masked"


def _remove_file(path: str) -> bool:
    try:
        if os.path.exists(path) or os.path.islink(path):
            os.remove(path)
            logger.debug(f"Removed {path}")
        else:
            logger.debug(f"No-op rm: {path} absent")
        return True
    except Exception:
        raise


def _rmdir_if_empty(path: str) -> bool:
    try:
        if os.path.isdir(path):
            try:
                os.rmdir(path)
                logger.debug(f"Removed empty dir {path}")
            except OSError as e:
                # ENOTEMPTY is fine; we only delete if empty.
                logger.debug(f"rmdir {path} skipped: {e}")
        return True
    except Exception:
        raise


def _rmtree(path: str, ignore_errors: bool = False) -> bool:
    if not os.path.exists(path):
        logger.debug(f"No-op rmtree: {path} absent")
        return True
    shutil.rmtree(path, ignore_errors=ignore_errors)
    logger.debug(f"Removed tree {path}")
    return True


def _publish_early_ping(
    mqtt_client: MQTTClient,
    site_id: str,
    device_id: str,
    correlation_id: str,
) -> bool:
    """Best-effort early ack so the UI doesn't go silent during teardown."""
    topic = status_topic(site_id, device_id, "device/uninstall")
    return mqtt_client.publish(
        topic,
        {"correlation_id": correlation_id, "status": "received"},
        qos=1,
    )


def _list_ovs_bridges() -> List[str]:
    try:
        result = subprocess.run(
            ["ovs-vsctl", "list-br"],
            check=False,
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        return [
            line.strip()
            for line in result.stdout.decode("utf-8", errors="replace").splitlines()
            if line.strip()
        ]
    except Exception:
        return []


def perform_uninstall(
    cmd: DeviceUninstallCommand,
    config_manager: ConfigManager,
    mqtt_client: MQTTClient,
    site_id: str,
    device_id: str,
) -> DeviceUninstallResponse:
    """Execute the uninstall plan and return a structured response.

    The caller owns response publishing and process termination. This
    separation keeps the orchestrator unit-testable without mocking MQTT.
    """
    rec = _StepRecorder()
    logger.info(
        "Uninstall starting: correlation_id=%s remove_bridges=%s "
        "remove_credentials=%s remove_agent_code=%s",
        cmd.correlation_id,
        cmd.remove_bridges,
        cmd.remove_credentials,
        cmd.remove_agent_code,
    )

    # Step 1 — early status ping (best-effort).
    rec.run(
        "early_status_ping",
        _publish_early_ping,
        mqtt_client,
        site_id,
        device_id,
        cmd.correlation_id,
    )

    # Step 2 — stop data-plane services.
    for svc in DATA_PLANE_SERVICES:
        rec.run(f"stop_service:{svc}", _stop_service, svc)

    # Step 3 — OVS teardown (only if remove_bridges).
    if cmd.remove_bridges:
        bridge_configs = {}
        try:
            bridge_configs = config_manager.get_all_bridge_configs() or {}
        except Exception:
            logger.exception("Failed to read bridge configs")
            rec.failed.append("read_bridge_configs")
        for bridge_name in list(bridge_configs.keys()):
            def _del(name=bridge_name):
                ok, msg = delete_bridge_and_cleanup(name, config_manager)
                if not ok:
                    raise RuntimeError(msg)
                return True
            rec.run(f"delete_bridge:{bridge_name}", _del)

        # Log (don't touch) stragglers — bridges that exist in OVS but
        # we don't own.
        our_names = set(bridge_configs.keys())
        for br in _list_ovs_bridges():
            if br not in our_names:
                logger.info(f"Leaving straggler OVS bridge in place: {br}")

    # Step 4 — stop axon-agent-ovs (after bridge teardown).
    rec.run(
        "stop_service:axon-agent-ovs.service",
        _stop_service,
        "axon-agent-ovs.service",
    )

    # Step 5 — systemd unit cleanup.
    #   Order: disable adjuncts → unmask CE classifier units →
    #   (terminal only) disable + rm EE/CE unit files →
    #   rm OVS drop-in → daemon-reload.
    for svc in ADJUNCT_DISABLE_UNITS:
        rec.run(f"systemctl_disable:{svc}", _disable_service, svc)

    rec.run(
        "unmask_ce_classifier",
        _unmask_service,
        "axon-agent-classifier.service",
    )
    rec.run(
        "unmask_ce_classifier_flow_stats",
        _unmask_service,
        "axon-agent-classifier-flow-stats.service",
    )

    if cmd.remove_agent_code:
        for svc in TERMINAL_DISABLE_UNITS:
            rec.run(f"systemctl_disable:{svc}", _disable_service, svc)
        for unit_path in TERMINAL_UNIT_FILES:
            rec.run(f"rm_unit:{os.path.basename(unit_path)}", _remove_file, unit_path)

    rec.run("rm_ovs_dropin", _remove_file, OVS_DROPIN_FILE)
    rec.run("rmdir_ovs_dropin", _rmdir_if_empty, OVS_DROPIN_DIR)

    rec.run("daemon_reload", lambda: _systemctl("daemon-reload") == 0 or True)

    # Step 6 — wipe credentials.
    if cmd.remove_credentials:
        for path in CREDENTIAL_FILES:
            rec.run(f"rm_cred:{os.path.basename(path)}", _remove_file, path)
        rec.run("wipe_var_lib_axon", _rmtree, VAR_LIB_AXON_DIR, True)
        rec.run("rmdir_etc_axon", _rmdir_if_empty, ETC_AXON_DIR)

    # Step 7 — remove code + venv (terminal mode only).
    #   After this returns, no further Python imports will resolve.
    #   The orchestrator and its imports are already in memory.
    if cmd.remove_agent_code:
        rec.run("rm_opt_axon_agent", _rmtree, OPT_AXON_AGENT_DIR, False)

    # Step 8 — final daemon-reload (post-file removal).
    rec.run("daemon_reload_final", lambda: _systemctl("daemon-reload") == 0 or True)

    # Determine overall status.
    if not rec.failed:
        status = DeviceUninstallResponse.STATUS_OK
        error_message = ""
    elif rec.completed:
        status = DeviceUninstallResponse.STATUS_PARTIAL
        error_message = "; ".join(rec.error_messages[:3])
    else:
        status = DeviceUninstallResponse.STATUS_FAILED
        error_message = "; ".join(rec.error_messages[:3]) or "no steps completed"

    response = DeviceUninstallResponse(
        correlation_id=cmd.correlation_id,
        status=status,
        completed_steps=rec.completed,
        failed_steps=rec.failed,
        error_message=error_message,
    )
    logger.info(
        "Uninstall finished: status=%s completed=%d failed=%d",
        DeviceUninstallResponse.Status.Name(status),
        len(rec.completed),
        len(rec.failed),
    )
    return response
