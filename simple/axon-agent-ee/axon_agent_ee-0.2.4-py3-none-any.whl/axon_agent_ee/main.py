"""EE Agent main entry point.

EEAxonAgent extends AxonAgent, adding:
  - EE companion services (EE classifier) to the service registry
  - subscription to the graceful-uninstall control topic during the
    runtime phase, dispatching to ``decommission.perform_uninstall``.

All other CE behavior (discovery, provisioning, MQTT, CE companion
services) is inherited unchanged.
"""

import logging
import os
import subprocess
import threading
import time
from typing import Optional, Set

from axon_agent.main import AxonAgent
from axon_shared.mqtt.topics import (
    DEVICE_UNINSTALL,
    DEVICE_UNINSTALL_RESPONSE,
    control_topic,
)
from axon_shared.proto.device_lifecycle_messages_pb2 import (
    DeviceUninstallCommand,
    DeviceUninstallResponse,
)

from axon_agent_ee import decommission
from axon_agent_ee.service_registry_ee import register_ee_services

logger = logging.getLogger(__name__)

# Fallback timeout after systemctl stop — if the process is somehow
# still alive this long after the stop command, force exit.
_TERMINAL_FALLBACK_SECONDS = 5.0


class EEAxonAgent(AxonAgent):
    """Enterprise Edition agent.

    Extends AxonAgent by registering EE companion services and
    subscribing to the graceful-uninstall MQTT topic during the runtime
    phase. super().__init__() calls register_ce_services(); we then add
    EE services.
    """

    def __init__(self):
        super().__init__()
        register_ee_services()
        # Idempotency + concurrency guards for uninstall commands.
        self._seen_uninstall_correlations: Set[str] = set()
        self._uninstall_lock = threading.Lock()
        self._uninstalling = False

    def _run_runtime_phase(self, config: dict) -> None:
        """Run CE runtime phase, then add EE-only subscriptions."""
        super()._run_runtime_phase(config)
        self._subscribe_uninstall(config)

    def _subscribe_uninstall(self, config: dict) -> None:
        site_id = config.get("network_id")
        device_id = config.get("device_id")
        if not site_id or not device_id:
            logger.error(
                "Cannot subscribe to uninstall topic: config missing "
                "network_id or device_id"
            )
            return

        topic = control_topic(site_id, device_id, DEVICE_UNINSTALL)

        def _callback(t: str, payload: bytes) -> None:
            self._handle_uninstall_command(payload, site_id, device_id)

        try:
            self.mqtt_client.subscribe_raw(topic, _callback, qos=2)
            logger.info(f"Subscribed to uninstall topic: {topic}")
        except Exception as e:
            logger.error(
                f"Failed to subscribe to uninstall topic {topic}: {e}",
                exc_info=True,
            )

    def _handle_uninstall_command(
        self, payload: bytes, site_id: str, device_id: str
    ) -> None:
        """Parse, gate, and dispatch an incoming uninstall command."""
        try:
            cmd = DeviceUninstallCommand()
            cmd.ParseFromString(payload)
        except Exception as e:
            logger.error(f"Failed to parse DeviceUninstallCommand: {e}")
            return

        corr_id = cmd.correlation_id or "<missing>"
        logger.info(
            "Uninstall command received: correlation_id=%s "
            "remove_bridges=%s remove_credentials=%s "
            "remove_agent_code=%s grace_seconds=%s",
            corr_id,
            cmd.remove_bridges,
            cmd.remove_credentials,
            cmd.remove_agent_code,
            cmd.grace_seconds,
        )

        with self._uninstall_lock:
            if not self.running:
                self._reply_failed(
                    cmd, site_id, device_id, "agent not in runtime phase"
                )
                return
            # Only dedup on real correlation IDs. proto3 defaults an absent
            # string field to "", and stashing that empty sentinel in the
            # dedup set would cause every subsequent command without a
            # correlation_id to be suppressed for the life of the process.
            if (
                cmd.correlation_id
                and cmd.correlation_id in self._seen_uninstall_correlations
            ):
                logger.info(
                    f"Duplicate uninstall correlation_id {corr_id}, ignoring"
                )
                return
            if self._uninstalling:
                logger.info(
                    "Uninstall already in progress, ignoring additional command"
                )
                return
            if cmd.correlation_id:
                self._seen_uninstall_correlations.add(cmd.correlation_id)
            self._uninstalling = True

        # Paho callback runs on the network thread — never block it.
        threading.Thread(
            target=self._run_uninstall_worker,
            args=(cmd, site_id, device_id),
            daemon=True,
            name="axon-ee-uninstall",
        ).start()

    def _run_uninstall_worker(
        self, cmd: DeviceUninstallCommand, site_id: str, device_id: str
    ) -> None:
        """Teardown on a background thread, publish response, schedule exit."""
        try:
            response = decommission.perform_uninstall(
                cmd, self.config_manager, self.mqtt_client, site_id, device_id
            )
        except Exception as e:
            logger.exception("Uninstall orchestrator crashed")
            response = DeviceUninstallResponse(
                correlation_id=cmd.correlation_id,
                status=DeviceUninstallResponse.STATUS_FAILED,
                error_message=f"orchestrator exception: {e}",
            )

        response_topic = control_topic(
            site_id, device_id, DEVICE_UNINSTALL_RESPONSE
        )
        payload = response.SerializeToString()
        try:
            published = self.mqtt_client.publish_raw_blocking(
                response_topic, payload, qos=2, timeout=5.0
            )
            if not published:
                logger.error(
                    "Failed to publish uninstall response within timeout; "
                    "proceeding with termination anyway"
                )
        except Exception:
            logger.exception("Exception publishing uninstall response")

        grace = cmd.grace_seconds if cmd.grace_seconds > 0 else 5

        if cmd.remove_agent_code:
            threading.Timer(
                grace, self._terminate_final
            ).start()
        else:
            threading.Timer(
                grace, self._terminate_restart
            ).start()

    @staticmethod
    def _terminate_final() -> None:
        """Terminal mode — stop the unit (no restart) then os._exit as fallback."""
        logger.info("Terminating: systemctl stop axon-agent-ee.service")
        try:
            subprocess.Popen(
                ["systemctl", "stop", "axon-agent-ee.service"]
            )
        except Exception:
            logger.exception("systemctl stop failed; falling through to os._exit")
        time.sleep(_TERMINAL_FALLBACK_SECONDS)
        logger.warning(
            "systemctl stop did not terminate us within %ss; os._exit(0)",
            _TERMINAL_FALLBACK_SECONDS,
        )
        os._exit(0)

    @staticmethod
    def _terminate_restart() -> None:
        """Re-enrollment mode — plain exit so Restart=always resurrects us."""
        logger.info("Exiting; systemd Restart=always will re-launch into discovery")
        os._exit(0)

    def _reply_failed(
        self,
        cmd: DeviceUninstallCommand,
        site_id: str,
        device_id: str,
        msg: str,
    ) -> None:
        """Publish an immediate STATUS_FAILED response and return."""
        logger.warning(f"Rejecting uninstall: {msg}")
        response = DeviceUninstallResponse(
            correlation_id=cmd.correlation_id,
            status=DeviceUninstallResponse.STATUS_FAILED,
            error_message=msg,
        )
        topic = control_topic(site_id, device_id, DEVICE_UNINSTALL_RESPONSE)
        try:
            self.mqtt_client.publish_raw(
                topic, response.SerializeToString(), qos=2
            )
        except Exception:
            logger.exception("Failed to publish uninstall rejection response")


def main() -> Optional[int]:
    """Entry point for axon-agent-ee."""
    from axon_agent.base_agent import setup_logging

    setup_logging("axon-agent-ee")
    agent = EEAxonAgent()
    agent.run()
    return None


if __name__ == "__main__":
    main()
