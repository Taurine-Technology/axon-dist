"""Geolocation resolver for switch public IP.

Resolves the switch's public IP to geographic coordinates and region
using free HTTP APIs. Results are cached to disk with a configurable TTL
to avoid repeated lookups.
"""

import json
import logging
import os
import time
import urllib.request
from dataclasses import asdict, dataclass

logger = logging.getLogger(__name__)


@dataclass
class GeoInfo:
    """Geographic location information for a switch."""

    region: str = ""
    country_code: str = ""
    latitude: float = 0.0
    longitude: float = 0.0
    public_ip: str = ""


class GeoResolver:
    """Resolves and caches switch geolocation from public IP.

    Uses ipinfo.io as the primary provider with ipify + ip-api.com
    as fallback. Caches results to disk with a configurable TTL.
    """

    def __init__(self, cache_path: str, cache_ttl_hours: int = 24):
        self._cache_path = cache_path
        self._ttl_seconds = cache_ttl_hours * 3600

    def resolve(self) -> GeoInfo:
        """Get geolocation info. Returns cached if valid, otherwise fetches."""
        cached = self._load_cache()
        if cached is not None:
            logger.info(
                f"Using cached geolocation: {cached.country_code} "
                f"({cached.region})"
            )
            return cached
        try:
            info = self._fetch()
            self._save_cache(info)
            return info
        except Exception as e:
            logger.warning(f"Geolocation resolution failed: {e}")
            return GeoInfo()

    def _fetch(self) -> GeoInfo:
        """Fetch geolocation from HTTP APIs.

        Primary: ipinfo.io/json (returns ip, region, country, loc)
        Fallback: api.ipify.org + ip-api.com/json/{ip}
        """
        # Primary provider: ipinfo.io
        try:
            req = urllib.request.Request(
                "https://ipinfo.io/json",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            lat_str, lon_str = data.get("loc", "0,0").split(",")
            info = GeoInfo(
                region=data.get("region", ""),
                country_code=data.get("country", ""),
                latitude=float(lat_str),
                longitude=float(lon_str),
                public_ip=data.get("ip", ""),
            )
            logger.info(
                f"Resolved geolocation via ipinfo.io: "
                f"{info.country_code} ({info.region})"
            )
            return info
        except Exception as e:
            logger.debug(f"ipinfo.io failed: {e}, trying fallback")

        # Fallback: ipify for IP, then ip-api.com for geo
        with urllib.request.urlopen(
            "https://api.ipify.org", timeout=10
        ) as resp:
            ip = resp.read().decode().strip()

        with urllib.request.urlopen(
            f"http://ip-api.com/json/{ip}", timeout=10
        ) as resp:
            data = json.loads(resp.read())

        info = GeoInfo(
            region=data.get("regionName", ""),
            country_code=data.get("countryCode", ""),
            latitude=float(data.get("lat", 0)),
            longitude=float(data.get("lon", 0)),
            public_ip=ip,
        )
        logger.info(
            f"Resolved geolocation via ip-api.com: "
            f"{info.country_code} ({info.region})"
        )
        return info

    def _load_cache(self) -> GeoInfo | None:
        """Load cached geolocation if it exists and hasn't expired."""
        if not os.path.exists(self._cache_path):
            return None
        try:
            with open(self._cache_path) as f:
                data = json.load(f)
            cached_at = data.pop("_timestamp", 0)
            if time.time() - cached_at > self._ttl_seconds:
                logger.debug("Geo cache expired")
                return None
            return GeoInfo(**data)
        except Exception as e:
            logger.debug(f"Failed to load geo cache: {e}")
            return None

    def _save_cache(self, info: GeoInfo):
        """Save geolocation to disk cache with timestamp."""
        try:
            cache_dir = os.path.dirname(self._cache_path)
            if cache_dir:
                os.makedirs(cache_dir, exist_ok=True)
            data = asdict(info)
            data["_timestamp"] = time.time()
            with open(self._cache_path, "w") as f:
                json.dump(data, f)
            logger.debug(f"Saved geo cache to {self._cache_path}")
        except Exception as e:
            logger.warning(f"Failed to save geo cache: {e}")
